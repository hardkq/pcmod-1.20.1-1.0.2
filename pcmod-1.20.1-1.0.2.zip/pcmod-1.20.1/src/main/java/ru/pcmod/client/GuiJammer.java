package ru.pcmod.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import ru.pcmod.common.ContainerJammer;
import ru.pcmod.common.TileJammer;

/** Окно глушилки: ползунок радиуса 16–128, индикатор FE/tick, шкала энергии, кнопка вкл/выкл. */
public class GuiJammer extends AbstractContainerScreen<ContainerJammer> {
    private static final int SPAN = TileJammer.MAX_RADIUS - TileJammer.MIN_RADIUS;
    private final ContainerJammer cj;
    private Button power;
    private int sent = -1;

    public GuiJammer(ContainerJammer c, Inventory inv, Component title) {
        super(c, inv, title);
        this.cj = c;
        this.imageWidth = 200;
        this.imageHeight = 112;
    }

    private final class RadiusSlider extends AbstractSliderButton {
        RadiusSlider(int x, int y, int w, int h, int r) {
            super(x, y, w, h, Component.empty(), (r - TileJammer.MIN_RADIUS) / (double) SPAN);
            updateMessage();
        }
        int radius() { return TileJammer.MIN_RADIUS + (int) Math.round(value * SPAN); }
        @Override protected void updateMessage() { setMessage(Component.translatable("gui.pcmod.jammer.radius", radius())); }
        @Override protected void applyValue() {
            int r = radius();
            if (r != sent) { sent = r; press(100 + r); }
        }
    }

    @Override
    protected void init() {
        super.init();
        int r = Math.max(TileJammer.MIN_RADIUS, Math.min(TileJammer.MAX_RADIUS, cj.d[ContainerJammer.RADIUS]));
        sent = r;
        addRenderableWidget(new RadiusSlider(leftPos + 10, topPos + 20, 180, 20, r));
        power = addRenderableWidget(Button.builder(Component.empty(), b -> press(0))
                .bounds(leftPos + 10, topPos + 84, 85, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.pcmod.close"), b -> onClose())
                .bounds(leftPos + 105, topPos + 84, 85, 20).build());
    }

    /** Кнопки идут на сервер как clickMenuButton. */
    private void press(int id) { minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void containerTick() {
        super.containerTick();
        if (power != null) power.setMessage(Component.translatable(cj.d[ContainerJammer.ENABLED] != 0 ? "gui.pcmod.jammer.on" : "gui.pcmod.jammer.off"));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        g.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xFFC6C6C6);
        int bx = leftPos + 10, by = topPos + 66, bw = 180;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 11, 0xFF373737);
        g.fill(bx, by, bx + bw, by + 10, 0xFF8B8B8B);
        int fill = bw * Math.min(cj.d[ContainerJammer.ENERGY], TileJammer.CAPACITY) / TileJammer.CAPACITY;
        g.fill(bx, by, bx + fill, by + 10, 0xFFC03030);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
        int[] d = cj.d;
        boolean act = d[ContainerJammer.ACTIVE] != 0;
        g.drawString(font, Component.translatable("block.pcmod.jammer"), 8, 6, 0x404040, false);
        g.drawString(font, Component.translatable("gui.pcmod.jammer.cost", TileJammer.cost(d[ContainerJammer.RADIUS])), 10, 46, 0x404040, false);
        g.drawString(font, Component.translatable(act ? "gui.pcmod.jammer.working" : "gui.pcmod.jammer.idle"), 10, 56, act ? 0x207020 : 0x802020, false);
        g.drawString(font, d[ContainerJammer.ENERGY] + " / " + TileJammer.CAPACITY + " FE", 12, 68, 0xFFFFFF, true);
    }
}
