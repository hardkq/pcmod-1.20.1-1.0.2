package ru.pcmod.client;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import ru.pcmod.common.ContainerPhoneTable;
import ru.pcmod.common.PartSpec;
import ru.pcmod.common.PhoneParts;

/** Окно стола сборки телефонов: слоты деталей, проверка совместимости (та же PhoneParts.check, что и на сервере), кнопка «Собрать». */
public class GuiPhoneTable extends AbstractContainerScreen<ContainerPhoneTable> {
    private final ContainerPhoneTable cm;
    private Button assemble;
    private List<Component> errs = List.of();

    public GuiPhoneTable(ContainerPhoneTable c, Inventory inv, Component title) {
        super(c, inv, title);
        this.cm = c;
        this.imageWidth = 200;
        this.imageHeight = ContainerPhoneTable.HEIGHT;
    }

    @Override
    protected void init() {
        super.init();
        assemble = addRenderableWidget(Button.builder(Component.translatable("gui.pcmod.phone.assemble"), b -> minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 0))
                .bounds(leftPos + 125, topPos + 90, 65, 20).build());
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void containerTick() {
        super.containerTick();
        errs = PhoneParts.check(cm.table);
        if (assemble != null) assemble.active = errs.isEmpty() && cm.table.getItem(PhoneParts.OUT).isEmpty();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        renderTooltip(g, mx, my);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        g.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xFFC6C6C6);
        for (Slot s : menu.slots) {
            int sx = leftPos + s.x, sy = topPos + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            g.fill(sx, sy, sx + 16, sy + 16, s == menu.slots.get(PhoneParts.OUT) ? 0xFF6B8B6B : 0xFF8B8B8B);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
        g.drawString(font, title, 8, 6, 0x404040, false);
        for (int i = 0; i < PhoneParts.IN; i++) {
            if (i == PhoneParts.RAM2) continue;
            g.drawString(font, Component.translatable("gui.pcmod.phone.slot." + PhoneParts.KEY[i]), ContainerPhoneTable.X[i], ContainerPhoneTable.Y[i] - 10, 0x404040, false);
        }
        g.drawString(font, Component.translatable("gui.pcmod.phone.slot.out"), ContainerPhoneTable.X[PhoneParts.OUT], ContainerPhoneTable.Y[PhoneParts.OUT] - 10, 0x404040, false);
        if (errs.isEmpty()) g.drawString(font, Component.translatable("gui.pcmod.phone.ok"), 10, 92, 0x207020, false);
        for (int i = 0; i < errs.size() && i < 3; i++)
            g.drawString(font, font.plainSubstrByWidth(errs.get(i).getString(), 112), 10, 92 + i * 10, 0x802020, false);
        g.drawString(font, summary(), 10, 124, 0x404040, false);
        g.drawString(font, Component.translatable("gui.pcmod.phone.inventory"), ContainerPhoneTable.INV_X, 140, 0x404040, false);
    }

    /** Итог по установленным деталям: ядра/ГГц, ОЗУ, накопитель, аккумулятор, экран. */
    private String summary() {
        StringBuilder sb = new StringBuilder();
        PartSpec soc = PhoneParts.spec(cm.table.getItem(PhoneParts.SOC)), rom = PhoneParts.spec(cm.table.getItem(PhoneParts.ROM)),
                 bat = PhoneParts.spec(cm.table.getItem(PhoneParts.BATT)), scr = PhoneParts.spec(cm.table.getItem(PhoneParts.SCREEN));
        int ram = 0;
        for (int i : new int[]{PhoneParts.RAM1, PhoneParts.RAM2}) { PartSpec r = PhoneParts.spec(cm.table.getItem(i)); if (r != null) ram += r.memMB / 1024; }
        if (soc != null) sb.append(soc.cores).append("c ").append(soc.ghz).append("GHz ");
        if (ram > 0) sb.append(ram).append("GB ");
        if (rom != null) sb.append(rom.gb).append("GB ");
        if (bat != null) sb.append(bat.mah).append("mAh ");
        if (scr != null) sb.append(scr.resX).append("x").append(scr.resY);
        return font.plainSubstrByWidth(sb.toString(), 180);
    }
}
