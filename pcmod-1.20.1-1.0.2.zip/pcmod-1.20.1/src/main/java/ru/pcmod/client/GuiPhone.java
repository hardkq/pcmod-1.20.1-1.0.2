package ru.pcmod.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import ru.pcmod.PCMod;
import ru.pcmod.common.ContainerPhone;
import ru.pcmod.common.PacketPhoneTouch;
import ru.pcmod.common.PhoneClient;
import ru.pcmod.common.PixelScreen;

/** Экран телефона: вертикальный пиксельный экран 180x320 (PixelScreen в портретном режиме) в рамке, касания мышью, кнопка питания. */
public class GuiPhone extends AbstractContainerScreen<ContainerPhone> {
    private static final long TEX_KEY = 0x7F00_0000_0000_0001L;
    private static final int BEZEL = 7;
    private float scale = 1f;
    private int sx, sy;
    private boolean dragging;
    private int lastX = -1, lastY = -1;

    public GuiPhone(ContainerPhone c, Inventory inv, Component title) {
        super(c, inv, title);
    }

    @Override
    protected void init() {
        super.init();
        scale = Math.max(0.5f, Math.min(2f, (height - 2 * BEZEL - 8) / (float) PixelScreen.PH));
        sx = Math.round((width - PixelScreen.PW * scale) / 2f);
        sy = Math.round((height - PixelScreen.PH * scale) / 2f);
        addRenderableWidget(Button.builder(Component.translatable("gui.pcmod.phone.power"),
            b -> PCMod.NET.sendToServer(new PacketPhoneTouch(3, 0, 0)))
            .bounds(sx + Math.round(PixelScreen.PW * scale) + BEZEL + 6, sy + 40, 50, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int w = Math.round(PixelScreen.PW * scale), h = Math.round(PixelScreen.PH * scale);
        g.fill(sx - BEZEL, sy - BEZEL, sx + w + BEZEL, sy + h + BEZEL, 0xFF15171C);
        g.fill(sx - BEZEL + 1, sy - BEZEL + 1, sx + w + BEZEL - 1, sy + h + BEZEL - 1, 0xFF2A2D35);
        g.fill(sx - 1, sy - 1, sx + w + 1, sy + h + 1, 0xFF000000);
        ResourceLocation rl = PixelTextures.get(PhoneClient.PIX, TEX_KEY);
        if (rl != null) {
            g.pose().pushPose();
            g.pose().translate(sx, sy, 0f);
            g.pose().scale(scale, scale, 1f);
            g.blit(rl, 0, 0, 0f, 0f, PixelScreen.PW, PixelScreen.PH, PixelScreen.PW, PixelScreen.PH);
            g.pose().popPose();
        }
        PixelTextures.sweep();
        super.render(g, mx, my, pt);
    }

    @Override protected void renderBg(GuiGraphics g, float pt, int mx, int my) { }
    @Override protected void renderLabels(GuiGraphics g, int mx, int my) { }

    private int px(double mx) { return (int) Math.floor((mx - sx) / scale); }
    private int py(double my) { return (int) Math.floor((my - sy) / scale); }
    private boolean inside(int x, int y) { return x >= 0 && y >= 0 && x < PixelScreen.PW && y < PixelScreen.PH; }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = px(mx), y = py(my);
        if (button == 0 && inside(x, y)) {
            dragging = true;
            lastX = x; lastY = y;
            PCMod.NET.sendToServer(new PacketPhoneTouch(0, x, y));
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging && button == 0) {
            int x = Math.max(0, Math.min(PixelScreen.PW - 1, px(mx))), y = Math.max(0, Math.min(PixelScreen.PH - 1, py(my)));
            if (x != lastX || y != lastY) {
                lastX = x; lastY = y;
                PCMod.NET.sendToServer(new PacketPhoneTouch(2, x, y));
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging && button == 0) {
            dragging = false;
            PCMod.NET.sendToServer(new PacketPhoneTouch(1, Math.max(0, Math.min(PixelScreen.PW - 1, px(mx))), Math.max(0, Math.min(PixelScreen.PH - 1, py(my)))));
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }
}
