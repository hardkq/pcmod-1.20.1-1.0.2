package ru.pcmod.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import ru.pcmod.common.ContainerGenerator;
import ru.pcmod.common.TileGenerator;

/** Окно генератора: слот топлива, пламя горения, шкала энергии и текущая выработка. */
public class GuiGenerator extends AbstractContainerScreen<ContainerGenerator> {
    private final ContainerGenerator cg;

    public GuiGenerator(ContainerGenerator c, Inventory inv, Component title) {
        super(c, inv, title);
        this.cg = c;
        this.imageWidth = 200;
        this.imageHeight = ContainerGenerator.HEIGHT;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        renderTooltip(g, mx, my);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        g.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xFFC6C6C6);
        for (Slot s : menu.slots) {
            int sx = leftPos + s.x, sy = topPos + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }
        // пламя: высота по остатку горения
        int fx = leftPos + ContainerGenerator.FUEL_X + 2, fy = topPos + ContainerGenerator.FUEL_Y - 18;
        g.fill(fx - 1, fy - 1, fx + 13, fy + 15, 0xFF373737);
        g.fill(fx, fy, fx + 12, fy + 14, 0xFF8B8B8B);
        int tot = cg.d[ContainerGenerator.TOTAL], b = cg.d[ContainerGenerator.BURN];
        if (tot > 0 && b > 0) {
            int h = Math.max(1, 14 * b / tot);
            g.fill(fx, fy + 14 - h, fx + 12, fy + 14, 0xFFF08020);
        }
        // шкала энергии
        int bx = leftPos + 70, by = topPos + 54, bw = 120;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 11, 0xFF373737);
        g.fill(bx, by, bx + bw, by + 10, 0xFF8B8B8B);
        int fill = bw * Math.min(cg.d[ContainerGenerator.ENERGY], TileGenerator.CAPACITY) / TileGenerator.CAPACITY;
        g.fill(bx, by, bx + fill, by + 10, 0xFFC03030);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
        boolean act = cg.d[ContainerGenerator.ACTIVE] != 0;
        g.drawString(font, Component.translatable("block.pcmod.generator"), 8, 6, 0x404040, false);
        g.drawString(font, Component.translatable("gui.pcmod.generator.output", TileGenerator.GEN), 8, 18, 0x404040, false);
        g.drawString(font, Component.translatable(act ? "gui.pcmod.generator.working" : "gui.pcmod.generator.idle"), 8, 30, act ? 0x207020 : 0x802020, false);
        g.drawString(font, Component.translatable("gui.pcmod.generator.fuel"), ContainerGenerator.FUEL_X - 8, ContainerGenerator.FUEL_Y + 20, 0x404040, false);
        g.drawString(font, cg.d[ContainerGenerator.ENERGY] + " / " + TileGenerator.CAPACITY + " FE", 74, 55, 0xFFFFFF, true);
        g.drawString(font, Component.translatable("gui.pcmod.generator.inventory"), ContainerGenerator.INV_X, 80, 0x404040, false);
    }
}
