package ru.pcmod.client;

import com.mojang.blaze3d.platform.NativeImage;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import ru.pcmod.common.PixelScreen;
import ru.pcmod.common.TileComputer;

/**
 * Динамические текстуры 320x180 для пиксельных экранов: по одной на ПК, общая для GUI монитора и для всех мониторов в мире
 * (в том числе подключённых видеокабелями). Загружается в видеопамять только при изменении PixelScreen.version.
 * Неиспользуемые текстуры освобождаются через 10 секунд. Только поток рендера.
 */
public final class PixelTextures {
    private static final long UNUSED_MS = 10_000L, SWEEP_MS = 3_000L;

    private static final class Entry {
        DynamicTexture tex;
        ResourceLocation rl;
        int version = -1;
        long used;
    }

    private static final Map<Long, Entry> MAP = new HashMap<>();
    private static long lastSweep;

    private PixelTextures() {}

    /** Текстура экрана ПК (обновлённая до текущего кадра) или null, если пиксельного экрана нет. */
    public static ResourceLocation get(TileComputer t) {
        return get(t.pix, t.getBlockPos().asLong());
    }

    /** Текстура любого PixelScreen (в том числе портретного экрана телефона) под своим ключом. */
    public static ResourceLocation get(PixelScreen ps, long key) {
        if (ps == null) return null;
        long now = System.currentTimeMillis();
        Entry e = MAP.get(key);
        if (e == null) {
            e = new Entry();
            e.tex = new DynamicTexture(new NativeImage(NativeImage.Format.RGBA, ps.fw, ps.fh, false));
            e.rl = new ResourceLocation("pcmod", "pixscreen/" + Long.toHexString(key).replace('-', 'm'));
            Minecraft.getInstance().getTextureManager().register(e.rl, e.tex);
            MAP.put(key, e);
        }
        e.used = now;
        if (e.version != ps.version) {
            NativeImage img = e.tex.getPixels();
            if (img != null) {
                int[] px = ps.px;
                for (int y = 0; y < ps.fh; y++) {
                    int o = y * ps.fw;
                    for (int x = 0; x < ps.fw; x++) {
                        int c = px[o + x];
                        // NativeImage хранит ABGR
                        img.setPixelRGBA(x, y, 0xFF000000 | (c & 0xFF) << 16 | (c & 0xFF00) | (c >> 16) & 0xFF);
                    }
                }
                e.tex.upload();
            }
            e.version = ps.version;
        }
        return e.rl;
    }

    /** Освободить давно не используемые текстуры (вызывать из рендера). */
    public static void sweep() {
        long now = System.currentTimeMillis();
        if (now - lastSweep < SWEEP_MS || MAP.isEmpty()) return;
        lastSweep = now;
        Iterator<Map.Entry<Long, Entry>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Entry e = it.next().getValue();
            if (now - e.used > UNUSED_MS) {
                Minecraft.getInstance().getTextureManager().release(e.rl);
                PcRenderTypes.forget(e.rl);
                it.remove();
            }
        }
    }
}
