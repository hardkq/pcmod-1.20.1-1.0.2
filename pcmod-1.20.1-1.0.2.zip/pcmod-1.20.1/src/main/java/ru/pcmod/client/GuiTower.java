package ru.pcmod.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import ru.pcmod.common.ContainerTower;
import ru.pcmod.common.TileTower;

/** Окно вышки: статус, оператор, радиус покрытия, абоненты онлайн. */
public class GuiTower extends AbstractContainerScreen<ContainerTower> {
    private final TileTower te;

    public GuiTower(ContainerTower c, Inventory inv, Component title) {
        super(c, inv, title);
        this.te = c.tower;
        this.imageWidth = 200;
        this.imageHeight = 100;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.translatable("gui.pcmod.close"), b -> onClose())
                .bounds(leftPos + 60, topPos + 74, 80, 20).build());
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        g.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xFFC6C6C6);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
        boolean on = te.isActive;
        g.drawString(font, Component.translatable("block.pcmod.tower"), 8, 6, 0x404040, false);
        g.drawString(font, Component.translatable("gui.pcmod.tower.status",
                Component.translatable(on ? "gui.pcmod.tower.on" : "gui.pcmod.tower.off")), 10, 20, on ? 0x207020 : 0x802020, false);
        g.drawString(font, Component.translatable("gui.pcmod.tower.operator",
                te.operatorId.isEmpty() ? Component.translatable("gui.pcmod.tower.none") : Component.literal(te.operatorId)), 10, 32, 0x404040, false);
        g.drawString(font, Component.translatable("gui.pcmod.tower.radius", te.radius()), 10, 44, 0x404040, false);
        g.drawString(font, Component.translatable("gui.pcmod.tower.subs", te.subscribers), 10, 56, 0x404040, false);
    }
}
