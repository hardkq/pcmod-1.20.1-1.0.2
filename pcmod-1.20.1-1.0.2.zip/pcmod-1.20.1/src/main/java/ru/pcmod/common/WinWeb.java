package ru.pcmod.common;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Страницы внутриигрового интернета для браузера WinCraft 11 (адреса вида games.pc): встроенные сайты на языке разметки и сайты игроков. */
final class WinWeb {
    private WinWeb() {}

    /** Встроенные сайты: на них нельзя зарегистрироваться, путь после адреса игнорируется (кроме soft.pc). */
    static final Set<String> BUILTIN = new HashSet<String>(Arrays.asList(
            "home.pc", "games.pc", "av.pc", "news.pc", "help.pc", "phone.pc", "apps.pc", "soft.pc", "search.pc"));

    static boolean isBuiltin(String url) {
        int sl = url.indexOf('/');
        return BUILTIN.contains(sl < 0 ? url : url.substring(0, sl));
    }

    static String norm(String raw) {
        String u = raw.trim().toLowerCase();
        for (String p : new String[] {"pc://", "http://", "https://"}) if (u.startsWith(p)) u = u.substring(p.length());
        if (u.startsWith("www.")) u = u.substring(4);
        int sl = u.indexOf('/');
        String path = "";
        if (sl >= 0) {
            path = u.substring(sl + 1);
            u = u.substring(0, sl);
        }
        if (u.isEmpty()) u = "home.pc";
        if (u.indexOf('.') < 0) u += ".pc";
        if (BUILTIN.contains(u) && !u.equals("soft.pc") && !u.equals("search.pc")) return u;
        int e = path.indexOf('/');
        if (e >= 0) path = path.substring(0, e);
        path = path.replaceAll(u.equals("search.pc") ? "[^a-z0-9_а-яё-]" : "[^a-z0-9_-]", "");
        if (!path.isEmpty() && path.length() <= 24 && !path.equals("index")) return u + "/" + path;
        return u;
    }

    /** Адрес "name.pc/page" -> {домен, страница}. */
    static String[] split(String url) {
        int sl = url.indexOf('/');
        return sl < 0 ? new String[] {url, ""} : new String[] {url.substring(0, sl), url.substring(sl + 1)};
    }

    /** Текст как есть (без разбора разметки): строка с обратной косой чертой. */
    static String lit(String s) { return "\\" + s.replace('\n', ' '); }

    /** Встроенная страница из разметки (доверенный режим: действия dl:, buy:, inst:). */
    static List<WebRow> md(String src) { return Markup.parse(src, "", false, null, true).page.rows; }

    static List<WebRow> offline(WinHost h) {
        return md("# Нет подключения к сети\n\n{err}" + lit(h.netStatus()) + "\n\nПодключите кабель или Wi-Fi в приложении «Сеть».\n");
    }

    /** Любая страница: встроенный сайт или сайт игрока с сервера (503, 404 и блокировка - страницами ошибок). */
    static WebPage doc(String url, WinSvc s) {
        if (isBuiltin(url)) return WebPage.of(page(url, s));
        String[] a = split(url);
        return site(s.siteFetch(a[0], a[1]), true);
    }

    /** Страница сайта игрока по ответу сервера; ru - язык страниц ошибок. */
    static WebPage site(SiteHost.Resp r, boolean ru) {
        if (r.code == SiteHost.OK) {
            WebPage pg = Markup.parse(r.body, r.domain, false, null, false).page;
            pg.title = r.title;
            return SiteWidgets.expand(pg, r.domain, r.x, ru);
        }
        if (r.code == SiteHost.PAYWALL) return SiteWidgets.paywall(r, ru);
        String home = "\n=> home.pc " + (ru ? "На начальную страницу" : "Home") + "\n";
        String src;
        if (r.code == SiteHost.UNAVAILABLE)
            src = ru ? "# 503 - сервер недоступен\n{err}Хостинг сайтов не отвечает: сервер выключен, перегрет или недоступен.\nПопробуйте позже (F5)." + home
                    : "# 503 - server unavailable\n{err}Site hosting is not responding: the server is off, overheated or unreachable.\nTry again later." + home;
        else if (r.code == SiteHost.BLOCKED)
            src = (ru ? "# Сайт заблокирован\n{err}Сайт нарушает правила сети." : "# Site blocked\n{err}This site violates network rules.")
                    + (r.note.isEmpty() ? "" : "\n{dim}" + lit((ru ? "Причина: " : "Reason: ") + r.note)) + home;
        else if (r.code == SiteHost.NO_NET)
            src = ru ? "# Нет подключения к сети\n{err}Подключите кабель или Wi-Fi." + home : "# No network connection\n{err}Connect a cable or Wi-Fi." + home;
        else {
            String d = r.domain.length() > 30 ? r.domain.substring(0, 30) : r.domain;
            src = ru ? "# 404 - сайт не найден\n{err}" + lit("По адресу " + d + (r.page.isEmpty() || r.page.equals("index") ? "" : "/" + r.page) + " в этой сети ничего нет.") + home
                    : "# 404 - site not found\n{err}" + lit("Nothing at " + d + (r.page.isEmpty() || r.page.equals("index") ? "" : "/" + r.page) + " in this network.") + home;
        }
        return Markup.parse(src, "", false, null, true).page;
    }

    private static String install(boolean has, String doneText, String dlName, String id) {
        return has ? "{dim}" + doneText + "\n" : ">> dl:" + id + " Скачать " + dlName + "\n";
    }

    static List<WebRow> page(String url, WinSvc s) {
        String srv = s.server();
        int doomKb = s.dlSize(WinSvc.DL_DOOM) / 1024, avKb = s.dlSize(WinSvc.DL_AV) / 1024;
        if (url.equals("soft.pc") || url.startsWith("soft.pc/")) return SoftWeb.pc(url, s);
        if (url.equals("search.pc") || url.startsWith("search.pc/")) return SiteWidgets.searchRows(url, true, s::siteSearch);
        String home = "\n=> home.pc На начальную страницу\n";
        switch (url) {
            case "home.pc":
                return md("# PC-Net - начальная страница\n\nДобро пожаловать во внутриигровой интернет!\n{dim}Сайты этой сети:\n\n"
                        + "=> soft.pc Магазин программ  (soft.pc) - программы, игры, лицензии\n"
                        + "=> games.pc GameZone  (games.pc) - бесплатные игры\n"
                        + "=> news.pc PC-News  (news.pc) - новости сети\n"
                        + "=> av.pc SafeGuard  (av.pc) - антивирус\n"
                        + "=> help.pc Справка  (help.pc) - как скачать и установить\n"
                        + "=> phone.pc AndroStore  (phone.pc) - приложения для телефонов\n\n"
                        + "{dim}Введите адрес в строке сверху и нажмите Enter.\n");
            case "games.pc":
                return md("# GameZone - бесплатные игры\n{dim}Скачайте игру, установите её и играйте на своём ПК.\n\n"
                        + "# DOOM (шареварная версия, 3 уровня)\nДемоны, дробовик и множество взрывоопасных бочек.\nУстановщик: " + doomKb + " КБ.\n"
                        + install(s.installed(WinSvc.DL_DOOM), "Уже установлено: запустите из меню «Пуск».", s.dlName(WinSvc.DL_DOOM), "doom") + home);
            case "av.pc":
                return md("# SafeGuard Antivirus - бесплатно\n{dim}Находит неизвестные программы, пришедшие с других ПК.\n\nКак это работает:\n"
                        + "- Через 3 секунды после попадания чужого вируса появится предупреждение.\n"
                        + "- Удалить: ПК перезагрузится и очистится (до 11 с).\n"
                        + "- Подождать: угроза остаётся, значок антивируса краснеет.\nУстановщик: " + avKb + " КБ.\n"
                        + install(s.installed(WinSvc.DL_AV), "Уже установлено: значок антивируса на панели задач.", s.dlName(WinSvc.DL_AV), "av") + home);
            case "news.pc":
                return md("# PC-News\n\n- GameZone теперь раздаёт DOOM. Бесплатно. Правда.\n- Майнеры сообщают о рекордной прибыли (и горячих видеокартах).\n"
                        + "- Прогноз: солнечно, местами криперы.\n\n{dim}" + lit("Сервер вашей сети: " + (srv.isEmpty() ? "нет" : srv)) + "\n" + home);
            case "phone.pc":
                return md("# AndroStore - приложения для телефонов\n{dim}Каталог для ОС AndroCraft: Змейка, Кубики, Сапёр.\n\n"
                        + "Установка делается на самом телефоне: откройте «Приложения» или сайт apps.pc в браузере телефона.\n"
                        + "Платные приложения оплачиваются с того же банковского счёта (консы), что и покупки на ПК.\n"
                        + "Телефон подключается к той же Wi-Fi сети; сообщения чата общие с мессенджером ПК.\n" + home);
            case "help.pc":
                return md("# Справка - как получить DOOM\n1. Откройте GameZone (games.pc) и нажмите «Скачать».\n2. Файл появится в папке «Загрузки» (Проводник).\n"
                        + "3. Откройте " + s.dlName(WinSvc.DL_DOOM) + " и нажмите «Установить».\n4. Запустите DOOM из меню «Пуск».\n\n"
                        + "{dim}Удаление: удалите /games/doom/doom.wad в Проводнике.\n{dim}По Wi-Fi загрузка идёт медленнее, чем по кабелю.\n" + home);
            default:
                return site(SiteHost.Resp.err(SiteHost.NOT_FOUND, url, "", ""), true).rows;
        }
    }
}
