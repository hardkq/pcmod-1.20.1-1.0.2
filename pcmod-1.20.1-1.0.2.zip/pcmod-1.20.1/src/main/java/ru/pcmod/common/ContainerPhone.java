package ru.pcmod.common;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;

/** Пустое меню экрана телефона (слотов нет): держит рука с телефоном, при закрытии завершает серверную сессию PhoneSession. */
public class ContainerPhone extends AbstractContainerMenu {
    public final InteractionHand hand;

    public ContainerPhone(int id, Inventory inv, InteractionHand hand) {
        super(ModMenus.PHONE.get(), id);
        this.hand = hand;
    }

    public ContainerPhone(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, buf.readBoolean() ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
    }

    @Override
    public boolean stillValid(Player p) {
        return p.getItemInHand(hand).getItem() instanceof ItemPhone;
    }

    @Override
    public void removed(Player p) {
        super.removed(p);
        if (!p.level().isClientSide) PhoneSession.close(p);
    }

    @Override
    public ItemStack quickMoveStack(Player p, int idx) { return ItemStack.EMPTY; }
}
