package ru.pcmod.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

/**
 * Панель задач WinCraft 11: «Пуск», поиск и значки приложений по центру (закреплённые и запущенные,
 * индикаторы окон), трей (скрытые значки, сеть, звук), часы с датой, уведомления, «показать рабочий стол».
 * Все методы ввода возвращают область {x, y, w, h}, которую надо перерисовать (null - ничего).
 */
public final class WinTaskbar {
    static final int W = PixelScreen.W, DOCK = WinWm.DOCK;
    private static final int START = 0, SEARCH = 1, APP = 2, CHEV = 3, SYS = 4, CLOCK = 5, BELL = 6, DESK = 7, TVIEW = 8, AV = 9;
    private static final int TIP_DELAY = 10;

    /** Связь панели с остальной системой. */
    public interface Env {
        long dayTime();

        /** NetLink.NONE, WIRED или WIFI. */
        int netType();

        /** Уровень сигнала Wi-Fi 0..4. */
        int netSignal();

        String userName();

        /** Действие кнопки питания в «Пуске»: 0 - заблокировать, 1 - перезагрузка, 2 - завершение работы. */
        void power(int action);

        /** Состояние антивируса: 0 - не установлен, 1 - защита включена, 2 - есть угрозы. */
        default int avState() { return 0; }

        /** Запустить приложение. */
        default void open(String appId) {}
    }

    /** Закреплённое приложение. */
    public static final class Pin {
        final String id, title;
        final int w, h;
        final Supplier<WinApp> make;

        public Pin(String id, String title, int w, int h, Supplier<WinApp> make) {
            this.id = id;
            this.title = title;
            this.w = w;
            this.h = h;
            this.make = make;
        }
    }

    private static final class Item {
        String id, title;
        Pin pin;
        final List<WinWm.Win> wins = new ArrayList<WinWm.Win>();
    }

    private static final class Cell {
        int kind, x, w;
        Item item;
    }

    private final WinWm wm;
    private final WinTheme th;
    private final boolean effects;
    private final Env env;
    private final List<Pin> pins = new ArrayList<Pin>();

    private String hoverKey, tipText = "";
    private long hoverSince, lastStamp = -1;
    private boolean tipPending, tipVisible;
    private int tipX, tipW, lastNet = -1, av;
    private WinUi.Menu menu;
    private Item menuItem;

    public WinTaskbar(WinWm wm, WinTheme th, boolean effects, Env env) {
        this.wm = wm;
        this.th = th;
        this.effects = effects;
        this.env = env;
    }

    public void pin(String id, String title, int w, int h, Supplier<WinApp> make) {
        pins.add(new Pin(id, title, w, h, make));
    }

    public boolean menuOpen() {
        return menu != null && menu.open;
    }

    static int[] barBox() {
        return new int[] {0, WinWm.workH(), W, DOCK};
    }

    // ================================================================== состав и раскладка
    private List<Item> items() {
        List<Item> r = new ArrayList<Item>();
        for (Pin p : pins) {
            Item it = new Item();
            it.id = p.id;
            it.title = p.title;
            it.pin = p;
            r.add(it);
        }
        List<WinWm.Win> ws = new ArrayList<WinWm.Win>(wm.windows());
        Collections.sort(ws, (a, b) -> a.seq - b.seq);
        for (WinWm.Win w : ws) {
            Item f = null;
            for (Item it : r) {
                if (it.id.equals(w.app.id())) {
                    f = it;
                    break;
                }
            }
            if (f == null) {
                f = new Item();
                f.id = w.app.id();
                f.title = w.app.title();
                r.add(f);
            }
            f.wins.add(w);
        }
        return r;
    }

    private String trayDate(long dt) {
        String d = WinClock.dateShort(dt, th.dateFmt);
        if (PixelScreen.textWidth(d) <= 52) return d;
        return th.dateFmt == 1 ? d.substring(2) : d.substring(0, 6) + d.substring(8);
    }

    private List<Cell> layout(List<Item> its) {
        List<Cell> c = new ArrayList<Cell>();
        long dt = env.dayTime();
        int cw = Math.max(PixelScreen.textWidth(WinClock.time(dt, th.h12)), PixelScreen.textWidth(trayDate(dt))) + 8;
        int x = W - 3;
        c.add(cell(DESK, x, 3, null));
        x -= 14;
        c.add(cell(BELL, x, 14, null));
        x -= cw;
        c.add(cell(CLOCK, x, cw, null));
        x -= 26;
        c.add(cell(SYS, x, 26, null));
        if (av > 0) {
            x -= 16;
            c.add(cell(AV, x, 16, null));
        }
        x -= 12;
        c.add(cell(CHEV, x, 12, null));
        int trayLeft = x;
        int n = 3 + its.size(), pitch = 20, avail = trayLeft - 4;
        if (n * pitch > avail) pitch = Math.max(14, avail / n);
        int total = n * pitch, sx = (W - total) / 2;
        if (sx + total > trayLeft - 2) sx = Math.max(2, trayLeft - 2 - total);
        c.add(cell(START, sx, pitch, null));
        c.add(cell(SEARCH, sx + pitch, pitch, null));
        c.add(cell(TVIEW, sx + 2 * pitch, pitch, null));
        for (int i = 0; i < its.size(); i++) c.add(cell(APP, sx + (i + 3) * pitch, pitch, its.get(i)));
        return c;
    }

    private static Cell cell(int kind, int x, int w, Item it) {
        Cell c = new Cell();
        c.kind = kind;
        c.x = x;
        c.w = w;
        c.item = it;
        return c;
    }

    private static Cell cellAt(List<Cell> cs, int mx) {
        for (Cell c : cs) if (mx >= c.x && mx < c.x + c.w) return c;
        return null;
    }

    private static String key(Cell c) {
        return c.kind == APP ? "a:" + c.item.id : "k:" + c.kind;
    }

    private static int[] cellBox(Cell c) {
        return new int[] {c.x - 1, WinWm.workH(), c.w + 2, DOCK};
    }

    /** Центр значка приложения на панели по x (куда сворачивается окно); середина панели, если значка нет. */
    int iconX(String id) {
        for (Cell c : layout(items())) if (c.kind == APP && c.item.id.equals(id)) return c.x + c.w / 2;
        return W / 2;
    }

    /** Указатель над кнопкой «Пуск» или «Поиск». */
    public boolean onStartButtons(int mx, int my) {
        if (my < WinWm.workH()) return false;
        Cell c = cellAt(layout(items()), mx);
        return c != null && (c.kind == START || c.kind == SEARCH);
    }

    private static int[] union(int[] a, int[] b) {
        return WinWm.union(a, b);
    }

    private String netText() {
        int t = env.netType();
        return t == NetLink.WIRED ? "Ethernet" : t == NetLink.WIFI ? "Wi-Fi" : "Нет подключения к сети";
    }

    private String tipFor(Cell c) {
        long dt = env.dayTime();
        switch (c.kind) {
            case START: return "Пуск";
            case SEARCH: return "Поиск";
            case TVIEW: return "Представление задач (Win+Tab)";
            case CHEV: return "Показать скрытые значки";
            case SYS: return netText();
            case CLOCK: return WinClock.dateLong(dt) + ", " + WinClock.time(dt, th.h12);
            case BELL: return "Уведомления";
            case DESK: return "Свернуть все окна";
            case AV: return av == 2 ? "Антивирус: найдены угрозы" : "Антивирус: защита включена";
            default:
                Item it = c.item;
                if (it.wins.size() == 1) return it.wins.get(0).app.title();
                if (it.wins.size() > 1) return it.title + " (" + it.wins.size() + ")";
                return it.title;
        }
    }

    // ================================================================== тик
    /** Раз в тик: часы, сеть, показ подсказки. Добавляет области перерисовки в out. */
    public void tick(long now, List<int[]> out) {
        if (now % 10 == 0 && WinClock.stamp(env.dayTime()) != lastStamp) out.add(barBox());
        if (now % 20 == 0) {
            int net = env.netType() * 8 + env.netSignal();
            if (net != lastNet) out.add(barBox());
            int a = env.avState();
            if (a != av) {
                av = a;
                out.add(barBox());
            }
        }
        if (tipPending && !tipVisible && hoverKey != null && now - hoverSince >= TIP_DELAY) {
            List<Item> its = items();
            for (Cell c : layout(its)) {
                if (key(c).equals(hoverKey)) {
                    showTip(c);
                    out.add(tipBox());
                    break;
                }
            }
        }
    }

    private void showTip(Cell c) {
        tipText = tipFor(c);
        tipW = PixelScreen.textWidth(tipText) + 12;
        tipX = Math.max(2, Math.min(W - tipW - 2, c.x + c.w / 2 - tipW / 2));
        tipVisible = true;
    }

    private int[] tipBox() {
        return new int[] {tipX - 8, WinWm.workH() - 28, tipW + 16, 30};
    }

    private int[] hideTip() {
        tipPending = false;
        if (!tipVisible) return null;
        tipVisible = false;
        return tipBox();
    }

    // ================================================================== ввод
    /** Мышь; onBar - указатель над панелью. */
    public int[] mouse(int mx, int my, int btn, int kind, long now, boolean onBar) {
        int[] dirty = null;
        List<Item> its = null;
        List<Cell> cs = null;
        Cell hc = null;
        if (onBar) {
            its = items();
            cs = layout(its);
            hc = cellAt(cs, mx);
        }
        String k = hc == null ? null : key(hc);
        if (k == null ? hoverKey != null : !k.equals(hoverKey)) {
            if (hoverKey != null) dirty = union(dirty, barBox());
            if (hc != null) dirty = union(dirty, cellBox(hc));
            dirty = union(dirty, hideTip());
            hoverKey = k;
            hoverSince = now;
            tipPending = hc != null;
        }
        if (onBar && hc != null && kind == PixelScreen.MOUSE_PRESS) {
            dirty = union(dirty, hideTip());
            if (btn == 0) dirty = union(dirty, click(hc));
            else if (btn == 1) dirty = union(dirty, context(hc));
        }
        return dirty;
    }

    private int[] click(Cell c) {
        switch (c.kind) {
            case START:
                return union(barBox(), wm.start.toggle(false));
            case SEARCH:
                return union(barBox(), wm.start.toggle(true));
            case TVIEW:
                return union(barBox(), wm.taskViewToggle());
            case DESK:
                return wm.showDesktop();
            case AV:
                env.open("av");
                return null;
            case APP:
                return clickItem(c.item);
            default:
                return null;
        }
    }

    private int[] clickItem(Item it) {
        List<WinWm.Win> g = it.wins;
        if (g.isEmpty()) {
            return it.pin == null ? null : wm.open(it.pin.make.get(), it.pin.w, it.pin.h);
        }
        if (g.size() == 1) return wm.activate(g.get(0));
        WinWm.Win f = wm.focused();
        if (f != null && g.contains(f)) return wm.activate(g.get((g.indexOf(f) + 1) % g.size()));
        List<WinWm.Win> z = wm.windows();
        for (int i = z.size() - 1; i >= 0; i--) if (g.contains(z.get(i))) return wm.activate(z.get(i));
        return null;
    }

    private int[] context(Cell c) {
        if (c.kind != APP) return null;
        Item it = c.item;
        String[] labels;
        if (it.wins.isEmpty()) labels = new String[] {"Открыть"};
        else if (it.wins.size() == 1) labels = new String[] {"Закрыть окно"};
        else labels = new String[] {"Закрыть окно", "Закрыть все окна (" + it.wins.size() + ")"};
        menu = new WinUi.Menu(labels);
        menu.openAt(c.x, WinWm.workH() - menu.h() - 4);
        menuItem = it;
        return menu.box();
    }

    /** Ввод, пока открыто меню значка: любое нажатие закрывает меню. */
    public int[] menuMouse(int mx, int my, int btn, int kind) {
        int it = menu.itemAt(mx, my), old = menu.hover;
        menu.hover = it;
        if (kind == PixelScreen.MOUSE_PRESS) {
            int[] d = menu.box();
            Item owner = menuItem;
            menu.open = false;
            menu = null;
            menuItem = null;
            if (it >= 0 && btn == 0) d = union(d, run(owner, it));
            return union(d, barBox());
        }
        return old != it ? menu.box() : null;
    }

    private int[] run(Item it, int index) {
        if (it.wins.isEmpty()) return clickItem(it);
        int[] d = null;
        if (index == 0) {
            List<WinWm.Win> z = wm.windows();
            for (int i = z.size() - 1; i >= 0; i--) {
                if (it.wins.contains(z.get(i))) {
                    return wm.closeWindow(z.get(i));
                }
            }
            return null;
        }
        for (WinWm.Win w : new ArrayList<WinWm.Win>(it.wins)) d = union(d, wm.closeWindow(w));
        return d;
    }

    // ================================================================== рисование
    public void paint(PixelScreen p) {
        List<Item> its = items();
        List<Cell> cs = layout(its);
        long dt = env.dayTime();
        lastStamp = WinClock.stamp(dt);
        lastNet = env.netType() * 8 + env.netSignal();
        int y = WinWm.workH();
        int base = th.bg();
        if (th.glass) WinGfx.mica(p, th, 0, y, W, DOCK, 0xC8);
        else p.fillRect(0, y, W, DOCK, base);
        p.hline(0, y, W, th.border());
        WinWm.Win f = wm.focused();
        for (Cell c : cs) {
            boolean hv = hoverKey != null && hoverKey.equals(key(c));
            int cx = c.x + c.w / 2, cy = y + 9;
            switch (c.kind) {
                case START:
                case SEARCH:
                case TVIEW:
                case APP: {
                    boolean active = c.kind == APP ? f != null && c.item.wins.contains(f)
                            : c.kind == TVIEW ? wm.taskViewOpen()
                            : wm.start.isOpen() && (c.kind == SEARCH) == wm.start.searchMode();
                    if (active) p.roundRect(c.x + 1, y + 2, c.w - 2, DOCK - 4, 4, th.dark ? 0x26FFFFFF : 0xB0FFFFFF);
                    if (hv) p.roundRect(c.x + 1, y + 2, c.w - 2, DOCK - 4, 4, th.hover());
                    if (c.kind == START) icon(p, "start", cx, cy);
                    else if (c.kind == SEARCH) icon(p, "search", cx, cy);
                    else if (c.kind == TVIEW) icon(p, "taskview", cx, cy);
                    else {
                        icon(p, c.item.id, cx, cy);
                        if (!c.item.wins.isEmpty()) {
                            if (active) p.roundRect(cx - 4, y + DOCK - 3, 8, 2, 1, th.accent());
                            else p.roundRect(cx - 2, y + DOCK - 3, 4, 2, 1, th.sub());
                        }
                    }
                    break;
                }
                case CHEV:
                    if (hv) p.roundRect(c.x, y + 3, c.w, DOCK - 6, 3, th.hover());
                    WinGfx.line(p, cx - 3, cy + 1, cx, cy - 2, th.text());
                    WinGfx.line(p, cx, cy - 2, cx + 3, cy + 1, th.text());
                    break;
                case SYS:
                    if (hv) p.roundRect(c.x, y + 3, c.w, DOCK - 6, 3, th.hover());
                    net(p, c.x + 7, cy);
                    volume(p, c.x + 19, cy);
                    break;
                case CLOCK:
                    if (hv) p.roundRect(c.x, y + 2, c.w, DOCK - 4, 3, th.hover());
                    p.drawTextRight(c.x + c.w - 4, y + 2, WinClock.time(dt, th.h12), th.text(), 1, false);
                    p.drawTextRight(c.x + c.w - 4, y + 11, trayDate(dt), th.text(), 1, false);
                    break;
                case BELL:
                    if (hv) p.roundRect(c.x, y + 3, c.w, DOCK - 6, 3, th.hover());
                    bell(p, cx, cy);
                    break;
                case AV:
                    if (hv) p.roundRect(c.x, y + 3, c.w, DOCK - 6, 3, th.hover());
                    shield(p, cx, cy, av == 2);
                    break;
                default:
                    if (hv) p.fillRect(c.x, y + 1, c.w, DOCK - 1, th.hover());
                    p.vline(c.x, y + 1, DOCK - 1, th.border());
                    break;
            }
        }
    }

    /** Подсказка и меню значка поверх всего (вызывать после окон и панели). */
    public void paintOverlay(PixelScreen p) {
        if (tipVisible) {
            int x = tipX, y = WinWm.workH() - 20, h = 15;
            if (effects) p.shadow(x, y, tipW, h, 4, 5, 0, 2, 0x60000000);
            p.roundRectBorder(x, y, tipW, h, 4, th.surface(), th.border());
            p.drawText(x + 6, y + 3, tipText, th.text());
        }
        if (menu != null && menu.open) menu.draw(p, th, effects);
    }

    // ================================================================== значки
    private void icon(PixelScreen p, String id, int cx, int cy) {
        WinIcons.draw(p, th, id, cx, cy);
    }

    private void net(PixelScreen p, int cx, int cy) {
        int c = th.text(), t = env.netType();
        if (t == NetLink.WIFI) {
            int sig = env.netSignal();
            int lit = sig >= 4 ? 3 : sig >= 3 ? 3 : sig >= 2 ? 2 : 1;
            p.fillRect(cx - 1, cy + 3, 2, 2, c);
            for (int r = 1; r <= 3; r++) {
                int col = r <= lit ? c : (th.sub() & 0x00FFFFFF) | 0x66000000;
                for (int a = -135; a <= -45; a += 5) {
                    double ang = Math.toRadians(a);
                    p.pixel(cx + (int) Math.round(Math.cos(ang) * r * 2.2), cy + 4 + (int) Math.round(Math.sin(ang) * r * 2.2), col);
                }
            }
        } else if (t == NetLink.WIRED) {
            p.rect(cx - 5, cy - 4, 10, 6, 1, c);
            p.fillRect(cx - 1, cy + 2, 2, 2, c);
            p.hline(cx - 3, cy + 4, 6, c);
        } else {
            p.roundRectOutline(cx - 5, cy - 5, 10, 10, 5, 1, c);
            p.hline(cx - 5, cy, 10, c);
            p.vline(cx, cy - 5, 10, c);
            p.fillRect(cx + 3, cy + 3, 3, 3, th.bad());
        }
    }

    private void volume(PixelScreen p, int cx, int cy) {
        int c = th.text();
        p.fillRect(cx - 5, cy - 1, 2, 3, c);
        p.fillRect(cx - 3, cy - 2, 1, 5, c);
        p.fillRect(cx - 2, cy - 3, 1, 7, c);
        p.fillRect(cx - 1, cy - 4, 1, 9, c);
        p.vline(cx + 2, cy - 2, 5, c);
        p.vline(cx + 4, cy - 4, 9, c);
    }

    private void shield(PixelScreen p, int cx, int cy, boolean bad) {
        int col = bad ? 0xFFE5484D : 0xFF2EA043;
        for (int r = 0; r < 10; r++) {
            int wd = r < 6 ? 8 : 8 - 2 * (r - 5);
            if (wd > 0) p.fillRect(cx - wd / 2, cy - 5 + r, wd, 1, col);
        }
        if (bad) {
            p.vline(cx, cy - 3, 4, 0xFFFFFFFF);
            p.pixel(cx, cy + 2, 0xFFFFFFFF);
        } else {
            p.pixel(cx - 2, cy, 0xFFFFFFFF);
            p.pixel(cx - 1, cy + 1, 0xFFFFFFFF);
            p.pixel(cx, cy, 0xFFFFFFFF);
            p.pixel(cx + 1, cy - 1, 0xFFFFFFFF);
            p.pixel(cx + 2, cy - 2, 0xFFFFFFFF);
        }
    }

    private void bell(PixelScreen p, int cx, int cy) {
        int c = th.text();
        p.roundRect(cx - 3, cy - 4, 6, 7, 3, c);
        p.hline(cx - 4, cy + 3, 8, c);
        p.fillRect(cx - 1, cy + 4, 2, 1, c);
        p.fillRect(cx, cy - 5, 1, 1, c);
    }
}
