package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import static ru.pcmod.common.PixelScreen.rgb;

/** Общие элементы интерфейса приложений AndroCraft: шапка, кнопки, прокручиваемый список, перенос текста. */
final class AppUi {
    static final int TOP = 44;

    /** Состояние прокрутки: тянем вверх/вниз, off - смещение содержимого в пикселях. */
    static final class Scroll {
        int off, start, y0;
        boolean moved;
        void down(int y) { start = off; y0 = y; moved = false; }
        void drag(int y, int content, int view) {
            if (Math.abs(y - y0) > 4) moved = true;
            off = Math.max(0, Math.min(Math.max(0, content - view), start + y0 - y));
        }
    }

    static boolean in(int x, int y, int rx, int ry, int rw, int rh) { return x >= rx && y >= ry && x < rx + rw && y < ry + rh; }

    static void header(AndroOs os, PixelScreen s, String icon, String title) {
        s.gradientV(0, 0, AndroOs.W, AndroOs.H, os.bg1(), os.bg2());
        s.fillRect(0, AndroOs.STATUS, AndroOs.W, 30, AndroIcons.colorOf(icon));
        AndroIcons.draw(s, icon, 8, AndroOs.STATUS + 4, 22);
        s.drawText(38, AndroOs.STATUS + 11, PixelScreen.fit(title, 132, 1, true), rgb(255, 255, 255), 1, true);
    }

    static void btn(AndroOs os, PixelScreen s, int x, int y, int w, int h, String label, boolean on) {
        s.roundRect(x, y, w, h, 8, on ? os.accent() : os.panel());
        s.drawTextCentered(x, w, y + h / 2 - 4, PixelScreen.fit(label, w - 4, 1, true), on ? rgb(255, 255, 255) : os.text(), 1, true);
    }

    static void tabs(AndroOs os, PixelScreen s, String[] names, int sel) {
        int w = 164 / names.length;
        for (int i = 0; i < names.length; i++) btn(os, s, 8 + i * w, TOP, w - 2, 20, names[i], i == sel);
    }

    static int tabAt(int n, int x, int y) {
        if (y < TOP || y >= TOP + 20 || x < 8) return -1;
        int i = (x - 8) / (164 / n);
        return i < n ? i : -1;
    }

    /** Перенос текста по ширине maxW (px). */
    static List<String> wrap(String t, int maxW) {
        List<String> out = new ArrayList<String>();
        StringBuilder cur = new StringBuilder();
        for (String w : t.split(" ", -1)) {
            while (PixelScreen.textWidth(w) > maxW && w.length() > 1) {
                int n = w.length();
                while (n > 1 && PixelScreen.textWidth(w.substring(0, n)) > maxW) n--;
                if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
                out.add(w.substring(0, n));
                w = w.substring(n);
            }
            String tr = cur.length() == 0 ? w : cur + " " + w;
            if (PixelScreen.textWidth(tr) > maxW && cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); cur.append(w); }
            else { cur.setLength(0); cur.append(tr); }
        }
        if (cur.length() > 0 || out.isEmpty()) out.add(cur.toString());
        return out;
    }

    static String two(int v) { return v < 10 ? "0" + v : String.valueOf(v); }
    static String hhmm(int minute) { return two(minute / 60 % 24) + ":" + two(minute % 60); }

    private AppUi() {}
}
