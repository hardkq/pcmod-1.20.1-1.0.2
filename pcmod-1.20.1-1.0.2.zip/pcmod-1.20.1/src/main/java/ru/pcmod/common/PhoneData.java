package ru.pcmod.common;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;

/**
 * Личные данные телефона в NBT предмета ("Data"): номер, контакты, журнал звонков, SMS, заметки, будильники, вход в чат.
 * Тяжёлые данные (фото) лежат в {@link PhoneBook} по идентификатору телефона ("Uid").
 */
public final class PhoneData {
    public static final int MAX_CONTACTS = 30, MAX_CALLS = 20, MAX_SMS = 60, MAX_NOTES = 20, MAX_ALARMS = 4;

    private PhoneData() {}

    public static CompoundTag d(ItemStack st) { return st.getOrCreateTagElement("Data"); }

    public static ListTag list(ItemStack st, String key) { return d(st).getList(key, Tag.TAG_COMPOUND); }

    /** Положить список обратно (getList возвращает копию-обёртку только при несовпадении типа). */
    public static void put(ItemStack st, String key, ListTag l) { d(st).put(key, l); }

    public static void cap(ListTag l, int max) { while (l.size() > max) l.remove(0); }

    public static String uid(ItemStack st) {
        CompoundTag t = d(st);
        if (!t.contains("Uid")) t.putString("Uid", UUID.randomUUID().toString());
        return t.getString("Uid");
    }

    /** Номер телефона из 7 цифр; выдаётся при первом обращении и записывается в реестр сервера. */
    public static String number(ItemStack st, PhoneBook pb) {
        CompoundTag t = d(st);
        if (t.getString("Number").isEmpty()) t.putString("Number", pb.allocate());
        else pb.claim(t.getString("Number"));
        return t.getString("Number");
    }

    public static String fmt(String n) {
        return n.length() == 7 ? n.substring(0, 3) + "-" + n.substring(3, 5) + "-" + n.substring(5) : n;
    }

    public static String contactName(ItemStack st, String num) {
        ListTag l = list(st, "Contacts");
        for (int i = 0; i < l.size(); i++) if (l.getCompound(i).getString("n").equals(num)) return l.getCompound(i).getString("name");
        return null;
    }

    public static String label(ItemStack st, String num) {
        String c = contactName(st, num);
        return c == null ? fmt(num) : c;
    }

    public static void addContact(ItemStack st, String name, String num) {
        ListTag l = list(st, "Contacts");
        for (int i = 0; i < l.size(); i++) if (l.getCompound(i).getString("n").equals(num)) { l.remove(i); break; }
        CompoundTag c = new CompoundTag();
        c.putString("name", name); c.putString("n", num);
        l.add(c);
        cap(l, MAX_CONTACTS);
        put(st, "Contacts", l);
    }

    /** type: 0 исходящий, 1 входящий, 2 пропущенный. */
    public static void addCall(ItemStack st, String num, int type, int minute) {
        ListTag l = list(st, "Calls");
        CompoundTag c = new CompoundTag();
        c.putString("n", num); c.putInt("t", type); c.putInt("m", minute);
        l.add(c);
        cap(l, MAX_CALLS);
        put(st, "Calls", l);
    }

    public static void addSms(ItemStack st, String peer, boolean out, String text, int minute) {
        ListTag l = list(st, "Sms");
        CompoundTag c = new CompoundTag();
        c.putString("p", peer); c.putBoolean("o", out); c.putString("x", text); c.putInt("m", minute);
        l.add(c);
        cap(l, MAX_SMS);
        put(st, "Sms", l);
    }

    public static ListTag strings(ItemStack st, String key) {
        return d(st).getList(key, Tag.TAG_STRING);
    }

    public static void addNote(ItemStack st, String text) {
        ListTag l = strings(st, "Notes");
        l.add(StringTag.valueOf(text));
        cap(l, MAX_NOTES);
        d(st).put("Notes", l);
    }

    /** Системные МБ занятого места: ОС + заметки + SMS + фото. */
    public static int usedMB(ItemStack st, int sysMB, int photos, int photoMB) {
        return sysMB + strings(st, "Notes").size() * 2 + list(st, "Sms").size() + photos * photoMB;
    }

    public static boolean vib(ItemStack st) { return d(st).getBoolean("Vib"); }
}
