package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Конфигурация WinCraft 11: требования, размер на накопителе, время загрузки и установки, уровни производительности.
 * Единая таблица для баланса: все числа WinCraft 11 меняются только здесь.
 */
public final class WinSpec {
    private WinSpec() {}

    public static final String ID = OsSpec.WIN_ID, NAME = "WinCraft 11";
    /** Версия и сборка (окна «Обновление» и «О системе»). */
    public static final String VERSION = "1.0", BUILD = "26100.1";
    /** Размер системы на накопителе, байт (все числа берутся из единой таблицы OsSpec). */
    public static final int OS_SIZE = OsSpec.WIN.size;

    /** Минимум: ниже ОС не запускается совсем. */
    public static final int MIN_CORES = OsSpec.WIN.minCores, MIN_RAM_MB = OsSpec.WIN.minRamMB, MIN_VRAM_MB = OsSpec.WIN.minVramMB,
            MIN_GPU_TIER = OsSpec.WIN.minGpuTier, MIN_DISK_KB = OsSpec.WIN.minDiskKB;
    /** Стандартная производительность (часть эффектов включена). */
    public static final int MID_CORES = OsSpec.WIN.midCores, MID_RAM_MB = OsSpec.WIN.midRamMB, MID_VRAM_MB = OsSpec.WIN.midVramMB;
    /** Полная производительность (все эффекты и анимации). */
    public static final int FULL_CORES = OsSpec.WIN.fullCores, FULL_RAM_MB = OsSpec.WIN.fullRamMB, FULL_VRAM_MB = OsSpec.WIN.fullVramMB;
    /** Нагрузка на процессор на рабочем столе. */
    public static final double HEAT_LOAD = OsSpec.WIN.heat;
    /** Базовое время загрузки и установки в тиках на накопителе со скоростью 1. */
    public static final int BOOT_TICKS = OsSpec.WIN.bootTicks, INSTALL_TICKS = OsSpec.WIN.installTicks;

    /** Уровень производительности: чем слабее железо, тем реже кадры анимации и тем меньше эффектов. */
    public enum Perf {
        LOW("Базовая", 4, 160, false, false),
        MEDIUM("Стандартная", 2, 125, true, false),
        FULL("Полная", 1, 100, true, true);

        public final String label;
        /** Анимация обновляется раз в animDiv тиков. */
        public final int animDiv;
        /** Множитель времени загрузки, %. */
        public final int bootPct;
        /** Прозрачность, Mica и тени. */
        public final boolean effects;
        /** Анимации открытия и закрытия окон. */
        public final boolean anims;

        Perf(String label, int animDiv, int bootPct, boolean effects, boolean anims) {
            this.label = label;
            this.animDiv = animDiv;
            this.bootPct = bootPct;
            this.effects = effects;
            this.anims = anims;
        }
    }

    /** Снимок железа ПК. */
    public static final class Hw {
        public int cores, ramMB, vramMB, gpuTier, driveKB, driveSpeed = 1;
        public double ghz;
        public String cpu = "", gpu = "", drive = "", mb = "";
        public boolean fastBoot;
    }

    /** Строка проверки требований. state: 0 не хватает, 1 запустится медленно, 2 хорошо. */
    public static final class Req {
        public final String name, need, have;
        public final int state;

        Req(String name, String need, String have, int state) {
            this.name = name;
            this.need = need;
            this.have = have;
            this.state = state;
        }
    }

    static String mem(int mb) {
        return mb >= 1024 && mb % 1024 == 0 ? (mb / 1024) + " ГБ" : mb + " МБ";
    }

    public static List<Req> checks(Hw h, boolean needDisk) {
        List<Req> r = new ArrayList<Req>();
        r.add(new Req("Процессор", MIN_CORES + "+ ядер", h.cores + " яд.",
                h.cores < MIN_CORES ? 0 : h.cores < MID_CORES ? 1 : 2));
        r.add(new Req("Память", mem(MIN_RAM_MB), mem(h.ramMB),
                h.ramMB < MIN_RAM_MB ? 0 : h.ramMB < MID_RAM_MB ? 1 : 2));
        boolean gpuBad = h.gpuTier < MIN_GPU_TIER || h.vramMB < MIN_VRAM_MB;
        r.add(new Req("Видеокарта", "GT-700+, " + mem(MIN_VRAM_MB), mem(h.vramMB),
                gpuBad ? 0 : h.vramMB < MID_VRAM_MB ? 1 : 2));
        if (needDisk) {
            r.add(new Req("Накопитель", MIN_DISK_KB + " КБ", h.driveKB + " КБ", h.driveKB < MIN_DISK_KB ? 0 : 2));
        }
        return r;
    }

    /** Чего не хватает ПК (пустой список - ОС запустится). needDisk - проверять размер накопителя (для установки). */
    public static List<String> problems(Hw h, boolean needDisk) {
        List<String> p = new ArrayList<String>();
        for (Req q : checks(h, needDisk)) {
            if (q.state == 0) p.add(q.name + ": нужно " + q.need + " (есть " + q.have + ")");
        }
        return p;
    }

    public static Perf perf(Hw h) {
        if (h.cores >= FULL_CORES && h.ramMB >= FULL_RAM_MB && h.vramMB >= FULL_VRAM_MB) return Perf.FULL;
        if (h.cores >= MID_CORES && h.ramMB >= MID_RAM_MB && h.vramMB >= MID_VRAM_MB) return Perf.MEDIUM;
        return Perf.LOW;
    }

    /** Время загрузки в тиках (до учёта вирусов). */
    public static int bootTicks(Hw h) {
        int base = BOOT_TICKS / Math.max(1, h.driveSpeed);
        base = base * perf(h).bootPct / 100;
        if (h.fastBoot) base /= 2;
        return Math.max(24, base);
    }

    /** Время установки в тиках. */
    public static int installTicks(Hw h) {
        int base = INSTALL_TICKS / Math.max(1, h.driveSpeed);
        return Math.max(120, base * perf(h).bootPct / 100);
    }

    // ------------------------------------------------------------------ нагрузка (Диспетчер задач)
    /** Системные процессы: названия, ОЗУ (МБ) и нагрузка ЦП (десятые доли ядро x ГГц). */
    public static final String[] SYS_NAMES = {"Система", "Диспетчер окон WinCraft", "Службы и драйверы"};
    public static final int[] SYS_RAM = {2600, 900, 700}, SYS_CPU = {3, 3, 2};
    /** Нагрузка на ГП от эффектов рабочего стола (условные единицы) на уровнях LOW, MEDIUM, FULL. */
    public static final int[] SYS_GPU = {1, 4, 8};

    /** Потребление приложения: {ОЗУ МБ, ЦП (десятые доли ядро x ГГц), ГП (условные единицы)}. */
    public static int[] cost(String id) {
        switch (id) {
            case "explorer": return new int[] {260, 3, 2};
            case "notepad": return new int[] {60, 1, 0};
            case "calc": return new int[] {45, 1, 0};
            case "taskmgr": return new int[] {110, 4, 1};
            case "paint": return new int[] {140, 5, 3};
            case "terminal": return new int[] {85, 2, 0};
            case "chat": return new int[] {110, 2, 1};
            case "net": return new int[] {90, 1, 1};
            case "browser": return new int[] {320, 6, 4};
            case "store": return new int[] {150, 2, 2};
            case "bank": return new int[] {80, 1, 0};
            case "settings": return new int[] {170, 3, 2};
            case "about": return new int[] {60, 1, 0};
            case "doom": return new int[] {420, 8, 6};
            case "av": return new int[] {180, 3, 1};
            case "setup": return new int[] {90, 2, 1};
            default: return new int[] {120, 3, 2};
        }
    }

    public static int sum(int[] a) {
        int s = 0;
        for (int v : a) s += v;
        return s;
    }

    /** Доля процессора (%) для нагрузки units (десятые доли ядро x ГГц). */
    public static double cpuShare(Hw h, int units) {
        return Math.min(100.0, units / 10.0 / Math.max(1.0, h.cores * h.ghz) * 100.0);
    }

    /** Общая нагрузка {ЦП %, ОЗУ МБ, ГП %} при приложениях ids в открытых окнах. */
    public static int[] load(Hw h, Perf perf, List<String> ids) {
        int cpu = sum(SYS_CPU), ram = sum(SYS_RAM), gpu = SYS_GPU[perf.ordinal()];
        for (String id : ids) {
            int[] c = cost(id);
            ram += c[0];
            cpu += c[1];
            gpu += c[2];
        }
        return new int[] {(int) Math.round(cpuShare(h, cpu)), Math.min(h.ramMB, ram), Math.min(100, gpu * 100 / Math.max(10, h.gpuTier * 10))};
    }
}
