package ru.pcmod.common;

import net.minecraft.world.entity.player.Player;
import static ru.pcmod.common.PixelScreen.rgb;

/** Общие проверки сети и тексты для сетевых приложений AndroCraft (Банк, Магазин, Браузер, Магазин приложений). */
final class AppNet {
    private AppNet() {}

    /** Телефон подключён к Wi-Fi сети мода. */
    static boolean wifi(AndroOs os) { return os.link != null && os.link.up(); }

    /** Есть Wi-Fi, сервер сети (как у ПК) и банк мира. */
    static boolean ready(AndroOs os) { return os.ses != null && wifi(os) && AppMessages.server(os) != null && Bank.get() != null; }

    static Player player(AndroOs os) { return os.ses.player; }

    static String id(AndroOs os) { return os.ses.player.getUUID().toString(); }

    /** Сообщение банка/магазина на языке телефона (сервер отдаёт английский текст). */
    static String tr(AndroOs os, String msg) { return os.lang == 0 ? WinSvcImpl.ru(msg) : msg; }

    static String kons(long v) { return Bank.fmt(v); }

    /** Экран «нет связи». */
    static void offline(AndroOs os, PixelScreen s) {
        boolean w = wifi(os);
        s.drawTextCentered(0, AndroOs.W, 120, w ? os.t("Сервер недоступен", "Server unavailable") : os.t("Нет подключения к сети", "No network connection"), rgb(240, 110, 100), 1, true);
        s.drawTextCentered(0, AndroOs.W, 138, w ? os.t("В сети нет сервера", "No server in this network") : os.t("Подключитесь к Wi-Fi", "Connect to Wi-Fi"), os.sub(), 1, false);
        if (!w) s.drawTextCentered(0, AndroOs.W, 150, os.t("в Настройках телефона", "in phone Settings"), os.sub(), 1, false);
    }

    /** Показывать приложение каждую секунду, пока оно открыто (баланс, таймеры, загрузки). */
    static boolean visible(AndroOs os, String id) { return os.phase == AndroOs.Phase.APP && os.app.equals(id) && os.awake(); }
}
