package ru.pcmod.common;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Менеджер окон WinCraft 11: заголовок, свернуть/развернуть/закрыть, перетаскивание, изменение размера за края и углы,
 * прикрепление к краям (snap), Alt+Tab, рабочие столы и «Представление задач», фокус, порядок окон, скруглённые углы и тени.
 * Методы ввода возвращают область {x, y, w, h}, которую надо перерисовать (null - ничего).
 */
public final class WinWm {
    static final int W = PixelScreen.W, H = PixelScreen.H;
    public static final int TB = 16, DOCK = 22, R = 6, BTN = 20, MAX_WINDOWS = 10, MAX_DESK = 4;
    /** Биты модификаторов (приходят от клиента). */
    public static final int M_SHIFT = 1, M_CTRL = 2, M_ALT = 4, M_SUPER = 8;
    private static final int P_BODY = 0, P_TITLE = 1, P_MIN = 2, P_MAX = 3, P_CLOSE = 4;
    private static final int E_L = 1, E_R = 2, E_T = 4, E_B = 8, FLY_DELAY = 12;
    private static final int K_D = 32, K_F4 = 62;
    private static final int A_OPEN = 0, A_CLOSE = 1, A_MIN = 2, A_RESTORE = 3;

    /** Анимация окна: открытие, закрытие, сворачивание к значку и возврат. Рисуется по снимку окна. */
    private static final class Anim {
        final Win w;
        final int kind, dur, sx, sy, sw, sh, tx, ty;
        final long t0;
        final int[] snap;
        int[] prev;

        Anim(Win w, int kind, long t0, int[] snap, int sx, int sy, int sw, int sh, int tx, int ty) {
            this.w = w;
            this.kind = kind;
            this.dur = kind == A_OPEN ? 6 : kind == A_CLOSE ? 4 : 5;
            this.t0 = t0;
            this.snap = snap;
            this.sx = sx;
            this.sy = sy;
            this.sw = sw;
            this.sh = sh;
            this.tx = tx;
            this.ty = ty;
        }
    }

    public static final class Win {
        public final WinApp app;
        public final int seq;
        public int x, y, w, h, rx, ry, rw, rh;
        /** Номер рабочего стола. */
        public int desk;
        /** Зона прикрепления (WinSnap.*); NONE - окно свободное. */
        public int snap;
        public boolean min, max;

        Win(WinApp app, int x, int y, int w, int h, int seq) {
            this.app = app;
            this.seq = seq;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }

    private final WinTheme th;
    private final boolean effects;
    /** Окна всех столов снизу вверх: последнее - сверху. */
    private final List<Win> z = new ArrayList<Win>();
    private final List<Win> hidden = new ArrayList<Win>();
    private Win drag, capture, hoverWin, lastTitle, rs;
    private int dragDX, dragDY, hoverPart = -1, opened, serial, pressX, pressY, snapZone, hoverEdge;
    private int rsEdge, rsX, rsY, rx0, ry0, rw0, rh0, pickEdge, cur, deskCount = 1, mods;
    private long lastTitleAt, maxSince;
    private boolean dragRestore, superUsed;
    private PixelScreen scratch;
    private final List<Anim> anims = new ArrayList<Anim>();
    private long clock;
    private final WinSnap.Flyout fly = new WinSnap.Flyout();
    private final WinSwitcher sw;
    private final WinTaskView tv;
    public final WinTaskbar bar;
    public final WinStart start;
    /** Значки рабочего стола (рисуются под окнами); null - рабочий стол без значков. */
    public WinDesk desk;

    public WinWm(WinTheme th, boolean effects, WinTaskbar.Env env, WinApps apps) {
        this.th = th;
        this.effects = effects;
        this.bar = new WinTaskbar(this, th, effects, env);
        this.start = new WinStart(this, th, effects, env, apps);
        this.sw = new WinSwitcher(this, th, effects);
        this.tv = new WinTaskView(this, th, effects);
    }

    public boolean startOpen() {
        return start.isOpen();
    }

    public boolean taskViewOpen() {
        return tv.isOpen();
    }

    /** Окна текущего рабочего стола снизу вверх. */
    public List<Win> windows() {
        return windowsOf(cur);
    }

    public List<Win> windowsOf(int d) {
        List<Win> r = new ArrayList<Win>();
        for (Win w : z) if (w.desk == d) r.add(w);
        return r;
    }

    public static int workH() {
        return H - DOCK;
    }

    public int curDesk() { return cur; }

    public int deskCount() { return deskCount; }

    private boolean vis(Win w) {
        return w.desk == cur;
    }

    private static int[] fullBox() {
        return new int[] {0, 0, W, H};
    }

    // ================================================================== окна
    public Win focused() {
        for (int i = z.size() - 1; i >= 0; i--) if (vis(z.get(i)) && !z.get(i).min) return z.get(i);
        return null;
    }

    public boolean dragging() {
        return drag != null || capture != null || rs != null;
    }

    public int count() {
        return z.size();
    }

    /** Новое окно со ступенчатым смещением на текущем столе; null, если окон уже слишком много. */
    public int[] open(WinApp app, int w, int h) {
        if (z.size() >= MAX_WINDOWS) return null;
        w = Math.min(w, W);
        h = Math.min(h, workH());
        int k = opened++ % 6;
        int x = Math.max(0, Math.min(W - w, 24 + k * 16)), y = Math.max(0, Math.min(workH() - h, 10 + k * 16));
        Win f0 = focused();
        Win n = new Win(app, x, y, w, h, ++serial);
        n.desk = cur;
        z.add(n);
        startAnim(n, A_OPEN);
        return refocus(f0, box(n));
    }

    /** К области d добавляет панель задач и окно, у которого изменился фокус. */
    private int[] refocus(Win f0, int[] d) {
        Win f1 = focused();
        if (f0 != f1) {
            if (f0 != null && !f0.min && z.contains(f0)) d = union(d, box(f0));
            if (f1 != null) d = union(d, box(f1));
        }
        return union(d, WinTaskbar.barBox());
    }

    private int[] raise(Win w) {
        Win f0 = focused();
        boolean was = w.min;
        z.remove(w);
        z.add(w);
        w.min = false;
        int[] d = was ? startAnim(w, A_RESTORE) : null;
        return union(refocus(f0, box(w)), d);
    }

    /** Вывести окно текущего стола на передний план (из Alt+Tab и «Представления задач»). */
    int[] bring(Win w) {
        if (!z.contains(w) || !vis(w)) return null;
        return union(box(w), raise(w));
    }

    private int[] close(Win w) {
        Win f0 = focused();
        int[] ad = w.min ? stopAnim(w) : startAnim(w, A_CLOSE);
        z.remove(w);
        hidden.remove(w);
        if (drag == w) drag = null;
        if (capture == w) capture = null;
        if (rs == w) rs = null;
        if (hoverWin == w) hoverWin = null;
        if (fly.win == w) fly.close();
        return union(refocus(f0, box(w)), ad);
    }

    private int[] minimize(Win w) {
        Win f0 = focused();
        int[] ad = w.min ? null : startAnim(w, A_MIN);
        w.min = true;
        if (drag == w) drag = null;
        if (capture == w) capture = null;
        if (rs == w) rs = null;
        return union(refocus(f0, box(w)), ad);
    }

    /** Закрыть окно (из панели задач). */
    public int[] closeWindow(Win w) {
        return z.contains(w) ? close(w) : null;
    }

    /** Значок на панели: свёрнутое окно - показать, окно в фокусе - свернуть, иначе - на передний план. */
    public int[] activate(Win w) {
        if (w.min) return union(box(w), raise(w));
        if (w == focused()) return minimize(w);
        return raise(w);
    }

    /** Свернуть все окна текущего стола; повторный вызов возвращает их. */
    public int[] showDesktop() {
        Win f0 = focused();
        int[] d = null;
        if (f0 != null) {
            hidden.clear();
            for (Win w : z) {
                if (vis(w) && !w.min) {
                    w.min = true;
                    hidden.add(w);
                    d = union(d, box(w));
                }
            }
            cancelPointer();
        } else {
            for (Win w : hidden) {
                if (z.contains(w) && vis(w)) {
                    w.min = false;
                    d = union(d, box(w));
                }
            }
            hidden.clear();
        }
        return refocus(f0, d);
    }

    // ================================================================== развернуть, прикрепить, восстановить
    private int[] snapTo(Win w, int zone) {
        if (!w.app.resizable() || zone == WinSnap.NONE) return null;
        int[] old = box(w);
        if (!w.max && w.snap == WinSnap.NONE) {
            w.rx = w.x; w.ry = w.y; w.rw = w.w; w.rh = w.h;
        }
        if (zone == WinSnap.MAX) {
            w.x = 0; w.y = 0; w.w = W; w.h = workH();
            w.max = true;
            w.snap = WinSnap.NONE;
        } else {
            int[] r = WinSnap.rect(zone);
            w.x = r[0]; w.y = r[1]; w.w = r[2]; w.h = r[3];
            w.max = false;
            w.snap = zone;
        }
        return union(old, box(w));
    }

    private int[] restore(Win w) {
        if (!w.max && w.snap == WinSnap.NONE) return null;
        int[] old = box(w);
        w.x = w.rx; w.y = w.ry; w.w = w.rw; w.h = w.rh;
        w.max = false;
        w.snap = WinSnap.NONE;
        return union(old, box(w));
    }

    private int[] toggleMax(Win w) {
        if (!w.app.resizable()) return null;
        return w.max || w.snap != WinSnap.NONE ? restore(w) : snapTo(w, WinSnap.MAX);
    }

    /** Win+стрелки: прикрепить влево/вправо, развернуть, восстановить или свернуть окно в фокусе. */
    private int[] arrowSnap(int key) {
        Win w = focused();
        if (w == null || !w.app.resizable()) return null;
        if (key == WinUi.K_LEFT) return w.snap == WinSnap.RIGHT ? restore(w) : snapTo(w, WinSnap.LEFT);
        if (key == WinUi.K_RIGHT) return w.snap == WinSnap.LEFT ? restore(w) : snapTo(w, WinSnap.RIGHT);
        if (key == WinUi.K_UP) return w.max ? null : snapTo(w, WinSnap.MAX);
        return w.max || w.snap != WinSnap.NONE ? restore(w) : minimize(w);
    }

    /** Область окна с тенью. */
    static int[] box(Win w) {
        return w.max ? new int[] {0, 0, W, workH()} : new int[] {w.x - 12, w.y - 8, w.w + 24, w.h + 22};
    }

    static int[] union(int[] a, int[] b) {
        if (a == null) return b;
        if (b == null) return a;
        int x0 = Math.min(a[0], b[0]), y0 = Math.min(a[1], b[1]);
        int x1 = Math.max(a[0] + a[2], b[0] + b[2]), y1 = Math.max(a[1] + a[3], b[1] + b[3]);
        return new int[] {x0, y0, x1 - x0, y1 - y0};
    }

    // ================================================================== рабочие столы
    private void cancelPointer() {
        drag = null;
        capture = null;
        rs = null;
        hoverWin = null;
        hoverPart = -1;
        hoverEdge = 0;
        dragRestore = false;
        snapZone = WinSnap.NONE;
        fly.close();
        anims.clear();
    }

    /** Перейти на рабочий стол i. */
    public int[] switchDesk(int i) {
        if (i < 0 || i >= deskCount || i == cur) return null;
        cancelPointer();
        hidden.clear();
        cur = i;
        return fullBox();
    }

    /** Создать рабочий стол и перейти на него. */
    public int[] newDesk() {
        if (deskCount >= MAX_DESK) return null;
        deskCount++;
        return switchDesk(deskCount - 1);
    }

    /** Удалить рабочий стол d: его окна переходят на соседний. */
    public int[] removeDesk(int d) {
        if (deskCount <= 1 || d < 0 || d >= deskCount) return null;
        cancelPointer();
        hidden.clear();
        int to = d == 0 ? 1 : d - 1;
        for (Win w : z) if (w.desk == d) w.desk = to;
        for (Win w : z) if (w.desk > d) w.desk--;
        cur = cur == d ? (to > d ? to - 1 : to) : cur > d ? cur - 1 : cur;
        deskCount--;
        return fullBox();
    }

    /** Переместить окно на другой рабочий стол. */
    public int[] moveToDesk(Win w, int d) {
        if (!z.contains(w) || d < 0 || d >= deskCount || w.desk == d) return null;
        Win f0 = focused();
        if (drag == w) drag = null;
        if (capture == w) capture = null;
        if (rs == w) rs = null;
        if (hoverWin == w) hoverWin = null;
        hidden.remove(w);
        w.desk = d;
        return union(refocus(f0, box(w)), fullBox());
    }

    /** Кнопка «Представление задач» и Win+Tab. */
    public int[] taskViewToggle() {
        int[] d = start.close();
        cancelPointer();
        return union(d, tv.toggle());
    }

    /** Закрыть все всплывающие окна (блокировка экрана). */
    public void cancel() {
        cancelPointer();
        sw.cancel();
        tv.cancel();
        start.close();
    }

    // ================================================================== попадание
    public Win at(int mx, int my) {
        for (int i = z.size() - 1; i >= 0; i--) {
            Win w = z.get(i);
            if (vis(w) && !w.min && mx >= w.x && my >= w.y && mx < w.x + w.w && my < w.y + w.h) return w;
        }
        return null;
    }

    public boolean dockHit(int mx, int my) {
        return my >= workH();
    }

    private int part(Win w, int mx, int my) {
        int ry = my - w.y;
        if (ry >= TB) return P_BODY;
        int rx = w.x + w.w - mx;
        if (rx <= BTN) return P_CLOSE;
        if (rx <= 2 * BTN) return P_MAX;
        if (rx <= 3 * BTN) return P_MIN;
        return P_TITLE;
    }

    /** Край или угол окна под указателем (E_*): 3 пикселя снаружи и 2 внутри рамки, у углов зона длиннее. */
    private static int edge(Win w, int mx, int my) {
        if (w.max || !w.app.resizable()) return 0;
        if (mx < w.x - 3 || mx >= w.x + w.w + 3 || my < w.y - 3 || my >= w.y + w.h + 3) return 0;
        int m = 0;
        if (mx < w.x + 2) m |= E_L;
        else if (mx >= w.x + w.w - 2) m |= E_R;
        if (my < w.y + 1) m |= E_T;
        else if (my >= w.y + w.h - 2) m |= E_B;
        if (m == 0) return 0;
        int cz = 8;
        if ((m & (E_T | E_B)) == 0) {
            if (my < w.y + cz) m |= E_T;
            else if (my >= w.y + w.h - cz) m |= E_B;
        } else if ((m & (E_L | E_R)) == 0) {
            if (mx < w.x + cz) m |= E_L;
            else if (mx >= w.x + w.w - cz) m |= E_R;
        }
        return m;
    }

    /** Окно под указателем: тело или рамка изменения размера (pickEdge - какая). */
    private Win pick(int mx, int my) {
        pickEdge = 0;
        for (int i = z.size() - 1; i >= 0; i--) {
            Win w = z.get(i);
            if (!vis(w) || w.min) continue;
            boolean body = mx >= w.x && my >= w.y && mx < w.x + w.w && my < w.y + w.h;
            int e = edge(w, mx, my);
            if (body || e != 0) {
                pickEdge = e;
                return w;
            }
        }
        return null;
    }

    private static int shape(int e) {
        if (e == 0) return WinGfx.CUR_ARROW;
        if ((e & (E_L | E_R)) != 0 && (e & (E_T | E_B)) == 0) return WinGfx.CUR_H;
        if ((e & (E_T | E_B)) != 0 && (e & (E_L | E_R)) == 0) return WinGfx.CUR_V;
        return (e == (E_L | E_T) || e == (E_R | E_B)) ? WinGfx.CUR_NWSE : WinGfx.CUR_NESW;
    }

    /** Вид указателя над рабочим столом (WinGfx.CUR_*). */
    public int cursor() {
        if (rs != null) return shape(rsEdge);
        if (drag != null || capture != null || sw.isOpen() || tv.isOpen() || fly.open) return WinGfx.CUR_ARROW;
        return shape(hoverEdge);
    }

    // ================================================================== ввод: мышь
    public int[] mouse(int mx, int my, int btn, int kind, long now) {
        clock = now;
        if (sw.isOpen()) return sw.mouse(mx, my, btn, kind);
        if (fly.open) {
            if (fly.inside(mx, my)) {
                int[] d = fly.hover(mx, my);
                if (kind == PixelScreen.MOUSE_PRESS && btn == 0) {
                    int zn = fly.zoneAt(mx, my);
                    if (zn != WinSnap.NONE) {
                        Win w = fly.win;
                        int[] c = fly.close();
                        hoverWin = null;
                        hoverPart = -1;
                        return union(union(d, c), snapTo(w, zn));
                    }
                }
                return d;
            }
            if (fly.onButton(mx, my) && kind != PixelScreen.MOUSE_PRESS) return null;
            int[] c = fly.close();
            return union(c, mouse1(mx, my, btn, kind, now));
        }
        return mouse1(mx, my, btn, kind, now);
    }

    private int[] mouse1(int mx, int my, int btn, int kind, long now) {
        hoverEdge = 0;
        boolean wasTv = tv.isOpen();
        if (wasTv && (my < workH() || tv.menuOpen())) return tv.mouse(mx, my, btn, kind, now);
        int[] d;
        if (start.isOpen()) {
            d = start.mouse(mx, my, btn, kind, bar.onStartButtons(mx, my));
            if (start.consumed()) return d;
            d = union(d, mouse0(mx, my, btn, kind, now));
        } else {
            d = mouse0(mx, my, btn, kind, now);
        }
        if (wasTv && tv.isOpen()) d = union(d, kind == PixelScreen.MOUSE_PRESS ? tv.close() : tv.leave());
        return d;
    }

    private int[] mouse0(int mx, int my, int btn, int kind, long now) {
        boolean press = kind == PixelScreen.MOUSE_PRESS && btn == 0;
        int[] dirty = null;
        if (bar.menuOpen()) return bar.menuMouse(mx, my, btn, kind);
        if (desk != null) {
            if (desk.menuOpen()) return desk.menuMouse(mx, my, btn, kind);
            if (desk.busy() && (kind == PixelScreen.MOUSE_DRAG || kind == PixelScreen.MOUSE_RELEASE)) return desk.mouse(mx, my, btn, kind, now, true);
        }
        if (kind == PixelScreen.MOUSE_RELEASE) {
            if (drag != null) {
                Win w = drag;
                int zn = snapZone;
                drag = null;
                dragRestore = false;
                snapZone = WinSnap.NONE;
                if (zn != WinSnap.NONE) dirty = union(WinSnap.previewBox(zn), snapTo(w, zn));
            }
            rs = null;
            if (capture != null) {
                Win c = capture;
                capture = null;
                if (c.app.mouse(mx - c.x - 1, my - c.y - TB, btn, kind)) dirty = union(dirty, content(c));
            }
            return dirty;
        }
        if (kind == PixelScreen.MOUSE_DRAG) {
            if (rs != null) return resizeTo(mx, my);
            if (drag != null) return moveDrag(mx, my);
            if (capture != null) {
                Win c = capture;
                return c.app.mouse(mx - c.x - 1, my - c.y - TB, btn, kind) ? content(c) : null;
            }
        }
        boolean onBar = my >= workH() && drag == null && capture == null && rs == null;
        dirty = bar.mouse(mx, my, btn, kind, now, onBar);
        if (onBar) {
            if (hoverWin != null) {
                dirty = union(dirty, titleBox(hoverWin));
                hoverWin = null;
                hoverPart = -1;
            }
            if (desk != null) dirty = union(dirty, desk.leave());
            return union(dirty, appLeave());
        }
        // подсветка кнопок заголовка и вид указателя у рамки
        Win w = pick(mx, my);
        int edge = w == null ? 0 : pickEdge;
        hoverEdge = edge;
        if (w == null || edge != 0 || part(w, mx, my) != P_BODY) dirty = union(dirty, appLeave());
        else if (kind == PixelScreen.MOUSE_MOVE) dirty = union(dirty, hoverApp(w, mx, my));
        int pt = w == null || edge != 0 ? -1 : part(w, mx, my);
        if (pt == P_BODY || pt == P_TITLE) pt = -1;
        if (w != hoverWin || pt != hoverPart) {
            if (hoverWin != null) dirty = union(dirty, titleBox(hoverWin));
            if (w != null) dirty = union(dirty, titleBox(w));
            hoverWin = w;
            hoverPart = pt;
            if (pt == P_MAX) maxSince = now;
        }
        if (w == null) return desk == null ? dirty : union(dirty, desk.mouse(mx, my, btn, kind, now, true));
        if (desk != null) dirty = union(dirty, desk.leave());
        if (edge != 0) {
            if (press) {
                if (w != focused()) dirty = union(dirty, raise(w));
                startResize(w, edge, mx, my);
            }
            return dirty;
        }
        if (press) {
            boolean wasTop = w == focused();
            int p0 = part(w, mx, my);
            if (!wasTop) dirty = union(dirty, raise(w));
            if (p0 == P_CLOSE) return union(dirty, close(w));
            if (p0 == P_MIN) return union(dirty, minimize(w));
            if (p0 == P_MAX) return union(dirty, toggleMax(w));
            if (p0 == P_TITLE) {
                if (lastTitle == w && now - lastTitleAt <= 8) {
                    lastTitle = null;
                    return union(dirty, toggleMax(w));
                }
                lastTitle = w;
                lastTitleAt = now;
                boolean fixed = w.max || w.snap != WinSnap.NONE;
                if (!fixed || w.app.resizable()) {
                    drag = w;
                    dragRestore = fixed;
                    pressX = mx;
                    pressY = my;
                    dragDX = mx - w.x;
                    dragDY = my - w.y;
                }
                return union(dirty, titleBox(w));
            }
            capture = w;
            if (w.app.mouse(mx - w.x - 1, my - w.y - TB, btn, kind)) dirty = union(dirty, content(w));
        } else if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN || btn == 1) {
            if (pt == -1 && part(w, mx, my) == P_BODY && w.app.mouse(mx - w.x - 1, my - w.y - TB, btn, kind)) dirty = union(dirty, content(w));
        }
        return dirty;
    }

    /** Окно, над содержимым которого сейчас указатель (ему шлются события MOVE для подсветки). */
    private Win appHover;

    private int[] hoverApp(Win w, int mx, int my) {
        int[] d = appHover != null && appHover != w ? appLeave() : null;
        appHover = w;
        return w.app.mouse(mx - w.x - 1, my - w.y - TB, 0, PixelScreen.MOUSE_MOVE) ? union(d, content(w)) : d;
    }

    /** Указатель ушёл с содержимого окна: приложение снимает подсветку (координаты за пределами окна). */
    private int[] appLeave() {
        Win o = appHover;
        appHover = null;
        return o != null && z.contains(o) && o.app.mouse(-1000, -1000, 0, PixelScreen.MOUSE_MOVE) ? content(o) : null;
    }

    private int[] moveDrag(int mx, int my) {
        Win w = drag;
        int[] old = box(w);
        if (dragRestore) {
            if (Math.abs(mx - pressX) + Math.abs(my - pressY) < 4) return null;
            dragRestore = false;
            float fx = Math.max(0f, Math.min(1f, (mx - w.x) / (float) w.w));
            w.w = w.rw;
            w.h = w.rh;
            w.max = false;
            w.snap = WinSnap.NONE;
            w.x = mx - Math.round(w.w * fx);
            w.y = Math.max(0, my - TB / 2);
            dragDX = mx - w.x;
            dragDY = my - w.y;
        }
        w.x = Math.max(-(w.w - 48), Math.min(W - 48, mx - dragDX));
        w.y = Math.max(0, Math.min(workH() - TB, my - dragDY));
        int zn = w.app.resizable() ? WinSnap.zoneAt(mx, my) : WinSnap.NONE;
        int[] d = union(old, box(w));
        if (zn != snapZone) {
            d = union(d, union(WinSnap.previewBox(snapZone), WinSnap.previewBox(zn)));
            snapZone = zn;
        }
        return d;
    }

    private void startResize(Win w, int edge, int mx, int my) {
        rs = w;
        rsEdge = edge;
        rsX = mx;
        rsY = my;
        rx0 = w.x;
        ry0 = w.y;
        rw0 = w.w;
        rh0 = w.h;
    }

    private int[] resizeTo(int mx, int my) {
        Win w = rs;
        int[] old = box(w);
        int dx = mx - rsX, dy = my - rsY, minW = Math.max(60, w.app.minW()), minH = Math.max(40, w.app.minH());
        int ox2 = rx0 + rw0, oy2 = ry0 + rh0;
        int x1 = rx0, y1 = ry0, x2 = ox2, y2 = oy2;
        if ((rsEdge & E_L) != 0) x1 = Math.max(Math.min(0, rx0), Math.min(ox2 - minW, rx0 + dx));
        if ((rsEdge & E_R) != 0) x2 = Math.min(Math.max(W, ox2), Math.max(rx0 + minW, ox2 + dx));
        if ((rsEdge & E_T) != 0) y1 = Math.max(0, Math.min(oy2 - minH, ry0 + dy));
        if ((rsEdge & E_B) != 0) y2 = Math.min(Math.max(workH(), oy2), Math.max(ry0 + minH, oy2 + dy));
        w.x = x1;
        w.y = y1;
        w.w = x2 - x1;
        w.h = y2 - y1;
        w.snap = WinSnap.NONE;
        return union(old, box(w));
    }

    private static int[] titleBox(Win w) {
        return new int[] {w.x, w.y, w.w, TB};
    }

    private static int[] content(Win w) {
        return new int[] {w.x + 1, w.y + TB, w.w - 2, w.h - TB - 1};
    }

    // ================================================================== ввод: клавиатура
    /** Состояние Shift/Ctrl/Alt/Win без реакции (экран входа). */
    public void setMods(int m) {
        mods = m;
    }

    /** Изменились клавиши-модификаторы: отпускание Alt/Ctrl подтверждает Alt+Tab, короткое нажатие Win открывает «Пуск». */
    public int[] mods(int m) {
        int old = mods;
        mods = m;
        int[] d = null;
        if (sw.isOpen() && (m & sw.hold()) == 0) d = sw.commit();
        boolean was = (old & M_SUPER) != 0, now = (m & M_SUPER) != 0;
        if (now && !was) {
            superUsed = false;
        } else if (!now && was && !superUsed) {
            d = union(d, tv.close());
            d = union(d, start.toggle(false));
        }
        return d;
    }

    private int[] openSwitcher() {
        List<Win> l = new ArrayList<Win>();
        for (int i = z.size() - 1; i >= 0; i--) if (vis(z.get(i))) l.add(z.get(i));
        if (l.isEmpty()) return null;
        cancelPointer();
        return union(start.close(), sw.open(l, (mods & M_SHIFT) != 0, mods & (M_ALT | M_CTRL)));
    }

    private int[] superKey(int key) {
        boolean ctrl = (mods & M_CTRL) != 0;
        if (key == WinUi.K_TAB) return taskViewToggle();
        if (key == K_D) return ctrl ? newDesk() : showDesktop();
        if (ctrl && key == WinUi.K_LEFT) return switchDesk(cur - 1);
        if (ctrl && key == WinUi.K_RIGHT) return switchDesk(cur + 1);
        if (ctrl && key == K_F4) return removeDesk(cur);
        if (key == WinUi.K_LEFT || key == WinUi.K_RIGHT || key == WinUi.K_UP || key == WinUi.K_DOWN) return arrowSnap(key);
        return null;
    }

    public int[] key(char c, int key) {
        if (key == 219 || key == 220) return start.toggle(false);
        if (sw.isOpen()) return sw.key(c, key, (mods & M_SHIFT) != 0);
        boolean sup = (mods & M_SUPER) != 0;
        if (key == WinUi.K_TAB && (mods & (M_ALT | M_CTRL)) != 0 && !sup && !tv.isOpen()) {
            int[] d = openSwitcher();
            if (d != null) return d;
        }
        if (sup) superUsed = true;
        if (tv.isOpen()) return tv.key(c, key, mods);
        if (sup) return superKey(key);
        if (desk != null && (desk.renaming() || desk.menuOpen())) return desk.key(c, key, false);
        if (start.isOpen()) return start.key(c, key);
        Win f = focused();
        if (f == null) return desk == null ? null : desk.key(c, key, true);
        return f.app.key(c, key) ? content(f) : null;
    }

    /** Раз в тик; возвращает области окон, которым нужна перерисовка. */
    public List<int[]> tick(long now) {
        List<int[]> r = new ArrayList<int[]>();
        clock = now;
        tickAnims(now, r);
        boolean covered = tv.isOpen();
        for (Win w : z) if (!w.min && w.app.tick(now) && vis(w) && !covered) r.add(content(w));
        bar.tick(now, r);
        start.tick(now, r);
        if (!fly.open && hoverPart == P_MAX && hoverWin != null && !dragging() && !covered && !sw.isOpen()
                && hoverWin.app.resizable() && now - maxSince >= FLY_DELAY) {
            Win w = hoverWin;
            r.add(fly.show(w, new int[] {w.x + w.w - 2 * BTN, w.y + 1, BTN, TB - 1}));
        }
        return r;
    }

    // ================================================================== снимки окон
    /** Снимок окна, вписанный в mw x mh; null на слабом железе (без эффектов). */
    WinThumb thumb(Win w, int mw, int mh) {
        if (!effects) return null;
        if (scratch == null) scratch = new PixelScreen();
        scratch.resetClip();
        scratch.clear(th.bg());
        drawWindow(scratch, w, true, false);
        int[] s = WinThumb.fit(w.w, w.h, mw, mh);
        return WinThumb.of(scratch, w.x, w.y, w.w, w.h, s[0], s[1], th.bg() & 0xFFFFFF);
    }

    // ================================================================== рисование
    /** Нарисовать рабочий стол (обои, окна, панель) в пределах области clip = {x, y, w, h}. */
    public void paint(PixelScreen p, int[] wall, int[] clip) {
        int cx = Math.max(0, clip[0]), cy = Math.max(0, clip[1]);
        int cw = Math.min(W, clip[0] + clip[2]) - cx, ch = Math.min(H, clip[1] + clip[3]) - cy;
        if (cw <= 0 || ch <= 0) return;
        p.pushClip(cx, cy, cw, ch);
        if (tv.isOpen()) {
            tv.paint(p, new int[] {cx, cy, cw, ch});
        } else {
            p.blit(wall, W, 0, 0, W, H, 0, 0, 255);
            if (desk != null) desk.paint(p, new int[] {cx, cy, cw, ch});
            Win f = focused();
            for (Win w : z) {
                if (w.min || !vis(w)) continue;
                int[] b = box(w);
                if (b[0] < cx + cw && b[0] + b[2] > cx && b[1] < cy + ch && b[1] + b[3] > cy) {
                    Anim a = animOf(w);
                    if (a != null && (a.kind == A_OPEN || a.kind == A_RESTORE)) drawGhost(p, a);
                    else drawWindow(p, w, w == f, true);
                }
            }
            for (Anim a : anims) if ((a.kind == A_CLOSE || a.kind == A_MIN) && a.w.desk == cur) drawGhost(p, a);
            if (drag != null && snapZone != WinSnap.NONE) WinSnap.paintPreview(p, th, snapZone);
            fly.paint(p, th, effects);
        }
        if (cy + ch > workH()) bar.paint(p);
        start.paint(p);
        bar.paintOverlay(p);
        if (desk != null) desk.paintMenu(p);
        sw.paint(p);
        p.popClip();
    }

    public void paintAll(PixelScreen p, int[] wall) {
        paint(p, wall, new int[] {0, 0, W, H});
    }

    // ================================================================== Mica и анимации
    /** Заголовок окна в фокусе: размытые обои под цветом темы (скруглённые верхние углы остаются). */
    private void micaTitle(PixelScreen p, Win w, int r) {
        int[] src = WinGfx.micaSrc(th.wall, th.dark);
        int tint = (th.bg() & 0xFFFFFF) | 0xB8000000;
        if (r > 0) {
            WinGfx.fill(p, src, w.x + r, w.y, w.w - 2 * r, r);
            p.fillRect(w.x + r, w.y, w.w - 2 * r, r, tint);
        }
        WinGfx.fill(p, src, w.x, w.y + r, w.w, TB - r);
        p.fillRect(w.x, w.y + r, w.w, TB - r, tint);
    }

    private Anim animOf(Win w) {
        for (Anim a : anims) if (a.w == w) return a;
        return null;
    }

    /** Убрать анимацию окна; возвращает область, где остался её кадр. */
    private int[] stopAnim(Win w) {
        Anim a = animOf(w);
        if (a == null) return null;
        anims.remove(a);
        return a.prev;
    }

    /** Снимок окна с прозрачными углами; в size кладёт {x, y, w, h} снятой области. null - окно не видно на экране. */
    private int[] snapshot(Win w, int[] size) {
        if (scratch == null) scratch = new PixelScreen();
        scratch.resetClip();
        scratch.clear(0xFF000000 | th.bg());
        drawWindow(scratch, w, true, false);
        int x0 = Math.max(0, w.x), y0 = Math.max(0, w.y), x1 = Math.min(W, w.x + w.w), y1 = Math.min(H, w.y + w.h);
        int sw = x1 - x0, sh = y1 - y0;
        if (sw < 8 || sh < 8) return null;
        int[] s = new int[sw * sh];
        int r = w.max ? 0 : R;
        for (int j = 0; j < sh; j++) {
            for (int i = 0; i < sw; i++) {
                int gx = x0 + i - w.x, gy = y0 + j - w.y;
                boolean out = false;
                if (r > 0) {
                    int cx = gx < r ? r : gx >= w.w - r ? w.w - r - 1 : -1, cy = gy < r ? r : gy >= w.h - r ? w.h - r - 1 : -1;
                    if (cx >= 0 && cy >= 0) out = (gx - cx) * (gx - cx) + (gy - cy) * (gy - cy) > r * r;
                }
                s[j * sw + i] = out ? 0 : 0xFF000000 | scratch.px[(y0 + j) * W + x0 + i];
            }
        }
        size[0] = x0;
        size[1] = y0;
        size[2] = sw;
        size[3] = sh;
        return s;
    }

    /** Начать анимацию окна (только если включены и тянутся железом). Возвращает область прежней анимации этого окна. */
    private int[] startAnim(Win w, int kind) {
        int[] old = stopAnim(w);
        if (!th.anim || !vis(w) || tv.isOpen()) return old;
        int[] size = new int[4];
        int[] snap = snapshot(w, size);
        if (snap == null) return old;
        anims.add(new Anim(w, kind, clock, snap, size[0], size[1], size[2], size[3], bar.iconX(w.app.id()), workH() + DOCK / 2));
        return old;
    }

    /** Прямоугольник и прозрачность кадра: {x, y, w, h, alpha}. */
    private static int[] ghost(Anim a, long now) {
        float t = Math.min(1f, Math.max(0f, (now - a.t0) / (float) a.dur));
        int cx = a.sx + a.sw / 2, cy = a.sy + a.sh / 2;
        float scale, al;
        if (a.kind == A_OPEN) {
            float e = 1 - (1 - t) * (1 - t);
            scale = 0.9f + 0.1f * e;
            al = e;
        } else if (a.kind == A_CLOSE) {
            scale = 1f - 0.1f * t;
            al = 1f - t;
        } else {
            float m = a.kind == A_MIN ? t * t : (1 - t) * (1 - t);
            scale = 1f - 0.88f * m;
            al = 1f - 0.9f * m;
            cx = Math.round(cx + (a.tx - cx) * m);
            cy = Math.round(cy + (a.ty - cy) * m);
        }
        int dw = Math.max(4, Math.round(a.sw * scale)), dh = Math.max(4, Math.round(a.sh * scale));
        return new int[] {cx - dw / 2, cy - dh / 2, dw, dh, Math.round(255 * al)};
    }

    private void drawGhost(PixelScreen p, Anim a) {
        int[] g = ghost(a, clock);
        WinGfx.blitFit(p, a.snap, a.sw, a.sh, g[0], g[1], g[2], g[3], g[4]);
    }

    private void tickAnims(long now, List<int[]> out) {
        for (Iterator<Anim> it = anims.iterator(); it.hasNext();) {
            Anim a = it.next();
            boolean done = now - a.t0 >= a.dur || a.w.desk != cur;
            int[] g = ghost(a, now);
            int[] d = new int[] {g[0] - 2, g[1] - 2, g[2] + 4, g[3] + 4};
            if (a.prev != null) d = union(d, a.prev);
            a.prev = d;
            out.add(d);
            if (done) {
                it.remove();
                if ((a.kind == A_OPEN || a.kind == A_RESTORE) && z.contains(a.w)) out.add(box(a.w));
            }
        }
    }

    /** live - рисуется на экране (тень, подсветка кнопок); иначе - для снимка. */
    private void drawWindow(PixelScreen p, Win w, boolean focus, boolean live) {
        int r = w.max ? 0 : R;
        if (!w.max && effects && live) p.shadow(w.x, w.y, w.w, w.h, r, focus ? 10 : 6, 0, focus ? 4 : 2, focus ? 0x66000000 : 0x38000000);
        p.roundRect(w.x, w.y, w.w, w.h, r, th.bg());
        if (th.glass && focus) micaTitle(p, w, r);
        p.roundRectOutline(w.x, w.y, w.w, w.h, r, 1, focus ? PixelScreen.lerp(th.border(), th.accent(), 0.5f) : th.border());
        WinGfx.logo(p, w.x + 6, w.y + 4, 8, focus ? th.accent() : th.sub());
        String t = PixelScreen.fit(w.app.title(), w.w - 3 * BTN - 24, 1, false);
        p.drawText(w.x + 20, w.y + (TB - PixelFont.H) / 2, t, focus ? th.text() : th.sub());
        int bx = w.x + w.w - BTN, by = w.y;
        boolean hv = live && w == hoverWin;
        // закрыть
        if (hv && hoverPart == P_CLOSE) p.roundRect(bx, by + 1, BTN - 1, TB - 1, w.max ? 0 : 3, 0xFFC42B1C);
        int gc = hv && hoverPart == P_CLOSE ? 0xFFFFFFFF : th.text();
        WinGfx.line(p, bx + 7, by + 5, bx + 12, by + 10, gc);
        WinGfx.line(p, bx + 7, by + 10, bx + 12, by + 5, gc);
        // развернуть / восстановить (у окон с постоянным размером кнопка тусклая)
        bx -= BTN;
        boolean canMax = w.app.resizable();
        int mc = canMax ? th.text() : PixelScreen.alpha(th.sub(), 0x70);
        if (canMax && hv && hoverPart == P_MAX) p.roundRect(bx, by + 1, BTN, TB - 1, 3, th.hover());
        if (w.max) {
            p.rect(bx + 8, by + 4, 6, 6, 1, mc);
            p.rect(bx + 6, by + 6, 6, 6, 1, mc);
            p.fillRect(bx + 7, by + 7, 4, 4, th.bg());
        } else {
            p.rect(bx + 7, by + 5, 7, 7, 1, mc);
        }
        // свернуть
        bx -= BTN;
        if (hv && hoverPart == P_MIN) p.roundRect(bx, by + 1, BTN, TB - 1, 3, th.hover());
        p.hline(bx + 7, by + 9, 7, th.text());
        p.pushClip(w.x + 1, w.y + TB, w.w - 2, w.h - TB - 1);
        w.app.draw(p, th, w.x + 1, w.y + TB, w.w - 2, w.h - TB - 1);
        p.popClip();
    }
}
