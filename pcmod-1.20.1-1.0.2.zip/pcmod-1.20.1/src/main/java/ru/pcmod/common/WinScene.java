package ru.pcmod.common;

/** Общая основа экранов WinCraft 11 (BIOS, установщик, сама ОС): буфер, курсор мыши, перерисовка без мерцания. */
abstract class WinScene implements PixelScreen.MouseListener {
    final WinHost h;
    final PixelScreen p;
    final WinTheme th = new WinTheme();
    private final WinGfx.Cursor cursor = new WinGfx.Cursor();
    int mx, my;
    /** Вид указателя: WinGfx.CUR_*. */
    int cursorShape;
    boolean hasMouse, cursorOn = true;
    /** Экран закрыт (ПК выключен или перезагружен): события игнорируются. */
    boolean dead;
    private boolean redrawn;

    WinScene(WinHost h) {
        this.h = h;
        this.p = h.pix();
    }

    /** Включить пиксельный режим и подписаться на мышь. */
    void activate() {
        p.setActive(true);
        p.resetClip();
        h.setMouse(this);
    }

    /** Перерисовать часть экрана: курсор снимается, рисуется r, курсор возвращается. */
    final void redraw(Runnable r) {
        redrawn = true;
        cursor.restore(p);
        p.resetClip();
        if (r != null) r.run();
        p.resetClip();
        if (hasMouse && cursorOn && !dead) cursor.draw(p, mx, my, cursorShape);
    }

    /** Мышь двинулась или нажата; mx, my уже обновлены. Перерисовку делает redraw(). */
    abstract void onMouse(int btn, int kind);

    @Override
    public final void mouse(int x, int y, int btn, int kind) {
        if (dead) return;
        if (x == PixelScreen.LEAVE) {
            if (hasMouse) {
                hasMouse = false;
                redraw(null);
            }
            return;
        }
        mx = Math.max(0, Math.min(PixelScreen.W - 1, x));
        my = Math.max(0, Math.min(PixelScreen.H - 1, y));
        hasMouse = true;
        redrawn = false;
        onMouse(btn, kind);
        if (!redrawn && !dead) redraw(null);
    }
}
