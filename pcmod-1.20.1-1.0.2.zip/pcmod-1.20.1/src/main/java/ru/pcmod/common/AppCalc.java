package ru.pcmod.common;

import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Калькулятор»: четыре действия, проценты, смена знака, десятичные, цепочки операций. */
final class AppCalc implements AndroOs.App {
    private static final class St {
        String disp = "0", expr = "";
        double acc;
        char op;
        boolean fresh, err;
    }

    private static final String[] KEYS = {"C", "+/-", "%", "/", "7", "8", "9", "x", "4", "5", "6", "-", "1", "2", "3", "+", "0", ".", "<", "="};

    private static St st(AndroOs os) { return os.state("calc", St::new); }

    private static String fmt(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return "Error";
        if (v == Math.rint(v) && Math.abs(v) < 1e12) return String.valueOf((long) v);
        String t = String.format(java.util.Locale.ROOT, "%.8f", v);
        t = t.replaceAll("0+$", "").replaceAll("\\.$", "");
        return t.length() > 14 ? String.format(java.util.Locale.ROOT, "%.6e", v) : t;
    }

    private static double val(St s) {
        try { return Double.parseDouble(s.disp); } catch (NumberFormatException e) { return 0; }
    }

    private static double apply(double a, char op, double b) {
        return switch (op) { case '+' -> a + b; case '-' -> a - b; case 'x' -> a * b; case '/' -> b == 0 ? Double.NaN : a / b; default -> b; };
    }

    private void press(St s, String k) {
        if (s.err && !k.equals("C")) return;
        char c = k.charAt(0);
        if (k.equals("C")) { s.disp = "0"; s.expr = ""; s.acc = 0; s.op = 0; s.fresh = false; s.err = false; }
        else if (k.equals("+/-")) { if (!s.disp.equals("0")) s.disp = s.disp.startsWith("-") ? s.disp.substring(1) : "-" + s.disp; }
        else if (k.equals("%")) { s.disp = fmt(val(s) / 100.0); s.fresh = true; }
        else if (k.equals("<")) { if (!s.fresh && s.disp.length() > 1) s.disp = s.disp.substring(0, s.disp.length() - 1); else if (!s.fresh) s.disp = "0"; if (s.disp.equals("-")) s.disp = "0"; }
        else if (k.equals(".")) { if (s.fresh) { s.disp = "0"; s.fresh = false; } if (!s.disp.contains(".")) s.disp += "."; }
        else if (c >= '0' && c <= '9') {
            if (s.fresh || s.disp.equals("0")) { s.disp = k; s.fresh = false; }
            else if (s.disp.length() < 12) s.disp += k;
        } else {
            double v = val(s);
            if (s.op != 0 && !s.fresh) v = apply(s.acc, s.op, v);
            if (Double.isNaN(v) || Double.isInfinite(v)) { s.disp = "Error"; s.err = true; s.op = 0; s.expr = ""; return; }
            s.disp = fmt(v);
            s.acc = v;
            s.fresh = true;
            if (k.equals("=")) { s.op = 0; s.expr = ""; }
            else { s.op = c; s.expr = fmt(v) + " " + c; }
        }
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "calc", os.t("Калькулятор", "Calculator"));
        s.roundRect(8, 48, 164, 50, 10, os.panel());
        s.drawTextRight(166, 54, PixelScreen.fit(st.expr, 150, 1, false), os.sub(), 1, false);
        String d = st.disp;
        int sc = PixelScreen.textWidth(d, 2, true) <= 152 ? 2 : 1;
        s.drawTextRight(166, 70, d, st.err ? rgb(240, 100, 90) : os.text(), sc, true);
        for (int i = 0; i < KEYS.length; i++) {
            int x = 8 + (i % 4) * 42, y = 108 + (i / 4) * 38;
            String k = KEYS[i];
            boolean opk = i % 4 == 3, eq = k.equals("=");
            s.roundRect(x, y, 38, 34, 10, eq ? os.accent() : opk ? AndroIcons.colorOf("calc") : os.panel());
            s.drawTextCentered(x, 38, y + 13, k, eq || opk ? rgb(255, 255, 255) : os.text(), 1, true);
        }
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        if (kind == 1 && os.tap(x, y) && x >= 8 && y >= 108 && (x - 8) % 42 < 38 && (y - 108) % 38 < 34) {
            int i = (y - 108) / 38 * 4 + (x - 8) / 42;
            if (i < KEYS.length) press(st(os), KEYS[i]);
        }
        return true;
    }
}
