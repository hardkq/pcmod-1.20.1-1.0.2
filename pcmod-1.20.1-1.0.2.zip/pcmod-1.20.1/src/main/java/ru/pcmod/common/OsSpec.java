package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Единая таблица баланса всех операционных систем: требования, размер на накопителе,
 * время загрузки и установки, нагрев процессора и уникальные плюсы.
 * Числа PCOS, PixelOS и WinCraft 11 меняются только здесь.
 *
 * Идея баланса: PCOS самая лёгкая и быстрая, PixelOS посередине, WinCraft 11 самая красивая и самая требовательная.
 */
public final class OsSpec {
    public static final String PCOS_ID = "pcos", PIXEL_ID = "pixel", WIN_ID = "wincraft";

    public final String id, name;
    /** Размер системы на накопителе, байт. */
    public int size;
    /** Минимум: ниже ОС не запускается. 0 - без требований. */
    public int minCores, minRamMB, minVramMB, minGpuTier, minDiskKB;
    /** Ниже этого числа ядер загрузка и установка идут на 30% дольше (ОС тормозит, но работает). */
    public int slowCores;
    /** Стандартный и полный уровни производительности (только для ОС с эффектами, иначе 0). */
    public int midCores, midRamMB, midVramMB, fullCores, fullRamMB, fullVramMB;
    /** Базовое время загрузки и установки в тиках на накопителе со скоростью 1. */
    public int bootTicks, installTicks;
    /** Нагрузка на процессор на рабочем столе (1.0 = полная): чем выше, тем сильнее греется ЦП. */
    public double heat;
    /** Уникальные плюсы и минусы (показываются в установщике). */
    public String[] perks = new String[0];

    private OsSpec(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public static final OsSpec PCOS = new OsSpec(PCOS_ID, "PCOS");
    public static final OsSpec PIXEL = new OsSpec(PIXEL_ID, "PixelOS");
    public static final OsSpec WIN = new OsSpec(WIN_ID, "WinCraft 11");

    static {
        // PCOS: работает на любом ПК, грузится и ставится быстрее всех, холодная, занимает минимум места.
        PCOS.size = 24 * 1024;
        PCOS.slowCores = 4;
        PCOS.bootTicks = 70;
        PCOS.installTicks = 400;
        PCOS.heat = 0.5;
        PCOS.perks = new String[] {
            "Runs on any PC, no minimum requirements",
            "Fastest boot and install",
            "Coolest desktop: fine with a weak cooler",
            "Smallest footprint: 24 KB"};

        // PixelOS: нужен приличный ПК, красивый пиксельный рабочий стол, средняя нагрузка.
        PIXEL.size = 96 * 1024;
        PIXEL.minCores = 6;
        PIXEL.minRamMB = 8192;
        PIXEL.minVramMB = 2048;
        PIXEL.minGpuTier = 3;
        PIXEL.minDiskKB = 128;
        PIXEL.slowCores = 8;
        PIXEL.bootTicks = 150;
        PIXEL.installTicks = 900;
        PIXEL.heat = 0.85;
        PIXEL.perks = new String[] {
            "Pixel-art desktop with sprites",
            "Needs a decent PC (6+ cores, 8 GB RAM)",
            "Medium boot time and heat"};

        // WinCraft 11: красивее и удобнее всех, самая требовательная и самая тяжёлая.
        WIN.size = 192 * 1024;
        WIN.minCores = 6;
        WIN.minRamMB = 12288;
        WIN.minVramMB = 2048;
        WIN.minGpuTier = 3;
        WIN.minDiskKB = 256;
        WIN.midCores = 8;
        WIN.midRamMB = 16384;
        WIN.midVramMB = 4096;
        WIN.fullCores = 10;
        WIN.fullRamMB = 32768;
        WIN.fullVramMB = 8192;
        WIN.bootTicks = 260;
        WIN.installTicks = 1800;
        WIN.heat = 1.0;
        WIN.perks = new String[] {
            "Most beautiful and convenient desktop",
            "Windows, themes, animations, multi-desktop",
            "Most demanding: 6+ cores, 12 GB RAM, 2 GB VRAM",
            "Slow boot, hottest CPU, weak PC lowers FPS and effects"};
    }

    public static final OsSpec[] ALL = {PCOS, PIXEL, WIN};

    /** Таблица по коду системы (неизвестный код - PCOS). */
    public static OsSpec of(String id) {
        if (PIXEL_ID.equals(id)) return PIXEL;
        if (WIN_ID.equals(id)) return WIN;
        return PCOS;
    }

    /** Время загрузки в тиках (до учёта вирусов). */
    public int boot(int driveSpeed, int cores, boolean fastBoot) {
        int base = bootTicks / Math.max(1, driveSpeed);
        if (cores < slowCores) base = base * 13 / 10;
        if (fastBoot) base /= 2;
        return Math.max(8, base);
    }

    /** Время установки в тиках. */
    public int install(int driveSpeed, int cores) {
        int base = installTicks / Math.max(1, driveSpeed);
        if (cores < slowCores) base = base * 13 / 10;
        return Math.max(40, base);
    }

    /** Чего не хватает ПК (пустой список - ОС запустится). diskKB проверяется только при установке. */
    public List<String> problems(int cores, int ramMB, int vramMB, int gpuTier, int diskKB, boolean needDisk) {
        List<String> p = new ArrayList<String>();
        if (cores < minCores) p.add("CPU: " + minCores + "+ cores (have " + cores + ")");
        if (ramMB < minRamMB) p.add("RAM: " + minRamMB + " MB (have " + ramMB + ")");
        if (gpuTier < minGpuTier || vramMB < minVramMB) p.add("GPU: " + minVramMB + " MB VRAM, GT-700 or better");
        if (needDisk && diskKB < minDiskKB) p.add("Drive: " + minDiskKB + " KB or more (HDD 1000+)");
        return p;
    }

    /** Сводная таблица для отладки и справки: по строке на систему. */
    public static List<String> table() {
        List<String> r = new ArrayList<String>();
        for (OsSpec o : ALL) {
            r.add(o.name + ": " + o.size / 1024 + " KB, CPU " + o.minCores + "+, RAM " + o.minRamMB + " MB, VRAM " + o.minVramMB
                    + " MB, boot " + o.bootTicks + " t, install " + o.installTicks + " t, heat " + o.heat);
        }
        return r;
    }
}
