package ru.pcmod.common;

/** DOOM в окне WinCraft 11: игра DoomGame (её графика сохранена) рисуется клетками 6x6 (вид) и 6x9 (панель состояния). */
public final class WinDoom implements WinApp {
    static final int VW = DoomGame.VW, VH = DoomGame.VH, HH = DoomGame.HUDH;
    static final int CW = 6, VCH = 6, HCH = 9;
    /** Размер игры в пикселях и окна вместе с заголовком. */
    public static final int GW = VW * CW, GH = VH * VCH + HH * HCH;
    public static final int WIN_W = GW + 2, WIN_H = GH + WinWm.TB + 1;
    private static final int[] PAL = {
            0xFF000000, 0xFF0000AA, 0xFF00AA00, 0xFF00AAAA, 0xFFAA0000, 0xFFAA00AA, 0xFFAA5500, 0xFFAAAAAA,
            0xFF555555, 0xFF5555FF, 0xFF55FF55, 0xFF55FFFF, 0xFFFF5555, 0xFFFF55FF, 0xFFFFFF55, 0xFFFFFFFF};
    /** Какие строки глифа 6x9 попадают в строку клетки высотой 6. */
    private static final int[][] ROWS = {{0, 1}, {1, 2}, {3, 4}, {4, 5}, {6, 7}, {7, 8}};

    private final WinSoft s;
    private final DoomGame g = new DoomGame();
    /** Тиков между кадрами игры: на слабом железе игра идёт медленнее. */
    private final int step;
    private long last = -1000, lastCheck;
    private int offX, offY;
    private boolean dead;

    public WinDoom(WinSoft s) {
        this.s = s;
        this.step = Math.max(2, s.perf.animDiv);
    }

    @Override public String title() { return "DOOM"; }

    @Override public String id() { return "doom"; }

    @Override public boolean resizable() { return false; }

    @Override public int minW() { return WIN_W; }

    @Override public int minH() { return WIN_H; }

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        offX = Math.max(0, (w - GW) / 2);
        offY = Math.max(0, (h - GH) / 2);
        final int ox = x + offX, oy = y + offY;
        p.fillRect(x, y, w, h, 0xFF000000);
        g.draw((cx, cy, c, attr) -> cell(p, ox, oy, cx, cy, c, attr));
    }

    private static void cell(PixelScreen p, int ox, int oy, int cx, int cy, char c, int attr) {
        if (cx < 0 || cx >= VW || cy < 0 || cy >= VH + HH) return;
        boolean view = cy < VH;
        int px = ox + cx * CW, py = oy + (view ? cy * VCH : VH * VCH + (cy - VH) * HCH), ch = view ? VCH : HCH;
        boolean solid = (attr & 16) != 0;
        int col = PAL[attr & 15];
        p.fillRect(px, py, CW, ch, solid ? col : 0xFF000000);
        if (c != ' ') glyph(p, px, py, c, solid ? 0xFF000000 : col, !view);
    }

    /** Глиф шрифта 6x9; в клетке высотой 6 он сжимается по вертикали. */
    private static void glyph(PixelScreen p, int x, int y, char c, int col, boolean tall) {
        long b = PixelFont.bits(PixelFont.index(c));
        if (b == 0) return;
        int rows = tall ? PixelFont.H : 6;
        for (int ry = 0; ry < rows; ry++) {
            int y1 = tall ? ry : ROWS[ry][0], y2 = tall ? ry : ROWS[ry][1];
            for (int cx = 0; cx < 6; cx++) {
                boolean on = false;
                for (int sy = y1; sy <= y2 && !on; sy++) on = (b >> (sy * 6 + cx) & 1L) != 0;
                if (on) p.pixel(x + cx, y + ry, col);
            }
        }
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int gx = rx - offX, gy = ry - offY, vx = -1, vy = -1;
        if (gx >= 0 && gx < GW && gy >= 0 && gy < GH) {
            vx = gx / CW;
            vy = gy < VH * VCH ? gy / VCH : VH + (gy - VH * VCH) / HCH;
        }
        g.look(vx, vy);
        if (kind == PixelScreen.MOUSE_PRESS && btn == 0 && vx >= 0) {
            g.click(vx, vy);
            g.dirty = false;
            return true;
        }
        return false;
    }

    @Override
    public boolean key(char c, int key) {
        g.key(c, key);
        g.dirty = false;
        return true;
    }

    @Override
    public boolean tick(long now) {
        if (dead) return false;
        if (now - lastCheck >= 20) {
            lastCheck = now;
            if (!s.svc.installed(WinSvc.DL_DOOM)) {
                dead = true;
                s.ctx.kill(this);
                return false;
            }
        }
        if (now - last < step) return false;
        last = now;
        g.tick();
        boolean d = g.dirty;
        g.dirty = false;
        return d;
    }
}
