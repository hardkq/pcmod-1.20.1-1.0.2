package ru.pcmod.common;

/** Страница «О системе»: версия WinCraft 11, характеристики ПК, уровень производительности и время работы. */
final class WinPageAbout extends WinFormPage {
    private final WinSpec.Perf perf;
    private long sec = -1;

    WinPageAbout(WinHost host, WinSpec.Perf perf) {
        super(host);
        this.perf = perf;
    }

    private static String two(long v) {
        return (v < 10 ? "0" : "") + v;
    }

    @Override
    void build(WinForm f) {
        WinSpec.Hw hw = host.hw();
        sec = host.uptime() / 20;
        f.card(WinSpec.NAME).sub("Версия " + WinSpec.VERSION + ", сборка " + WinSpec.BUILD).logo();
        f.section("Устройство");
        f.card("Имя устройства").value(host.hostName());
        f.card("Пользователь").value(host.userName());
        f.card("Процессор").value(hw.cpu);
        f.card("Ядра и частота").value(hw.cores + " x " + hw.ghz + " ГГц");
        f.card("Память").value(WinSpec.mem(hw.ramMB));
        f.card("Видеокарта").value(hw.gpu);
        f.card("Видеопамять").value(WinSpec.mem(hw.vramMB));
        f.card("Материнская плата").value(hw.mb);
        f.card("Накопитель").value(hw.drive + ", " + WinForm.size(hw.driveKB * 1024L));
        f.section("Система");
        f.card("Производительность").value(perf.label);
        f.card("Время работы").value(two(sec / 3600) + ":" + two(sec / 60 % 60) + ":" + two(sec % 60));
    }

    @Override
    public boolean tick(long now) {
        if (now % 20 != 0 || host.uptime() / 20 == sec) return false;
        form.refresh();
        return true;
    }
}
