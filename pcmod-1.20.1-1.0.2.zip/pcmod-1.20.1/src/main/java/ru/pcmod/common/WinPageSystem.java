package ru.pcmod.common;

/** Страница «Система»: уровень производительности и требования, время загрузки, хранилище, питание и блокировка. */
final class WinPageSystem extends WinFormPage {
    private static final String[] PERF_INFO = {"Слабое железо: без эффектов, редкие кадры", "Прозрачность есть, анимаций окон нет", "Все эффекты и анимации"};
    private static final int[] IDLE = {0, 1, 3, 5, 10};
    private static final String[] IDLE_NAMES = {"Никогда", "1 мин", "3 мин", "5 мин", "10 мин"};

    private final WinSpec.Perf perf;
    private final WinSettings.Ctx ctx;

    WinPageSystem(WinHost host, WinTheme th, WinSpec.Perf perf, WinSettings.Ctx ctx) {
        super(host);
        this.perf = perf;
        this.ctx = ctx;
    }

    private int idleIndex() {
        try {
            int m = Integer.parseInt(host.pref("idle").trim());
            for (int i = 0; i < IDLE.length; i++) if (IDLE[i] == m) return i;
        } catch (NumberFormatException e) {
            // настройка не задана: никогда
        }
        return 0;
    }

    @Override
    void build(WinForm f) {
        WinSpec.Hw hw = host.hw();
        f.section("Устройство");
        f.card(host.hostName().isEmpty() ? WinSpec.NAME : host.hostName()).sub("Пользователь: " + host.userName()).icon("pc");

        f.section("Производительность");
        f.card("Уровень: " + perf.label).sub(PERF_INFO[perf.ordinal()]).state(perf == WinSpec.Perf.FULL ? 2 : perf == WinSpec.Perf.MEDIUM ? 1 : 0);
        for (WinSpec.Req q : WinSpec.checks(hw, false)) {
            f.card(q.name).sub("Нужно: " + q.need).value(q.have).state(q.state);
        }
        f.card("Время загрузки").sub("С учётом накопителя").value(WinSpec.bootTicks(hw) / 20 + " с");
        f.card("Быстрая загрузка").sub("Параметр BIOS").value(hw.fastBoot ? "Вкл" : "Выкл");

        long[] d = host.disk();
        long total = d[0], os = d[1], files = d[2], used = os + files;
        f.section("Хранилище");
        f.card(hw.drive.isEmpty() ? "Накопитель" : hw.drive).sub("Свободно: " + WinForm.size(Math.max(0, total - used)))
                .value(WinForm.size(used) + " из " + WinForm.size(total)).bar(total > 0 ? (float) used / total : 0f);
        f.card("Система").value(WinForm.size(os));
        f.card("Файлы и данные").value(WinForm.size(files));

        f.section("Питание");
        f.card("Блокировка при бездействии").choice(IDLE_NAMES, idleIndex(), i -> host.setPref("idle", String.valueOf(IDLE[i])));
        f.card("Заблокировать").sub("Нужен пароль").button("Выполнить", true, () -> ctx.power(0));
        f.card("Перезагрузка").sub("Перезапуск ПК").button("Выполнить", true, () -> ctx.power(1));
        f.card("Завершение работы").sub("Выключение ПК").button("Выполнить", true, () -> ctx.power(2));
    }
}
