package ru.pcmod.common;

import static ru.pcmod.common.PixelScreen.argb;
import static ru.pcmod.common.PixelScreen.rgb;

/** Иконки приложений AndroCraft, нарисованные примитивами PixelScreen (у каждого приложения своя графика). Размер 26..30 px. */
public final class AndroIcons {
    private static final int WHITE = rgb(255, 255, 255);

    private static int color(String id) {
        return switch (id) {
            case "phone" -> rgb(52, 168, 83);
            case "messages" -> rgb(66, 133, 244);
            case "browser" -> rgb(0, 172, 193);
            case "camera" -> rgb(97, 97, 110);
            case "gallery" -> rgb(233, 84, 140);
            case "store" -> rgb(0, 150, 136);
            case "bank" -> rgb(46, 125, 50);
            case "shop" -> rgb(251, 140, 0);
            case "calc" -> rgb(84, 110, 122);
            case "notes" -> rgb(251, 192, 45);
            case "clock" -> rgb(92, 107, 192);
            case "files" -> rgb(30, 136, 229);
            case "tasks" -> rgb(69, 90, 100);
            case "settings" -> rgb(120, 130, 150);
            case "snake" -> rgb(67, 160, 71);
            case "dice" -> rgb(171, 71, 188);
            case "mines" -> rgb(96, 125, 139);
            default -> rgb(90, 90, 100);
        };
    }

    public static int colorOf(String id) { return color(id); }

    /** Иконка id в квадрате size x size с левым верхним углом (x, y). */
    public static void draw(PixelScreen s, String id, int x, int y, int size) {
        int c = color(id), cx = x + size / 2, cy = y + size / 2;
        s.roundRect(x, y, size, size, 8, c);
        s.roundRect(x + 1, y + 1, size - 2, size / 2, 7, argb(34, 255, 255, 255));
        int dark = rgb((c >> 16 & 255) * 2 / 3, (c >> 8 & 255) * 2 / 3, (c & 255) * 2 / 3);
        switch (id) {
            case "phone" -> { s.fillRect(cx - 8, cy - 8, 6, 5, WHITE); s.fillRect(cx - 5, cy - 8, 3, 16, WHITE); s.fillRect(cx - 8, cy + 3, 6, 5, WHITE); }
            case "messages" -> {
                s.roundRect(cx - 9, cy - 8, 18, 12, 3, WHITE); s.fillRect(cx - 6, cy + 4, 3, 4, WHITE);
                s.hline(cx - 6, cy - 4, 12, c); s.hline(cx - 6, cy - 1, 8, c);
            }
            case "browser" -> {
                s.roundRectOutline(cx - 9, cy - 9, 18, 18, 9, 2, WHITE); s.vline(cx, cy - 9, 18, WHITE); s.hline(cx - 9, cy, 18, WHITE);
                s.roundRectOutline(cx - 4, cy - 9, 8, 18, 4, 1, WHITE);
            }
            case "camera" -> {
                s.fillRect(cx - 4, cy - 8, 8, 3, WHITE); s.roundRect(cx - 9, cy - 5, 18, 13, 2, WHITE);
                s.roundRect(cx - 4, cy - 3, 8, 8, 4, dark); s.roundRect(cx - 2, cy - 1, 4, 4, 2, rgb(120, 190, 255));
            }
            case "gallery" -> {
                s.roundRectOutline(cx - 9, cy - 8, 18, 16, 2, 2, WHITE); s.roundRect(cx + 2, cy - 5, 4, 4, 2, rgb(255, 225, 90));
                for (int i = 0; i < 7; i++) s.vline(cx - 7 + i, cy + 5 - i, i + 1, WHITE);
                for (int i = 0; i < 5; i++) s.vline(cx - 1 + i, cy + 1 + i - 1, 5 - i + 1, WHITE);
            }
            case "store" -> { for (int i = 0; i < 10; i++) { int h = 9 - (i * 9) / 10; s.vline(cx - 5 + i, cy - h, 2 * h + 1, WHITE); } }
            case "bank" -> { s.roundRect(cx - 9, cy - 9, 18, 18, 9, WHITE); s.drawText(cx - 2, cy - 4, "$", c); }
            case "shop" -> { s.roundRectOutline(cx - 4, cy - 9, 8, 9, 4, 2, WHITE); s.roundRect(cx - 8, cy - 3, 16, 12, 2, WHITE); }
            case "calc" -> {
                s.roundRect(cx - 8, cy - 9, 16, 18, 2, WHITE); s.fillRect(cx - 6, cy - 7, 12, 4, dark);
                for (int r = 0; r < 3; r++) for (int k = 0; k < 3; k++) s.fillRect(cx - 6 + k * 5, cy - 1 + r * 4, 2, 2, r == 2 && k == 2 ? rgb(251, 140, 0) : dark);
            }
            case "notes" -> {
                s.roundRect(cx - 7, cy - 9, 14, 18, 2, WHITE);
                for (int i = 0; i < 4; i++) s.hline(cx - 4, cy - 5 + i * 4, i == 3 ? 5 : 8, rgb(150, 150, 160));
            }
            case "clock" -> { s.roundRectOutline(cx - 9, cy - 9, 18, 18, 9, 2, WHITE); s.vline(cx, cy - 6, 7, WHITE); s.hline(cx, cy, 5, WHITE); }
            case "files" -> { s.fillRect(cx - 9, cy - 6, 8, 3, WHITE); s.roundRect(cx - 9, cy - 4, 18, 13, 2, WHITE); }
            case "tasks" -> { s.roundRect(cx - 8, cy - 8, 16, 4, 2, WHITE); s.roundRect(cx - 8, cy - 2, 12, 4, 2, WHITE); s.roundRect(cx - 8, cy + 4, 16, 4, 2, WHITE); }
            case "settings" -> {
                s.fillRect(cx - 2, cy - 10, 4, 4, WHITE); s.fillRect(cx - 2, cy + 6, 4, 4, WHITE);
                s.fillRect(cx - 10, cy - 2, 4, 4, WHITE); s.fillRect(cx + 6, cy - 2, 4, 4, WHITE);
                s.roundRect(cx - 7, cy - 7, 14, 14, 7, WHITE); s.roundRect(cx - 3, cy - 3, 6, 6, 3, c);
            }
            case "snake" -> {
                for (int i = 0; i < 4; i++) s.roundRect(cx - 9 + i * 5, cy + (i % 2 == 0 ? 1 : -4), 5, 5, 2, i == 3 ? rgb(190, 255, 160) : WHITE);
                s.roundRect(cx + 5, cy + 5, 4, 4, 2, rgb(255, 90, 80));
            }
            case "dice" -> {
                s.roundRect(cx - 8, cy - 8, 16, 16, 4, WHITE);
                for (int[] d : new int[][] {{-5, -5}, {0, 0}, {4, 4}, {4, -5}, {-5, 4}}) s.roundRect(cx + d[0], cy + d[1], 3, 3, 1, dark);
            }
            case "mines" -> {
                s.roundRect(cx - 5, cy - 5, 10, 10, 5, WHITE);
                s.vline(cx, cy - 9, 18, WHITE); s.hline(cx - 9, cy, 18, WHITE);
                s.fillRect(cx - 7, cy - 7, 2, 2, WHITE); s.fillRect(cx + 5, cy + 5, 2, 2, WHITE);
                s.fillRect(cx - 7, cy + 5, 2, 2, WHITE); s.fillRect(cx + 5, cy - 7, 2, 2, WHITE);
                s.fillRect(cx - 3, cy - 3, 2, 2, c);
            }
            default -> { }
        }
    }

    /** Папка: полупрозрачная плитка с мини-иконками (до 4). */
    public static void folder(PixelScreen s, String[] ids, int x, int y, int size) {
        s.roundRect(x, y, size, size, 8, argb(90, 255, 255, 255));
        int m = (size - 12) / 2;
        for (int i = 0; i < ids.length && i < 4; i++)
            s.roundRect(x + 4 + (i % 2) * (m + 4), y + 4 + (i / 2) * (m + 4), m, m, 3, color(ids[i]));
    }

    private AndroIcons() {}
}
