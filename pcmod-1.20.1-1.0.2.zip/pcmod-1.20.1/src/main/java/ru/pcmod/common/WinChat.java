package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Чат: вход и регистрация на сервере сети, общий чат и личные сообщения, счётчики непрочитанных. Только символы ASCII, до 100 знаков. */
public final class WinChat implements WinApp {
    private static final String GEN = "#general";
    private static final int LW = 76, IH = 17, HEAD = 18, INP = 22;
    private final WinSoft s;
    private final WinSvc svc;
    private final WinUi.Field fNick = new WinUi.Field(0, 0, 100), fPass = new WinUi.Field(0, 0, 100), fMsg = new WinUi.Field(0, 0, 100);
    private final WinUi.Button bLogin = new WinUi.Button("Войти", 0, 0, 70, true), bReg = new WinUi.Button("Регистрация", 0, 0, 80, false),
            bSend = new WinUi.Button("Отпр.", 0, 0, 38, true), bOut = new WinUi.Button("Выйти", 0, 0, 50, false);
    private String peer = GEN, err = "";
    private int focus, aw = 260, ah = 130, lsc, sc, maxSc, lastRev = -1, hoverItem = -1, hoverBtn = -1;
    private int ox, oy, linkY = -1;

    public WinChat(WinSoft s) {
        this.s = s;
        this.svc = s.svc;
        fNick.max = 16;
        fNick.hint = "Ник (a-z, 0-9, _)";
        fPass.max = 16;
        fPass.mask = true;
        fPass.hint = "Пароль";
        fMsg.max = 100;
        fMsg.hint = "Сообщение";
        fNick.sb.append(svc.chatSavedNick());
        focus = fNick.sb.length() > 0 ? 1 : 0;
    }

    @Override public String title() { return "Чат"; }

    @Override public String id() { return "chat"; }

    @Override public int minW() { return 200; }

    @Override public int minH() { return 100; }

    private boolean loggedIn() { return !svc.chatNick().isEmpty(); }

    static String hhmm(long tt) {
        long h = ((tt % 24000L) / 1000L + 6L) % 24L, m = (tt % 1000L) * 60L / 1000L;
        return (h < 10 ? "0" : "") + h + ":" + (m < 10 ? "0" : "") + m;
    }

    private List<String> peers() {
        List<String> r = new ArrayList<String>();
        r.add(GEN);
        r.addAll(svc.chatUsers());
        return r;
    }

    // ------------------------------------------------------------------ рисование
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        ox = x;
        oy = y;
        if (!loggedIn()) drawLogin(p, th, x, y, w, h);
        else drawChat(p, th, x, y, w, h);
    }

    private void drawLogin(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        int fw = Math.min(170, w - 24), x0 = x + (w - fw) / 2, cy = y + Math.max(6, (h - 130) / 2);
        p.drawTextCentered(x, w, cy, "Вход в чат", th.text(), 1, true);
        cy += 14;
        boolean srv = !svc.server().isEmpty();
        String st = !svc.netUp() ? "Нет подключения к сети" : !srv ? "Сервер не найден" : "Сервер: " + svc.server();
        p.drawTextCentered(x, w, cy, PixelScreen.fit(st, w - 12, 1, false), srv && svc.netUp() ? th.sub() : th.bad(), 1, false);
        if (svc.servers().size() > 1) {
            p.drawTextCentered(x, w, cy + 10, "[ сменить сервер ]", hoverBtn == 9 ? th.accentHover() : th.accent(), 1, false);
            linkY = cy + 10;
        } else {
            linkY = -1;
        }
        cy += 24;
        fNick.x = x0;
        fNick.y = cy;
        fNick.w = fw;
        fNick.draw(p, th, focus == 0, s.host.time());
        fPass.x = x0;
        fPass.y = cy + 22;
        fPass.w = fw;
        fPass.draw(p, th, focus == 1, s.host.time());
        bLogin.x = x0;
        bLogin.y = cy + 46;
        bLogin.w = fw / 2 - 2;
        bReg.x = x0 + fw / 2 + 2;
        bReg.y = cy + 46;
        bReg.w = fw / 2 - 2;
        bLogin.hover = hoverBtn == 0;
        bReg.hover = hoverBtn == 1;
        bLogin.enabled = bReg.enabled = svc.netUp() && srv;
        bLogin.draw(p, th);
        bReg.draw(p, th);
        if (!err.isEmpty()) {
            int ey = cy + 66;
            for (String ln : WinSoft.wrap(err, fw)) {
                p.drawTextCentered(x, w, ey, ln, th.bad(), 1, false);
                ey += 10;
            }
        }
    }

    private void drawChat(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        List<String> ps = peers();
        if (!ps.contains(peer)) peer = GEN;
        // список
        p.fillRect(x, y, LW, h, th.surface());
        p.vline(x + LW, y, h, th.border());
        p.drawText(x + 8, y + 5, "Чаты", th.text(), 1, true);
        int rows = Math.max(1, (h - HEAD - 32) / IH);
        lsc = Math.max(0, Math.min(Math.max(0, ps.size() - rows), lsc));
        for (int i = 0; i < rows && lsc + i < ps.size(); i++) {
            String id = ps.get(lsc + i);
            int iy = y + HEAD + i * IH;
            boolean sel = id.equals(peer);
            if (sel) p.roundRect(x + 3, iy, LW - 6, IH - 1, 3, PixelScreen.alpha(th.accent(), 0x30));
            else if (i == hoverItem) p.roundRect(x + 3, iy, LW - 6, IH - 1, 3, th.hover());
            boolean gen = id.equals(GEN);
            int ac = gen ? th.accent() : 0xFF000000 | (id.hashCode() * 0x9E3779B1 & 0x00B0B0B0) + 0x00404040;
            p.roundRect(x + 6, iy + 2, 11, 11, 5, ac);
            p.drawTextCentered(x + 6, 11, iy + 3, gen ? "#" : id.substring(0, 1).toUpperCase(), 0xFFFFFFFF, 1, false);
            if (!gen && svc.chatUserOnline(id)) p.roundRect(x + 13, iy + 10, 5, 5, 2, th.ok());
            int un = svc.chatUnread(id);
            int nw = un > 0 ? 14 : 0;
            p.drawText(x + 21, iy + 4, PixelScreen.fit(gen ? "Общий" : id, LW - 28 - nw, 1, false), th.text());
            if (un > 0) {
                p.roundRect(x + LW - 18, iy + 3, 14, 10, 5, th.accent());
                p.drawTextCentered(x + LW - 18, 14, iy + 4, un > 9 ? "9+" : "" + un, th.onAccent(), 1, false);
            }
        }
        WinSoft.scrollbar(p, th, x + LW - 4, y + HEAD, rows * IH, ps.size(), rows, lsc);
        p.drawText(x + 6, y + h - 28, PixelScreen.fit(svc.chatNick(), LW - 12, 1, false), th.sub());
        bOut.x = x + 4;
        bOut.w = LW - 8;
        bOut.h = 14;
        bOut.y = y + h - 17;
        bOut.hover = hoverBtn == 2;
        bOut.draw(p, th);
        // заголовок диалога
        int px = x + LW + 1, pw = w - LW - 1;
        p.fillRect(px, y, pw, HEAD - 1, th.bg());
        p.hline(px, y + HEAD - 1, pw, th.border());
        boolean gen = peer.equals(GEN);
        p.drawText(px + 8, y + 5, gen ? "Общий чат" : peer, th.text(), 1, true);
        String stat = !svc.chatOnline() ? "нет связи" : gen ? (svc.chatUsers().size() + 1) + " участн." : svc.chatUserOnline(peer) ? "в сети" : "не в сети";
        p.drawTextRight(px + pw - 6, y + 5, stat, !svc.chatOnline() ? th.bad() : th.sub(), 1, false);
        // сообщения
        int top = y + HEAD, bot = y + h - INP;
        p.pushClip(px, top, pw, bot - top);
        List<WinSvc.Msg> ms = svc.chatThread(peer);
        int bw = pw - 24, tw = bw - 10;
        List<int[]> geo = new ArrayList<int[]>();
        List<List<String>> lines = new ArrayList<List<String>>();
        int total = 4;
        for (WinSvc.Msg m : ms) {
            List<String> ls = WinSoft.wrap(m.text, tw);
            lines.add(ls);
            int hh = 6 + ls.size() * 10 + 10 + (gen && !m.mine ? 10 : 0);
            geo.add(new int[] {hh});
            total += hh + 3;
        }
        maxSc = Math.max(0, total - (bot - top));
        sc = Math.max(0, Math.min(maxSc, sc));
        int yy = bot - 2 + sc;
        for (int i = ms.size() - 1; i >= 0; i--) {
            WinSvc.Msg m = ms.get(i);
            List<String> ls = lines.get(i);
            int hh = geo.get(i)[0];
            yy -= hh + 3;
            if (yy + hh < top || yy > bot) continue;
            int mw = 0;
            for (String ln : ls) mw = Math.max(mw, PixelScreen.textWidth(ln));
            mw = Math.max(mw, PixelScreen.textWidth(hhmm(m.time)) + 4);
            if (gen && !m.mine) mw = Math.max(mw, PixelScreen.textWidth(m.from));
            mw = Math.min(bw, mw + 10);
            int bx = m.mine ? px + pw - 8 - mw : px + 6;
            int fillc = m.mine ? th.accent() : th.surface();
            if (m.mine) p.roundRect(bx, yy, mw, hh, 5, fillc);
            else p.roundRectBorder(bx, yy, mw, hh, 5, fillc, th.border());
            int tc = m.mine ? th.onAccent() : th.text(), sc2 = m.mine ? PixelScreen.alpha(th.onAccent(), 0xC0) : th.sub();
            int ty = yy + 4;
            if (gen && !m.mine) {
                p.drawText(bx + 5, ty, m.from, th.accent(), 1, true);
                ty += 10;
            }
            for (String ln : ls) {
                p.drawText(bx + 5, ty, ln, tc);
                ty += 10;
            }
            p.drawTextRight(bx + mw - 5, ty, hhmm(m.time), sc2, 1, false);
        }
        if (ms.isEmpty()) p.drawTextCentered(px, pw, top + (bot - top) / 2 - 4, "Сообщений пока нет", th.sub(), 1, false);
        p.popClip();
        WinSoft.scrollbar(p, th, x + w - 4, top + 2, bot - top - 4, total, bot - top, maxSc - sc);
        // ввод
        int iy = y + h - INP;
        p.hline(px, iy, pw, th.border());
        if (!err.isEmpty()) p.drawText(px + 6, iy - 10, PixelScreen.fit(err, pw - 12, 1, false), th.bad());
        fMsg.x = px + 4;
        fMsg.y = iy + 3;
        fMsg.w = pw - 50;
        fMsg.h = 16;
        fMsg.draw(p, th, true, s.host.time());
        bSend.x = px + pw - 44;
        bSend.y = iy + 3;
        bSend.hover = hoverBtn == 3;
        bSend.enabled = fMsg.sb.length() > 0 && svc.chatOnline();
        bSend.draw(p, th);
    }

    // ------------------------------------------------------------------ действия
    private void doLogin(boolean reg) {
        String n = fNick.sb.toString(), pw = fPass.sb.toString();
        String e = reg ? svc.chatRegister(n, pw) : svc.chatLogin(n, pw);
        err = e == null ? "" : e;
        if (e == null) {
            fPass.sb.setLength(0);
            peer = GEN;
            sc = 0;
            fMsg.sb.setLength(0);
        }
    }

    private void send() {
        if (fMsg.sb.length() == 0) return;
        String e = svc.chatSend(peer, fMsg.sb.toString());
        err = e == null ? "" : e;
        if (e == null) {
            fMsg.sb.setLength(0);
            sc = 0;
        }
    }

    private void select(String id) {
        peer = id;
        sc = 0;
        err = "";
        svc.chatView(peer);
    }

    // ------------------------------------------------------------------ ввод
    private static boolean btn(WinUi.Button b, int ax, int ay) {
        return b.hit(ax, ay);
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int ax = rx + ox, ay = ry + oy;
        int hb = -1, hi = -1;
        if (!loggedIn()) {
            if (btn(bLogin, ax, ay)) hb = 0;
            else if (btn(bReg, ax, ay)) hb = 1;
            else if (linkY >= 0 && ay >= linkY && ay < linkY + 10 && rx > 20 && rx < aw - 20) hb = 9;
        } else {
            if (btn(bOut, ax, ay)) hb = 2;
            else if (btn(bSend, ax, ay)) hb = 3;
            if (rx >= 0 && rx < LW && ry >= HEAD) hi = (ry - HEAD) / IH;
        }
        boolean d = hb != hoverBtn || hi != hoverItem;
        hoverBtn = hb;
        hoverItem = hi;
        if (loggedIn() && (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN)) {
            int dir = kind == PixelScreen.MOUSE_SCROLL_UP ? 1 : -1;
            if (rx < LW) {
                lsc = Math.max(0, lsc - dir);
            } else {
                sc = Math.max(0, Math.min(maxSc, sc + dir * 20));
            }
            return true;
        }
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return d;
        if (!loggedIn()) {
            if (hb == 0) doLogin(false);
            else if (hb == 1) doLogin(true);
            else if (hb == 9) {
                svc.chatNextServer();
                err = "";
            } else if (fNick.hit(ax, ay)) focus = 0;
            else if (fPass.hit(ax, ay)) focus = 1;
            return true;
        }
        if (hb == 2) {
            svc.chatLogout();
            err = "";
            return true;
        }
        if (hb == 3) {
            send();
            return true;
        }
        if (hi >= 0) {
            List<String> ps = peers();
            if (lsc + hi < ps.size() && ry < ah - 30) select(ps.get(lsc + hi));
        }
        return true;
    }

    @Override
    public boolean key(char c, int key) {
        if (!loggedIn()) {
            if (key == WinUi.K_TAB || key == WinUi.K_UP || key == WinUi.K_DOWN) {
                focus = 1 - focus;
                return true;
            }
            WinUi.Field f = focus == 0 ? fNick : fPass;
            if (focus == 0 && c >= 'A' && c <= 'Z') c = (char) (c + 32);
            if (c >= 32 && (c > 126)) return false;
            if (f.key(c, key)) {
                if (focus == 0) focus = 1;
                else doLogin(false);
            }
            if (!err.isEmpty() && c >= 32) err = "";
            return true;
        }
        if (key == WinUi.K_TAB) {
            List<String> ps = peers();
            select(ps.get((ps.indexOf(peer) + 1) % ps.size()));
            return true;
        }
        if (key == WinSoft.K_PGUP) {
            sc = Math.min(maxSc, sc + 40);
            return true;
        }
        if (key == WinSoft.K_PGDN) {
            sc = Math.max(0, sc - 40);
            return true;
        }
        if (key == WinSoft.K_UP || key == WinSoft.K_DOWN) {
            sc = Math.max(0, Math.min(maxSc, sc + (key == WinSoft.K_UP ? 12 : -12)));
            return true;
        }
        if (c >= 32 && c > 126) return false;
        if (WinUi.isEnter(c, key)) {
            send();
            return true;
        }
        fMsg.key(c, key);
        if (!err.isEmpty() && c >= 32) err = "";
        return true;
    }

    @Override
    public boolean tick(long now) {
        boolean d = now % 10 == 0;
        if (!loggedIn()) return d;
        svc.chatView(peer);
        if (now % 20 == 0 && svc.chatPoll()) d = true;
        int rev = svc.chatRev();
        if (rev != lastRev) {
            lastRev = rev;
            d = true;
        }
        return d;
    }
}
