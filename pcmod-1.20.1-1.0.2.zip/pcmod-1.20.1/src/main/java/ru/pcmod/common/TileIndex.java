package ru.pcmod.common;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Серверный индекс загруженных блок-сущностей одного типа по измерениям (вышки, глушилки) — без обращения к чанкам. */
public final class TileIndex<T extends BlockEntity> {
    private final Map<ResourceKey<Level>, Set<T>> map = new ConcurrentHashMap<>();

    public void add(T t) {
        Level l = t.getLevel();
        if (l != null && !l.isClientSide) map.computeIfAbsent(l.dimension(), k -> ConcurrentHashMap.newKeySet()).add(t);
    }

    public void remove(T t) {
        Level l = t.getLevel();
        if (l == null) return;
        Set<T> s = map.get(l.dimension());
        if (s != null) s.remove(t);
    }

    public Collection<T> in(Level l) {
        if (l == null || l.isClientSide) return Collections.emptyList();
        Set<T> s = map.get(l.dimension());
        return s == null ? Collections.emptyList() : s;
    }
}
