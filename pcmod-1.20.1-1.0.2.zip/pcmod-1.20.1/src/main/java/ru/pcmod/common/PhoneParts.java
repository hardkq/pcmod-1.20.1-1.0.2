package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;
import ru.pcmod.common.PartSpec.Cat;

/** Слоты стола сборки, проверка совместимости комплектующих телефона и сборка предмета «Телефон» (NBT "Parts"). */
public final class PhoneParts {
    public static final int SOC = 0, RAM1 = 1, RAM2 = 2, ROM = 3, BATT = 4, SCREEN = 5, CAM = 6, BOARD = 7, CASE = 8, MODEM = 9;
    /** Число входных слотов; слот IN (индекс 10) - выход. */
    public static final int IN = 10, OUT = 10;
    public static final Cat[] CAT = {Cat.PH_SOC, Cat.PH_RAM, Cat.PH_RAM, Cat.PH_ROM, Cat.PH_BATT, Cat.PH_SCREEN, Cat.PH_CAM, Cat.PH_BOARD, Cat.PH_CASE, Cat.PH_MODEM};
    public static final String[] KEY = {"soc", "ram", "ram", "rom", "battery", "screen", "camera", "board", "case", "modem"};
    /** Начальный заряд собранного телефона, %. */
    public static final int START_CHARGE_PCT = 20;

    public static PartSpec spec(ItemStack s) {
        return s != null && !s.isEmpty() && s.getItem() instanceof ItemPart p ? p.spec : null;
    }

    private static Component slotName(int i) { return Component.translatable("gui.pcmod.phone.slot." + KEY[i]); }
    private static Component err(String k) { return Component.translatable("gui.pcmod.phone.err." + k); }

    /** Список проблем (пустой = можно собирать). Работает одинаково на клиенте (для GUI) и на сервере (для сборки). Камера необязательна. */
    public static List<Component> check(Container c) {
        List<Component> e = new ArrayList<Component>();
        PartSpec soc = spec(c.getItem(SOC)), rom = spec(c.getItem(ROM)), bat = spec(c.getItem(BATT)), scr = spec(c.getItem(SCREEN)),
                 brd = spec(c.getItem(BOARD)), cas = spec(c.getItem(CASE)), mod = spec(c.getItem(MODEM));
        PartSpec r1 = spec(c.getItem(RAM1)), r2 = spec(c.getItem(RAM2));
        Object[] need = {soc, r1 != null ? r1 : r2, null, rom, bat, scr, null, brd, cas, mod};
        for (int i = 0; i < IN; i++) {
            if (i == RAM2 || i == CAM) continue;
            if (need[i] == null) e.add(Component.translatable("gui.pcmod.phone.missing", slotName(i)));
        }
        if (soc != null && brd != null && soc.socket != brd.socket) e.add(err("platform"));
        if (brd != null) {
            if (r1 != null && r1.ramType != brd.ramType || r2 != null && r2.ramType != brd.ramType) e.add(err("ram_type"));
            if (r1 != null && r2 != null && r1.ramType != r2.ramType) e.add(err("ram_mix"));
            if (r1 != null && r2 != null && brd.ramSlots < 2) e.add(err("ram_slots"));
            if (mod != null && mod.net > brd.net) e.add(err("modem_net"));
            if (cas != null && brd.size > cas.size) e.add(err("board_size"));
        }
        if (cas != null) {
            if (scr != null && scr.size != cas.size) e.add(err("screen_size"));
            if (bat != null && bat.mah > cas.mah) e.add(err("batt_cap"));
            if (bat != null && bat.size > cas.size) e.add(err("batt_size"));
        }
        return e;
    }

    /** Собрать телефон из слотов 0..IN-1 (вызывать после check == пусто). Детали копируются в NBT "Parts". */
    public static ItemStack build(Container c) {
        ItemStack ph = new ItemStack(ModItems.PHONE.get());
        ListTag l = new ListTag();
        for (int i = 0; i < IN; i++) {
            ItemStack s = c.getItem(i);
            if (s.isEmpty()) continue;
            CompoundTag ct = new CompoundTag();
            s.save(ct);
            l.add(ct);
        }
        CompoundTag t = ph.getOrCreateTag();
        t.put("Parts", l);
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(c.getItem(CASE).getItem());
        t.putString("Model", id == null ? "" : id.getPath());
        PartSpec bat = spec(c.getItem(BATT));
        t.putInt("Charge", bat == null ? 0 : bat.mah * START_CHARGE_PCT / 100);
        return ph;
    }

    private PhoneParts() {}
}
