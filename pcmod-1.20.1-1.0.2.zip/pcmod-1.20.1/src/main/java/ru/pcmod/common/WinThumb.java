package ru.pcmod.common;

/** Уменьшенный снимок окна для Alt+Tab и «Представления задач» (усреднение по площади, непрозрачный). */
final class WinThumb {
    final int w, h;
    final int[] px;

    private WinThumb(int w, int h) {
        this.w = w;
        this.h = h;
        this.px = new int[w * h];
    }

    /** Размер снимка окна sw x sh, вписанного в mw x mh без увеличения: {w, h}. */
    static int[] fit(int sw, int sh, int mw, int mh) {
        double s = Math.min(1.0, Math.min(mw / (double) Math.max(1, sw), mh / (double) Math.max(1, sh)));
        return new int[] {Math.max(1, (int) Math.round(sw * s)), Math.max(1, (int) Math.round(sh * s))};
    }

    /** Область (sx, sy, sw, sh) экрана src, сжатая до tw x th; за пределами экрана - цвет fill. */
    static WinThumb of(PixelScreen src, int sx, int sy, int sw, int sh, int tw, int th, int fill) {
        WinThumb t = new WinThumb(tw, th);
        int W = PixelScreen.W, H = PixelScreen.H;
        for (int j = 0; j < th; j++) {
            int y0 = sy + j * sh / th, y1 = Math.max(y0 + 1, sy + (j + 1) * sh / th);
            for (int i = 0; i < tw; i++) {
                int x0 = sx + i * sw / tw, x1 = Math.max(x0 + 1, sx + (i + 1) * sw / tw);
                int r = 0, g = 0, b = 0, n = 0;
                for (int y = y0; y < y1; y++) {
                    for (int x = x0; x < x1; x++) {
                        int c = x < 0 || y < 0 || x >= W || y >= H ? fill : src.px[y * W + x];
                        r += c >> 16 & 255;
                        g += c >> 8 & 255;
                        b += c & 255;
                        n++;
                    }
                }
                t.px[j * tw + i] = 0xFF000000 | (r / n) << 16 | (g / n) << 8 | b / n;
            }
        }
        return t;
    }

    void draw(PixelScreen p, int x, int y) {
        p.blit(px, w, h, x, y);
    }
}
