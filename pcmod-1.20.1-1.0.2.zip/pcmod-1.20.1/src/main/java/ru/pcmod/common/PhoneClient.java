package ru.pcmod.common;

/** Клиентский кадр экрана телефона (обновляется PacketPhonePixels, рисуется GuiPhone). Только данные, на сервере не используется. */
public final class PhoneClient {
    public static final PixelScreen PIX = new PixelScreen(true);
    private PhoneClient() {}
}
