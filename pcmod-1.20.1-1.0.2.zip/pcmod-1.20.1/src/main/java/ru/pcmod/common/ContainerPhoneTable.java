package ru.pcmod.common;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Меню стола сборки: 10 слотов деталей, выход, инвентарь. Кнопка «Собрать» - clickMenuButton(0). */
public class ContainerPhoneTable extends ContainerBlank {
    public static final int HEIGHT = 232, INV_X = 19, INV_Y = 150, HOTBAR_Y = 208;
    /** Позиции слотов по индексам PhoneParts (SOC, RAM1, RAM2, ROM, BATT, SCREEN, CAM, BOARD, CASE, MODEM, OUT). */
    public static final int[] X = {10, 40, 60, 90, 120, 40, 150, 10, 70, 100, 166};
    public static final int[] Y = {28, 28, 28, 28, 28, 64, 28, 64, 64, 64, 64};

    public final TilePhoneTable table;

    public ContainerPhoneTable(int id, Inventory inv, BlockEntity te) {
        super(ModMenus.PHONE_TABLE.get(), id, te);
        this.table = (TilePhoneTable) te;
        for (int i = 0; i < TilePhoneTable.SIZE; i++) addSlot(new SlotMiner(table, i, X[i], Y[i]));
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c + r * 9 + 9, INV_X + c * 18, INV_Y + r * 18));
        }
        for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c, INV_X + c * 18, HOTBAR_Y));
    }

    public ContainerPhoneTable(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, inv.player.level().getBlockEntity(buf.readBlockPos()));
    }

    @Override
    public boolean clickMenuButton(Player p, int id) {
        if (table.getLevel() == null || table.getLevel().isClientSide) return false;
        if (id == 0) p.displayClientMessage(table.assemble(), true);
        return true;
    }

    @Override
    public net.minecraft.world.item.ItemStack quickMoveStack(Player p, int idx) {
        return quickMoveOwn(p, idx, TilePhoneTable.SIZE);
    }
}
