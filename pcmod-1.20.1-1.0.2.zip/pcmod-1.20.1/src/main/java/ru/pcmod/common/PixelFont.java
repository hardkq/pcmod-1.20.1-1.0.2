package ru.pcmod.common;

/**
 * Пиксельный шрифт для PixelScreen: ASCII, кириллица (А-Я, а-я, Ё, ё), °, •.
 * Исходная сетка 6x9 (шрифт X11 misc-fixed 6x9, public domain), ширина символа подгоняется под глиф (пропорциональный).
 * Бит (y * 6 + x) набора = пиксель глифа.
 */
public final class PixelFont {
    public static final int H = 9, SPACE = 3, CELL = 6;

    private static final long[] ASCII = {
        0x0L, 0x4004104100L, 0x28A280L, 0x28A7CA7CA280L, 0x439550E155384L, 0x42A484212542L,
        0x589646249180L, 0x104100L, 0x204104104200L, 0x108208208100L, 0x1129F291000L, 0x411F104000L,
        0x4208300000000L, 0x1F000000L, 0xC300000000L, 0x2084210400L, 0xC492492300L, 0xE104106100L,
        0x1E108412300L, 0xE410308780L, 0x87C928C200L, 0xE410382780L, 0xC492382300L, 0x4108410780L,
        0xC492312300L, 0xC41C492300L, 0xC30030C000L, 0x420830030C000L, 0x18181198000L, 0x7C07C0000L,
        0x3310303000L, 0x400431048CL, 0xE04D549380L, 0x1145F44A100L, 0xF4513D13C0L, 0xC482092300L,
        0xE492492380L, 0x1E082382780L, 0x2082382780L, 0xC49A092300L, 0x12492792480L, 0xE104104380L,
        0x6248208700L, 0x1248A18A480L, 0x1E082082080L, 0x1145555B440L, 0x12492696480L, 0xE451451380L,
        0x208E492380L, 0x40C696492300L, 0x1248E492380L, 0xC488112300L, 0x41041047C0L, 0xC492492480L,
        0xC31E492480L, 0x116D5551440L, 0x1128410A440L, 0x4104291440L, 0x1E084210780L, 0xE082082380L,
        0x10408102080L, 0xE208208380L, 0x44A100L, 0x1F000000000000L, 0x8100L, 0x1C492700000L,
        0xE492382080L, 0x1C082700000L, 0x1C492710400L, 0x1C19A300000L, 0x410E114200L, 0xC41C492300000L,
        0x12492382080L, 0xE104180100L, 0x4288208300200L, 0x12286282080L, 0xE104104180L, 0x115552C0000L,
        0x12492380000L, 0xC492300000L, 0x208E492380000L, 0x1041C492700000L, 0x2096280000L, 0xE606700000L,
        0x8504384100L, 0x1C492480000L, 0xC312480000L, 0xA555440000L, 0x1230C480000L, 0xC49C492480000L,
        0x1E108780000L, 0x8104084108L, 0x104104104100L, 0x2104204102L, 0x294000L
    };
    private static final long[] CYR = {
        0x1145F44A100L, 0xF4513C13C0L, 0xF4513D13C0L, 0x2082082780L, 0x45F28A28A300L, 0x1E082382780L,
        0x15555395540L, 0xE450311380L, 0x12496692480L, 0x1249669248CL, 0x1248A18A480L, 0x11492492700L,
        0x1145555B440L, 0x12492792480L, 0xE451451380L, 0x114514517C0L, 0x208E492380L, 0xC482092300L,
        0x41041047C0L, 0xE41E451440L, 0x439554E100L, 0x1128410A440L, 0x841F249249240L, 0x1041E451440L,
        0x1F555555540L, 0x841F555555540L, 0xE4923820C0L, 0x176595D1440L, 0xE492382080L, 0xE450711380L,
        0x95575D5240L, 0x1249C492700L, 0x1E249380000L, 0xC492382310L, 0xE58A180000L, 0x2082780000L,
        0x45F28A300000L, 0xE1C9180000L, 0x1538E540000L, 0xE614300000L, 0x13559440000L, 0x13559444280L,
        0x1238A480000L, 0x11492700000L, 0x1155B440000L, 0x1145F440000L, 0xE451380000L, 0x114517C0000L,
        0x104F4513C0000L, 0x1E051380000L, 0x41047C0000L, 0xE41E451440000L, 0x410E555384100L, 0x1230C480000L,
        0x841F249240000L, 0x10791440000L, 0x1F555540000L, 0x841F555540000L, 0xE48E0C0000L, 0x17657440000L,
        0xE48E080000L, 0x730A1C0000L, 0x95D7240000L, 0x9389380000L
    };
    private static final long[] EXTRA = {
        0x1E08E09E014L, 0x1C392300280L, 0xC48C000L, 0x31E78C000L
    };

    private static final long[] G = new long[ASCII.length + CYR.length + EXTRA.length];
    private static final int[] LEFT = new int[G.length], ADV = new int[G.length];

    static {
        System.arraycopy(ASCII, 0, G, 0, ASCII.length);
        System.arraycopy(CYR, 0, G, ASCII.length, CYR.length);
        System.arraycopy(EXTRA, 0, G, ASCII.length + CYR.length, EXTRA.length);
        for (int i = 0; i < G.length; i++) {
            int mn = CELL, mx = -1;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < CELL; x++)
                    if ((G[i] >> (y * CELL + x) & 1L) != 0) {
                        if (x < mn) mn = x;
                        if (x > mx) mx = x;
                    }
            if (mx < 0) { LEFT[i] = 0; ADV[i] = SPACE; }
            else { LEFT[i] = mn; ADV[i] = mx - mn + 2; }
        }
    }

    private PixelFont() {}

    /** Номер глифа для символа; неизвестные символы превращаются в '?'. */
    public static int index(char c) {
        if (c >= 32 && c < 127) return c - 32;
        if (c >= 0x410 && c <= 0x44F) return ASCII.length + (c - 0x410);
        int e = ASCII.length + CYR.length;
        switch (c) {
            case 0x401: return e;
            case 0x451: return e + 1;
            case 0xB0: return e + 2;
            case 0x2022: case 0x2219: case 0xB7: return e + 3;
            case 0xA0: return 0;
            case 0x2013: case 0x2014: case 0x2212: return '-' - 32;
            case 0xAB: case 0xBB: case 0x201C: case 0x201D: return '"' - 32;
            case 0x2018: case 0x2019: return '\'' - 32;
            case 0x2026: return '.' - 32;
            case 0x2116: return 'N' - 32;
            default: return '?' - 32;
        }
    }

    public static long bits(int idx) { return G[idx]; }
    /** Первый занятый столбец глифа в сетке 6x9. */
    public static int left(int idx) { return LEFT[idx]; }
    /** Шаг до следующего символа (ширина глифа + 1 пиксель промежутка). */
    public static int advance(int idx) { return ADV[idx]; }
}
