package ru.pcmod.common;

import java.util.List;

/** Графический BIOS (UEFI) компьютера с установленной WinCraft 11 или её установочным диском. Те же настройки, что в текстовом BIOS. */
public final class WinBios extends WinScene {
    private static final int W = PixelScreen.W, H = PixelScreen.H;
    private static final int BG = 0xFF11161D, BAR = 0xFF1B2330, CARD = 0xFF1D2531, LINE = 0xFF2E394A, TXT = 0xFFE6EBF2, SUB = 0xFF8E9BAE;
    private static final String[] TABS = {"Main", "Boot", "Monitor", "Exit"};
    private static final String[] EXIT = {"Save changes and exit", "Discard changes and exit", "Load setup defaults"};

    private int tab, sel, order;
    private boolean fast;
    private final int[] tabX = new int[4], tabW = new int[4];

    public WinBios(WinHost h) {
        super(h);
        th.dark = true;
        order = h.bootOrder();
        fast = h.fastBoot();
        int x = 10;
        for (int i = 0; i < 4; i++) {
            tabW[i] = PixelScreen.textWidth(TABS[i]) + 18;
            tabX[i] = x;
            x += tabW[i] + 4;
        }
    }

    public void begin() {
        activate();
        redraw(this::drawAll);
    }

    private int maxSel() {
        return tab == 1 ? 2 : tab == 3 ? 3 : 0;
    }

    private void setTab(int t) {
        tab = (t + 4) % 4;
        sel = 0;
        redraw(this::drawAll);
    }

    private void activate(int s) {
        if (tab == 1) {
            if (s == 0) order = 1 - order;
            else if (s == 1) fast = !fast;
            redraw(this::drawContent);
        } else if (tab == 3) {
            if (s == 0) {
                dead = true;
                h.saveBios(order, fast);
            } else if (s == 1) {
                dead = true;
                h.restart();
            } else {
                order = 0;
                fast = false;
                redraw(this::drawContent);
            }
        }
    }

    public void tick() {
        if (dead) return;
        long now = h.time();
        if (tab == 2 && now % 10 == 0) redraw(this::drawContent);
        else if (tab == 0 && now % 40 == 0) redraw(this::drawContent);
    }

    public void key(char c, int key) {
        if (dead) return;
        if (key == WinUi.K_LEFT) setTab(tab - 1);
        else if (key == WinUi.K_RIGHT) setTab(tab + 1);
        else if (key == WinUi.K_UP) {
            sel = Math.max(0, sel - 1);
            redraw(this::drawContent);
        } else if (key == WinUi.K_DOWN) {
            sel = Math.max(0, Math.min(maxSel() - 1, sel + 1));
            redraw(this::drawContent);
        } else if (key == WinUi.K_F10) {
            dead = true;
            h.saveBios(order, fast);
        } else if (WinUi.isEnter(c, key)) {
            activate(sel);
        }
    }

    // ------------------------------------------------------------------ мышь
    private int rowAt(int x, int y) {
        if (tab == 1 && x >= 10 && x < W - 10) {
            for (int i = 0; i < 2; i++) if (y >= 46 + i * 28 && y < 46 + i * 28 + 24) return i;
        }
        if (tab == 3 && x >= 10 && x < 190) {
            for (int i = 0; i < 3; i++) if (y >= 46 + i * 26 && y < 46 + i * 26 + 20) return i;
        }
        return -1;
    }

    @Override
    void onMouse(int btn, int kind) {
        boolean press = kind == PixelScreen.MOUSE_PRESS && btn == 0;
        if (press && my >= 20 && my < 38) {
            for (int i = 0; i < 4; i++) {
                if (mx >= tabX[i] && mx < tabX[i] + tabW[i]) {
                    setTab(i);
                    return;
                }
            }
        }
        int r = rowAt(mx, my);
        if (r >= 0 && r != sel) {
            sel = r;
            redraw(this::drawContent);
        }
        if (press && r >= 0) activate(r);
    }

    // ------------------------------------------------------------------ рисование
    private void drawAll() {
        p.fillRect(0, 0, W, H, BG);
        p.fillRect(0, 0, W, 17, BAR);
        WinGfx.logo(p, 8, 4, 9, 0xFF3C9BFF);
        p.drawText(22, 4, "PCM UEFI Setup Utility", TXT, 1, true);
        p.drawTextRight(W - 8, 4, WinClock.time(h.dayTime()), SUB, 1, false);
        for (int i = 0; i < 4; i++) {
            if (i == tab) p.roundRect(tabX[i], 21, tabW[i], 16, 4, th.accent());
            p.drawTextCentered(tabX[i], tabW[i], 25, TABS[i], i == tab ? 0xFFFFFFFF : SUB, 1, false);
        }
        p.hline(0, 39, W, LINE);
        p.hline(0, H - 14, W, LINE);
        p.drawText(8, H - 10, "Left/Right: tabs   Up/Down: select   Enter: change   F10: save & exit", SUB);
        drawContent();
    }

    private void drawContent() {
        p.fillRect(0, 40, W, H - 54, BG);
        switch (tab) {
            case 0: rows(h.biosMain()); break;
            case 2: rows(h.biosMonitor()); break;
            case 1: drawBoot(); break;
            default: drawExit(); break;
        }
    }

    private void rows(List<String[]> list) {
        int y = 44;
        for (String[] r : list) {
            int vc = r.length > 2 && r[2].equals("bad") ? 0xFFFF8A8A : r.length > 2 && r[2].equals("warn") ? 0xFFFFD166 : TXT;
            p.drawText(12, y, r[0], SUB);
            p.drawText(100, y, PixelScreen.fit(r[1], W - 110, 1, false), vc);
            y += 11;
        }
    }

    private void card(int y, int hgt, boolean on) {
        p.roundRectBorder(10, y, W - 20, hgt, 4, CARD, on ? th.accent() : LINE);
    }

    private void drawBoot() {
        card(46, 24, sel == 0);
        p.drawText(20, 54, "1st boot device", TXT);
        p.drawTextRight(W - 20, 54, order == 0 ? "Storage drive" : "Boot media", 0xFF6CB6FF, 1, false);
        card(74, 24, sel == 1);
        p.drawText(20, 82, "Fast boot", TXT);
        p.roundRect(W - 52, 79, 30, 14, 7, fast ? th.accent() : 0xFF4A5568);
        p.roundRect(fast ? W - 36 : W - 50, 81, 10, 10, 5, 0xFFFFFFFF);
        p.drawText(12, 108, "Enter or click toggles the selected option.", SUB);
        p.drawText(12, 120, "Changes apply after Save & Exit (F10).", SUB);
    }

    private void drawExit() {
        for (int i = 0; i < 3; i++) {
            int y = 46 + i * 26;
            p.roundRectBorder(10, y, 180, 20, 4, i == sel ? th.accent() : CARD, i == sel ? th.accent() : LINE);
            p.drawText(20, y + 6, EXIT[i], i == sel ? 0xFFFFFFFF : TXT);
        }
    }
}
