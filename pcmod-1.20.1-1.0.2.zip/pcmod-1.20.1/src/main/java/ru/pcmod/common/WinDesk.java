package ru.pcmod.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Значки (ярлыки) на рабочем столе WinCraft 11: выделение щелчком и рамкой, перемещение мышью с привязкой к сетке,
 * двойной щелчок запускает приложение, контекстные меню ПКМ, переименование (F2), удаление (Delete).
 * Раскладка хранится на накопителе (WinHost.pref). Методы ввода возвращают область {x, y, w, h} для перерисовки.
 */
public final class WinDesk {
    static final int W = PixelScreen.W;
    private static final int DOUBLE = 8, MARGIN = 2, MAX_LABEL = 24, MAX_ITEMS = 40;
    private static final int A_OPEN = 1, A_REN = 2, A_DEL = 3, A_SIZE = 4, A_SORT = 5, A_GRID = 6, A_SHOW = 7, A_NEW = 8, A_REFRESH = 9, A_PERS = 10, A_MAKE = 100;
    private static final int K_ESC = 1, K_F2 = 60, K_DEL = 211;
    private static final String PREF = "desk";

    /** Связь рабочего стола с системой. */
    public interface Host {
        /** Запустить приложение; возвращает область перерисовки или null. */
        int[] open(String appId);

        String pref(String key);

        void setPref(String key, String value);
    }

    private static final class Item {
        String app, label;
        int x, y, ox, oy;
        boolean sel;
    }

    private final WinTheme th;
    private final boolean effects;
    private final WinApps apps;
    private final Host host;
    private final List<Item> items = new ArrayList<Item>();
    private final Set<String> removed = new HashSet<String>();

    private boolean loaded, large = true, grid = true, show = true;
    private Item hov, pressItem, lastItem, ren;
    private final StringBuilder rsb = new StringBuilder();
    private boolean dragging, band, renAll;
    private int pressX, pressY, bx, by, bx2, by2, menuX, menuY;
    private long lastAt;
    private WinUi.Menu menu;
    private int[] acts = new int[0];

    public WinDesk(WinTheme th, boolean effects, WinApps apps, Host host) {
        this.th = th;
        this.effects = effects;
        this.apps = apps;
        this.host = host;
    }

    // ================================================================== размеры
    private int cw() { return large ? 56 : 44; }

    private int ch() { return large ? 48 : 38; }

    private int isz() { return large ? 24 : 16; }

    private int cols() { return Math.max(1, (W - MARGIN) / cw()); }

    private int rows() { return Math.max(1, (WinWm.workH() - MARGIN) / ch()); }

    private int gx(int c) { return MARGIN + c * cw(); }

    private int gy(int r) { return MARGIN + r * ch(); }

    private int colOf(int x) { return Math.max(0, Math.min(cols() - 1, Math.round((x - MARGIN) / (float) cw()))); }

    private int rowOf(int y) { return Math.max(0, Math.min(rows() - 1, Math.round((y - MARGIN) / (float) ch()))); }

    private static int[] union(int[] a, int[] b) {
        return WinWm.union(a, b);
    }

    private int[] box(Item i) {
        return i == null ? null : new int[] {i.x - 1, i.y - 1, cw() + 2, ch() + 2};
    }

    private static boolean hit(int[] a, int[] clip) {
        return a[0] < clip[0] + clip[2] && a[0] + a[2] > clip[0] && a[1] < clip[1] + clip[3] && a[1] + a[3] > clip[1];
    }

    // ================================================================== состав и сохранение
    /** Прочитать раскладку (один раз) и добавить ярлыки приложений, которых ещё нет на столе. */
    public void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        try {
            String s = host.pref(PREF);
            if (s != null && !s.isEmpty()) {
                String[] parts = s.split("\\|", -1);
                String[] head = parts[0].split(";", -1);
                if (head.length >= 4) {
                    large = head[1].equals("L");
                    grid = head[2].equals("1");
                    show = head[3].equals("1");
                }
                for (int i = 1; i < parts.length && items.size() < MAX_ITEMS; i++) {
                    String e = parts[i];
                    if (e.isEmpty()) continue;
                    if (e.charAt(0) == '!') {
                        removed.add(e.substring(1));
                        continue;
                    }
                    String[] f = e.split("~", -1);
                    if (f.length < 4 || apps.get(f[0]) == null) continue;
                    Item it = new Item();
                    it.app = f[0];
                    it.label = f[1].isEmpty() ? apps.get(f[0]).label : f[1];
                    it.x = Math.max(0, Math.min(W - cw(), Integer.parseInt(f[2])));
                    it.y = Math.max(0, Math.min(WinWm.workH() - ch(), Integer.parseInt(f[3])));
                    items.add(it);
                }
            }
        } catch (RuntimeException e) {
            items.clear();
            removed.clear();
        }
        boolean added = false;
        for (WinApps.Info a : apps.all()) {
            if (!a.desk || removed.contains(a.id) || has(a.id)) continue;
            Item it = new Item();
            it.app = a.id;
            it.label = a.label;
            placeFree(it);
            items.add(it);
            added = true;
        }
        if (added) save();
    }

    private boolean has(String app) {
        for (Item i : items) if (i.app.equals(app)) return true;
        return false;
    }

    private void save() {
        StringBuilder b = new StringBuilder("1;").append(large ? 'L' : 'S').append(';').append(grid ? 1 : 0).append(';').append(show ? 1 : 0);
        for (Item i : items) b.append('|').append(i.app).append('~').append(i.label).append('~').append(i.x).append('~').append(i.y);
        for (String r : removed) b.append("|!").append(r);
        host.setPref(PREF, b.toString());
    }

    /** Закрыть меню, снять выделение и переименование (экран блокировки). */
    public void reset() {
        menu = null;
        ren = null;
        hov = null;
        pressItem = null;
        dragging = false;
        band = false;
        for (Item i : items) i.sel = false;
    }

    // ================================================================== сетка
    private boolean occupied(int c, int r, Set<Item> ignore) {
        for (Item i : items) {
            if (ignore.contains(i)) continue;
            if (colOf(i.x) == c && rowOf(i.y) == r) return true;
        }
        return false;
    }

    /** Ближайшая к (c0, r0) свободная клетка; ignore - элементы, которые не считаются занимающими место. */
    private int[] nearestFree(int c0, int r0, Set<Item> ignore) {
        int[] best = null;
        long bd = Long.MAX_VALUE;
        for (int c = 0; c < cols(); c++) {
            for (int r = 0; r < rows(); r++) {
                if (occupied(c, r, ignore)) continue;
                long d = (long) (c - c0) * (c - c0) * 4 + (long) (r - r0) * (r - r0);
                if (d < bd) {
                    bd = d;
                    best = new int[] {c, r};
                }
            }
        }
        return best == null ? new int[] {Math.min(c0, cols() - 1), Math.min(r0, rows() - 1)} : best;
    }

    /** Первая свободная клетка столбец за столбцом сверху вниз. */
    private void placeFree(Item it) {
        Set<Item> ign = new HashSet<Item>();
        ign.add(it);
        for (int c = 0; c < cols(); c++) {
            for (int r = 0; r < rows(); r++) {
                if (!occupied(c, r, ign)) {
                    it.x = gx(c);
                    it.y = gy(r);
                    return;
                }
            }
        }
        it.x = gx(0);
        it.y = gy(0);
    }

    /** Привязать выбранные значки к сетке (по очереди, не занимая чужие клетки). */
    private void snapSelected() {
        Set<Item> pending = new HashSet<Item>();
        for (Item i : items) if (i.sel) pending.add(i);
        for (Item i : new ArrayList<Item>(pending)) {
            pending.remove(i);
            Set<Item> ign = new HashSet<Item>(pending);
            ign.add(i);
            int[] c = nearestFree(colOf(i.x), rowOf(i.y), ign);
            i.x = gx(c[0]);
            i.y = gy(c[1]);
        }
    }

    private void snapAll() {
        List<Item> order = new ArrayList<Item>(items);
        Collections.sort(order, (a, b) -> a.x != b.x ? a.x - b.x : a.y - b.y);
        Set<Item> pending = new HashSet<Item>(order);
        for (Item i : order) {
            pending.remove(i);
            Set<Item> ign = new HashSet<Item>(pending);
            ign.add(i);
            int[] c = nearestFree(colOf(i.x), rowOf(i.y), ign);
            i.x = gx(c[0]);
            i.y = gy(c[1]);
        }
    }

    private void sortByName() {
        List<Item> order = new ArrayList<Item>(items);
        Collections.sort(order, (a, b) -> a.label.compareToIgnoreCase(b.label));
        int r = rows();
        for (int n = 0; n < order.size(); n++) {
            order.get(n).x = gx(Math.min(cols() - 1, n / r));
            order.get(n).y = gy(n % r);
        }
    }

    // ================================================================== выбор
    private int selCount() {
        int n = 0;
        for (Item i : items) if (i.sel) n++;
        return n;
    }

    private Item itemAt(int mx, int my) {
        if (!show) return null;
        for (int i = items.size() - 1; i >= 0; i--) {
            Item it = items.get(i);
            if (mx >= it.x && my >= it.y && mx < it.x + cw() && my < it.y + ch()) return it;
        }
        return null;
    }

    /** Выделить только it (null - снять выделение). */
    private int[] select(Item only) {
        int[] d = null;
        for (Item i : items) {
            boolean s = i == only;
            if (i.sel != s) {
                i.sel = s;
                d = union(d, box(i));
            }
        }
        return d;
    }

    private int[] bandBox() {
        int x = Math.min(bx, bx2), y = Math.min(by, by2);
        return new int[] {x, y, Math.abs(bx2 - bx) + 1, Math.abs(by2 - by) + 1};
    }

    // ================================================================== ввод
    public boolean busy() { return pressItem != null || band; }

    public boolean menuOpen() { return menu != null && menu.open; }

    public boolean renaming() { return ren != null; }

    /** Указатель ушёл с рабочего стола (над окном или панелью): убрать подсветку. */
    public int[] leave() {
        if (hov == null) return null;
        int[] d = box(hov);
        hov = null;
        return d;
    }

    /** Мышь; surface - указатель над свободным местом рабочего стола. */
    public int[] mouse(int mx, int my, int btn, int kind, long now, boolean surface) {
        if (kind == PixelScreen.MOUSE_DRAG) return dragTo(mx, my);
        if (kind == PixelScreen.MOUSE_RELEASE) return release();
        if (kind != PixelScreen.MOUSE_MOVE && kind != PixelScreen.MOUSE_PRESS) return null;
        int[] d = null;
        Item it = surface ? itemAt(mx, my) : null;
        if (it != hov) {
            d = union(box(hov), box(it));
            hov = it;
        }
        if (kind != PixelScreen.MOUSE_PRESS || !surface) return d;
        if (ren != null) d = union(d, commitRename());
        if (btn == 0) {
            if (it != null) {
                if (!it.sel) d = union(d, select(it));
                pressItem = it;
                pressX = mx;
                pressY = my;
                dragging = false;
                for (Item i : items) {
                    i.ox = i.x;
                    i.oy = i.y;
                }
                if (lastItem == it && now - lastAt <= DOUBLE) {
                    lastItem = null;
                    pressItem = null;
                    return union(d, launch(it));
                }
                lastItem = it;
                lastAt = now;
            } else {
                lastItem = null;
                d = union(d, select(null));
                band = true;
                bx = bx2 = mx;
                by = by2 = my;
            }
        } else if (btn == 1) {
            lastItem = null;
            if (it != null) {
                if (!it.sel) d = union(d, select(it));
                d = union(d, openItemMenu(mx, my));
            } else {
                d = union(d, select(null));
                d = union(d, openDeskMenu(mx, my));
            }
        }
        return d;
    }

    private int[] dragTo(int mx, int my) {
        int[] d = null;
        if (band) {
            d = bandBox();
            bx2 = Math.max(0, Math.min(W - 1, mx));
            by2 = Math.max(0, Math.min(WinWm.workH() - 1, my));
            int[] nb = bandBox();
            d = union(d, nb);
            for (Item i : items) {
                boolean in = show && i.x < nb[0] + nb[2] && i.x + cw() > nb[0] && i.y < nb[1] + nb[3] && i.y + ch() > nb[1];
                if (in != i.sel) {
                    i.sel = in;
                    d = union(d, box(i));
                }
            }
            return d;
        }
        if (pressItem == null) return null;
        if (!dragging && Math.abs(mx - pressX) + Math.abs(my - pressY) < 4) return null;
        dragging = true;
        int dx = mx - pressX, dy = my - pressY;
        int minX = Integer.MAX_VALUE, maxX = 0, minY = Integer.MAX_VALUE, maxY = 0;
        for (Item i : items) {
            if (!i.sel) continue;
            minX = Math.min(minX, i.ox);
            maxX = Math.max(maxX, i.ox);
            minY = Math.min(minY, i.oy);
            maxY = Math.max(maxY, i.oy);
        }
        if (minX == Integer.MAX_VALUE) return null;
        dx = Math.max(-minX, Math.min(W - cw() - maxX, dx));
        dy = Math.max(-minY, Math.min(WinWm.workH() - ch() - maxY, dy));
        for (Item i : items) {
            if (!i.sel) continue;
            d = union(d, box(i));
            i.x = i.ox + dx;
            i.y = i.oy + dy;
            d = union(d, box(i));
        }
        return d;
    }

    private int[] release() {
        int[] d = null;
        if (band) {
            band = false;
            return bandBox();
        }
        if (pressItem == null) return null;
        Item pi = pressItem;
        pressItem = null;
        if (dragging) {
            dragging = false;
            for (Item i : items) if (i.sel) d = union(d, box(i));
            if (grid) snapSelected();
            for (Item i : items) if (i.sel) d = union(d, box(i));
            save();
        } else if (selCount() > 1) {
            d = select(pi);
        }
        return d;
    }

    private int[] launch(Item it) {
        return host.open(it.app);
    }

    // ================================================================== клавиши
    /** Клавиша: переименование, а при hot (нет окна в фокусе) - Enter, F2, Delete, Esc. */
    public int[] key(char c, int key, boolean hot) {
        if (ren != null) {
            int[] b = box(ren);
            if (key == K_ESC) {
                ren = null;
            } else if (WinUi.isEnter(c, key)) {
                return commitRename();
            } else if (key == WinUi.K_BACK || c == '\b') {
                if (renAll) rsb.setLength(0);
                else if (rsb.length() > 0) rsb.setLength(rsb.length() - 1);
                renAll = false;
            } else if (c >= 32 && c != 127 && c != '|' && c != '~' && c != ';') {
                if (renAll) rsb.setLength(0);
                renAll = false;
                if (rsb.length() < MAX_LABEL) rsb.append(c);
            }
            return b;
        }
        if (menuOpen() && key == K_ESC) {
            int[] b = menu.box();
            menu = null;
            return b;
        }
        if (!hot) return null;
        Item one = null;
        int n = 0;
        for (Item i : items) {
            if (i.sel) {
                one = i;
                n++;
            }
        }
        if (key == K_ESC) return select(null);
        if (n == 0) return null;
        if (WinUi.isEnter(c, key)) {
            int[] d = null;
            for (Item i : new ArrayList<Item>(items)) if (i.sel) d = union(d, launch(i));
            return d;
        }
        if (key == K_DEL) return deleteSelected();
        if (key == K_F2 && n == 1) return startRename(one);
        return null;
    }

    private int[] startRename(Item it) {
        ren = it;
        rsb.setLength(0);
        rsb.append(it.label);
        renAll = true;
        return box(it);
    }

    private int[] commitRename() {
        Item it = ren;
        ren = null;
        if (it == null) return null;
        String s = rsb.toString().trim();
        if (!s.isEmpty()) {
            it.label = s;
            save();
        }
        return box(it);
    }

    private int[] deleteSelected() {
        int[] d = null;
        for (Item i : new ArrayList<Item>(items)) {
            if (!i.sel) continue;
            d = union(d, box(i));
            items.remove(i);
            if (i == hov) hov = null;
            WinApps.Info a = apps.get(i.app);
            if (a != null && a.desk && !has(i.app)) removed.add(i.app);
        }
        save();
        return d;
    }

    // ================================================================== контекстные меню
    private int[] openItemMenu(int mx, int my) {
        boolean one = selCount() == 1;
        String[] labels = one ? new String[] {"Открыть", "Переименовать", "Удалить"} : new String[] {"Открыть", "Удалить"};
        acts = one ? new int[] {A_OPEN, A_REN, A_DEL} : new int[] {A_OPEN, A_DEL};
        return showMenu(new WinUi.Menu(labels), mx, my);
    }

    private int[] openDeskMenu(int mx, int my) {
        String[] labels = {large ? "Мелкие значки" : "Крупные значки", "Упорядочить по имени",
                grid ? "Свободное размещение" : "Выровнять по сетке", show ? "Скрыть значки" : "Показать значки",
                "Создать ярлык...", "Обновить", "Персонализация"};
        acts = new int[] {A_SIZE, A_SORT, A_GRID, A_SHOW, A_NEW, A_REFRESH, A_PERS};
        menuX = mx;
        menuY = my;
        return showMenu(new WinUi.Menu(labels), mx, my);
    }

    private int[] showMenu(WinUi.Menu m, int mx, int my) {
        int[] old = menu == null ? null : menu.box();
        menu = m;
        m.openAt(mx, my);
        return union(old, m.box());
    }

    /** Список приложений для нового ярлыка. */
    private int[] openNewMenu() {
        List<WinApps.Info> l = apps.all();
        String[] labels = new String[l.size()];
        acts = new int[l.size()];
        for (int i = 0; i < l.size(); i++) {
            labels[i] = l.get(i).title;
            acts[i] = A_MAKE + i;
        }
        if (labels.length == 0) return null;
        return showMenu(new WinUi.Menu(labels), menuX, menuY);
    }

    /** Ввод, пока открыто меню: нажатие вне меню закрывает его. */
    public int[] menuMouse(int mx, int my, int btn, int kind) {
        int it = menu.itemAt(mx, my), old = menu.hover;
        menu.hover = it;
        if (kind != PixelScreen.MOUSE_PRESS) return old != it ? menu.box() : null;
        int[] d = menu.box();
        int act = it >= 0 && btn == 0 ? acts[it] : 0;
        menu = null;
        return union(d, act == 0 ? null : doAct(act));
    }

    private int[] doAct(int a) {
        int[] d = null;
        if (a == A_OPEN) {
            for (Item i : new ArrayList<Item>(items)) if (i.sel) d = union(d, launch(i));
        } else if (a == A_REN) {
            for (Item i : items) if (i.sel) return startRename(i);
        } else if (a == A_DEL) {
            return deleteSelected();
        } else if (a == A_SIZE) {
            int[][] cr = new int[items.size()][];
            for (int n = 0; n < cr.length; n++) cr[n] = new int[] {colOf(items.get(n).x), rowOf(items.get(n).y)};
            large = !large;
            for (int n = 0; n < cr.length; n++) {
                items.get(n).x = gx(Math.min(cr[n][0], cols() - 1));
                items.get(n).y = gy(Math.min(cr[n][1], rows() - 1));
            }
            snapAll();
            save();
            return new int[] {0, 0, W, WinWm.workH()};
        } else if (a == A_SORT) {
            sortByName();
            save();
            return new int[] {0, 0, W, WinWm.workH()};
        } else if (a == A_GRID) {
            grid = !grid;
            if (grid) snapAll();
            save();
            return new int[] {0, 0, W, WinWm.workH()};
        } else if (a == A_SHOW) {
            show = !show;
            hov = null;
            if (!show) {
                for (Item i : items) i.sel = false;
            }
            save();
            return new int[] {0, 0, W, WinWm.workH()};
        } else if (a == A_NEW) {
            return openNewMenu();
        } else if (a == A_PERS) {
            return host.open("personal");
        } else if (a == A_REFRESH) {
            return new int[] {0, 0, W, WinWm.workH()};
        } else if (a >= A_MAKE) {
            List<WinApps.Info> l = apps.all();
            int n = a - A_MAKE;
            if (n < l.size() && items.size() < MAX_ITEMS) {
                WinApps.Info info = l.get(n);
                Item it = new Item();
                it.app = info.id;
                it.label = info.label;
                it.x = Math.max(0, Math.min(W - cw(), menuX));
                it.y = Math.max(0, Math.min(WinWm.workH() - ch(), menuY));
                items.add(it);
                for (Item i : items) i.sel = i == it;
                if (grid) snapSelected();
                removed.remove(info.id);
                save();
                return new int[] {0, 0, W, WinWm.workH()};
            }
        }
        return d;
    }

    // ================================================================== рисование
    /** Значки и рамка выделения в пределах clip (под окнами). */
    public void paint(PixelScreen p, int[] clip) {
        if (!show) return;
        for (Item it : items) {
            if (hit(box(it), clip)) drawItem(p, it);
        }
        if (band) {
            int[] b = bandBox();
            if (hit(b, clip)) {
                p.fillRect(b[0], b[1], b[2], b[3], PixelScreen.alpha(th.accent(), 0x48));
                p.rect(b[0], b[1], b[2], b[3], 1, PixelScreen.alpha(PixelScreen.lerp(th.accent(), 0xFFFFFFFF, 0.3f), 0xC0));
            }
        }
    }

    /** Контекстное меню поверх окон. */
    public void paintMenu(PixelScreen p) {
        if (menu != null && menu.open) menu.draw(p, th, effects);
    }

    private void drawItem(PixelScreen p, Item it) {
        int x = it.x, y = it.y, w = cw(), h = ch(), s = isz();
        if (it.sel) {
            p.roundRect(x, y, w, h, 4, PixelScreen.alpha(th.accent(), 0x58));
            p.roundRectOutline(x, y, w, h, 4, 1, PixelScreen.alpha(PixelScreen.lerp(th.accent(), 0xFFFFFFFF, 0.35f), 0xB0));
        } else if (it == hov) {
            p.roundRect(x, y, w, h, 4, 0x30FFFFFF);
        }
        WinApps.Info a = apps.get(it.app);
        int ix = x + (w - s) / 2, iy = y + 2;
        WinIcons.drawSized(p, th, a == null ? it.app : a.icon, ix, iy, s);
        WinIcons.shortcutBadge(p, ix - 1, iy + s - 7);
        int ty = iy + s + 2;
        if (it == ren) {
            drawRename(p, it, x, ty - 1, w);
            return;
        }
        int ly = ty;
        for (String t : wrap(it.label, w - 3)) {
            int tx = x + (w - PixelScreen.textWidth(t)) / 2;
            p.drawText(tx + 1, ly + 1, t, 0xA0000000);
            p.drawText(tx + 1, ly, t, 0x70000000);
            p.drawText(tx, ly + 1, t, 0x70000000);
            p.drawText(tx, ly, t, 0xFFFFFFFF);
            ly += 9;
        }
    }

    /** Подпись в одну или две строки по словам; не влезающее обрезается с «...». */
    private static List<String> wrap(String s, int maxW) {
        List<String> r = new ArrayList<String>();
        String cur = "";
        for (String word : s.split(" ")) {
            if (word.isEmpty()) continue;
            while (cur.isEmpty() && PixelScreen.textWidth(word) > maxW && word.length() > 1) {
                int n = word.length() - 1;
                while (n > 1 && PixelScreen.textWidth(word.substring(0, n)) > maxW) n--;
                r.add(word.substring(0, n));
                word = word.substring(n);
            }
            String t = cur.isEmpty() ? word : cur + " " + word;
            if (PixelScreen.textWidth(t) <= maxW || cur.isEmpty()) {
                cur = t;
            } else {
                r.add(cur);
                cur = word;
            }
        }
        if (!cur.isEmpty()) r.add(cur);
        if (r.size() > 2) {
            StringBuilder rest = new StringBuilder(r.get(1));
            for (int i = 2; i < r.size(); i++) rest.append(' ').append(r.get(i));
            String first = r.get(0);
            r.clear();
            r.add(first);
            r.add(rest.toString());
        }
        for (int i = 0; i < r.size(); i++) r.set(i, PixelScreen.fit(r.get(i), maxW, 1, false));
        return r;
    }

    private void drawRename(PixelScreen p, Item it, int x, int y, int w) {
        p.roundRectBorder(x + 1, y, w - 2, 11, 3, th.surface(), th.accent());
        String shown = rsb.toString();
        int maxW = w - 10;
        while (shown.length() > 0 && PixelScreen.textWidth(shown) > maxW) shown = renAll ? shown.substring(0, shown.length() - 1) : shown.substring(1);
        int tw = PixelScreen.textWidth(shown);
        if (renAll && tw > 0) {
            p.fillRect(x + 3, y + 1, tw + 2, 9, th.accent());
            p.drawText(x + 4, y + 1, shown, th.onAccent());
        } else {
            p.drawText(x + 4, y + 1, shown, th.text());
            p.fillRect(x + 4 + tw + 1, y + 2, 1, 7, th.text());
        }
    }
}
