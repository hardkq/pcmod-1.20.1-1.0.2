package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Связь WinCraft 11 с компьютером: железо, учётная запись, питание, установка, BIOS. Реализует WinBridge. */
public interface WinHost {
    PixelScreen pix();

    /** Подписка на мышь в пикселях (null - отписаться). */
    void setMouse(PixelScreen.MouseListener m);

    /** Игровое время мира, тики. */
    long time();

    /** Время суток (для часов). */
    long dayTime();

    WinSpec.Hw hw();

    /** Имя пользователя на накопителе. */
    String userName();

    boolean checkPass(String pass);

    /** Вход выполнен: ПК переходит в состояние рабочего стола. */
    void loginOk();

    void powerOff();

    void restart();

    /** Записать систему на накопитель (форматирование, учётная запись). */
    void install(String host, String user, String pass);

    /** Тип сетевого подключения: NetLink.NONE, WIRED, WIFI. */
    default int netType() { return NetLink.NONE; }

    /** Уровень сигнала Wi-Fi 0..4. */
    default int netSignal() { return 0; }

    /** Настройка пользователя WinCraft 11, хранится на накопителе ("" - нет). */
    default String pref(String key) { return ""; }

    default void setPref(String key, String value) {}

    /** Накопитель, байт: {ёмкость, система, занято файлами}. */
    default long[] disk() { return new long[] {0, 0, 0}; }

    /** Имя ПК в сети. */
    default String hostName() { return ""; }

    /** Тиков с момента загрузки. */
    default long uptime() { return 0; }

    /** Установлен ли модуль Wi-Fi. */
    default boolean wifiModule() { return false; }

    /** Сети Wi-Fi в зоне действия: {имя, сигнал 1..4, "1" - с паролем}, сильные первыми. */
    default List<String[]> wifiScan() { return new ArrayList<String[]>(); }

    /** Сохранённая сеть Wi-Fi ("" - нет). */
    default String wifiSaved() { return ""; }

    /** Подключиться к Wi-Fi и запомнить сеть. null - успех, иначе причина отказа. */
    default String wifiConnect(String ssid, String pass) { return "Недоступно"; }

    /** Забыть сохранённую сеть Wi-Fi. */
    default void wifiForget() {}

    /** Причина, по которой нет подключения (по-русски). */
    default String netStatus() { return ""; }

    /** Сведения о подключении: {название, значение}. */
    default List<String[]> netInfo() { return new ArrayList<String[]>(); }

    /** Файловая система накопителя (приложения WinCraft 11). */
    WinFs fs();

    /** Службы мира: чат, магазин, банк, загрузки (приложения WinCraft 11). */
    WinSvc svc();

    /** Температура процессора, °C. */
    default int temp() { return 40; }

    int bootOrder();

    boolean fastBoot();

    /** Сохранить настройки BIOS и перезагрузить ПК. */
    void saveBios(int order, boolean fast);

    /** Строки вкладки Main: {название, значение}. */
    List<String[]> biosMain();

    /** Строки вкладки Monitor: {название, значение, "bad"|"warn"|""}. */
    List<String[]> biosMonitor();
}
