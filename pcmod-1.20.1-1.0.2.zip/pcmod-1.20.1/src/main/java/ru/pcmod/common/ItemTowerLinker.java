package ru.pcmod.common;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * Инструмент привязки вышки к серверу оператора.
 * ПКМ по TileServer — запомнить serverId (BlockPos.asLong) и operatorId (domain) в NBT.
 * ПКМ по TileTower  — привязать вышку к сохранённому серверу.
 * Если линкер не привязан к серверу — сообщение игроку.
 * Успешная привязка вышки — частицы HAPPY_VILLAGER.
 * Крафт: золотая палочка + 2x редстоун + компас (3x3 shaped) — см. tower_linker.json.
 */
public class ItemTowerLinker extends Item {

    private static final String NBT_SERVER_POS  = "serverPos";
    private static final String NBT_OPERATOR_ID = "operatorId";
    private static final String NBT_SERVER_DIM  = "serverDim";

    public ItemTowerLinker(Item.Properties props) {
        super(props);
    }

    // --- NBT-геттеры ---

    public static boolean hasServer(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null && t.contains(NBT_SERVER_POS);
    }

    public static long getServerPos(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null ? t.getLong(NBT_SERVER_POS) : 0L;
    }

    public static String getOperatorId(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null ? t.getString(NBT_OPERATOR_ID) : "";
    }

    public static String getServerDim(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null ? t.getString(NBT_SERVER_DIM) : "";
    }

    // --- NBT-сеттеры ---

    private static void setServer(ItemStack stack, BlockPos pos, String operatorId, String dim) {
        CompoundTag t = stack.getOrCreateTag();
        t.putLong(NBT_SERVER_POS, pos.asLong());
        t.putString(NBT_OPERATOR_ID, operatorId);
        t.putString(NBT_SERVER_DIM, dim);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;

        BlockPos pos = ctx.getClickedPos();
        Player player = ctx.getPlayer();
        if (player == null) return InteractionResult.PASS;

        ItemStack stack = ctx.getItemInHand();
        BlockEntity be = level.getBlockEntity(pos);

        // --- ПКМ по TileServer: запомнить сервер ---
        if (be instanceof TileServer ts) {
            String opId = ts.operatorId;
            if (opId.isEmpty()) {
                player.displayClientMessage(Component.translatable("gui.pcmod.tower_linker.no_operator").withStyle(ChatFormatting.RED), true);
                return InteractionResult.FAIL;
            }
            String dim  = level.dimension().location().toString();
            setServer(stack, pos, opId, dim);
            player.displayClientMessage(
                Component.translatable("gui.pcmod.tower_linker.server_bound", pos.toShortString())
                    .withStyle(ChatFormatting.GREEN),
                true
            );
            return InteractionResult.SUCCESS;
        }

        // --- ПКМ по TileTower: привязать вышку ---
        if (be instanceof TileTower tower) {
            if (!hasServer(stack)) {
                player.displayClientMessage(
                    Component.translatable("gui.pcmod.tower_linker.no_server")
                        .withStyle(ChatFormatting.RED),
                    true
                );
                return InteractionResult.FAIL;
            }

            String dim = level.dimension().location().toString();
            if (!dim.equals(getServerDim(stack))) {
                player.displayClientMessage(
                    Component.translatable("gui.pcmod.tower_linker.wrong_dim")
                        .withStyle(ChatFormatting.RED),
                    true
                );
                return InteractionResult.FAIL;
            }

            OperatorStore st = OperatorStore.get();
            OperatorStore.Operator op = st == null ? null : st.get(getOperatorId(stack));
            if (op == null) {
                player.displayClientMessage(Component.translatable("gui.pcmod.tower_linker.no_operator").withStyle(ChatFormatting.RED), true);
                return InteractionResult.FAIL;
            }
            tower.bindToServer(BlockPos.of(getServerPos(stack)), op.id.toString());
            st.addTower(op.id, pos);

            // частицы HAPPY_VILLAGER вокруг вышки
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.HAPPY_VILLAGER,
                    pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                    12, 0.4, 0.5, 0.4, 0.1);
            }

            player.displayClientMessage(
                Component.translatable("gui.pcmod.tower_linker.tower_bound", op.name)
                    .withStyle(ChatFormatting.GREEN),
                true
            );
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }
}
