package ru.pcmod.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

/**
 * Меню «Пуск» WinCraft 11: поиск, закреплённые приложения, рекомендуемые (недавно открытые), список всех приложений,
 * пользователь и кнопка питания. Методы ввода возвращают область {x, y, w, h} для перерисовки (null - ничего).
 */
public final class WinStart {
    static final int W = PixelScreen.W;
    public static final int MW = 208, MH = 150;
    private static final int PIN_COLS = 6, MAX_PIN = 12, MAX_REC = 4, ROWS_RES = 7, ROWS_ALL = 7, KEY_ESC = 1;
    private static final int H_ALL = 1, H_BACK = 2, H_POWER = 3, H_PIN = 100, H_REC = 200, H_RES = 300, H_LIST = 400;

    private final WinWm wm;
    private final WinTheme th;
    private final boolean effects;
    private final WinTaskbar.Env env;
    private final WinApps apps;
    private final WinUi.Field query = new WinUi.Field(0, 0, 186);
    private final WinUi.Menu power = new WinUi.Menu("Заблокировать", "Перезагрузка", "Завершение работы");
    private final LinkedList<String> recent = new LinkedList<String>();
    private boolean open, search, allApps, consumed, phase;
    private int hov, sel, scroll;

    public WinStart(WinWm wm, WinTheme th, boolean effects, WinTaskbar.Env env, WinApps apps) {
        this.wm = wm;
        this.th = th;
        this.effects = effects;
        this.env = env;
        this.apps = apps;
        query.max = 24;
    }

    public boolean isOpen() { return open; }

    /** Меню открыто кнопкой «Поиск». */
    public boolean searchMode() { return open && search; }

    /** Последнее событие мыши обработано меню (дальше его передавать не надо). */
    public boolean consumed() { return consumed; }

    private static int[] union(int[] a, int[] b) {
        return WinWm.union(a, b);
    }

    private int x0() { return (W - MW) / 2; }

    private int y0() { return WinWm.workH() - MH - 4; }

    private int[] box() {
        return new int[] {x0() - 8, y0() - 6, MW + 16, MH + 16};
    }

    // ================================================================== открытие и закрытие
    public int[] toggle(boolean searchBtn) {
        if (open) return close();
        open = true;
        search = searchBtn;
        allApps = false;
        query.sb.setLength(0);
        sel = 0;
        scroll = 0;
        hov = 0;
        power.open = false;
        return union(box(), WinTaskbar.barBox());
    }

    public int[] close() {
        if (!open) return null;
        open = false;
        power.open = false;
        hov = 0;
        return union(box(), WinTaskbar.barBox());
    }

    // ================================================================== данные
    private boolean searching() {
        return query.sb.length() > 0;
    }

    private List<WinApps.Info> results() {
        String q = query.sb.toString().toLowerCase(Locale.ROOT).trim();
        List<WinApps.Info> first = new ArrayList<WinApps.Info>(), rest = new ArrayList<WinApps.Info>();
        for (WinApps.Info a : apps.all()) {
            String t = a.title.toLowerCase(Locale.ROOT);
            if (t.startsWith(q)) first.add(a);
            else if (t.contains(q)) rest.add(a);
        }
        first.addAll(rest);
        return first;
    }

    private List<WinApps.Info> pinned() {
        List<WinApps.Info> r = new ArrayList<WinApps.Info>();
        for (WinApps.Info a : apps.all()) if (a.pinned && r.size() < MAX_PIN) r.add(a);
        return r;
    }

    private List<WinApps.Info> recommended() {
        List<WinApps.Info> r = new ArrayList<WinApps.Info>();
        for (String id : recent) {
            WinApps.Info a = apps.get(id);
            if (a != null) r.add(a);
        }
        return r;
    }

    private List<WinApps.Info> sorted() {
        List<WinApps.Info> r = new ArrayList<WinApps.Info>(apps.all());
        Collections.sort(r, (a, b) -> a.title.compareToIgnoreCase(b.title));
        return r;
    }

    // ================================================================== геометрия
    private int[] rect(int id) {
        int x0 = x0(), y0 = y0(), i;
        if (id == H_ALL || id == H_BACK) {
            int bw = PixelScreen.textWidth(id == H_BACK ? "Назад" : "Все приложения") + 18;
            return new int[] {x0 + MW - 11 - bw, y0 + 21, bw, 13};
        }
        if (id == H_POWER) return new int[] {x0 + MW - 29, y0 + 132, 18, 16};
        if (id >= H_LIST) {
            i = id - H_LIST;
            return new int[] {x0 + 11 + (i % 2) * 94, y0 + 36 + (i / 2) * 13, 92, 13};
        }
        if (id >= H_RES) return new int[] {x0 + 11, y0 + 33 + (id - H_RES) * 13, 186, 13};
        if (id >= H_REC) {
            i = id - H_REC;
            return new int[] {x0 + 11 + (i % 2) * 94, y0 + 102 + (i / 2) * 13, 92, 13};
        }
        i = id - H_PIN;
        return new int[] {x0 + 11 + (i % PIN_COLS) * 31, y0 + 35 + (i / PIN_COLS) * 26, 31, 26};
    }

    private static boolean in(int[] r, int mx, int my) {
        return mx >= r[0] && my >= r[1] && mx < r[0] + r[2] && my < r[1] + r[3];
    }

    private boolean inside(int mx, int my) {
        return mx >= x0() && my >= y0() && mx < x0() + MW && my < y0() + MH;
    }

    private int hit(int mx, int my) {
        if (in(rect(H_POWER), mx, my)) return H_POWER;
        if (searching()) {
            int n = Math.min(ROWS_RES, results().size());
            for (int i = 0; i < n; i++) if (in(rect(H_RES + i), mx, my)) return H_RES + i;
        } else if (allApps) {
            if (in(rect(H_BACK), mx, my)) return H_BACK;
            int n = Math.min(ROWS_ALL * 2, sorted().size() - scroll * 2);
            for (int i = 0; i < n; i++) if (in(rect(H_LIST + i), mx, my)) return H_LIST + i;
        } else {
            if (in(rect(H_ALL), mx, my)) return H_ALL;
            int n = pinned().size();
            for (int i = 0; i < n; i++) if (in(rect(H_PIN + i), mx, my)) return H_PIN + i;
            n = Math.min(MAX_REC, recommended().size());
            for (int i = 0; i < n; i++) if (in(rect(H_REC + i), mx, my)) return H_REC + i;
        }
        return 0;
    }

    // ================================================================== ввод
    /** Запустить приложение по id (ярлыки рабочего стола). */
    public int[] run(String id) {
        WinApps.Info a = apps.get(id);
        return a == null ? null : launch(a);
    }

    private int[] launch(WinApps.Info a) {
        recent.remove(a.id);
        recent.addFirst(a.id);
        while (recent.size() > MAX_REC) recent.removeLast();
        int[] d = close();
        return union(d, wm.open(a.make.get(), a.w, a.h));
    }

    private int[] click(int id) {
        if (id == H_ALL || id == H_BACK) {
            allApps = id == H_ALL;
            scroll = 0;
            hov = 0;
            return box();
        }
        if (id == H_POWER) {
            int[] r = rect(H_POWER);
            power.openAt(r[0] + r[2] - power.w, r[1] - power.h() - 2);
            return box();
        }
        if (id >= H_LIST) {
            List<WinApps.Info> l = sorted();
            int i = scroll * 2 + id - H_LIST;
            return i < l.size() ? launch(l.get(i)) : null;
        }
        List<WinApps.Info> l = id >= H_RES ? results() : id >= H_REC ? recommended() : pinned();
        int i = id - (id >= H_RES ? H_RES : id >= H_REC ? H_REC : H_PIN);
        return i < l.size() ? launch(l.get(i)) : null;
    }

    private int[] scrollBy(int d) {
        if (!allApps || searching()) return null;
        int rows = (sorted().size() + 1) / 2, max = Math.max(0, rows - ROWS_ALL), n = Math.max(0, Math.min(max, scroll + d));
        if (n == scroll) return null;
        scroll = n;
        return box();
    }

    /** overBtn - указатель над кнопкой «Пуск» или «Поиск» на панели задач (её нажатие закроет меню само). */
    public int[] mouse(int mx, int my, int btn, int kind, boolean overBtn) {
        consumed = false;
        if (!open) return null;
        boolean press = kind == PixelScreen.MOUSE_PRESS;
        if (power.open) {
            consumed = true;
            int it = power.itemAt(mx, my), old = power.hover;
            power.hover = it;
            if (press) {
                power.open = false;
                int[] d = box();
                if (it >= 0 && btn == 0) {
                    d = union(d, close());
                    env.power(it);
                }
                return d;
            }
            return old != it ? power.box() : null;
        }
        boolean ins = inside(mx, my);
        if (press) {
            if (!ins) {
                if (overBtn) return null;
                consumed = true;
                return close();
            }
            consumed = true;
            if (btn != 0) return null;
            int id = hit(mx, my);
            return id > 0 ? click(id) : null;
        }
        int[] d = null;
        if (!ins) {
            if (hov != 0) {
                d = rect(hov);
                hov = 0;
            }
            return d;
        }
        consumed = true;
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN)
            return scrollBy(kind == PixelScreen.MOUSE_SCROLL_DOWN ? 1 : -1);
        int id = hit(mx, my);
        if (id != hov) {
            if (hov != 0) d = rect(hov);
            if (id != 0) d = union(d, rect(id));
            hov = id;
        }
        return d;
    }

    /** Клавиша при открытом меню; любой набранный текст идёт в поиск. */
    public int[] key(char c, int key) {
        if (!open) return null;
        if (power.open) {
            power.open = false;
            return box();
        }
        if (key == KEY_ESC) return close();
        boolean s = searching();
        if (key == WinUi.K_DOWN || key == WinUi.K_UP) {
            if (!s) return null;
            int n = Math.min(ROWS_RES, results().size());
            if (n == 0) return null;
            int ns = Math.max(0, Math.min(n - 1, sel + (key == WinUi.K_DOWN ? 1 : -1)));
            if (ns == sel) return null;
            int[] d = union(rect(H_RES + sel), rect(H_RES + ns));
            sel = ns;
            return d;
        }
        if (WinUi.isEnter(c, key)) {
            if (!s) return null;
            List<WinApps.Info> r = results();
            return r.isEmpty() ? null : launch(r.get(Math.min(sel, r.size() - 1)));
        }
        int before = query.sb.length();
        query.key(c, key);
        if (query.sb.length() == before) return null;
        sel = 0;
        allApps = false;
        scroll = 0;
        return box();
    }

    /** Раз в тик: мигание курсора поиска. */
    public void tick(long now, List<int[]> out) {
        if (!open) return;
        boolean ph = (now / 10) % 2 == 0;
        if (ph != phase) {
            phase = ph;
            out.add(new int[] {x0() + 11, y0() + 6, 186, 14});
        }
    }

    // ================================================================== рисование
    public void paint(PixelScreen p) {
        if (!open) return;
        int x0 = x0(), y0 = y0();
        if (effects) p.shadow(x0, y0, MW, MH, 8, 10, 0, 3, 0x70000000);
        WinGfx.glass(p, th, x0, y0, MW, MH, 8, th.bg(), 0xDC);
        p.pushClip(x0, y0 + 130, MW, MH - 130);
        p.roundRect(x0, y0 + 112, MW, MH - 112, 8, th.dark ? 0x33000000 : 0x14000000);
        p.popClip();
        p.hline(x0 + 1, y0 + 130, MW - 2, th.border());
        p.roundRectOutline(x0, y0, MW, MH, 8, 1, th.border());
        drawSearch(p);
        if (searching()) drawResults(p);
        else if (allApps) drawAll(p);
        else drawHome(p);
        drawFooter(p);
        power.draw(p, th, effects);
    }

    private void hoverBg(PixelScreen p, int id) {
        if (hov != id) return;
        int[] r = rect(id);
        p.roundRect(r[0], r[1], r[2], r[3], 4, th.hover());
    }

    private void drawSearch(PixelScreen p) {
        int x = x0() + 11, y = y0() + 6;
        p.roundRectBorder(x, y, 186, 14, 7, th.surface(), th.border());
        p.fillRect(x + 7, y + 12, 172, 1, phase || searching() ? th.accent() : 0x00000000);
        p.roundRectOutline(x + 5, y + 3, 7, 7, 3, 1, th.sub());
        WinGfx.line(p, x + 10, y + 8, x + 12, y + 10, th.sub());
        String s = query.sb.toString();
        int maxW = 186 - 30, tw = PixelScreen.textWidth(s);
        while (tw > maxW && s.length() > 0) {
            s = s.substring(1);
            tw = PixelScreen.textWidth(s);
        }
        if (s.isEmpty()) p.drawText(x + 18, y + 3, "Введите здесь для поиска", th.sub());
        else p.drawText(x + 18, y + 3, s, th.text());
        if (phase) p.fillRect(x + 18 + (tw > 0 ? tw + 1 : 0), y + 3, 1, 8, th.text());
    }

    private void drawHome(PixelScreen p) {
        int x0 = x0(), y0 = y0();
        p.drawText(x0 + 13, y0 + 24, "Закреплённые", th.text(), 1, true);
        hoverBg(p, H_ALL);
        int[] b = rect(H_ALL);
        p.drawText(b[0] + 5, b[1] + 2, "Все приложения", th.text());
        WinGfx.line(p, b[0] + b[2] - 8, b[1] + 3, b[0] + b[2] - 5, b[1] + 6, th.text());
        WinGfx.line(p, b[0] + b[2] - 5, b[1] + 6, b[0] + b[2] - 8, b[1] + 9, th.text());
        List<WinApps.Info> pin = pinned();
        for (int i = 0; i < pin.size(); i++) {
            int[] r = rect(H_PIN + i);
            hoverBg(p, H_PIN + i);
            WinIcons.draw(p, th, pin.get(i).id, r[0] + r[2] / 2, r[1] + 9);
            p.drawTextCentered(r[0], r[2], r[1] + 16, PixelScreen.fit(pin.get(i).title, r[2] - 2, 1, false), th.text(), 1, false);
        }
        p.drawText(x0 + 13, y0 + 91, "Рекомендуемые", th.text(), 1, true);
        List<WinApps.Info> rec = recommended();
        if (rec.isEmpty()) {
            p.drawText(x0 + 13, y0 + 106, PixelScreen.fit("Недавние приложения появятся здесь", MW - 26, 1, false), th.sub());
            return;
        }
        for (int i = 0; i < rec.size() && i < MAX_REC; i++) {
            int[] r = rect(H_REC + i);
            hoverBg(p, H_REC + i);
            WinIcons.draw(p, th, rec.get(i).id, r[0] + 9, r[1] + 6);
            p.drawText(r[0] + 19, r[1] + 2, PixelScreen.fit(rec.get(i).title, r[2] - 22, 1, false), th.text());
        }
    }

    private void drawResults(PixelScreen p) {
        int x0 = x0(), y0 = y0();
        p.drawText(x0 + 13, y0 + 23, "Приложения", th.text(), 1, true);
        List<WinApps.Info> r = results();
        if (r.isEmpty()) {
            p.drawTextCentered(x0, MW, y0 + 60, "Ничего не найдено", th.text(), 1, false);
            p.drawTextCentered(x0, MW, y0 + 72, PixelScreen.fit("по запросу «" + query.sb + "»", MW - 24, 1, false), th.sub(), 1, false);
            return;
        }
        for (int i = 0; i < r.size() && i < ROWS_RES; i++) {
            int[] b = rect(H_RES + i);
            if (i == sel) {
                p.roundRect(b[0], b[1], b[2], b[3], 4, th.hover());
                p.roundRect(b[0] + 1, b[1] + 3, 2, b[3] - 6, 1, th.accent());
            }
            hoverBg(p, H_RES + i);
            WinIcons.draw(p, th, r.get(i).id, b[0] + 11, b[1] + 6);
            p.drawText(b[0] + 22, b[1] + 2, r.get(i).title, th.text());
            p.drawTextRight(b[0] + b[2] - 6, b[1] + 2, "Приложение", th.sub(), 1, false);
        }
    }

    private void drawAll(PixelScreen p) {
        int x0 = x0(), y0 = y0();
        p.drawText(x0 + 13, y0 + 24, "Все приложения", th.text(), 1, true);
        hoverBg(p, H_BACK);
        int[] b = rect(H_BACK);
        p.drawText(b[0] + 12, b[1] + 2, "Назад", th.text());
        WinGfx.line(p, b[0] + 7, b[1] + 3, b[0] + 4, b[1] + 6, th.text());
        WinGfx.line(p, b[0] + 4, b[1] + 6, b[0] + 7, b[1] + 9, th.text());
        List<WinApps.Info> l = sorted();
        for (int s = 0; s < ROWS_ALL * 2; s++) {
            int i = scroll * 2 + s;
            if (i >= l.size()) break;
            int[] r = rect(H_LIST + s);
            hoverBg(p, H_LIST + s);
            WinIcons.draw(p, th, l.get(i).id, r[0] + 9, r[1] + 6);
            p.drawText(r[0] + 19, r[1] + 2, PixelScreen.fit(l.get(i).title, r[2] - 22, 1, false), th.text());
        }
        int rows = (l.size() + 1) / 2;
        if (rows > ROWS_ALL) {
            int th0 = ROWS_ALL * 13, bh = Math.max(8, th0 * ROWS_ALL / rows);
            int by = y0 + 36 + (th0 - bh) * scroll / (rows - ROWS_ALL);
            p.roundRect(x0 + MW - 8, by, 2, bh, 1, th.sub());
        }
    }

    private void drawFooter(PixelScreen p) {
        int x0 = x0(), y0 = y0();
        WinGfx.avatar(p, x0 + 19, y0 + 140, 12, 0xFF5E82AA, 0xFFE8F0F8);
        p.drawText(x0 + 30, y0 + 136, PixelScreen.fit(env.userName(), 120, 1, false), th.text());
        int[] r = rect(H_POWER);
        if (hov == H_POWER || power.open) p.roundRect(r[0], r[1], r[2], r[3], 4, th.hover());
        WinGfx.power(p, r[0] + r[2] / 2, r[1] + r[3] / 2, 4, th.text());
    }
}
