package ru.pcmod.common;

import java.util.List;

/** Файловая система накопителя для приложений WinCraft 11. Пути как на диске: /home/имя/Documents. */
public interface WinFs {
    /** Наибольший размер текстового файла (предел строки NBT накопителя). */
    int MAX_TEXT = 24000;

    String home();

    boolean isDir(String p);

    boolean isFile(String p);

    /** Имена в каталоге; каталоги с «/» в конце. */
    List<String> list(String dir);

    String read(String p);

    /** Создать или перезаписать файл; false - нет места, нет каталога или файл слишком большой. */
    boolean write(String p, String text);

    boolean mkdir(String p);

    /** 0 - удалено, 1 - нет такого, 2 - каталог не пуст. */
    int remove(String p);

    /** Размер файла в байтах (-1 - нет файла). */
    int size(String p);

    long free();

    long capacity();

    /** Системный путь: его нельзя удалять и переименовывать. */
    boolean locked(String p);

    static String parent(String p) {
        int i = p.lastIndexOf('/');
        return i <= 0 ? "/" : p.substring(0, i);
    }

    static String name(String p) {
        return p.substring(p.lastIndexOf('/') + 1);
    }

    static String join(String dir, String n) {
        return dir.equals("/") ? "/" + n : dir + "/" + n;
    }

    /** Расширение маленькими буквами без точки ("" - нет). */
    static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i <= 0 || i == name.length() - 1 ? "" : name.substring(i + 1).toLowerCase();
    }

    /** Путь в виде C:\Users\имя\... (так его показывают окна). */
    static String show(String p) {
        if (p.equals("/")) return "C:\\";
        String s = p.startsWith("/home") && (p.length() == 5 || p.charAt(5) == '/') ? "/Users" + p.substring(5) : p;
        return "C:" + s.replace('/', '\\');
    }

    /** Путь из текста: C:\Users\имя, \Users\имя, /home/имя; относительный - от cwd. */
    static String parse(String cwd, String t) {
        t = t.trim().replace('\\', '/');
        if (t.length() >= 2 && t.charAt(1) == ':') t = t.substring(2).isEmpty() ? "/" : t.substring(2);
        if (t.equalsIgnoreCase("/users") || t.toLowerCase().startsWith("/users/")) t = "/home" + t.substring(6);
        String full = t.startsWith("/") ? t : join(cwd, t);
        java.util.ArrayList<String> out = new java.util.ArrayList<String>();
        for (String part : full.split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) {
                if (!out.isEmpty()) out.remove(out.size() - 1);
            } else {
                out.add(part);
            }
        }
        StringBuilder b = new StringBuilder();
        for (String o : out) b.append('/').append(o);
        return b.length() == 0 ? "/" : b.toString();
    }

    /** Свободное имя в каталоге: «Новая папка», «Новая папка (2)»... ext без точки. */
    default String unique(String dir, String base, String ext) {
        String e = ext.isEmpty() ? "" : "." + ext;
        String n = base + e;
        for (int i = 2; isDir(join(dir, n)) || isFile(join(dir, n)); i++) n = base + " (" + i + ")" + e;
        return n;
    }

    /** Копия файла или каталога со всем содержимым. */
    default boolean copy(String src, String dst) {
        if (isFile(src)) {
            String t = read(src);
            return t != null && size(src) == t.length() && write(dst, t);
        }
        if (!isDir(src) || dst.equals(src) || dst.startsWith(src + "/")) return false;
        if (!isDir(dst) && !mkdir(dst)) return false;
        boolean ok = true;
        for (String n : list(src)) {
            String c = n.endsWith("/") ? n.substring(0, n.length() - 1) : n;
            ok &= copy(join(src, c), join(dst, c));
        }
        return ok;
    }

    /** Удалить файл или каталог со всем содержимым. */
    default boolean removeAll(String p) {
        if (locked(p)) return false;
        if (isDir(p)) {
            for (String n : list(p)) removeAll(join(p, n.endsWith("/") ? n.substring(0, n.length() - 1) : n));
        }
        return remove(p) == 0;
    }

    default boolean move(String src, String dst) {
        if (locked(src) || src.equals(dst) || !copy(src, dst)) return false;
        return removeAll(src);
    }
}
