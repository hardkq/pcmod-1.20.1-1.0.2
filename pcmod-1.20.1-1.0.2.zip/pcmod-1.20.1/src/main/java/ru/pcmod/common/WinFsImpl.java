package ru.pcmod.common;

import java.util.List;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;

/** Файловая система накопителя (VFS) для WinCraft 11. */
final class WinFsImpl implements WinFs {
    private final Supplier<CompoundTag> root;
    private final IntSupplier capKB;
    private final Runnable saved;

    WinFsImpl(Supplier<CompoundTag> root, IntSupplier capKB, Runnable saved) {
        this.root = root;
        this.capKB = capKB;
        this.saved = saved;
    }

    @Override
    public String home() {
        CompoundTag r = root.get();
        return r == null ? "/" : "/home/" + r.getString("user");
    }

    @Override public boolean isDir(String p) { CompoundTag r = root.get(); return r != null && VFS.isDir(r, p); }

    @Override public boolean isFile(String p) { CompoundTag r = root.get(); return r != null && VFS.isFile(r, p); }

    @Override
    public List<String> list(String dir) {
        CompoundTag r = root.get();
        return r == null ? new java.util.ArrayList<String>() : VFS.listDir(r, dir);
    }

    @Override public String read(String p) { CompoundTag r = root.get(); return r == null ? null : VFS.read(r, p); }

    @Override
    public boolean write(String p, String text) {
        CompoundTag r = root.get();
        if (r == null || text.length() > MAX_TEXT || !VFS.write(r, p, text, capKB.getAsInt())) return false;
        saved.run();
        return true;
    }

    @Override
    public boolean mkdir(String p) {
        CompoundTag r = root.get();
        if (r == null || !VFS.mkdir(r, p)) return false;
        saved.run();
        return true;
    }

    @Override
    public int remove(String p) {
        CompoundTag r = root.get();
        if (r == null || locked(p)) return 1;
        int res = VFS.remove(r, p);
        if (res == 0) saved.run();
        return res;
    }

    @Override public int size(String p) { CompoundTag r = root.get(); return r == null ? -1 : VFS.sizeOf(r, p); }

    @Override
    public long free() {
        CompoundTag r = root.get();
        return r == null ? 0 : Math.max(0, VFS.free(r, capKB.getAsInt()));
    }

    @Override public long capacity() { return capKB.getAsInt() * 1024L; }

    @Override
    public boolean locked(String p) {
        if (p.equals("/") || p.equals("/home") || p.equals("/etc") || p.equals("/bin")) return true;
        String h = home();
        return p.equals(h) || p.equals(h + "/Desktop") || p.equals(h + "/Documents") || p.equals(h + "/Downloads")
                || p.equals(h + "/Pictures");
    }
}
