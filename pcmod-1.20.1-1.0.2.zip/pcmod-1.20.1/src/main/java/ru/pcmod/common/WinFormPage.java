package ru.pcmod.common;

/** Страница «Параметров» из карточек WinForm: наследник описывает карточки в build(), состояние берёт из WinHost. */
abstract class WinFormPage implements WinPage {
    final WinHost host;
    final WinForm form = new WinForm(this::build);

    WinFormPage(WinHost host) {
        this.host = host;
    }

    /** Заполнить форму карточками; вызывается при каждом изменении состояния. */
    abstract void build(WinForm f);

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        form.draw(p, th, x, y, w, h, host.time());
    }

    @Override public boolean mouse(int rx, int ry, int btn, int kind) { return form.mouse(rx, ry, btn, kind); }

    @Override public boolean key(char c, int key) { return form.key(key); }

    @Override public void enter() { form.refresh(); }
}
