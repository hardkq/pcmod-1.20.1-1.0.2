package ru.pcmod.common;

/** Пиксельное превью товара 32x32 (рисуется кодом, без файлов): общее для браузера ПК и телефона. */
final class SoftPreview {
    static final int SIZE = 32;

    private SoftPreview() { }

    static void draw(PixelScreen p, String id, int x, int y) {
        p.roundRect(x - 1, y - 1, SIZE + 2, SIZE + 2, 3, 0xFF8892A0);
        switch (id) {
            case "doom": {
                p.fillRect(x, y, 32, 32, 0xFF3A0D0D);
                p.fillRect(x + 8, y + 5, 16, 14, 0xFFE8E0D0);
                p.fillRect(x + 10, y + 19, 12, 5, 0xFFD8D0C0);
                p.fillRect(x + 10, y + 10, 4, 4, 0xFF000000);
                p.fillRect(x + 18, y + 10, 4, 4, 0xFF000000);
                p.fillRect(x + 15, y + 15, 2, 3, 0xFF4A3A30);
                for (int i = 0; i < 4; i++) p.fillRect(x + 11 + i * 3, y + 20, 1, 4, 0xFF3A0D0D);
                for (int i = 0; i < 8; i++) p.fillRect(x + i * 4, y + 26 + (i % 2) * 2, 3, 6 - (i % 2) * 2, i % 3 == 0 ? 0xFFFFC83D : 0xFFE5532D);
                break;
            }
            case "av": {
                p.fillRect(x, y, 32, 32, 0xFF12305A);
                for (int i = 0; i < 22; i++) {
                    int w = i < 14 ? 20 : 20 - (i - 13) * 2;
                    p.fillRect(x + 16 - w / 2, y + 5 + i, w, 1, i < 2 ? 0xFF9ADFFF : 0xFF2FA4FF);
                }
                p.fillRect(x + 11, y + 15, 3, 3, 0xFFFFFFFF);
                p.fillRect(x + 14, y + 18, 3, 3, 0xFFFFFFFF);
                for (int i = 0; i < 5; i++) p.fillRect(x + 17 + i, y + 17 - i, 2, 2, 0xFFFFFFFF);
                break;
            }
            case "sitebuilder": {
                p.fillRect(x, y, 32, 32, 0xFFEEF2F7);
                p.fillRect(x, y, 32, 6, 0xFF0F6CBD);
                p.fillRect(x + 26, y + 2, 3, 3, 0xFFFFFFFF);
                p.fillRect(x + 3, y + 9, 26, 4, 0xFF4CC2FF);
                p.fillRect(x + 3, y + 15, 12, 12, 0xFFFFB900);
                p.fillRect(x + 18, y + 16, 11, 2, 0xFF7A8594);
                p.fillRect(x + 18, y + 20, 11, 2, 0xFF7A8594);
                p.fillRect(x + 18, y + 24, 7, 2, 0xFF7A8594);
                break;
            }
            case "mobileop": {
                p.fillRect(x, y, 32, 32, 0xFF10263F);
                p.fillRect(x + 15, y + 8, 2, 20, 0xFFCFD6DF);
                p.fillRect(x + 11, y + 26, 10, 2, 0xFFCFD6DF);
                p.fillRect(x + 14, y + 5, 4, 4, 0xFFFFB900);
                for (int i = 1; i <= 3; i++) { p.fillRect(x + 15 - 3 * i, y + 4 + i, 1, 6 - i * 2 + 2, 0xFF4CC2FF); p.fillRect(x + 16 + 3 * i, y + 4 + i, 1, 6 - i * 2 + 2, 0xFF4CC2FF); }
                break;
            }
            case "snake": {
                p.fillRect(x, y, 32, 32, 0xFF14301C);
                int[][] seg = {{4, 24}, {8, 24}, {12, 24}, {12, 20}, {12, 16}, {16, 16}, {20, 16}, {20, 12}, {20, 8}};
                for (int[] s : seg) p.fillRect(x + s[0], y + s[1], 4, 4, 0xFF5CD66E);
                p.fillRect(x + 21, y + 9, 1, 1, 0xFF000000);
                p.fillRect(x + 26, y + 20, 4, 4, 0xFFE5532D);
                break;
            }
            case "dice": {
                p.fillRect(x, y, 32, 32, 0xFF2B2F4A);
                p.roundRect(x + 5, y + 5, 22, 22, 4, 0xFFFFFFFF);
                int[][] d = {{9, 9}, {19, 9}, {14, 14}, {9, 19}, {19, 19}};
                for (int[] q : d) p.fillRect(x + q[0], y + q[1], 4, 4, 0xFF222222);
                break;
            }
            case "mines": {
                p.fillRect(x, y, 32, 32, 0xFF9AA4B0);
                for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) p.fillRect(x + 1 + i * 8, y + 1 + j * 8, 7, 7, (i + j) % 2 == 0 ? 0xFFC9D1DB : 0xFFB5BFCB);
                p.fillRect(x + 11, y + 11, 6, 6, 0xFF222222);
                p.fillRect(x + 13, y + 9, 2, 10, 0xFF222222);
                p.fillRect(x + 9, y + 13, 10, 2, 0xFF222222);
                p.fillRect(x + 22, y + 3, 5, 5, 0xFFE5532D);
                break;
            }
            default: {
                p.fillRect(x, y, 32, 32, 0xFF3B4658);
                p.fillRect(x + 8, y + 8, 16, 16, 0xFF6B7A90);
                p.fillRect(x + 12, y + 12, 8, 8, 0xFFB9C4D2);
            }
        }
    }
}
