package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Страница «Сеть»: состояние подключения, режим «в самолёте» (настройка "air"), список сетей Wi-Fi с подключением по паролю
 * и сведения о подключении. Сеть берётся у ПК через WinHost, поэтому страница показывает то, что реально происходит.
 */
final class WinPageNet extends WinFormPage {
    private final WinUi.Field pass = new WinUi.Field(0, 0, 100);
    private List<String[]> aps = new ArrayList<String[]>();
    private String sel = "", msg = "", scanSig = "", netSig = "";
    private long scanAt = -1000;

    WinPageNet(WinHost host) {
        super(host);
        pass.mask = true;
        pass.max = 16;
        pass.hint = "Пароль сети";
    }

    private boolean air() {
        return "1".equals(host.pref("air"));
    }

    private void scan() {
        aps = host.wifiModule() && !air() ? host.wifiScan() : new ArrayList<String[]>();
        scanSig = sigOf(aps);
        scanAt = host.time();
    }

    private static String sigOf(List<String[]> l) {
        StringBuilder b = new StringBuilder();
        for (String[] a : l) b.append(a[0]).append(':').append(a[1]).append(':').append(a[2]).append(';');
        return b.toString();
    }

    private String netSigNow() {
        return host.netType() + ":" + host.netSignal() + ":" + host.wifiSaved() + ":" + air();
    }

    private boolean fieldOn() {
        return !air() && !sel.isEmpty() && !sel.equals(host.wifiSaved());
    }

    @Override
    public void enter() {
        sel = "";
        msg = "";
        pass.sb.setLength(0);
        netSig = netSigNow();
        scan();
        form.refresh();
    }

    private void toggleAir() {
        host.setPref("air", air() ? "0" : "1");
        sel = "";
        msg = "";
        scan();
    }

    private void choose(String ssid, boolean secured) {
        if (ssid.equals(sel)) {
            sel = "";
            msg = "";
            return;
        }
        sel = ssid;
        msg = "";
        pass.sb.setLength(0);
        if (!secured && !ssid.equals(host.wifiSaved())) connect(ssid);
    }

    private void connect(String ssid) {
        String e = host.wifiConnect(ssid, pass.sb.toString());
        pass.sb.setLength(0);
        if (e == null) {
            sel = "";
            msg = "";
        } else {
            msg = e;
        }
        scan();
    }

    private void forget() {
        host.wifiForget();
        sel = "";
        msg = "";
        scan();
    }

    @Override
    void build(WinForm f) {
        boolean air = air();
        int type = host.netType();
        String saved = host.wifiSaved();
        f.section("Состояние");
        if (air) f.card("Режим «в самолёте»").sub("Все сети отключены").state(1);
        else if (type == NetLink.WIRED) f.card("Ethernet").sub("Подключено по кабелю").state(2);
        else if (type == NetLink.WIFI) f.card("Wi-Fi").sub("Подключено: " + saved).state(2);
        else f.card("Нет подключения").sub(host.netStatus()).state(0);
        f.card("Режим «в самолёте»").sub("Отключить все сети").toggle(air, true, this::toggleAir);

        f.section("Wi-Fi");
        if (!host.wifiModule()) {
            f.note("Модуль Wi-Fi не установлен. Подключите ПК кабелем к роутеру.", false);
        } else if (air) {
            f.note("Выключите режим «в самолёте», чтобы искать сети.", false);
        } else {
            boolean listed = false;
            for (String[] a : aps) {
                final String ssid = a[0];
                final boolean secured = a[2].equals("1");
                boolean conn = type == NetLink.WIFI && ssid.equals(saved);
                if (ssid.equals(saved)) listed = true;
                String s = conn ? "Подключено" : ssid.equals(saved) ? "Сохранена" : secured ? "Защищена паролем" : "Открытая сеть";
                f.card(ssid).sub(s).signal(parse(a[1])).click(() -> choose(ssid, secured));
                if (ssid.equals(sel)) {
                    if (ssid.equals(saved)) {
                        f.card("Сохранённая сеть").sub("Пароль хранится на диске").button("Забыть", true, this::forget);
                    } else {
                        f.field(pass, "Подключить", () -> connect(ssid));
                        if (!msg.isEmpty()) f.note(msg, true);
                    }
                }
            }
            if (!saved.isEmpty() && !listed) f.card(saved).sub(host.netStatus()).button("Забыть", true, this::forget);
            if (aps.isEmpty()) f.note("Сети поблизости не найдены.", false);
            f.card("Обновить список").sub("Поиск сетей поблизости").button("Найти", true, this::scan);
        }

        if (!air) {
            f.section("Сведения");
            for (String[] r : host.netInfo()) f.card(r[0]).value(r[1]);
        }
    }

    private static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override
    public boolean key(char c, int key) {
        if (fieldOn() && key != WinUi.K_UP && key != WinUi.K_DOWN) {
            if (pass.key(c, key)) connect(sel);
            form.refresh();
            return true;
        }
        return form.key(key);
    }

    @Override
    public boolean tick(long now) {
        boolean ch = fieldOn() && now % 10 == 0;
        if (now % 20 != 0) return ch;
        String ns = netSigNow();
        if (!ns.equals(netSig)) {
            netSig = ns;
            form.refresh();
            ch = true;
        }
        if (now - scanAt >= 100 && host.wifiModule() && !air()) {
            List<String[]> n = host.wifiScan();
            scanAt = now;
            if (!sigOf(n).equals(scanSig)) {
                aps = n;
                scanSig = sigOf(n);
                form.refresh();
                ch = true;
            }
        }
        return ch;
    }
}
