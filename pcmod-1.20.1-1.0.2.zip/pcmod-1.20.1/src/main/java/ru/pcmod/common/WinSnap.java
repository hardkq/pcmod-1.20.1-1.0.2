package ru.pcmod.common;

/**
 * Прикрепление окон WinCraft 11 к краям экрана (snap): зоны, область предпросмотра при перетаскивании
 * и всплывающее окно раскладок над кнопкой «Развернуть».
 */
public final class WinSnap {
    private WinSnap() {}

    public static final int NONE = 0, MAX = 1, LEFT = 2, RIGHT = 3, TL = 4, TR = 5, BL = 6, BR = 7, L66 = 8, R34 = 9, L34 = 10, R66 = 11;
    private static final int W = PixelScreen.W;

    /** Прямоугольник зоны {x, y, w, h} в рабочей области (без панели задач). */
    public static int[] rect(int zone) {
        int wh = WinWm.workH(), hw = W / 2, hh = wh / 2;
        switch (zone) {
            case LEFT: return new int[] {0, 0, hw, wh};
            case RIGHT: return new int[] {hw, 0, W - hw, wh};
            case TL: return new int[] {0, 0, hw, hh};
            case TR: return new int[] {hw, 0, W - hw, hh};
            case BL: return new int[] {0, hh, hw, wh - hh};
            case BR: return new int[] {hw, hh, W - hw, wh - hh};
            case L66: return new int[] {0, 0, W * 2 / 3, wh};
            case R34: return new int[] {W * 2 / 3, 0, W - W * 2 / 3, wh};
            case L34: return new int[] {0, 0, W / 3, wh};
            case R66: return new int[] {W / 3, 0, W - W / 3, wh};
            default: return new int[] {0, 0, W, wh};
        }
    }

    /** Зона, в которую попадает окно, если отпустить его в точке (mx, my); NONE - никуда. */
    public static int zoneAt(int mx, int my) {
        int wh = WinWm.workH();
        boolean l = mx <= 2, r = mx >= W - 3, t = my <= 1;
        if (l) return my <= 14 ? TL : my >= wh - 15 ? BL : LEFT;
        if (r) return my <= 14 ? TR : my >= wh - 15 ? BR : RIGHT;
        return t ? MAX : NONE;
    }

    /** Область перерисовки для предпросмотра зоны (null - нет зоны). */
    public static int[] previewBox(int zone) {
        if (zone == NONE) return null;
        int[] r = rect(zone);
        return new int[] {r[0] - 2, r[1] - 2, r[2] + 4, r[3] + 4};
    }

    /** Полупрозрачный предпросмотр: куда встанет окно. */
    public static void paintPreview(PixelScreen p, WinTheme th, int zone) {
        if (zone == NONE) return;
        int[] r = rect(zone);
        p.roundRect(r[0] + 3, r[1] + 3, r[2] - 6, r[3] - 6, 6, PixelScreen.alpha(th.accent(), 0x48));
        p.roundRectOutline(r[0] + 3, r[1] + 3, r[2] - 6, r[3] - 6, 6, 1, PixelScreen.alpha(th.accent(), 0xC0));
    }

    // ================================================================== раскладки
    /** {зона, x, y, w, h} в процентах плитки. */
    private static final int[][][] LAYOUTS = {
            {{LEFT, 0, 0, 50, 100}, {RIGHT, 50, 0, 50, 100}},
            {{L66, 0, 0, 66, 100}, {R34, 66, 0, 34, 100}},
            {{L34, 0, 0, 34, 100}, {R66, 34, 0, 66, 100}},
            {{TL, 0, 0, 50, 50}, {TR, 50, 0, 50, 50}, {BL, 0, 50, 50, 50}, {BR, 50, 50, 50, 50}}};
    private static final int TW = 34, TH = 22, GAP = 5, FW = 2 * TW + 3 * GAP, FH = 2 * TH + 3 * GAP;

    /** Окно раскладок у кнопки «Развернуть». */
    public static final class Flyout {
        public boolean open;
        public WinWm.Win win;
        private int x, y, hover;
        private int[] btn = new int[4];

        /** Показать под кнопкой b = {x, y, w, h}; возвращает область перерисовки. */
        public int[] show(WinWm.Win w, int[] b) {
            win = w;
            btn = b;
            x = Math.max(2, Math.min(W - FW - 2, b[0] + b[2] / 2 - FW / 2));
            y = b[1] + b[3];
            hover = NONE;
            open = true;
            return box();
        }

        public int[] box() {
            return new int[] {x - 8, y - 4, FW + 16, FH + 14};
        }

        public int[] close() {
            if (!open) return null;
            open = false;
            win = null;
            return box();
        }

        /** Указатель над самим окном раскладок. */
        public boolean inside(int mx, int my) {
            return open && mx >= x && my >= y && mx < x + FW && my < y + FH;
        }

        /** Указатель над кнопкой «Развернуть», открывшей окно раскладок. */
        public boolean onButton(int mx, int my) {
            return open && mx >= btn[0] && my >= btn[1] && mx < btn[0] + btn[2] && my < btn[1] + btn[3];
        }

        private int[] tile(int i) {
            return new int[] {x + GAP + (i % 2) * (TW + GAP), y + GAP + (i / 2) * (TH + GAP)};
        }

        private int[] zoneRect(int i, int[] z) {
            int[] t = tile(i);
            int x0 = t[0] + z[1] * TW / 100, x1 = t[0] + (z[1] + z[3]) * TW / 100;
            int y0 = t[1] + z[2] * TH / 100, y1 = t[1] + (z[2] + z[4]) * TH / 100;
            return new int[] {x0, y0, x1 - x0, y1 - y0};
        }

        public int zoneAt(int mx, int my) {
            if (!open) return NONE;
            for (int i = 0; i < LAYOUTS.length; i++) {
                for (int[] z : LAYOUTS[i]) {
                    int[] r = zoneRect(i, z);
                    if (mx >= r[0] && my >= r[1] && mx < r[0] + r[2] && my < r[1] + r[3]) return z[0];
                }
            }
            return NONE;
        }

        /** Подсветка зоны под указателем; возвращает область перерисовки, если она сменилась. */
        public int[] hover(int mx, int my) {
            int z = zoneAt(mx, my);
            if (z == hover) return null;
            hover = z;
            return box();
        }

        public void paint(PixelScreen p, WinTheme th, boolean effects) {
            if (!open) return;
            if (effects) p.shadow(x, y, FW, FH, 7, 7, 0, 2, 0x70000000);
            p.roundRectBorder(x, y, FW, FH, 7, th.surface(), th.border());
            int idle = th.dark ? 0xFF55595E : 0xFFC9CED6;
            for (int i = 0; i < LAYOUTS.length; i++) {
                for (int[] z : LAYOUTS[i]) {
                    int[] r = zoneRect(i, z);
                    p.roundRect(r[0] + 1, r[1] + 1, r[2] - 2, r[3] - 2, 2, z[0] == hover ? th.accent() : idle);
                }
            }
        }
    }
}
