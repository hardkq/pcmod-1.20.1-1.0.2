package ru.pcmod.common;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Сервер -> клиент: сжатая дельта или ключевой кадр портретного PixelScreen телефона. */
public class PacketPhonePixels {
    public final byte[] data;

    public PacketPhonePixels(byte[] data) { this.data = data; }

    public static void encode(PacketPhonePixels m, FriendlyByteBuf b) { b.writeByteArray(m.data); }

    public static PacketPhonePixels decode(FriendlyByteBuf b) { return new PacketPhonePixels(b.readByteArray(600000)); }

    public static void handle(PacketPhonePixels m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> PhoneClient.PIX.apply(m.data));
        ctx.setPacketHandled(true);
    }
}
