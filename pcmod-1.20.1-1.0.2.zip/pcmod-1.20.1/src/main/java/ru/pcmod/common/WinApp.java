package ru.pcmod.common;

/** Приложение в окне WinCraft 11. Координаты мыши - внутри области содержимого окна. */
public interface WinApp {
    String title();

    /** Идентификатор приложения: окна одного приложения группируются в один значок на панели задач и берут один значок. */
    default String id() { return getClass().getSimpleName(); }

    /** Нарисовать содержимое в области (x, y, w, h); фон окна уже залит цветом темы. */
    void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h);

    /** Можно ли менять размер окна и разворачивать его. */
    default boolean resizable() { return true; }

    /** Наименьшая ширина и высота окна (с заголовком). */
    default int minW() { return 120; }

    default int minH() { return 80; }

    /** Мышь в окне; true - содержимое нужно перерисовать. */
    default boolean mouse(int rx, int ry, int btn, int kind) { return false; }

    /** Клавиша для окна в фокусе; true - перерисовать. */
    default boolean key(char c, int key) { return false; }

    /** Раз в тик; true - перерисовать. */
    default boolean tick(long now) { return false; }
}
