package ru.pcmod.common;

import java.util.List;
import net.minecraft.world.entity.player.Player;
import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Магазин» (предметы): тот же каталог, лимиты и запас, что и в магазине на ПК; оплата с общего банковского счёта. */
final class AppShop implements AndroOs.App {
    private static final int TOP = 70, ROW = 30, VIEW = 208;

    private static final class St {
        final AppUi.Scroll sc = new AppUi.Scroll();
        long stamp = Long.MIN_VALUE;
        String msg = "";
        boolean ok;
        long until;
    }

    private static St st(AndroOs os) { return os.state("shop", St::new); }

    private static String left(AndroOs os, int v) { return v == Integer.MAX_VALUE ? os.t("без лимита", "unlimited") : os.t("осталось ", "left ") + v; }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "shop", os.t("Магазин", "Shop"));
        if (!AppNet.ready(os)) { AppNet.offline(os, s); return; }
        Bank b = Bank.get();
        String id = AppNet.id(os);
        long cur = Shop.stamp();
        if (st.stamp != cur) {
            if (st.stamp != Long.MIN_VALUE) { st.msg = os.t("Каталог обновлён", "Catalog updated"); st.ok = true; st.until = os.now() + 80; }
            st.stamp = cur;
        }
        List<Shop.Offer> cat = Shop.catalog();
        long bal = b.balance(id);
        int secs = Shop.secondsLeft();
        s.drawText(10, 50, AppNet.kons(bal), os.text(), 1, true);
        s.drawTextRight(170, 50, os.t("Обновление ", "Refresh ") + secs / 60 + ":" + AppUi.two(secs % 60), os.sub(), 1, false);
        s.pushClip(0, TOP - 2, AndroOs.W, VIEW + 2);
        for (int i = 0; i < cat.size(); i++) {
            int y = TOP + i * ROW - st.sc.off;
            if (y < TOP - ROW || y > TOP + VIEW) continue;
            Shop.Offer o = cat.get(i);
            int pl = Shop.playerLeft(b, id, o), sl = Shop.stockLeft(b, o), lim = Math.min(pl, sl);
            boolean can = pl > 0 && sl > 0 && bal >= o.price;
            s.roundRect(8, y, 164, ROW - 3, 8, os.panel());
            int ic = 0xFF000000 | ((o.key.hashCode() * 0x9E3779B1) & 0x00B0B0B0) + 0x00404040;
            s.roundRect(13, y + 6, 14, 14, 4, ic);
            s.drawTextCentered(13, 14, y + 9, o.name.isEmpty() ? "?" : o.name.substring(0, 1).toUpperCase(), rgb(255, 255, 255), 1, false);
            s.drawText(32, y + 4, PixelScreen.fit(o.name, 74, 1, true), os.text(), 1, true);
            String sub = sl <= 0 ? os.t("распродано", "sold out") : pl <= 0 ? os.t("лимит", "limit") : left(os, lim);
            s.drawText(32, y + 15, PixelScreen.fit(o.price + " K, " + sub, 74, 1, false), sl <= 0 || pl <= 0 ? rgb(240, 110, 100) : os.sub());
            btn(os, s, 108, y + 4, 24, "x1", can);
            btn(os, s, 135, y + 4, 33, os.t("Макс", "Max"), can);
        }
        s.popClip();
        if (cat.isEmpty()) s.drawTextCentered(0, AndroOs.W, 150, os.t("Каталог пуст", "Catalog is empty"), os.sub(), 1, false);
        if (st.until > os.now()) s.drawTextCentered(0, AndroOs.W, 284, PixelScreen.fit(st.msg, 168, 1, true), st.ok ? rgb(80, 220, 120) : rgb(240, 110, 100), 1, true);
    }

    private static void btn(AndroOs os, PixelScreen s, int x, int y, int w, String t, boolean on) {
        s.roundRect(x, y, w, 16, 6, on ? os.accent() : os.panel());
        s.drawTextCentered(x, w, y + 4, t, on ? rgb(255, 255, 255) : os.sub(), 1, true);
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St st = st(os);
        if (kind == 0) { st.sc.down(y); return true; }
        if (kind == 2) { st.sc.drag(y, Shop.catalog().size() * ROW, VIEW); return true; }
        if (!os.tap(x, y) || st.sc.moved || y < TOP || y >= TOP + VIEW || !AppNet.ready(os)) return true;
        int i = (y - TOP + st.sc.off) / ROW, ry = (y - TOP + st.sc.off) % ROW;
        List<Shop.Offer> cat = Shop.catalog();
        if (i >= cat.size() || ry < 4 || ry > 20) return true;
        boolean one = x >= 108 && x < 132, max = x >= 135 && x < 168;
        if (!one && !max) return true;
        Player p = AppNet.player(os);
        Bank.Res r = Shop.buy(p, i, max ? 0 : 1, st.stamp);
        st.msg = AppNet.tr(os, r.msg);
        st.ok = r.ok;
        st.until = os.now() + 100;
        return true;
    }

    @Override
    public void bg(AndroOs os) { if (AppNet.visible(os, "shop") && AppNet.ready(os)) os.dirty(); }
}
