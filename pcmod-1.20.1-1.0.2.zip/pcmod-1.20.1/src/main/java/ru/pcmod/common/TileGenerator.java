package ru.pcmod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.EnergyStorage;
import net.minecraftforge.items.ItemStackHandler;

/**
 * Генератор на топливе (как угольный): сжигает любое топливо из слота и вырабатывает GEN FE/tick.
 * Энергия копится в буфере и сама отдаётся соседним блокам с Forge Energy (глушилка и др.), до MAX_OUT FE/tick на сторону.
 * Если буфер полон - топливо не сгорает. Воронки могут класть топливо.
 */
public class TileGenerator extends BlockEntity {
    /** Буфер не больше 32767: значения идут клиенту через DataSlot (short). */
    public static final int CAPACITY = 30000, GEN = 100, MAX_OUT = 400;

    private final ItemStackHandler inv = new ItemStackHandler(1) {
        @Override public boolean isItemValid(int slot, ItemStack s) { return burnTime(s) > 0; }
        @Override protected void onContentsChanged(int slot) { setChanged(); }
    };
    private final Fe energy = new Fe();
    private final LazyOptional<ItemStackHandler> itemCap = LazyOptional.of(() -> inv);
    private final LazyOptional<EnergyStorage> energyCap = LazyOptional.of(() -> energy);

    public int burn, burnTotal;
    public boolean producing;

    public TileGenerator(BlockPos pos, BlockState st) { super(ModBlockEntities.GENERATOR.get(), pos, st); }

    private static final class Fe extends EnergyStorage {
        Fe() { super(CAPACITY, 0, MAX_OUT); }
        int space() { return capacity - energy; }
        void add(int n) { energy = Math.min(capacity, energy + n); }
        void drain(int n) { energy = Math.max(0, energy - n); }
        void set(int v) { energy = Math.max(0, Math.min(capacity, v)); }
    }

    public static int burnTime(ItemStack s) {
        return s.isEmpty() ? 0 : Math.max(0, ForgeHooks.getBurnTime(s, RecipeType.SMELTING));
    }

    public ItemStackHandler items() { return inv; }
    public int stored() { return energy.getEnergyStored(); }

    /** Серверный тик (ticker в BlockGenerator). */
    public void tick() {
        Level l = level;
        if (l == null || l.isClientSide) return;
        boolean room = energy.space() >= GEN;
        if (burn <= 0 && room) {
            ItemStack s = inv.getStackInSlot(0);
            int bt = burnTime(s);
            if (bt > 0) {
                burn = burnTotal = bt;
                ItemStack rest = s.getItem().hasCraftingRemainingItem(s) ? s.getItem().getCraftingRemainingItem(s) : ItemStack.EMPTY;
                s.shrink(1);
                inv.setStackInSlot(0, s.isEmpty() ? rest : s);
                setChanged();
            }
        }
        boolean on = false;
        if (burn > 0 && room) {
            energy.add(GEN);
            burn--;
            on = true;
            setChanged();
        }
        if (burn <= 0) burnTotal = 0;
        push(l);
        if (on != producing) producing = on;
        BlockState st = getBlockState();
        if (st.hasProperty(BlockGenerator.LIT) && st.getValue(BlockGenerator.LIT) != on)
            l.setBlock(worldPosition, st.setValue(BlockGenerator.LIT, on), 3);
    }

    private void push(Level l) {
        for (Direction d : Direction.values()) {
            int amt = Math.min(energy.getEnergyStored(), MAX_OUT);
            if (amt <= 0) return;
            BlockEntity n = l.getBlockEntity(worldPosition.relative(d));
            if (n == null) continue;
            int sent = n.getCapability(ForgeCapabilities.ENERGY, d.getOpposite()).map(c -> c.canReceive() ? c.receiveEnergy(amt, false) : 0).orElse(0);
            if (sent > 0) { energy.drain(sent); setChanged(); }
        }
    }

    @Override public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
        if (cap == ForgeCapabilities.ENERGY) return energyCap.cast();
        if (cap == ForgeCapabilities.ITEM_HANDLER) return itemCap.cast();
        return super.getCapability(cap, side);
    }

    @Override public void setRemoved() { itemCap.invalidate(); energyCap.invalidate(); super.setRemoved(); }

    @Override public void load(CompoundTag t) {
        super.load(t);
        inv.deserializeNBT(t.getCompound("inv"));
        energy.set(t.getInt("energy"));
        burn = t.getInt("burn");
        burnTotal = t.getInt("burnTotal");
    }

    @Override protected void saveAdditional(CompoundTag t) {
        super.saveAdditional(t);
        t.put("inv", inv.serializeNBT());
        t.putInt("energy", energy.getEnergyStored());
        t.putInt("burn", burn);
        t.putInt("burnTotal", burnTotal);
    }
}
