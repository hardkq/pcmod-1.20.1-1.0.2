package ru.pcmod.common;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Меню глушилки: радиус, вкл/выкл, энергия, работа — через DataSlot. Кнопки: 0 = вкл/выкл, 100+R = радиус R. */
public class ContainerJammer extends ContainerBlank {
    public static final int RADIUS = 0, ENABLED = 1, ENERGY = 2, ACTIVE = 3;
    public final TileJammer jam;
    /** Значения для экрана (на клиенте приходят с сервера). */
    public final int[] d = new int[4];

    public ContainerJammer(int id, Inventory inv, BlockEntity te) {
        super(ModMenus.JAMMER.get(), id, te);
        this.jam = (TileJammer) te;
        for (int i = 0; i < 4; i++) {
            final int k = i;
            addDataSlot(new DataSlot() {
                @Override public int get() { return live(k); }
                @Override public void set(int v) { d[k] = v; }
            });
        }
    }

    public ContainerJammer(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, inv.player.level().getBlockEntity(buf.readBlockPos()));
    }

    private int live(int k) {
        return switch (k) {
            case RADIUS -> jam.radius;
            case ENABLED -> jam.enabled ? 1 : 0;
            case ENERGY -> jam.stored();
            default -> jam.active ? 1 : 0;
        };
    }

    @Override
    public boolean clickMenuButton(Player p, int id) {
        if (jam.getLevel() == null || jam.getLevel().isClientSide) return false;
        if (id == 0) jam.toggle();
        else if (id >= 100) jam.setRadius(id - 100);
        return true;
    }
}
