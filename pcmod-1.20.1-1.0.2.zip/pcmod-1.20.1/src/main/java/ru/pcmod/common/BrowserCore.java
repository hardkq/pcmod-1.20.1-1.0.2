package ru.pcmod.common;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Общая модель браузера PC-Net для ПК и телефона (без рисования): вкладки (до 4), переходы и «назад», закладки, история,
 * подсказки адреса, кэш страниц сайтов и расчёт загрузки по типу канала. Интерфейс (WinBrowser, AppBrowser) только рисует и вызывает методы.
 */
final class BrowserCore {
    static final int MAX_TABS = 4, MAX_BM = 20, MAX_HIST = 30, MAX_NAV = 20, MAX_CACHE = 6;
    /** Типы канала. */
    static final int NONE = 0, WIRED = 1, WIFI = 2, CELL = 3;
    /** Страница - «сжатый» трафик: во столько раз быстрее канала передаются данные страницы. */
    private static final int PAGE_SPEEDUP = 4;

    /** Вкладка: адрес, стек переходов, прокрутка, состояние загрузки. */
    static final class Tab {
        String url = "home.pc";
        final List<String> nav = new ArrayList<String>();
        int scroll;
        /** Страница сайта игрока (ответ сервера), null - встроенная страница или ещё не загружена. */
        WebPage page;
        String pageUrl = "";
        /** Страница показана из кэша, потому что сервер или сеть недоступны. */
        boolean stale;
        boolean loading;
        double done;
        int total;

        Tab() { nav.add(url); }

        int pct() { return total <= 0 ? 100 : (int) Math.min(100, done * 100 / total); }
    }

    final List<Tab> tabs = new ArrayList<Tab>();
    int cur;
    final List<String> bookmarks = new ArrayList<String>();
    /** Общая история: новые в конце. */
    final List<String> history = new ArrayList<String>();
    private final Map<String, WebPage> cache = new LinkedHashMap<String, WebPage>();

    BrowserCore() { tabs.add(new Tab()); }

    Tab tab() { return tabs.get(Math.max(0, Math.min(cur, tabs.size() - 1))); }

    // ------------------------------------------------------------------ вкладки
    boolean newTab(String url) {
        if (tabs.size() >= MAX_TABS) return false;
        Tab t = new Tab();
        tabs.add(t);
        cur = tabs.size() - 1;
        go(t, url);
        return true;
    }

    void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        if (tabs.size() == 1) {
            tabs.set(0, new Tab());
            cur = 0;
            return;
        }
        tabs.remove(i);
        if (cur >= tabs.size() || cur > i) cur = Math.max(0, cur - 1);
    }

    // ------------------------------------------------------------------ переходы
    /** Переход по адресу: нормализация, стек «назад», история. Загрузку запускает вызывающий (startLoad). */
    void go(Tab t, String raw) {
        String u = WinWeb.norm(raw);
        t.url = u;
        t.page = null;
        t.stale = false;
        t.scroll = 0;
        if (!t.nav.get(t.nav.size() - 1).equals(u)) t.nav.add(u);
        while (t.nav.size() > MAX_NAV) t.nav.remove(0);
        visit(u);
    }

    boolean canBack(Tab t) { return t.nav.size() > 1; }

    boolean back(Tab t) {
        if (t.nav.size() < 2) return false;
        t.nav.remove(t.nav.size() - 1);
        t.url = t.nav.get(t.nav.size() - 1);
        t.page = null;
        t.stale = false;
        t.scroll = 0;
        return true;
    }

    private void visit(String u) {
        history.remove(u);
        history.add(u);
        while (history.size() > MAX_HIST) history.remove(0);
    }

    // ------------------------------------------------------------------ закладки
    boolean isBookmarked(String u) { return bookmarks.contains(u); }

    /** @return true - добавлена, false - удалена или список полон (проверять isBookmarked) */
    boolean toggleBookmark(String u) {
        if (bookmarks.remove(u)) return false;
        if (bookmarks.size() >= MAX_BM) return false;
        bookmarks.add(u);
        return true;
    }

    // ------------------------------------------------------------------ подсказки
    /** Подсказки адреса: сначала адреса, начинающиеся с текста, затем содержащие; пустой текст - недавние и закладки. */
    List<String> suggest(String typed, int max) {
        String p = typed == null ? "" : typed.trim().toLowerCase();
        for (String pre : new String[] {"pc://", "http://", "https://"}) if (p.startsWith(pre)) p = p.substring(pre.length());
        List<String> pool = new ArrayList<String>();
        for (int i = history.size() - 1; i >= 0; i--) add(pool, history.get(i));
        for (String b : bookmarks) add(pool, b);
        List<String> builtin = new ArrayList<String>(WinWeb.BUILTIN);
        java.util.Collections.sort(builtin);
        for (String b : builtin) add(pool, b);
        List<String> out = new ArrayList<String>();
        if (p.isEmpty()) {
            for (String s : pool) if (out.size() < max) out.add(s);
            return out;
        }
        for (String s : pool) if (s.startsWith(p) && !s.equals(p) && out.size() < max) out.add(s);
        for (String s : pool) if (!s.startsWith(p) && s.contains(p) && out.size() < max) out.add(s);
        return out;
    }

    private static void add(List<String> l, String s) { if (!l.contains(s)) l.add(s); }

    // ------------------------------------------------------------------ кэш
    void cachePut(String url, WebPage pg) {
        cache.remove(url);
        cache.put(url, pg);
        while (cache.size() > MAX_CACHE) cache.remove(cache.keySet().iterator().next());
    }

    WebPage cacheGet(String url) { return cache.get(url); }

    // ------------------------------------------------------------------ загрузка
    /** Размер страницы в «байтах» для индикатора: текст, таблицы, картинки. */
    static int weight(WebPage pg) {
        long w = 600;
        for (WebRow r : pg.rows) {
            w += r.text.length() + 40;
            if (r.cells != null) for (String c : r.cells) w += c.length() + 8;
            if (r.pix != null) w += r.pw * r.ph / 2;
        }
        return (int) Math.min(40000, w);
    }

    /** Скорость канала, байт/с: кабель 3072, Wi-Fi 1024-3072 по сигналу 0..4, сотовая 4G по уровню сети 2..4. */
    static double rate(int chan, int signal) {
        switch (chan) {
            case WIRED: return 3072;
            case WIFI: return 1024 + 512 * Math.max(0, Math.min(4, signal));
            case CELL: return 768 + 256 * Math.max(0, Math.min(4, signal));
            default: return 0;
        }
    }

    /** Начать загрузку страницы весом total; fromCache - страница уже в кэше (загрузка в 4 раза короче). */
    void startLoad(Tab t, int total, boolean fromCache) {
        t.loading = true;
        t.done = 0;
        t.total = Math.max(1, fromCache ? total / 4 : total);
    }

    /** Один тик загрузки (20 в секунду). true - прогресс изменился (нужен кадр). rate - байт/с с учётом лагов. */
    boolean tickLoad(Tab t, double rate) {
        if (!t.loading) return false;
        int before = t.pct();
        t.done += rate * PAGE_SPEEDUP / 20.0;
        if (t.done >= t.total) {
            t.loading = false;
            t.done = t.total;
            return true;
        }
        return t.pct() != before;
    }

    // ------------------------------------------------------------------ хранение (строки через \n)
    static String join(List<String> l) { return String.join("\n", l); }

    static void split(String s, List<String> out, int max) {
        out.clear();
        if (s == null || s.isEmpty()) return;
        for (String p : s.split("\n")) {
            String n = p.trim();
            if (n.isEmpty() || n.length() > 60 || out.contains(n) || !n.matches("[a-z0-9./_-]+")) continue;
            out.add(n);
            if (out.size() >= max) break;
        }
    }
}
