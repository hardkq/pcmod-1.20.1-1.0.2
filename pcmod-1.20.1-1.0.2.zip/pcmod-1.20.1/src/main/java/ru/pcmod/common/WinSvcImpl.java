package ru.pcmod.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;

/** Службы мира для WinCraft 11 поверх ПК: чат (ChatClient), магазин (Shop), банк (Bank), загрузки. */
final class WinSvcImpl implements WinSvc {
    private static final Map<String, String> RU = new HashMap<String, String>();

    static {
        String[][] t = {
                {"No server found", "Сервер не найден"}, {"Password must not be empty", "Пароль не может быть пустым"},
                {"Bad nick (a-z, 0-9, _; max 16)", "Ник: a-z, 0-9, _ (до 16 знаков, первая - буква)"}, {"Nick is already taken", "Ник уже занят"},
                {"Unknown user", "Нет такого пользователя"}, {"Wrong password", "Неверный пароль"},
                {"Not connected to the server", "Нет связи с сервером"}, {"Not logged in", "Вход не выполнен"},
                {"No such user", "Нет такого пользователя"}, {"Cannot message yourself", "Нельзя писать самому себе"},
                {"Empty message", "Пустое сообщение"}, {"Message is too long (max 100)", "Сообщение длиннее 100 знаков"},
                {"Session expired, please log in again", "Сеанс истёк, войдите снова"},
                {"Bank is unavailable", "Банк недоступен"}, {"No kons banknotes in your inventory", "В инвентаре нет купюр"},
                {"Enter an amount", "Введите сумму"}, {"Account limit reached", "Достигнут предел счёта"},
                {"Not enough funds on the account", "Недостаточно средств на счёте"},
                {"Catalog has just changed - check it again", "Каталог только что обновился - проверьте снова"},
                {"Item is not on sale", "Товар снят с продажи"}, {"This item is free", "Товар бесплатный"}, {"You already own this", "Лицензия уже куплена"},
                {"Internal error", "Внутренняя ошибка, попробуйте ещё раз"}, {"Select an item first", "Сначала выберите товар"}, {"Sold out until the next catalog", "Распродано до смены каталога"},
                {"Your limit for this item is reached", "Ваш лимит на этот товар исчерпан"},
                {"Bad domain (a-z, 0-9, hyphen; 3-16 chars)", "Адрес: a-z, 0-9, дефис, 3-16 знаков"}, {"This domain is reserved", "Этот адрес зарезервирован"},
                {"Domain is not allowed", "Этот адрес запрещён"}, {"Domain is already taken", "Адрес уже занят"}, {"No such site", "Нет такого сайта"},
                {"This is not your site", "Это не ваш сайт"}, {"Site is blocked", "Сайт заблокирован"},
                {"Domain has expired - renew it first", "Срок домена вышел - сначала продлите"}, {"Cannot renew that far ahead", "Так далеко вперёд продлить нельзя"},
                {"Bad page name (a-z, 0-9, _, -; max 24)", "Имя страницы: a-z, 0-9, _, - (до 24 знаков)"}, {"Page not found", "Страница не найдена"},
                {"Page saved", "Страница сохранена"}, {"Page deleted", "Страница удалена"}, {"Saved", "Сохранено"}, {"Empty page", "Пустая страница"},
                {"Text contains forbidden words", "Текст содержит запрещённые слова"}, {"Page contains forbidden characters", "Недопустимые символы в тексте"},
                {"Bad tag (letters, digits, hyphen)", "Тег: буквы, цифры, дефис"}, {"Site hosting is unavailable (503)", "Хостинг недоступен (503)"},
                {"Bad action", "Недопустимое действие"}, {"Too fast - wait a little", "Слишком часто - подождите немного"},
                {"Owner has no chat account", "У владельца нет аккаунта в чате"}, {"Message sent to the owner", "Сообщение отправлено владельцу"},
                {"You cannot pay yourself", "Нельзя платить самому себе"}, {"Donation: 1-1000 kons", "Донат: от 1 до 1000 консов"},
                {"This page is free", "Страница бесплатная"}, {"You already have access", "Доступ уже есть"}, {"Page sales are closed", "Продажа доступа закрыта"},
                {"Rate 1-5", "Оценка от 1 до 5"}, {"You cannot rate your own site", "Нельзя оценивать свой сайт"}, {"Rating is closed", "Оценки закрыты"},
                {"Thanks for your rating", "Спасибо за оценку"}, {"You cannot report your own site", "Нельзя жаловаться на свой сайт"},
                {"Describe the problem (3+ chars)", "Опишите проблему (от 3 знаков)"}, {"You have already reported this site", "Вы уже жаловались на этот сайт"},
                {"Reports saved", "Жалоб уже достаточно"}, {"Report sent", "Жалоба отправлена"}, {"Guestbook is full", "Гостевая книга заполнена"},
                {"Too many entries waiting for approval", "Слишком много записей ждёт одобрения"}, {"Entry added", "Запись добавлена"},
                {"Entry sent: it will appear after the owner approves it", "Запись отправлена: появится после одобрения владельцем"},
                {"Entry approved", "Запись одобрена"}, {"Entry deleted", "Запись удалена"}, {"Entry not found", "Запись не найдена"},
                {"Owner's account is full", "Счёт владельца переполнен"}, {"The home page cannot be paid", "Главная страница не может быть платной"}};
        for (String[] r : t) RU.put(r[0], r[1]);
    }

    private final ComputerLogic l;

    WinSvcImpl(ComputerLogic l) {
        this.l = l;
    }

    private static String lineRu(String t) {
        String[][] m = {{"Line is too long (max ", "Строка длиннее "}, {"Too many elements (max ", "Слишком много элементов (до "},
                {"Too many images (max ", "Слишком много картинок (до "}, {"Too many table columns (max ", "Слишком много столбцов (до "},
                {"Table cell is too long (max ", "Ячейка длиннее "}};
        for (String[] e : m) {
            if (t.startsWith(e[0])) {
                String n = t.substring(e[0].length(), t.length() - 1);
                return e[1] + n + (e[1].endsWith("длиннее ") ? " знаков" : ")");
            }
        }
        String[][] x = {{"Bad style (colors, b, dim, ok, err)", "Стиль: цвета, b, dim, ok, err"}, {"Bad price", "Недопустимая цена (@price)"},
                {"Bad form (name label)", "Форма: @form имя подпись"}, {"Unknown directive", "Неизвестная директива"},
                {"Bad link target", "Недопустимая цель ссылки"}, {"Bad color", "Неизвестный цвет"}, {"Empty text", "Пустой текст"},
                {"Image: bad size (1-32 x 1-32)", "Картинка: размер 1-32 x 1-32"}, {"Image: rows must have equal width", "Картинка: строки разной длины"},
                {"Image: bad pixel (0-9, a-f, .)", "Картинка: пиксели 0-9, a-f и точка"}, {"Image is not closed (@end)", "Картинка не закрыта (@end)"},
                {"Table rows must have the same number of cells", "В строках таблицы разное число ячеек"}};
        for (String[] e : x) if (t.equals(e[0])) return e[1];
        return t;
    }

    static String ru(String s) {
        if (s == null) return null;
        String r = RU.get(s);
        if (r != null) return r;
        if (s.startsWith("Line ")) {
            int c = s.indexOf(": ");
            if (c > 5) return "Строка " + s.substring(5, c) + ": " + lineRu(s.substring(c + 2));
        }
        if (s.startsWith("Donated ")) {
            int to = s.lastIndexOf(" to ");
            return "Донат " + s.substring(8, to < 0 ? s.length() : to) + " отправлен: " + (to < 0 ? "" : s.substring(to + 4));
        }
        if (s.startsWith("Access bought for ")) return "Доступ куплен за " + s.substring(18);
        if (s.startsWith("Message is too long")) return "Сообщение слишком длинное (до 100 знаков)";
        if (s.startsWith("Not enough kons (need ")) return "Не хватает консов (нужно " + s.substring(22, s.length() - 1) + ")";
        if (s.startsWith("Max withdrawal is ")) return "Снять за раз можно не больше " + s.substring(18);
        if (s.startsWith("You carry only ")) return "У вас с собой только " + s.substring(15);
        if (s.startsWith("Deposited ")) return "Внесено " + s.substring(10).replace("(change ", "(сдача ");
        if (s.startsWith("Withdrew ")) return "Снято " + s.substring(9);
        if (s.startsWith("Site limit reached (")) return "Достигнут лимит сайтов: " + s.substring(20, s.length() - 1);
        if (s.startsWith("Registered ")) {
            int f = s.indexOf(" for ");
            return f < 0 ? s : "Адрес зарегистрирован: " + s.substring(11, f) + " за " + s.substring(f + 5);
        }
        if (s.startsWith("Renewed ")) {
            int f = s.indexOf(" for ");
            return f < 0 ? s : "Продлено: " + s.substring(8, f) + " за " + s.substring(f + 5);
        }
        if (s.startsWith("Released ")) return "Адрес освобождён: " + s.substring(9);
        if (s.startsWith("Page is too large (max ")) return "Страница слишком большая (до " + s.substring(23, s.length() - 7) + " байт)";
        if (s.startsWith("Site is too large (max ")) return "Сайт слишком большой (до " + s.substring(23, s.length() - 7) + " байт)";
        if (s.startsWith("Too many pages (max ")) return "Слишком много страниц (до " + s.substring(20, s.length() - 1) + ")";
        if (s.startsWith("Title is too long (max ")) return "Название слишком длинное (до " + s.substring(23, s.length() - 1) + " знаков)";
        if (s.startsWith("Too many tags")) return "Слишком много или слишком длинные теги (до 5 по 12 знаков)";
        if (s.startsWith("Bought ")) {
            int f = s.indexOf(" for ");
            return f < 0 ? s : "Куплено: " + s.substring(7, f) + " за " + s.substring(f + 5);
        }
        return s;
    }

    private static Res res(Bank.Res r) { return new Res(r.ok, ru(r.msg)); }

    // ------------------------------------------------------------------ сеть
    @Override public boolean netUp() { return l.link().up(); }

    @Override
    public String server() {
        TileServer s = l.chat.server();
        return s == null ? "" : s.domain;
    }

    @Override
    public List<String> servers() {
        List<String> r = new ArrayList<String>();
        for (TileServer s : l.chat.servers()) r.add(s.domain);
        return r;
    }

    @Override
    public double linkRate() {
        NetLink k = l.link();
        double fx = VirusEffects.netSpeed(l);
        if (k.type == NetLink.WIRED) return 3072 * fx;
        if (k.type == NetLink.WIFI) return (1024 + 512 * Math.max(0, Math.min(4, k.signal))) * fx;
        return 0;
    }

    // ------------------------------------------------------------------ чат
    @Override public String chatSavedNick() { return l.chat.savedNick(); }

    @Override public String chatNick() { return l.chat.nick == null ? "" : l.chat.nick; }

    @Override public boolean chatOnline() { return l.chat.online; }

    @Override public int chatRev() { return l.chat.rev; }

    @Override public String chatLogin(String nick, String pass) { return ru(l.chat.login(nick, pass)); }

    @Override public String chatRegister(String nick, String pass) { return ru(l.chat.register(nick, pass)); }

    @Override public void chatLogout() { l.chat.logout(); }

    @Override public void chatNextServer() { l.chat.nextServer(); }

    @Override public List<String> chatUsers() { return new ArrayList<String>(l.chat.users); }

    @Override public boolean chatUserOnline(String nick) { return l.chat.onlineNicks.contains(nick); }

    @Override
    public List<Msg> chatThread(String peer) {
        List<Msg> r = new ArrayList<Msg>();
        for (ChatStore.Msg m : l.chat.thread(peer)) r.add(new Msg(m.from, m.text, m.time, m.from.equals(l.chat.nick)));
        return r;
    }

    @Override public int chatUnread(String peer) { return peer == null ? l.chat.totalUnread() : l.chat.unreadFor(peer); }

    @Override
    public void chatView(String peer) {
        l.chat.viewing = peer;
        if (peer != null) l.chat.unread.remove(peer);
    }

    @Override public String chatSend(String to, String text) { return ru(l.chat.send(to, text)); }

    @Override public boolean chatPoll() { return l.chat.poll(); }

    // ------------------------------------------------------------------ банк и магазин
    @Override public boolean bankReady() { return l.link().up() && l.chat.server() != null && Bank.get() != null; }

    @Override public String account() { return l.actorName; }

    @Override
    public long balance() {
        Bank b = Bank.get();
        return b == null ? 0 : b.balance(l.actorId);
    }

    @Override public long cash() { return l.actor == null ? -1 : Bank.cash(l.actor); }

    @Override
    public List<String> history() {
        Bank b = Bank.get();
        return b == null ? new ArrayList<String>() : new ArrayList<String>(b.history(l.actorId));
    }

    @Override
    public Res deposit(long amount) {
        Bank b = Bank.get();
        if (l.actor == null) return new Res(false, "Нажмите любую клавишу у монитора");
        if (!bankReady() || b == null) return new Res(false, "Нет связи с сервером");
        return res(b.deposit(l.actor, amount));
    }

    @Override
    public Res withdraw(long amount) {
        Bank b = Bank.get();
        if (l.actor == null) return new Res(false, "Нажмите любую клавишу у монитора");
        if (!bankReady() || b == null) return new Res(false, "Нет связи с сервером");
        return res(b.withdraw(l.actor, amount));
    }

    @Override public long shopStamp() { return Shop.stamp(); }

    @Override public int shopSeconds() { return Shop.secondsLeft(); }

    @Override
    public List<Offer> catalog() {
        List<Offer> r = new ArrayList<Offer>();
        Bank b = Bank.get();
        if (b == null) return r;
        for (Shop.Offer o : Shop.catalog()) {
            r.add(new Offer(o.key, o.name, o.price, o.limit, o.stock, Shop.playerLeft(b, l.actorId, o), Shop.stockLeft(b, o)));
        }
        return r;
    }

    @Override
    public Res buy(int index, int qty, long stamp) {
        if (l.actor == null) return new Res(false, "Нажмите любую клавишу у монитора");
        if (!bankReady()) return new Res(false, "Нет связи с сервером");
        return res(Shop.buy(l.actor, index, qty, stamp));
    }

    // ------------------------------------------------------------------ реестр товаров и лицензии
    private static String kindId(int kind) { return kind == DL_AV ? "av" : "doom"; }

    private static SoftItem pcItem(String id) {
        SoftItem i = SoftRegistry.get(id);
        return i != null && i.isPc() && !i.mainFile.isEmpty() ? i : null;
    }

    @Override public List<SoftItem> softCatalog() { return SoftRegistry.all(); }

    @Override
    public int softPrice(String id) {
        SoftItem i = SoftRegistry.get(id);
        return i == null ? 0 : SoftRegistry.price(i);
    }

    @Override public boolean softLicensed(String id) { return SoftLicenses.allowed(l.actorId, SoftRegistry.get(id)); }

    @Override
    public Res softBuy(String id) {
        if (l.actor == null) return new Res(false, "Нажмите любую клавишу у монитора");
        if (!bankReady()) return new Res(false, "Нет связи с сервером");
        return res(SoftLicenses.buy(l.actor, id));
    }

    @Override
    public boolean softInstalled(String id) {
        SoftItem it = pcItem(id);
        CompoundTag r = l.root();
        return it != null && r != null && VFS.isFile(r, it.mainFile);
    }

    @Override
    public boolean softRunnable(String id) {
        SoftItem it = SoftRegistry.get(id);
        return it != null && (it.legacy || SoftLicenses.allowed(l.actorId, it));
    }

    /** Общие причины отказа для загрузки и установки (null - можно). */
    private String softBlock(SoftItem it) {
        if (!SoftLicenses.allowed(l.actorId, it)) return "Нужна лицензия: купите на сайте soft.pc";
        if (it.reqRamMB > 0 && l.t.totalRamMB() < it.reqRamMB) return "Мало ОЗУ: нужно " + it.reqRamMB + " МБ";
        return null;
    }

    private String doneText(SoftItem it) { return it.noun + " уже установлен"; }

    @Override
    public String softDlCheck(String id) {
        SoftItem it = pcItem(id);
        if (it == null || it.setupFile.isEmpty()) return "Неизвестная программа";
        CompoundTag r = l.root();
        if (r == null) return "Система не установлена";
        if (softInstalled(id)) return doneText(it);
        String b = softBlock(it);
        if (b != null) return b;
        if (VFS.isFile(r, downloads() + "/" + it.setupFile)) return "Уже скачано: откройте папку «Загрузки»";
        if (VFS.free(r, capKB()) < it.setupSize + 128) return "Мало места на диске (нужно " + it.setupSize / 1024 + " КБ)";
        return null;
    }

    @Override
    public boolean softDlFinish(String id) {
        SoftItem it = pcItem(id);
        CompoundTag r = l.root();
        if (it == null || r == null || it.setupFile.isEmpty() || softBlock(it) != null) return false;
        String dir = downloads();
        if (!VFS.isDir(r, dir)) VFS.mkdir(r, dir);
        boolean ok = VFS.isDir(r, dir) && VFS.writeSized(r, dir + "/" + it.setupFile, it.setupMagic, it.setupSize - it.setupMagic.length(), capKB());
        l.t.setChanged();
        return ok;
    }

    @Override
    public String softSetupId(String path) {
        CompoundTag r = l.root();
        if (r == null || !path.endsWith(".exe")) return "";
        return SoftRegistry.setupId(VFS.read(r, path));
    }

    @Override
    public String softSetupPath(String id) {
        SoftItem it = pcItem(id);
        CompoundTag r = l.root();
        if (it == null || r == null || it.setupFile.isEmpty()) return "";
        String p = downloads() + "/" + it.setupFile;
        return VFS.isFile(r, p) ? p : "";
    }

    @Override
    public String softSetupCheck(String id, String path) {
        SoftItem it = pcItem(id);
        if (it == null) return "Неизвестная программа";
        CompoundTag r = l.root();
        if (r == null) return "Система не установлена";
        if (softInstalled(id)) return doneText(it);
        String b = softBlock(it);
        if (b != null) return b;
        int inst = VFS.sizeOf(r, path);
        if (inst < 0) return "Файл установщика не найден";
        if (VFS.free(r, capKB()) + inst + 16 < it.needBytes) return "Мало места на диске: нужно " + (it.needBytes + 1023) / 1024 + " КБ";
        return null;
    }

    @Override
    public Res softSetupRun(String id, String path) {
        String e = softSetupCheck(id, path);
        if (e != null) return new Res(false, e);
        SoftItem it = pcItem(id);
        CompoundTag r = l.root();
        VFS.remove(r, path);
        for (String d : it.dirs) if (!VFS.isDir(r, d)) VFS.mkdir(r, d);
        boolean ok = VFS.writeSized(r, it.mainFile, it.mainMagic, it.installedSize - it.mainMagic.length(), capKB());
        l.t.setChanged();
        if (!ok) return new Res(false, "Не удалось установить: диск заполнен");
        if (it.post != null) it.post.accept(l);
        return new Res(true, "");
    }

    // ------------------------------------------------------------------ загрузки (DOOM и антивирус - через реестр)
    private int capKB() {
        PartSpec sto = l.t.spec(TileComputer.STORAGE);
        return sto == null ? 0 : sto.storageKB;
    }

    private String downloads() { return "/home/" + l.user + "/Downloads"; }

    @Override public boolean installed(int kind) { return softInstalled(kindId(kind)); }

    @Override public String dlName(int kind) { return SoftRegistry.get(kindId(kind)).setupFile; }

    @Override public int dlSize(int kind) { return SoftRegistry.get(kindId(kind)).setupSize; }

    @Override public String dlCheck(int kind) { return softDlCheck(kindId(kind)); }

    @Override public boolean dlFinish(int kind) { return softDlFinish(kindId(kind)); }

    // ------------------------------------------------------------------ антивирус
    @Override
    public int avState() {
        if (!Antivirus.installed(l.root())) return 0;
        return Antivirus.threats(l.t, true) > 0 ? 2 : 1;
    }

    private static String virusKind(int type) {
        switch (type) {
            case Virus.TYPE_FILE_CORRUPTED: return "повреждение файлов";
            case Virus.TYPE_PERFORMANCE_DRAIN: return "замедление системы";
            case Virus.TYPE_DISK_SPACE: return "занимает место на диске";
            case Virus.TYPE_NETWORK_HIJACK: return "перехват сети";
            case Virus.TYPE_SYSTEM_INSTABILITY: return "нестабильность системы";
            default: return "скрытая программа";
        }
    }

    @Override
    public List<String[]> avThreats() {
        List<String[]> r = new ArrayList<String[]>();
        for (Virus v : l.t.viruses()) {
            if (!v.incoming) continue;
            r.add(new String[] {v.virusId, virusKind(v.type) + ", опасность " + v.severity + "%" + (v.ignored ? ", отложено" : "")});
        }
        return r;
    }

    @Override public int avWaiting() { return Antivirus.threats(l.t, false); }

    @Override public void avRemove() { Antivirus.actionRemove(l); }

    @Override public void avWait() { Antivirus.actionWait(l); }

    // ------------------------------------------------------------------ установщик программ (через реестр)
    @Override
    public int setupKind(String path) {
        String id = softSetupId(path);
        return id.equals("doom") ? DL_DOOM : id.equals("av") ? DL_AV : 0;
    }

    @Override public String setupName(int kind) { return SoftRegistry.get(kindId(kind)).ru; }

    @Override public String setupFolder(int kind) { return SoftRegistry.get(kindId(kind)).folder(); }

    @Override public int setupBytes(int kind) { return SoftRegistry.get(kindId(kind)).needBytes; }

    @Override public String setupCheck(int kind, String path) { return softSetupCheck(kindId(kind), path); }

    @Override public Res setupRun(int kind, String path) { return softSetupRun(kindId(kind), path); }

    // ------------------------------------------------------------------ сайты игроков
    @Override public SiteHost.Resp siteFetch(String domain, String page) { return SiteHost.fetch(l.link().up(), l.chat.server(), domain, page, l.actorId); }

    @Override public List<SiteStore.Listing> siteSearch(String q, int section, int max) { return SiteStore.search(q, section, max); }

    @Override
    public Res siteAct(String target, String input) {
        if (l.actor == null) return new Res(false, "Нажмите любую клавишу у монитора");
        String e = SiteHost.reach(l.link().up(), l.chat.server());
        return e != null ? new Res(false, ru(e)) : res(SiteStore.act(l.actor, l.chat.server(), target, input));
    }

    @Override public List<SiteStore.Info> siteMine() { return SiteStore.mine(l.actorId); }

    @Override
    public int[] siteTerms() {
        return new int[] {SiteConfig.price(), SiteConfig.renewPrice(), SiteConfig.days(), SiteConfig.maxSites(),
                SiteConfig.maxPages(), SiteConfig.maxPageBytes(), SiteConfig.maxTotalBytes()};
    }

    /** null - можно выполнять операцию с сайтом (игрок у монитора, сеть и сервер отвечают). */
    private Res siteGuard() {
        if (l.actor == null) return new Res(false, "Нажмите любую клавишу у монитора");
        if (!SoftLicenses.allowed(l.actorId, SoftRegistry.get("sitebuilder"))) return new Res(false, "Нужна лицензия «Конструктор сайтов»: купите на soft.pc");
        String e = SiteHost.reach(l.link().up(), l.chat.server());
        return e == null ? null : new Res(false, ru(e));
    }

    @Override
    public Res siteRegister(String domain) {
        Res g = siteGuard();
        return g != null ? g : res(SiteStore.register(l.actor, domain));
    }

    @Override
    public Res siteRenew(String domain) {
        Res g = siteGuard();
        return g != null ? g : res(SiteStore.renew(l.actor, domain));
    }

    @Override
    public Res siteRelease(String domain) {
        Res g = siteGuard();
        return g != null ? g : res(SiteStore.release(l.actor, domain));
    }

    @Override
    public Res sitePut(String domain, String page, String markup) {
        Res g = siteGuard();
        return g != null ? g : res(SiteStore.putPage(l.actor, domain, page, markup));
    }

    @Override
    public Res siteDeletePage(String domain, String page) {
        Res g = siteGuard();
        return g != null ? g : res(SiteStore.deletePage(l.actor, domain, page));
    }

    @Override
    public Res siteMeta(String domain, String title, String tags) {
        Res g = siteGuard();
        return g != null ? g : res(SiteStore.setMeta(l.actor, domain, title, tags));
    }

    // ------------------------------------------------------------------ мобильный оператор
    private TileServer mobServer() { return l.link().up() ? l.chat.server() : null; }

    /** null - можно выполнять операцию (игрок у монитора, сеть и сервер отвечают). */
    private Res mobGuard() {
        if (l.actor == null) return new Res(false, "Нажмите любую клавишу у монитора");
        return mobServer() == null ? new Res(false, "Нет связи с сервером") : null;
    }

    @Override public SoftMobileOperator.View mobState() { return SoftMobileOperator.view(mobServer(), l.actorId); }

    @Override
    public Res mobBuyLicense(String name) {
        Res g = mobGuard();
        return g != null ? g : SoftMobileOperator.buyLicense(mobServer(), l.actor, name);
    }

    @Override
    public Res mobAddTariff(String name, int activationCost, int mbPrice, int dailyFee) {
        Res g = mobGuard();
        return g != null ? g : SoftMobileOperator.addTariff(mobServer(), l.actorId, name, activationCost, mbPrice, dailyFee);
    }

    @Override
    public Res mobDelTariff(String tariffId) {
        Res g = mobGuard();
        return g != null ? g : SoftMobileOperator.delTariff(mobServer(), l.actorId, tariffId);
    }

    @Override
    public Res mobIssueSim(String tariffId) {
        Res g = mobGuard();
        return g != null ? g : SoftMobileOperator.issueSim(mobServer(), l.actor, tariffId);
    }

    @Override
    public Res mobBuyData(int mb) {
        Res g = mobGuard();
        return g != null ? g : SoftMobileOperator.buyData(mobServer(), l.actor, mb);
    }

    @Override
    public Res mobPayout() {
        Res g = mobGuard();
        return g != null ? g : SoftMobileOperator.payout(mobServer(), l.actorId);
    }
}
