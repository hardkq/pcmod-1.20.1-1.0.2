package ru.pcmod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Зарядная станция: в ней стоит один телефон, заряжается по ChargeRate мА·ч в секунду. */
public class TileCharger extends BlockEntity {
    public static final int RATE = 50;
    private ItemStack phone = ItemStack.EMPTY;

    public TileCharger(BlockPos pos, BlockState st) { super(ModBlockEntities.CHARGER.get(), pos, st); }

    public ItemStack phone() { return phone; }

    public void setPhone(ItemStack s) {
        phone = s == null ? ItemStack.EMPTY : s;
        setChanged();
        if (level != null && !level.isClientSide)
            level.setBlock(worldPosition, getBlockState().setValue(BlockCharger.HAS_PHONE, !phone.isEmpty()), 3);
    }

    public ItemStack takePhone() {
        ItemStack s = phone;
        setPhone(ItemStack.EMPTY);
        return s;
    }

    /** Серверный тик (ticker в BlockCharger). */
    public void tick() {
        if (level == null || level.isClientSide || phone.isEmpty() || level.getGameTime() % 20 != 0) return;
        if (ItemPhone.addCharge(phone, RATE)) setChanged();
    }

    @Override public void load(CompoundTag t) {
        super.load(t);
        phone = t.contains("Phone") ? ItemStack.of(t.getCompound("Phone")) : ItemStack.EMPTY;
    }

    @Override protected void saveAdditional(CompoundTag t) {
        super.saveAdditional(t);
        if (!phone.isEmpty()) t.put("Phone", phone.save(new CompoundTag()));
    }
}
