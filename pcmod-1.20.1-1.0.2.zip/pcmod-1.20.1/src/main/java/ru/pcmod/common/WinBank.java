package ru.pcmod.common;

import java.util.List;

/** Банк: баланс счёта, наличные в инвентаре игрока, внесение и снятие консов, история операций. */
public final class WinBank implements WinApp {
    private static final int ST = 14;
    private final WinSoft s;
    private final WinSvc svc;
    private final WinUi.Field amt = new WinUi.Field(0, 0, 70);
    private final WinUi.Button bDep = new WinUi.Button("Внести", 0, 0, 50, true), bAll = new WinUi.Button("Внести всё", 0, 0, 70, false),
            bWd = new WinUi.Button("Снять", 0, 0, 44, false);
    private long bal, cash = -1;
    private List<String> hist = new java.util.ArrayList<String>();
    private String msg = "";
    private boolean msgOk, lastUp = true;
    private int hover = -1, aw = 250, ah = 130, ox, oy, hsc;

    public WinBank(WinSoft s) {
        this.s = s;
        this.svc = s.svc;
        amt.max = 9;
        amt.hint = "Сумма";
        refresh();
    }

    @Override public String title() { return "Банк"; }

    @Override public String id() { return "bank"; }

    @Override public int minW() { return 236; }

    @Override public int minH() { return 110; }

    private boolean ready() { return svc.bankReady(); }

    private void refresh() {
        if (!ready()) return;
        bal = svc.balance();
        cash = svc.cash();
        hist = svc.history();
    }

    private long amount() {
        try {
            return amt.sb.length() == 0 ? 0 : Long.parseLong(amt.sb.toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ рисование
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        ox = x;
        oy = y;
        if (!ready()) {
            p.drawTextCentered(x, w, y + h / 2 - 10, svc.netUp() ? "Банк недоступен" : "Нет подключения к сети", th.bad(), 1, true);
            p.drawTextCentered(x, w, y + h / 2 + 2, "Нужна сеть с сервером", th.sub(), 1, false);
            return;
        }
        // карточка счёта
        p.roundRectBorder(x + 6, y + 6, w - 12, 36, 6, th.surface(), th.border());
        p.drawText(x + 14, y + 11, "Счёт: " + (svc.account().isEmpty() ? "-" : svc.account()), th.sub());
        p.drawText(x + 14, y + 22, WinSoft.kons(bal) + " К", th.text(), 2, true);
        p.drawTextRight(x + w - 14, y + 11, "Наличные", th.sub(), 1, false);
        p.drawTextRight(x + w - 14, y + 24, cash < 0 ? "-" : WinSoft.kons(cash) + " К", th.text(), 1, true);
        // операции
        int oy2 = y + 48;
        amt.x = x + 6;
        amt.y = oy2;
        amt.w = 70;
        amt.draw(p, th, true, s.host.time());
        bDep.w = PixelScreen.textWidth(bDep.label) + 16;
        bAll.w = PixelScreen.textWidth(bAll.label) + 16;
        bWd.w = PixelScreen.textWidth(bWd.label) + 16;
        bDep.x = x + 80;
        bAll.x = bDep.x + bDep.w + 3;
        bWd.x = bAll.x + bAll.w + 3;
        bDep.y = bAll.y = bWd.y = oy2;
        bDep.hover = hover == 0;
        bAll.hover = hover == 1;
        bWd.hover = hover == 2;
        bDep.enabled = amount() > 0;
        bWd.enabled = amount() > 0;
        bDep.draw(p, th);
        bAll.draw(p, th);
        bWd.draw(p, th);
        if (!msg.isEmpty()) p.drawText(x + 8, oy2 + 20, PixelScreen.fit(msg, w - 16, 1, false), msgOk ? th.ok() : th.bad());
        // история
        int hy = oy2 + 32, rows = Math.max(0, (y + h - hy - 2) / 10);
        p.drawText(x + 8, hy - 1, "Последние операции", th.text(), 1, true);
        hy += 11;
        rows--;
        int n = hist.size();
        hsc = Math.max(0, Math.min(Math.max(0, n - rows), hsc));
        if (n == 0) p.drawText(x + 8, hy, "Операций пока нет", th.sub());
        for (int i = 0; i < rows && i + hsc < n; i++) {
            String t = hist.get(n - 1 - hsc - i);
            int c = t.startsWith("+") ? th.ok() : t.startsWith("-") ? th.bad() : th.text();
            p.drawText(x + 10, hy + i * 10, PixelScreen.fit(t, w - 24, 1, false), c);
        }
        WinSoft.scrollbar(p, th, x + w - 5, hy, rows * 10, n, rows, hsc);
    }

    // ------------------------------------------------------------------ ввод
    private void result(WinSvc.Res r) {
        msg = r.msg;
        msgOk = r.ok;
        if (r.ok) amt.sb.setLength(0);
        refresh();
    }

    private void doDeposit(boolean all) {
        long a = all ? -1 : amount();
        if (!all && a <= 0) return;
        result(svc.deposit(a));
    }

    private void doWithdraw() {
        long a = amount();
        if (a <= 0) return;
        result(svc.withdraw(a));
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int ax = rx + ox, ay = ry + oy, hv = -1;
        if (ready()) {
            if (bDep.hit(ax, ay)) hv = 0;
            else if (bAll.hit(ax, ay)) hv = 1;
            else if (bWd.hit(ax, ay)) hv = 2;
        }
        boolean d = hv != hover;
        hover = hv;
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            hsc = Math.max(0, hsc + (kind == PixelScreen.MOUSE_SCROLL_UP ? -1 : 1));
            return true;
        }
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return d;
        if (hv == 0) doDeposit(false);
        else if (hv == 1) doDeposit(true);
        else if (hv == 2) doWithdraw();
        else return d;
        return true;
    }

    @Override
    public boolean key(char c, int key) {
        if (!ready()) return false;
        if (WinUi.isEnter(c, key)) {
            doDeposit(false);
            return true;
        }
        if (key == WinUi.K_BACK || c == '\b' || (c >= '0' && c <= '9')) {
            amt.key(c, key);
            msg = "";
            return true;
        }
        return false;
    }

    @Override
    public boolean tick(long now) {
        boolean d = now % 10 == 0;
        boolean up = ready();
        if (up != lastUp) {
            lastUp = up;
            d = true;
        }
        if (up && now % 20 == 0) {
            long b = svc.balance(), c = svc.cash();
            int hn = svc.history().size();
            if (b != bal || c != cash || hn != hist.size()) {
                refresh();
                d = true;
            }
        }
        return d;
    }
}
