package ru.pcmod.common;

/** Рисование WinCraft 11: логотип, индикатор загрузки, обои, аватар, значки, курсор. */
public final class WinGfx {
    private WinGfx() {}

    private static final int W = PixelScreen.W, H = PixelScreen.H;
    private static final int[][] WALL = new int[WinWalls.COUNT * 2][], LOGIN = new int[WinWalls.COUNT * 2][],
            LOCK = new int[WinWalls.COUNT * 2][], MICA = new int[WinWalls.COUNT * 2][];

    private static int key(int idx, boolean dark) {
        return (idx < 0 || idx >= WinWalls.COUNT ? 0 : idx) * 2 + (dark ? 1 : 0);
    }

    // ------------------------------------------------------------------ обои
    /** Обои с номером idx (WinWalls) в светлом или тёмном варианте. Считаются один раз. */
    public static synchronized int[] wall(int idx, boolean dark) {
        int k = key(idx, dark);
        if (WALL[k] == null) WALL[k] = WinWalls.gen(k / 2, dark);
        return WALL[k];
    }

    /** Обои «Bloom»: цветок на синем фоне. */
    static int[] genWall(boolean dark) {
        int[] o = new int[W * H];
        double cx = 172, cy = 96;
        int c1 = dark ? 0xFF04091F : 0xFFEAF2FC, c2 = dark ? 0xFF0B1E58 : 0xFFB9D6F4;
        int p0 = dark ? 0xFF16349A : 0xFF3F86E8, p1 = dark ? 0xFF3C8CFF : 0xFF0B4FC4, p2 = dark ? 0xFF8FDCFF : 0xFF0A2C86;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                float t = (x / (float) W * 0.6f + y / (float) H * 0.4f);
                int base = PixelScreen.lerp(c1, c2, t);
                double dx = x - cx, dy = (y - cy) * 1.1, r = Math.sqrt(dx * dx + dy * dy), th = Math.atan2(dy, dx);
                double f = 0;
                for (int k = 0; k < 3; k++) {
                    double pet = Math.max(0, Math.sin(th * 5 + r * (0.034 + 0.018 * k) + k * 1.9));
                    pet = pet * pet;
                    double sig = 60 + 15 * k;
                    f += pet * Math.exp(-r * r / (2 * sig * sig)) * (0.70 - 0.2 * k);
                }
                float v = (float) Math.min(1, f);
                int pc = v < 0.5f ? PixelScreen.lerp(p0, p1, v * 2) : PixelScreen.lerp(p1, p2, (v - 0.5f) * 2);
                int c = PixelScreen.lerp(base, pc, Math.min(1f, v * 1.25f));
                double g = Math.exp(-r * r / (2 * 22.0 * 22.0));
                c = PixelScreen.lerp(c, dark ? 0xFFBFE9FF : 0xFFFFFFFF, (float) (g * 0.55));
                o[y * W + x] = c | 0xFF000000;
            }
        }
        return o;
    }

    /** Фон экрана входа: размытые обои, затемнённые (как акрил в Windows 11). */
    public static synchronized int[] loginBg(int idx, boolean dark) {
        int k = key(idx, dark);
        if (LOGIN[k] == null) {
            int[] b = blur(wall(idx, dark), 7);
            for (int i = 0; i < b.length; i++) b[i] = PixelScreen.lerp(b[i] | 0xFF000000, 0xFF0A1428, 0.38f) | 0xFF000000;
            LOGIN[k] = b;
        }
        return LOGIN[k];
    }

    /** Фон экрана блокировки: обои с затемнением сверху (под крупные часы). */
    public static synchronized int[] lockBg(int idx, boolean dark) {
        int k = key(idx, dark);
        if (LOCK[k] == null) {
            int[] b = wall(idx, dark).clone();
            for (int y = 0; y < H; y++) {
                float a = y < 110 ? 0.45f * (1 - y / 110f) : 0f;
                float bt = y > 150 ? 0.3f * (y - 150) / 30f : 0f;
                for (int x = 0; x < W; x++) {
                    int c = b[y * W + x];
                    if (a > 0) c = PixelScreen.lerp(c, 0xFF000814, a);
                    if (bt > 0) c = PixelScreen.lerp(c, 0xFF000814, bt);
                    b[y * W + x] = c | 0xFF000000;
                }
            }
            LOCK[k] = b;
        }
        return LOCK[k];
    }

    private static int[] blur(int[] src, int r) {
        int[] a = src.clone(), b = new int[src.length];
        for (int pass = 0; pass < 2; pass++) {
            for (int y = 0; y < H; y++) {
                for (int x = 0; x < W; x++) {
                    int sr = 0, sg = 0, sb = 0, n = 0;
                    for (int i = -r; i <= r; i++) {
                        int xx = Math.min(W - 1, Math.max(0, x + i)), c = a[y * W + xx];
                        sr += c >> 16 & 255;
                        sg += c >> 8 & 255;
                        sb += c & 255;
                        n++;
                    }
                    b[y * W + x] = 0xFF000000 | (sr / n) << 16 | (sg / n) << 8 | sb / n;
                }
            }
            for (int y = 0; y < H; y++) {
                for (int x = 0; x < W; x++) {
                    int sr = 0, sg = 0, sb = 0, n = 0;
                    for (int i = -r; i <= r; i++) {
                        int yy = Math.min(H - 1, Math.max(0, y + i)), c = b[yy * W + x];
                        sr += c >> 16 & 255;
                        sg += c >> 8 & 255;
                        sb += c & 255;
                        n++;
                    }
                    a[y * W + x] = 0xFF000000 | (sr / n) << 16 | (sg / n) << 8 | sb / n;
                }
            }
        }
        return a;
    }

    /** Размытые обои для Mica (кэш). */
    public static synchronized int[] micaSrc(int idx, boolean dark) {
        int k = key(idx, dark);
        if (MICA[k] == null) MICA[k] = blur(wall(idx, dark), 5);
        return MICA[k];
    }

    /** Mica: размытые обои под цветом темы (tint 0..255 - сколько цвета темы поверх обоев). Область в пределах экрана. */
    public static void mica(PixelScreen p, WinTheme th, int x, int y, int w, int h, int tint) {
        if (w <= 0 || h <= 0) return;
        fill(p, micaSrc(th.wall, th.dark), x, y, w, h);
        p.fillRect(x, y, w, h, (th.bg() & 0xFFFFFF) | (tint << 24));
    }

    /**
     * Полупрозрачная панель со скруглёнными углами: Mica с цветом base и прозрачностью alpha.
     * Без прозрачности (th.glass == false) панель сплошная.
     */
    public static void glass(PixelScreen p, WinTheme th, int x, int y, int w, int h, int r, int base, int alpha) {
        if (!th.glass) {
            p.roundRect(x, y, w, h, r, base | 0xFF000000);
            return;
        }
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        int[] src = micaSrc(th.wall, th.dark);
        fill(p, src, x, y + r, w, h - 2 * r);
        fill(p, src, x + r, y, w - 2 * r, r);
        fill(p, src, x + r, y + h - r, w - 2 * r, r);
        p.roundRect(x, y, w, h, r, (base & 0xFFFFFF) | (alpha << 24));
    }

    /** Снимок src (sw x sh, ARGB, прозрачные углы) в прямоугольник dw x dh с общей прозрачностью alpha (анимации окон). */
    public static void blitFit(PixelScreen p, int[] src, int sw, int sh, int dx, int dy, int dw, int dh, int alpha) {
        if (dw <= 0 || dh <= 0 || alpha <= 0) return;
        int[] t = new int[dw * dh];
        for (int j = 0; j < dh; j++) {
            int sy = Math.min(sh - 1, j * sh / dh);
            for (int i = 0; i < dw; i++) t[j * dw + i] = src[sy * sw + Math.min(sw - 1, i * sw / dw)];
        }
        p.blit(t, dw, 0, 0, dw, dh, dx, dy, alpha);
    }

    /** Закрасить прямоугольник куском готовой картинки экрана (фон под перерисовываемым элементом). */
    public static void fill(PixelScreen p, int[] src, int x, int y, int w, int h) {
        int x0 = Math.max(0, x), y0 = Math.max(0, y), x1 = Math.min(W, x + w), y1 = Math.min(H, y + h);
        if (x1 <= x0 || y1 <= y0) return;
        p.blit(src, W, x0, y0, x1 - x0, y1 - y0, x0, y0, 255);
    }

    public static void full(PixelScreen p, int[] src) {
        p.blit(src, W, 0, 0, W, H, 0, 0, 255);
    }

    // ------------------------------------------------------------------ логотип и индикатор
    /** Логотип WinCraft: четыре квадрата 2x2. */
    public static void logo(PixelScreen p, int x, int y, int size, int c) {
        int gap = Math.max(1, size / 14), s = (size - gap) / 2;
        p.fillRect(x, y, s, s, c);
        p.fillRect(x + s + gap, y, s, s, c);
        p.fillRect(x, y + s + gap, s, s, c);
        p.fillRect(x + s + gap, y + s + gap, s, s, c);
    }

    /** Круговой индикатор Windows 11: пять точек бегут по кругу и догоняют друг друга. tick - тики, период 44. */
    public static void spinner(PixelScreen p, int cx, int cy, int r, long tick, int c) {
        double t = (tick % 44) / 44.0;
        for (int i = 0; i < 5; i++) {
            double u = t - i * 0.055;
            u -= Math.floor(u);
            double e = u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2;
            double ang = e * 2 * Math.PI - Math.PI / 2;
            int x = cx + (int) Math.round(Math.cos(ang) * r), y = cy + (int) Math.round(Math.sin(ang) * r);
            p.roundRect(x - 1, y - 1, 3, 3, 1, c);
        }
    }

    /** Фоновый прямоугольник под индикатором (для перерисовки кадра). */
    public static int[] spinnerBox(int cx, int cy, int r) {
        return new int[] {cx - r - 3, cy - r - 3, 2 * r + 7, 2 * r + 7};
    }

    // ------------------------------------------------------------------ аватар и значки
    /** Круглый аватар пользователя диаметром d. */
    public static void avatar(PixelScreen p, int cx, int cy, int d, int bg, int fg) {
        int[] a = new int[d * d];
        double c = d / 2.0, R = d / 2.0;
        for (int j = 0; j < d; j++) {
            for (int i = 0; i < d; i++) {
                double x = i + 0.5, y = j + 0.5;
                double outer = cover(R - Math.hypot(x - c, y - c));
                if (outer <= 0) continue;
                double head = cover(d * 0.18 - Math.hypot(x - c, y - d * 0.38));
                double body = cover(d * 0.36 - Math.hypot(x - c, y - d * 1.0));
                double g = Math.max(head, body);
                int col = PixelScreen.lerp(bg | 0xFF000000, fg | 0xFF000000, (float) g);
                a[j * d + i] = PixelScreen.alpha(col, (int) Math.round(outer * 255));
            }
        }
        p.blit(a, d, d, cx - d / 2, cy - d / 2);
    }

    private static double cover(double v) {
        return Math.min(1, Math.max(0, v + 0.5));
    }

    /** Значок питания (кольцо с чёрточкой) радиусом r. */
    public static void power(PixelScreen p, int cx, int cy, int r, int c) {
        for (int y = cy - r - 2; y <= cy + r + 1; y++) {
            for (int x = cx - r - 2; x <= cx + r + 1; x++) {
                double dx = x + 0.5 - cx - 0.5, dy = y + 0.5 - cy - 0.5, d = Math.hypot(dx, dy);
                double ang = Math.toDegrees(Math.atan2(dx, -dy));
                boolean gap = Math.abs(ang) < 38;
                double cov = gap ? 0 : cover(0.75 - Math.abs(d - r));
                if (Math.abs(dx) < 0.9 && dy < 0 && dy > -r - 1.5 && dy < -0.5 + 0) cov = Math.max(cov, cover(0.95 - Math.abs(dx)));
                if (cov > 0.05) p.pixel(x, y, PixelScreen.alpha(c, (int) (cov * (c >>> 24))));
            }
        }
    }

    /** Линия в 1 пиксель. */
    public static void line(PixelScreen p, int x0, int y0, int x1, int y1, int c) {
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
        while (true) {
            p.pixel(x0, y0, c);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    /** Стрелка вправо. */
    public static void arrowRight(PixelScreen p, int cx, int cy, int c) {
        line(p, cx - 3, cy, cx + 3, cy, c);
        line(p, cx, cy - 3, cx + 3, cy, c);
        line(p, cx, cy + 3, cx + 3, cy, c);
    }

    /** Значок состояния в цветном круге: 2 - галочка, 1 - восклицательный знак, 0 - крестик. */
    public static void state(PixelScreen p, int cx, int cy, int state, WinTheme th) {
        int col = state == 2 ? 0xFF2E9E3E : state == 1 ? 0xFFE0A100 : 0xFFD13438;
        p.roundRect(cx - 6, cy - 6, 12, 12, 6, col);
        int w = 0xFFFFFFFF;
        if (state == 2) {
            line(p, cx - 3, cy, cx - 1, cy + 2, w);
            line(p, cx - 1, cy + 2, cx + 3, cy - 2, w);
        } else if (state == 1) {
            p.fillRect(cx, cy - 3, 1, 4, w);
            p.fillRect(cx, cy + 2, 1, 1, w);
        } else {
            line(p, cx - 2, cy - 2, cx + 2, cy + 2, w);
            line(p, cx - 2, cy + 2, cx + 2, cy - 2, w);
        }
    }

    // ------------------------------------------------------------------ текст
    /** Текст с мягкой тенью (для надписей на обоях). */
    public static void shadowText(PixelScreen p, int x, int y, String s, int c, int scale, boolean bold) {
        p.drawText(x + scale, y + scale, s, 0x66000000, scale, bold);
        p.drawText(x, y, s, c, scale, bold);
    }

    public static void shadowCentered(PixelScreen p, int x, int w, int y, String s, int c, int scale, boolean bold) {
        shadowText(p, x + (w - PixelScreen.textWidth(s, scale, bold)) / 2, y, s, c, scale, bold);
    }

    // ------------------------------------------------------------------ курсор мыши
    /** Виды указателя: стрелка, стрелки изменения размера (горизонталь, вертикаль, диагонали). */
    public static final int CUR_ARROW = 0, CUR_H = 1, CUR_V = 2, CUR_NWSE = 3, CUR_NESW = 4;

    /** Указатель. Рисуется в буфере поверх сцены, под ним запоминается фон. */
    public static final class Cursor {
        private static final String[] ARROW = {
                "k.........",
                "kk........",
                "kwk.......",
                "kwwk......",
                "kwwwk.....",
                "kwwwwk....",
                "kwwwwwk...",
                "kwwwwwwk..",
                "kwwwwwwwk.",
                "kwwwwwkkkk",
                "kwwkwwk...",
                "kwk.kwwk..",
                "kk..kwwk..",
                "k....kwwk.",
                ".....kwwk.",
                "......kk.."};
        /** Заливка стрелок размера ('w'); чёрная обводка достраивается сама. */
        private static final String[] FILL_H = {
                "...w...w...",
                "..ww...ww..",
                ".www...www.",
                "wwwwwwwwwww",
                ".www...www.",
                "..ww...ww..",
                "...w...w..."};
        private static final String[] FILL_V = transpose(FILL_H);
        private static final String[] FILL_NWSE = {
                "wwww.....",
                "www......",
                "www......",
                "w..w.....",
                "....w....",
                ".....w..w",
                "......www",
                "......www",
                ".....wwww"};
        private static final String[] FILL_NESW = mirror(FILL_NWSE);
        private static final String[][] SHAPES = {ARROW, outline(FILL_H), outline(FILL_V), outline(FILL_NWSE), outline(FILL_NESW)};
        private static final int MAXC = 16;
        private final int[] saved = new int[MAXC * MAXC];
        private boolean has;
        private int sx, sy, shape;

        private static String[] transpose(String[] a) {
            String[] r = new String[a[0].length()];
            for (int x = 0; x < r.length; x++) {
                StringBuilder b = new StringBuilder();
                for (String row : a) b.append(row.charAt(x));
                r[x] = b.toString();
            }
            return r;
        }

        private static String[] mirror(String[] a) {
            String[] r = new String[a.length];
            for (int i = 0; i < a.length; i++) r[i] = new StringBuilder(a[i]).reverse().toString();
            return r;
        }

        /** Заливка 'w' плюс чёрный контур 'k' шириной 1 пиксель (с рамкой в 1 пиксель вокруг). */
        private static String[] outline(String[] f) {
            int w = f[0].length() + 2, h = f.length + 2;
            char[][] g = new char[h][w];
            for (char[] row : g) java.util.Arrays.fill(row, '.');
            for (int y = 0; y < f.length; y++) for (int x = 0; x < f[y].length(); x++) if (f[y].charAt(x) == 'w') g[y + 1][x + 1] = 'w';
            String[] r = new String[h];
            for (int y = 0; y < h; y++) {
                StringBuilder b = new StringBuilder();
                for (int x = 0; x < w; x++) {
                    char c = g[y][x];
                    if (c != 'w') {
                        for (int dy = -1; dy <= 1 && c != 'k'; dy++)
                            for (int dx = -1; dx <= 1; dx++) {
                                int yy = y + dy, xx = x + dx;
                                if (yy >= 0 && yy < h && xx >= 0 && xx < w && g[yy][xx] == 'w') {
                                    c = 'k';
                                    break;
                                }
                            }
                    }
                    b.append(c);
                }
                r[y] = b.toString();
            }
            return r;
        }

        private static int hotX(int s) { return s == CUR_ARROW ? 0 : SHAPES[s][0].length() / 2; }

        private static int hotY(int s) { return s == CUR_ARROW ? 0 : SHAPES[s].length / 2; }

        /** Вернуть пиксели под курсором (перед любой перерисовкой). */
        public void restore(PixelScreen p) {
            if (!has) return;
            has = false;
            p.resetClip();
            String[] sh = SHAPES[shape];
            for (int j = 0; j < sh.length; j++) {
                for (int i = 0; i < sh[j].length(); i++) {
                    int x = sx + i, y = sy + j;
                    if (sh[j].charAt(i) != '.' && x >= 0 && y >= 0 && x < W && y < H) p.pixel(x, y, 0xFF000000 | saved[j * MAXC + i]);
                }
            }
        }

        public void draw(PixelScreen p, int x, int y, int kind) {
            p.resetClip();
            shape = kind < 0 || kind >= SHAPES.length ? 0 : kind;
            String[] sh = SHAPES[shape];
            sx = x - hotX(shape);
            sy = y - hotY(shape);
            for (int j = 0; j < sh.length; j++) {
                for (int i = 0; i < sh[j].length(); i++) {
                    char ch = sh[j].charAt(i);
                    int xx = sx + i, yy = sy + j;
                    if (ch == '.' || xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
                    saved[j * MAXC + i] = p.px[yy * W + xx];
                    p.pixel(xx, yy, ch == 'k' ? 0xFF000000 : 0xFFFFFFFF);
                }
            }
            has = true;
        }
    }
}
