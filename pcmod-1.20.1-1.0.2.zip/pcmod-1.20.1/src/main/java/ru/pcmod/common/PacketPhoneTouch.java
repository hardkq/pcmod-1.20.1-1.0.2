package ru.pcmod.common;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Клиент -> сервер: касание экрана телефона. kind: 0 нажатие, 1 отпускание, 2 перетаскивание, 3 кнопка питания; x, y - пиксель 0..179 x 0..319. */
public class PacketPhoneTouch {
    public final int kind, x, y;

    public PacketPhoneTouch(int kind, int x, int y) { this.kind = kind; this.x = x; this.y = y; }

    public static void encode(PacketPhoneTouch m, FriendlyByteBuf b) { b.writeByte(m.kind); b.writeShort(m.x); b.writeShort(m.y); }

    public static PacketPhoneTouch decode(FriendlyByteBuf b) { return new PacketPhoneTouch(b.readByte(), b.readShort(), b.readShort()); }

    public static void handle(PacketPhoneTouch m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> {
            ServerPlayer p = ctx.getSender();
            if (p == null || !(p.containerMenu instanceof ContainerPhone)) return;
            PhoneSession s = PhoneSession.get(p);
            if (s != null) s.touch(m.kind, m.x, m.y);
        });
        ctx.setPacketHandled(true);
    }
}
