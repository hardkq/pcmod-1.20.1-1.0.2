package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/**
 * Предмет «Телефон»: комплектующие лежат в NBT "Parts" (список ItemStack), модель корпуса - "Model", заряд - "Charge" (мА·ч),
 * подключение кабелем к ПК - "Plug" (BlockPos.asLong) и "PlugDim". ПКМ открывает экран телефона (ContainerPhone / PhoneSession).
 */
public class ItemPhone extends Item {
    /** Скорость зарядки по USB-кабелю от включённого ПК, мА·ч в секунду. */
    public static final int USB_RATE = 20;
    private static final String[] CASES = {"ph_case_mini", "ph_case_classic", "ph_case_slim", "ph_case_flagship", "ph_case_max"};

    public ItemPhone(Item.Properties props) { super(props); }

    public static List<ItemStack> parts(ItemStack phone) {
        List<ItemStack> r = new ArrayList<ItemStack>();
        CompoundTag t = phone.getTag();
        if (t == null) return r;
        ListTag l = t.getList("Parts", Tag.TAG_COMPOUND);
        for (int i = 0; i < l.size(); i++) r.add(ItemStack.of(l.getCompound(i)));
        return r;
    }

    /** Характеристики установленной детали данной категории (или null). */
    public static PartSpec part(ItemStack phone, PartSpec.Cat cat) {
        for (ItemStack s : parts(phone)) {
            PartSpec sp = PhoneParts.spec(s);
            if (sp != null && sp.cat == cat) return sp;
        }
        return null;
    }

    /** Телефон собран на столе (есть SoC, аккумулятор, экран и корпус). */
    public static boolean assembled(ItemStack phone) {
        return part(phone, PartSpec.Cat.PH_SOC) != null && part(phone, PartSpec.Cat.PH_BATT) != null
            && part(phone, PartSpec.Cat.PH_SCREEN) != null && part(phone, PartSpec.Cat.PH_CASE) != null;
    }

    /** Уровень SoC (0 - нет). */
    public static int socTier(ItemStack phone) {
        PartSpec p = part(phone, PartSpec.Cat.PH_SOC);
        return p == null ? 0 : p.tier;
    }

    /** Суммарная ОЗУ, МБ. */
    public static int ramMB(ItemStack phone) {
        int r = 0;
        for (ItemStack s : parts(phone)) {
            PartSpec sp = PhoneParts.spec(s);
            if (sp != null && sp.cat == PartSpec.Cat.PH_RAM) r += sp.memMB;
        }
        return r;
    }

    /** Встроенная память, ГБ. */
    public static int romGB(ItemStack phone) {
        PartSpec p = part(phone, PartSpec.Cat.PH_ROM);
        return p == null ? 0 : p.gb;
    }

    public static int capacityMah(ItemStack phone) {
        PartSpec b = part(phone, PartSpec.Cat.PH_BATT);
        return b == null ? 0 : b.mah;
    }

    public static int charge(ItemStack phone) {
        CompoundTag t = phone.getTag();
        return t == null ? 0 : Math.max(0, Math.min(capacityMah(phone), t.getInt("Charge")));
    }

    /** Заряд в процентах 0..100. */
    public static int percent(ItemStack phone) {
        int cap = capacityMah(phone);
        return cap <= 0 ? 0 : charge(phone) * 100 / cap;
    }

    /** Добавить заряд. true - заряд изменился. */
    public static boolean addCharge(ItemStack phone, int mah) {
        int cap = capacityMah(phone), cur = charge(phone);
        if (cap <= 0 || cur >= cap || mah <= 0) return false;
        phone.getOrCreateTag().putInt("Charge", Math.min(cap, cur + mah));
        return true;
    }

    /** Списать заряд (не ниже нуля). */
    public static void drain(ItemStack phone, int mah) {
        int cur = charge(phone);
        if (cur <= 0 || mah <= 0) return;
        phone.getOrCreateTag().putInt("Charge", Math.max(0, cur - mah));
    }

    /** Расход при включённом экране, мА·ч в секунду: растёт с уровнем SoC, размером и частотой экрана. */
    public static int screenDrainPerSec(ItemStack phone) {
        PartSpec soc = part(phone, PartSpec.Cat.PH_SOC), scr = part(phone, PartSpec.Cat.PH_SCREEN);
        return 2 + (soc == null ? 0 : soc.tier) + (scr == null ? 0 : scr.size + (scr.hz >= 90 ? 1 : 0));
    }

    /** SIM-карта в слоте телефона (EMPTY - слот пуст). */
    public static ItemStack getSim(ItemStack phone) {
        CompoundTag t = phone.getTag();
        return t != null && t.contains("Sim", Tag.TAG_COMPOUND) ? ItemStack.of(t.getCompound("Sim")) : ItemStack.EMPTY;
    }

    public static void setSim(ItemStack phone, ItemStack sim) {
        if (sim.isEmpty()) {
            if (phone.getTag() != null) phone.getTag().remove("Sim");
        } else phone.getOrCreateTag().put("Sim", sim.save(new CompoundTag()));
    }

    /** Слот SIM: ПКМ по телефону в инвентаре с SIM на курсоре - вставить (или поменять), с пустым курсором - достать. */
    @Override
    public boolean overrideOtherStackedOnMe(ItemStack phone, ItemStack other, net.minecraft.world.inventory.Slot slot,
            net.minecraft.world.inventory.ClickAction action, Player player, net.minecraft.world.entity.SlotAccess access) {
        if (action != net.minecraft.world.inventory.ClickAction.SECONDARY || !slot.allowModification(player)) return false;
        ItemStack sim = getSim(phone);
        if (other.isEmpty()) {
            if (sim.isEmpty()) return false;
            access.set(sim);
            setSim(phone, ItemStack.EMPTY);
            return true;
        }
        if (!(other.getItem() instanceof ItemSimCard)) return false;
        if (sim.isEmpty()) {
            setSim(phone, other.split(1));
        } else if (other.getCount() == 1) {
            setSim(phone, other.copy());
            access.set(sim);
        } else return false;
        return true;
    }

    /** Номер модели корпуса для модели предмета в руке: 0 - неизвестно, 1..5 - mini, classic, slim, flagship, max. */
    public static int caseIndex(ItemStack phone) {
        CompoundTag t = phone.getTag();
        if (t == null) return 0;
        String m = t.getString("Model");
        for (int i = 0; i < CASES.length; i++) if (CASES[i].equals(m)) return i + 1;
        return 0;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player pl, InteractionHand hand) {
        ItemStack st = pl.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(st);
        if (!(pl instanceof ServerPlayer sp)) return InteractionResultHolder.pass(st);
        if (!assembled(st)) {
            sp.displayClientMessage(Component.translatable("gui.pcmod.phone.unassembled"), true);
            return InteractionResultHolder.fail(st);
        }
        if (charge(st) <= 0) {
            sp.displayClientMessage(Component.translatable("gui.pcmod.phone.dead"), true);
            return InteractionResultHolder.fail(st);
        }
        PhoneSession.open(sp, hand);
        NetworkHooks.openScreen(sp, new SimpleMenuProvider((id, inv, p) -> new ContainerPhone(id, inv, hand),
            Component.translatable("item.pcmod.phone")), buf -> buf.writeBoolean(hand == InteractionHand.OFF_HAND));
        return InteractionResultHolder.success(st);
    }

    /** Серверный тик в инвентаре: медленный саморазряд и зарядка по кабелю от включённого ПК рядом. */
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || level.getGameTime() % 20 != 0) return;
        CompoundTag t = stack.getTag();
        if (t != null && t.contains("Plug")) {
            BlockPos p = BlockPos.of(t.getLong("Plug"));
            boolean ok = t.getString("PlugDim").equals(level.dimension().location().toString()) && level.hasChunkAt(p)
                && entity.distanceToSqr(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5) <= 36.0
                && level.getBlockEntity(p) instanceof TileComputer tc && tc.isOn();
            if (ok) addCharge(stack, USB_RATE);
            else {
                t.remove("Plug");
                t.remove("PlugDim");
                if (entity instanceof Player pl) pl.displayClientMessage(Component.translatable("gui.pcmod.phone.unplugged"), true);
            }
        }
        if (level.getGameTime() % 1200 == 0) drain(stack, 1);
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) { return slotChanged; }

    @Override public boolean isBarVisible(ItemStack s) { return capacityMah(s) > 0; }
    @Override public int getBarWidth(ItemStack s) { return Math.round(13.0F * percent(s) / 100.0F); }
    @Override public int getBarColor(ItemStack s) {
        int p = percent(s);
        return p > 50 ? 0x33DD55 : p > 20 ? 0xEEBB22 : 0xEE3322;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        int cap = capacityMah(stack);
        if (cap > 0) tips.add(Component.translatable("tooltip.pcmod.phone.battery", percent(stack)).withStyle(net.minecraft.ChatFormatting.GRAY));
        CompoundTag t = stack.getTag();
        if (t != null && t.contains("Plug")) tips.add(Component.translatable("tooltip.pcmod.phone.plugged").withStyle(net.minecraft.ChatFormatting.GREEN));
        ItemStack sim = getSim(stack);
        tips.add(sim.isEmpty() ? Component.translatable("tooltip.pcmod.phone.no_sim").withStyle(net.minecraft.ChatFormatting.DARK_GRAY)
            : Component.translatable("tooltip.pcmod.phone.sim", ItemSimCard.formatNumber(ItemSimCard.getPhoneNumber(sim))).withStyle(net.minecraft.ChatFormatting.AQUA));
        for (ItemStack s : parts(stack)) tips.add(Component.literal(" ").append(s.getHoverName()).withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
    }
}
