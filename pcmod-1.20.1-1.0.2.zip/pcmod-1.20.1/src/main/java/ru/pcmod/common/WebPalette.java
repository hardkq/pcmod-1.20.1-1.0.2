package ru.pcmod.common;

/** Палитра языка разметки: 16 цветов; в пикселях картинок - символы 0-9 a-f, в стилях и @bg - имена или тот же символ. */
public final class WebPalette {
    public static final String[] NAMES = {"black", "white", "gray", "silver", "red", "orange", "yellow", "lime",
            "green", "teal", "cyan", "blue", "navy", "purple", "pink", "brown"};
    public static final int[] RGB = {0xFF000000, 0xFFFFFFFF, 0xFF808080, 0xFFC0C0C0, 0xFFE02B2B, 0xFFF08A1C, 0xFFF2D21B, 0xFF7ED321,
            0xFF1E9E3A, 0xFF138A8A, 0xFF2BC4E8, 0xFF2D6FE0, 0xFF1A2A6C, 0xFF8E44C8, 0xFFF06AA8, 0xFF8B5A2B};

    private WebPalette() { }

    /** Индекс по имени или по одному символу 0-9 a-f; -1 - нет такого цвета. */
    public static int index(String s) {
        if (s == null || s.isEmpty()) return -1;
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(s)) return i;
        if (s.length() == 1) return Character.digit(s.charAt(0), 16);
        return -1;
    }

    /** Относительная яркость 0..1. */
    public static float luma(int argb) {
        return (0.299f * ((argb >> 16) & 255) + 0.587f * ((argb >> 8) & 255) + 0.114f * (argb & 255)) / 255f;
    }
}
