package ru.pcmod.common;

/**
 * Значки WinCraft 11 в стиле Windows 11: плоские, скруглённые, цветные. Каждый значок нарисован на сетке 24x24
 * и масштабируется под любой размер (14 - панель задач и «Пуск», 16 и 24 - рабочий стол).
 * Идентификатор значка - id приложения; неизвестный id рисуется как обычное окно.
 */
public final class WinIcons {
    private WinIcons() {}

    /** Маленький значок (панель задач, «Пуск») с центром в (cx, cy). */
    public static void draw(PixelScreen p, WinTheme th, String id, int cx, int cy) {
        int c = th.text();
        if (id.equals("start")) {
            WinGfx.logo(p, cx - 6, cy - 6, 12, th.accent());
        } else if (id.equals("taskview")) {
            p.roundRect(cx - 6, cy - 5, 9, 7, 2, th.accent());
            p.roundRectBorder(cx - 3, cy - 2, 9, 7, 2, th.surface(), c);
        } else if (id.equals("search")) {
            p.roundRectOutline(cx - 5, cy - 5, 9, 9, 4, 1, c);
            WinGfx.line(p, cx + 2, cy + 2, cx + 5, cy + 5, c);
        } else {
            drawSized(p, th, id, cx - 7, cy - 7, 14);
        }
    }

    /** Значок size x size с левым верхним углом (x, y). */
    public static void drawSized(PixelScreen p, WinTheme th, String id, int x, int y, int size) {
        Ic g = new Ic(p, x, y, size / 24f);
        switch (id) {
            case "pc": pc(g); break;
            case "folder": case "explorer": folder(g); break;
            case "notepad": notepad(g); break;
            case "calc": calc(g); break;
            case "taskmgr": taskmgr(g); break;
            case "paint": paint(g); break;
            case "personal": personal(g); break;
            case "terminal": terminal(g); break;
            case "chat": chat(g); break;
            case "net": net(g); break;
            case "browser": browser(g); break;
            case "store": store(g); break;
            case "bank": bank(g); break;
            case "av": shield(g); break;
            case "sitebuilder": builder(g); break;
            case "mobileop": mobile(g); break;
            case "doom": doom(g); break;
            case "settings": gear(g); break;
            case "trash": trash(g); break;
            case "about": about(g, th); break;
            case "setup": setup(g); break;
            default: window(g, th); break;
        }
    }

    /** Стрелка ярлыка 8x8 с левым верхним углом (x, y). */
    public static void shortcutBadge(PixelScreen p, int x, int y) {
        p.roundRect(x, y, 8, 8, 2, 0xFFFFFFFF);
        p.roundRectOutline(x, y, 8, 8, 2, 1, 0xFFAEB6C0);
        int c = 0xFF1B6FD1;
        WinGfx.line(p, x + 2, y + 6, x + 5, y + 3, c);
        p.fillRect(x + 3, y + 2, 3, 1, c);
        p.fillRect(x + 5, y + 2, 1, 3, c);
    }

    // ------------------------------------------------------------------ рисовальщик на сетке 24x24
    private static final class Ic {
        final PixelScreen p;
        final int ox, oy;
        final float k;

        Ic(PixelScreen p, int ox, int oy, float k) {
            this.p = p;
            this.ox = ox;
            this.oy = oy;
            this.k = k;
        }

        int sx(float v) { return ox + Math.round(v * k); }

        int sy(float v) { return oy + Math.round(v * k); }

        void fr(float x, float y, float w, float h, int c) {
            int x0 = sx(x), y0 = sy(y), x1 = sx(x + w), y1 = sy(y + h);
            p.fillRect(x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), c);
        }

        void rr(float x, float y, float w, float h, float r, int c) {
            int x0 = sx(x), y0 = sy(y), x1 = sx(x + w), y1 = sy(y + h);
            p.roundRect(x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), Math.round(r * k), c);
        }

        void ro(float x, float y, float w, float h, float r, float t, int c) {
            int x0 = sx(x), y0 = sy(y), x1 = sx(x + w), y1 = sy(y + h);
            p.roundRectOutline(x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), Math.round(r * k), Math.max(1, Math.round(t * k)), c);
        }

        void gv(float x, float y, float w, float h, int c1, int c2) {
            int x0 = sx(x), y0 = sy(y), x1 = sx(x + w), y1 = sy(y + h);
            p.gradientV(x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), c1, c2);
        }

        void circle(float cx, float cy, float r, int c) {
            rr(cx - r, cy - r, 2 * r, 2 * r, r, c);
        }

        /** Линия толщиной t (в единицах сетки). */
        void ln(float x0, float y0, float x1, float y1, float t, int c) {
            int a = sx(x0), b = sy(y0), d = sx(x1), e = sy(y1), n = Math.max(1, Math.round(t * k));
            for (int i = 0; i < n; i++) {
                int o = i - (n - 1) / 2;
                WinGfx.line(p, a, b + o, d, e + o, c);
                if (n > 1) WinGfx.line(p, a + o, b, d + o, e, c);
            }
        }
    }

    // ------------------------------------------------------------------ значки
    private static void pc(Ic g) {
        g.rr(2, 3, 20, 14, 2.5f, 0xFF39475A);
        g.gv(4, 5, 16, 10, 0xFF62B8FF, 0xFF1F6FD1);
        g.fr(10, 17, 4, 3, 0xFF8793A1);
        g.rr(6, 19.5f, 12, 2.2f, 1, 0xFFB3BDC8);
    }

    private static void folder(Ic g) {
        g.rr(2, 3, 9.5f, 6, 2, 0xFFE0A100);
        g.rr(2, 5.5f, 20, 14.5f, 2.5f, 0xFFE9AB0B);
        g.rr(2, 8, 20, 12.5f, 2.5f, 0xFFFFC83D);
        g.fr(3, 8, 18, 1, 0xFFFFE08A);
    }

    private static void notepad(Ic g) {
        g.rr(4, 2, 16, 20, 2.5f, 0xFFFFFFFF);
        g.ro(4, 2, 16, 20, 2.5f, 1, 0xFFB5C1CF);
        g.rr(4, 2, 16, 6, 2.5f, 0xFF2F8DE6);
        g.fr(4, 5, 16, 3, 0xFF2F8DE6);
        g.fr(7, 11, 10, 1.3f, 0xFF9AA7B6);
        g.fr(7, 14, 10, 1.3f, 0xFF9AA7B6);
        g.fr(7, 17, 6, 1.3f, 0xFF9AA7B6);
    }

    private static void calc(Ic g) {
        g.rr(4, 2, 16, 20, 3, 0xFF3C4350);
        g.rr(6, 4, 12, 5, 1.5f, 0xFFBEE9F0);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                g.rr(6 + j * 4.2f, 11 + i * 3.6f, 3.4f, 2.8f, 0.8f, i == 2 && j == 2 ? 0xFF3DA5F4 : 0xFFE6EAF0);
            }
        }
    }

    private static void taskmgr(Ic g) {
        g.rr(2, 3, 20, 18, 3, 0xFF1F2A36);
        g.fr(4, 9, 16, 0.8f, 0xFF35465A);
        g.fr(4, 14, 16, 0.8f, 0xFF35465A);
        g.ln(4, 17, 8, 12, 1.6f, 0xFF4ADE80);
        g.ln(8, 12, 11, 15, 1.6f, 0xFF4ADE80);
        g.ln(11, 15, 15, 7, 1.6f, 0xFF4ADE80);
        g.ln(15, 7, 20, 11, 1.6f, 0xFF4ADE80);
    }

    private static void paint(Ic g) {
        g.rr(2, 4, 20, 16, 7.5f, 0xFFF0D9B5);
        g.circle(7, 9, 2.2f, 0xFFE5484D);
        g.circle(12, 7, 2.2f, 0xFFFFC53D);
        g.circle(17, 9.5f, 2.2f, 0xFF30A46C);
        g.circle(7, 15, 2.2f, 0xFF3E63DD);
        g.circle(15.5f, 16, 2.8f, 0xFFC9AE86);
    }

    private static void personal(Ic g) {
        g.rr(2, 3, 20, 14, 3, 0xFF2B7DE8);
        g.rr(12, 3, 10, 14, 3, 0xFF1B2A6B);
        g.circle(8, 9, 2.6f, 0xFFFFE08A);
        g.fr(9, 17, 6, 1.6f, 0xFF8A8A8A);
        g.fr(7, 18.6f, 10, 1.6f, 0xFF8A8A8A);
    }

    private static void terminal(Ic g) {
        g.rr(2, 4, 20, 16, 3, 0xFF0C0C0C);
        g.ro(2, 4, 20, 16, 3, 1, 0xFF5F6B78);
        g.ln(6, 9, 10, 12, 1.6f, 0xFFFFFFFF);
        g.ln(10, 12, 6, 15, 1.6f, 0xFFFFFFFF);
        g.fr(12, 15, 6, 1.7f, 0xFFFFFFFF);
    }

    private static void chat(Ic g) {
        g.rr(2, 3, 20, 14, 6, 0xFF6B69D6);
        g.fr(5, 15, 4, 2, 0xFF6B69D6);
        g.fr(5, 16.5f, 3, 2, 0xFF6B69D6);
        g.fr(5, 18, 2, 2, 0xFF6B69D6);
        g.circle(8, 10, 1.5f, 0xFFFFFFFF);
        g.circle(12, 10, 1.5f, 0xFFFFFFFF);
        g.circle(16, 10, 1.5f, 0xFFFFFFFF);
    }

    private static void net(Ic g) {
        g.circle(12, 12, 10, 0xFF2B7DE0);
        g.ro(6.5f, 2, 11, 20, 5.5f, 1.2f, 0xCCFFFFFF);
        g.fr(11.4f, 2, 1.2f, 20, 0xCCFFFFFF);
        g.fr(2, 11.4f, 20, 1.2f, 0xCCFFFFFF);
        g.fr(4, 6.5f, 16, 1, 0x88FFFFFF);
        g.fr(4, 16.5f, 16, 1, 0x88FFFFFF);
    }

    private static void browser(Ic g) {
        g.circle(12, 12, 10, 0xFF1B6FD1);
        g.circle(13, 13.5f, 7, 0xFF3ED1A8);
        g.circle(14.5f, 12, 3.8f, 0xFF1B6FD1);
        g.circle(8, 7, 2.2f, 0x55FFFFFF);
    }

    private static void store(Ic g) {
        g.ro(7, 3, 10, 10, 4, 2, 0xFF55606E);
        g.rr(3, 8, 18, 14, 3, 0xFF2F86E8);
        g.fr(8, 12.5f, 3.4f, 3.4f, 0xFFFFFFFF);
        g.fr(12.6f, 12.5f, 3.4f, 3.4f, 0xFFFFFFFF);
        g.fr(8, 17, 3.4f, 3.4f, 0xFFFFFFFF);
        g.fr(12.6f, 17, 3.4f, 3.4f, 0xFFFFFFFF);
    }

    private static void bank(Ic g) {
        for (int r = 0; r < 8; r++) {
            float w = 3 + r * 2.4f;
            g.fr(12 - w / 2, 3 + r, w, 1, 0xFF2E8B57);
        }
        g.fr(5, 12, 3, 7, 0xFFE6F2EA);
        g.fr(10.5f, 12, 3, 7, 0xFFE6F2EA);
        g.fr(16, 12, 3, 7, 0xFFE6F2EA);
        g.rr(3, 19.5f, 18, 2.5f, 1, 0xFF2E8B57);
        g.fr(12 - 1, 7.5f, 2, 2, 0xFFFFFFFF);
    }

    private static void shield(Ic g) {
        for (int y = 0; y < 20; y++) {
            float w = y < 10 ? 16 : 16 * (1 - (y - 10) / 10f * 0.92f);
            g.fr(12 - w / 2, 2.5f + y, w, 1, y < 10 ? 0xFF2EAA5E : 0xFF279A53);
        }
        g.ln(8, 11.5f, 11, 14.5f, 1.8f, 0xFFFFFFFF);
        g.ln(11, 14.5f, 16, 8.5f, 1.8f, 0xFFFFFFFF);
    }

    private static void builder(Ic g) {
        g.rr(2, 3, 20, 18, 3, 0xFFEEF2F7);
        g.rr(2, 3, 20, 5, 3, 0xFF0F6CBD);
        g.rr(4, 10, 7, 8, 1, 0xFFFFB900);
        g.fr(13, 10.5f, 7, 1.6f, 0xFF7A8594);
        g.fr(13, 13.5f, 7, 1.6f, 0xFF7A8594);
        g.fr(13, 16.5f, 5, 1.6f, 0xFF7A8594);
    }

    private static void mobile(Ic g) {
        g.rr(2, 2, 20, 20, 4, 0xFF10263F);
        g.fr(11, 8, 2, 12, 0xFFCFD6DF);
        g.fr(8, 19, 8, 1.6f, 0xFFCFD6DF);
        g.circle(12, 7, 2f, 0xFFFFB900);
        g.fr(6, 5, 1.4f, 5, 0xFF4CC2FF);
        g.fr(17, 5, 1.4f, 5, 0xFF4CC2FF);
    }

    private static void doom(Ic g) {
        g.rr(2, 2, 20, 20, 4, 0xFF3B0A0A);
        g.ro(2, 2, 20, 20, 4, 1.2f, 0xFFC62828);
        g.circle(12, 10, 6.5f, 0xFFE8E0D0);
        g.rr(8, 14, 8, 5.5f, 1.5f, 0xFFE8E0D0);
        g.circle(9.3f, 10, 1.9f, 0xFF3B0A0A);
        g.circle(14.7f, 10, 1.9f, 0xFF3B0A0A);
        g.fr(11.3f, 13, 1.4f, 1.6f, 0xFF3B0A0A);
        g.fr(10, 17, 0.9f, 2.5f, 0xFF3B0A0A);
        g.fr(12.5f, 17, 0.9f, 2.5f, 0xFF3B0A0A);
    }

    private static void gear(Ic g) {
        int c = 0xFF8C98A8;
        for (int a = 0; a < 8; a++) {
            double ang = Math.toRadians(a * 45);
            g.rr((float) (12 + Math.cos(ang) * 8) - 1.9f, (float) (12 + Math.sin(ang) * 8) - 1.9f, 3.8f, 3.8f, 0.9f, c);
        }
        g.circle(12, 12, 7.2f, c);
        g.circle(12, 12, 3.2f, 0xFF3C4552);
    }

    private static void trash(Ic g) {
        g.rr(9, 2.5f, 6, 2.5f, 1, 0xFF8794A3);
        g.rr(4, 4.5f, 16, 2.6f, 1.2f, 0xFF9AA6B4);
        g.rr(6, 8, 12, 13.5f, 2, 0xFFC1CBD6);
        g.fr(9, 10.5f, 1.2f, 8, 0xFF8794A3);
        g.fr(11.4f, 10.5f, 1.2f, 8, 0xFF8794A3);
        g.fr(13.8f, 10.5f, 1.2f, 8, 0xFF8794A3);
    }

    private static void about(Ic g, WinTheme th) {
        g.circle(12, 12, 10, th.accent());
        g.fr(11, 10, 2, 8, 0xFFFFFFFF);
        g.fr(11, 6, 2, 2.2f, 0xFFFFFFFF);
    }

    private static void setup(Ic g) {
        g.rr(3, 3, 18, 18, 4, 0xFF4A90E2);
        g.ln(12, 6, 12, 14, 2, 0xFFFFFFFF);
        g.ln(8.5f, 11, 12, 14.5f, 2, 0xFFFFFFFF);
        g.ln(15.5f, 11, 12, 14.5f, 2, 0xFFFFFFFF);
        g.fr(7, 17, 10, 2, 0xFFFFFFFF);
    }

    private static void window(Ic g, WinTheme th) {
        g.rr(3, 4, 18, 16, 3, th.surface());
        g.ro(3, 4, 18, 16, 3, 1, th.border());
        g.rr(3, 4, 18, 5, 3, th.accent());
        g.fr(3, 6.5f, 18, 2.5f, th.accent());
    }
}
