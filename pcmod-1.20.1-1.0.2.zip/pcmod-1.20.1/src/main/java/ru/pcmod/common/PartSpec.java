package ru.pcmod.common;

/** Характеристики компонента ПК. */
public class PartSpec {
    public enum Cat { MOTHERBOARD, CPU, COOLER, RAM, GPU, STORAGE, PSU, MEDIA, NET, DATA,
        /** Комплектующие телефона: SoC, ОЗУ, накопитель, аккумулятор, экран, камера, плата, корпус, SIM/модем. */
        PH_SOC, PH_RAM, PH_ROM, PH_BATT, PH_SCREEN, PH_CAM, PH_BOARD, PH_CASE, PH_MODEM }

    public final Cat cat;
    public final String label;
    public int tier, socket, ramType, ramSlots, memMB, cores, watts, cooling, storageKB, speed, vram;
    /** Хешрейт видеокарты в МХ/с для майнер-фермы (0 = не майнит). */
    public int hash;
    public double ghz;
    /** Телефон: габарит (экран/плата/аккумулятор/корпус), макс. ёмкость батареи корпуса, Мп, разрешение, Гц, уровень связи (1 Wi-Fi, 2 4G, 3 5G), ГБ, дюймы. */
    public int size, mah, mp, resX, resY, hz, net, gb;
    public double inch;
    /** Жёсткий диск (HDD): такие накопители можно ставить в отсеки сервера. */
    public boolean hdd;
    /** Для установочных дисков: какую ОС ставит носитель ("pcos" или "pixel"). */
    public String os = "pcos";

    public PartSpec(Cat cat, String label) {
        this.cat = cat;
        this.label = label;
    }

    public PartSpec tier(int v) { tier = v; return this; }
    public PartSpec socket(int v) { socket = v; return this; }
    public PartSpec ramType(int v) { ramType = v; return this; }
    public PartSpec ramSlots(int v) { ramSlots = v; return this; }
    public PartSpec memMB(int v) { memMB = v; return this; }
    public PartSpec cores(int v) { cores = v; return this; }
    public PartSpec watts(int v) { watts = v; return this; }
    public PartSpec cooling(int v) { cooling = v; return this; }
    public PartSpec storageKB(int v) { storageKB = v; return this; }
    public PartSpec speed(int v) { speed = v; return this; }
    public PartSpec vram(int v) { vram = v; return this; }
    public PartSpec hash(int v) { hash = v; return this; }
    public PartSpec ghz(double v) { ghz = v; return this; }
    public PartSpec hdd() { hdd = true; return this; }
    public PartSpec size(int v) { size = v; return this; }
    public PartSpec mah(int v) { mah = v; return this; }
    public PartSpec mp(int v) { mp = v; return this; }
    public PartSpec res(int x, int y) { resX = x; resY = y; return this; }
    public PartSpec hz(int v) { hz = v; return this; }
    public PartSpec net(int v) { net = v; return this; }
    public PartSpec gb(int v) { gb = v; return this; }
    public PartSpec inch(double v) { inch = v; return this; }
    public PartSpec os(String v) { os = v; return this; }

    public static String socketName(int s) { return "SK-" + s; }
    public static String phoneSocketName(int s) { return "AS-" + s; }
    public static String phoneRamName(int t) { return "LPDDR" + (t + 2); }
    public static String netName(int n) { return n == 1 ? "Wi-Fi" : n == 2 ? "Wi-Fi + 4G" : "Wi-Fi + 4G + 5G"; }
    public static String sizeName(int s) { return s == 1 ? "S" : s == 2 ? "M" : "L"; }
    public static String ramName(int t) { return t == 1 ? "DDR3" : t == 2 ? "DDR4" : "DDR5"; }
}
