package ru.pcmod.common;

/** Цвета WinCraft 11 (светлая или тёмная тема и акцентный цвет). Цвета - ARGB. Заполняется WinLook. */
public final class WinTheme {
    public boolean dark;
    public int accent = 0xFF0067C0;
    /** Номер обоев (WinWalls). */
    public int wall;
    /** Прозрачность и Mica включены (настройка и железо позволяют). */
    public boolean glass;
    /** Анимации окон включены (настройка и железо позволяют). */
    public boolean anim;
    /** Часы в 12-часовом формате (настройка «Время»). */
    public boolean h12;
    /** Формат даты: индекс в WinClock.DATE_FMT. */
    public int dateFmt;

    public int accent() { return accent; }
    public int bg() { return dark ? 0xFF202020 : 0xFFF3F3F3; }
    public int surface() { return dark ? 0xFF2D2D2D : 0xFFFFFFFF; }
    public int border() { return dark ? 0xFF454545 : 0xFFDADADA; }
    public int text() { return dark ? 0xFFFFFFFF : 0xFF1B1B1B; }
    public int sub() { return dark ? 0xFFC8C8C8 : 0xFF606060; }
    public int hover() { return dark ? 0x22FFFFFF : 0x14000000; }
    public int accentHover() { return PixelScreen.lerp(accent, 0xFFFFFFFF, 0.14f); }
    public int accentPress() { return PixelScreen.lerp(accent, 0xFF000000, 0.18f); }
    public int onAccent() { return 0xFFFFFFFF; }
    public int ok() { return dark ? 0xFF6CCB5F : 0xFF0F7B0F; }
    public int warn() { return dark ? 0xFFFCE100 : 0xFF9D5D00; }
    public int bad() { return dark ? 0xFFFF99A4 : 0xFFC42B1C; }
}
