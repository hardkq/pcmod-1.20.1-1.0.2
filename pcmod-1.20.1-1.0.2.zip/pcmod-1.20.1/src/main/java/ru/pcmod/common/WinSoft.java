package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Встроенные приложения WinCraft 11 (Проводник, Блокнот, Калькулятор, Диспетчер задач, Paint, Терминал):
 * регистрация в WinApps и общие средства - буфер обмена, запуск других приложений, значки файлов.
 */
public final class WinSoft {
    public static final int K_ESC = 1, K_F2 = 60, K_F5 = 63, K_HOME = 199, K_END = 207, K_PGUP = 201, K_PGDN = 209,
            K_DEL = 211, K_UP = 200, K_DOWN = 208, K_LEFT = 203, K_RIGHT = 205;

    /** Процесс (открытое окно) для Диспетчера задач. */
    public static final class Proc {
        public final WinApp app;
        public final String id, title;
        public final boolean min;

        public Proc(WinApp app, boolean min) {
            this.app = app;
            this.id = app.id();
            this.title = app.title();
            this.min = min;
        }
    }

    /** Что приложениям нужно от рабочего стола (выполняется после обработки события). */
    public interface Ctx {
        /** Запустить приложение; arg - путь файла или "". */
        void open(String appId, String arg);

        /** Закрыть окно приложения. */
        void kill(WinApp app);

        List<Proc> procs();
    }

    final WinHost host;
    final WinApps apps;
    final WinTheme th;
    final WinSpec.Perf perf;
    final WinFs fs;
    final WinSvc svc;
    final Ctx ctx;
    /** Аргумент для приложения, которое сейчас создаётся (путь файла). */
    String arg;
    /** Буфер обмена: текст и список файлов (clipCut - файлы вырезаны). */
    String clipText = "";
    final List<String> clipFiles = new ArrayList<String>();
    boolean clipCut;

    public WinSoft(WinApps apps, WinHost host, WinTheme th, WinSpec.Perf perf, Ctx ctx) {
        this.apps = apps;
        this.host = host;
        this.th = th;
        this.perf = perf;
        this.fs = host.fs();
        this.svc = host.svc();
        this.ctx = ctx;
        apps.add("explorer", "Проводник", 262, 150, true, () -> new WinExplorer(this, take()));
        apps.add("notepad", "Блокнот", 220, 130, true, () -> new WinNotepad(this, take()));
        apps.add("calc", "Калькулятор", 150, 150, true, () -> new WinCalc(this));
        apps.add("taskmgr", "Диспетчер задач", 252, 150, true, () -> new WinTaskMgr(this));
        apps.add("paint", "Paint", 262, 150, true, () -> new WinPaint(this, take()));
        apps.add("terminal", "Терминал", 240, 132, true, () -> new WinTerm(this));
        apps.add("chat", "Чат", 262, 150, true, () -> new WinChat(this));
        apps.add("net", "Сеть", 250, 150, true, () -> new WinNetApp(this));
        apps.add("browser", "Браузер", 290, 156, true, () -> new WinBrowser(this));
        apps.add("store", "Магазин", 262, 150, true, () -> new WinStore(this));
        apps.add("bank", "Банк", 250, 150, true, () -> new WinBank(this));
        apps.add("doom", "DOOM", WinDoom.WIN_W, WinDoom.WIN_H, false, () -> new WinDoom(this));
        apps.add("av", "Антивирус SafeGuard", 262, 150, false, () -> new WinAntivirus(this, take()));
        apps.add("setup", "Установщик программ", 250, 132, false, () -> new WinInstaller(this, take()));
        apps.gate("setup", () -> false);
        apps.add("sitebuilder", "Конструктор сайтов", 316, 168, false, () -> new WinSiteBuilder(this));
        apps.add("mobileop", "Мобильный оператор", 340, 190, false, () -> new WinMobileOp(this));
        // программы из реестра товаров: видны, когда установлены; запуск только с лицензией (проверка на сервере)
        for (SoftItem it : SoftRegistry.allIncludingOff()) {
            if (!it.isPc() || it.appId.isEmpty()) continue;
            final String sid = it.id;
            apps.gate(it.appId, () -> svc.softInstalled(sid));
            apps.lock(it.appId, () -> svc.softRunnable(sid));
        }
    }

    private String take() {
        String a = arg;
        arg = null;
        return a == null ? "" : a;
    }

    /** Запуск приложения для файла: .exe - установщик, .pnt - Paint, остальное - Блокнот. */
    void openFile(String path) {
        String e = WinFs.ext(WinFs.name(path));
        ctx.open(e.equals("exe") ? "setup" : e.equals("pnt") ? "paint" : "notepad", path);
    }

    static boolean in(int x, int y, int bx, int by, int bw, int bh) {
        return x >= bx && y >= by && x < bx + bw && y < by + bh;
    }

    /** Плоская кнопка панели инструментов. */
    static void flat(PixelScreen p, WinTheme th, int x, int y, int w, int h, String label, boolean hover, boolean on) {
        if (on) p.roundRect(x, y, w, h, 3, PixelScreen.alpha(th.accent(), 0x40));
        else if (hover) p.roundRect(x, y, w, h, 3, th.hover());
        p.drawTextCentered(x, w, y + (h - PixelFont.H) / 2, label, th.text(), 1, false);
    }

    /** Полоса прокрутки справа от списка. */
    static void scrollbar(PixelScreen p, WinTheme th, int x, int y, int h, int total, int view, int pos) {
        if (total <= view) return;
        p.roundRect(x, y, 3, h, 1, PixelScreen.alpha(th.sub(), 0x30));
        int bh = Math.max(8, h * view / total), by = y + (h - bh) * pos / Math.max(1, total - view);
        p.roundRect(x, by, 3, bh, 1, PixelScreen.alpha(th.sub(), 0xA0));
    }

    /** Значок файла 12x12 с левым верхним углом (x, y). */
    static void fileIcon(PixelScreen p, String name, boolean dir, int x, int y) {
        if (dir) {
            p.roundRect(x, y + 1, 6, 4, 1, 0xFFD89A00);
            p.roundRect(x, y + 3, 12, 8, 2, 0xFFFFC83D);
            return;
        }
        p.roundRectBorder(x + 1, y, 10, 12, 2, 0xFFFFFFFF, 0xFF9AA4B0);
        String ext = WinFs.ext(name);
        if (ext.equals("pnt")) {
            p.fillRect(x + 3, y + 2, 6, 3, 0xFF4CC2FF);
            p.fillRect(x + 3, y + 5, 3, 4, 0xFF6CCB5F);
            p.fillRect(x + 6, y + 5, 3, 4, 0xFFFFB900);
        } else if (ext.equals("exe")) {
            p.roundRect(x + 1, y, 10, 12, 2, 0xFF0F6CBD);
            p.fillRect(x + 3, y + 3, 2, 2, 0xFFFFFFFF);
            p.fillRect(x + 6, y + 3, 2, 2, 0xFFFFFFFF);
            p.fillRect(x + 3, y + 6, 2, 2, 0xFFFFFFFF);
            p.fillRect(x + 6, y + 6, 2, 2, 0xFFFFFFFF);
        } else {
            for (int i = 0; i < 4; i++) p.hline(x + 3, y + 3 + i * 2, i == 3 ? 3 : 6, 0xFF7A8594);
        }
    }

    static String sizeText(int b) {
        if (b < 0) return "";
        return b < 1024 ? b + " Б" : (b + 1023) / 1024 + " КБ";
    }

    static String bytesText(long b) {
        if (b < 1024) return b + " Б";
        if (b < 1024L * 1024) return String.format("%.1f КБ", b / 1024.0).replace('.', ',');
        return String.format("%.2f МБ", b / 1048576.0).replace('.', ',');
    }

    /** Перенос текста по словам в строки не шире maxW пикселей. */
    static List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<String>();
        StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ", -1)) {
            String t = cur.length() == 0 ? w : cur + " " + w;
            if (PixelScreen.textWidth(t) <= maxW) {
                cur.setLength(0);
                cur.append(t);
                continue;
            }
            if (cur.length() > 0) out.add(cur.toString());
            cur.setLength(0);
            String rest = w;
            while (PixelScreen.textWidth(rest) > maxW && rest.length() > 1) {
                int k = rest.length() - 1;
                while (k > 1 && PixelScreen.textWidth(rest.substring(0, k)) > maxW) k--;
                out.add(rest.substring(0, k));
                rest = rest.substring(k);
            }
            cur.append(rest);
        }
        out.add(cur.toString());
        return out;
    }

    /** Число консов с пробелами между тысячами: 1 234 567. */
    static String kons(long v) {
        String d = Long.toString(Math.abs(v));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < d.length(); i++) {
            if (i > 0 && (d.length() - i) % 3 == 0) b.append(' ');
            b.append(d.charAt(i));
        }
        return (v < 0 ? "-" : "") + b;
    }
}
