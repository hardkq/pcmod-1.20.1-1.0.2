package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Живые элементы страниц сайтов (общие для ПК и телефона): разметка даёт только маркеры (@counter, @guestbook, @form, @donate, @rate,
 * @report, @card), а здесь они превращаются в обычные строки WebRow с данными сервера. Здесь же страницы платного доступа,
 * каталог search.pc и разбор действий-ссылок для браузеров.
 */
public final class SiteWidgets {
    private SiteWidgets() { }

    /** Источник каталога (SiteStore::search). */
    public interface Src {
        List<SiteStore.Listing> get(String q, int section, int max);
    }

    private static String rating(int r10, boolean ru) {
        String s = r10 / 10 + (ru ? "," : ".") + r10 % 10;
        return s;
    }

    private static WebRow row(char k, String t, String tg) { return new WebRow(k, t, tg); }

    private static WebRow dim(String t) {
        WebRow r = new WebRow('t', t, null);
        r.tone = 'd';
        return r;
    }

    /** Маркеры -> строки. ex == null (предпросмотр в конструкторе): подсказки-заглушки без действий. */
    static WebPage expand(WebPage pg, String domain, SiteStore.Extra ex, boolean ru) {
        List<WebRow> o = new ArrayList<WebRow>();
        if (ex != null && ex.suspicious) {
            WebRow w = row('t', ru ? "Внимание: на этот сайт поступили жалобы. Будьте осторожны." : "Warning: this site has been reported. Be careful.", null);
            w.tone = 'e';
            o.add(w);
        }
        boolean hdr = !pg.rows.isEmpty() && pg.rows.get(0).kind == 'H';
        for (WebRow r : pg.rows) {
            switch (r.kind) {
                case 'C':
                    o.add(dim(ex == null ? (ru ? "(здесь будет счётчик посетителей)" : "(visitor counter goes here)")
                            : (ru ? "Посетителей: " : "Visitors: ") + ex.visits));
                    break;
                case 'A': {
                    o.add(row('s', ru ? "Об авторе" : "About the author", null));
                    if (ex == null) {
                        o.add(dim(ru ? "(визитка: автор, дата создания, рейтинг)" : "(card: author, creation date, rating)"));
                        break;
                    }
                    o.add(row('t', (ru ? "Автор: " : "Author: ") + ex.ownerName, null));
                    o.add(dim((ru ? "Сайт создан в игровые сутки " : "Site created on game day ") + ex.created));
                    o.add(dim(ex.votes == 0 ? (ru ? "Рейтинг: оценок пока нет" : "Rating: no votes yet")
                            : (ru ? "Рейтинг: " : "Rating: ") + rating(ex.rating10, ru) + " / 5 (" + ex.votes + ")"));
                    break;
                }
                case 'D':
                    o.add(ex == null ? dim(ru ? "[кнопка доната]" : "[donate button]")
                            : row('b', r.text.isEmpty() ? (ru ? "Поддержать автора" : "Support the author") : r.text, "donate:" + domain));
                    break;
                case 'R':
                    o.add(ex == null ? dim(ru ? "[оценка сайта]" : "[site rating]") : row('b', ru ? "Оценить сайт (1-5)" : "Rate this site (1-5)", "rate:" + domain));
                    break;
                case 'X':
                    if (ex == null) o.add(dim(ru ? "[жалоба]" : "[report]"));
                    else o.add(row('l', ru ? "Пожаловаться на сайт" : "Report this site", "report:" + domain));
                    break;
                case 'M':
                    o.add(ex == null ? dim("[" + r.text + "]") : row('b', r.text, "form:" + domain + ":" + r.target));
                    break;
                case 'G': {
                    o.add(row('s', ru ? "Гостевая книга" : "Guestbook", null));
                    if (ex == null) {
                        o.add(dim(ru ? "(записи гостей появятся здесь)" : "(guest entries appear here)"));
                        break;
                    }
                    if (ex.guests.isEmpty()) o.add(dim(ru ? "Пока пусто. Станьте первым!" : "Empty so far. Be the first!"));
                    for (String[] g : ex.guests) {
                        boolean wait = g[3].equals("wait");
                        WebRow t = row('t', (wait ? (ru ? "[ждёт одобрения] " : "[pending] ") : "") + g[1] + ": " + g[2], null);
                        if (wait) t.tone = 'd';
                        o.add(t);
                        if (ex.owner) {
                            if (wait) o.add(row('l', ru ? "  Одобрить" : "  Approve", "gbok:" + domain + ":" + g[0]));
                            o.add(row('l', ru ? "  Удалить" : "  Delete", "gbdel:" + domain + ":" + g[0]));
                        }
                    }
                    o.add(row('b', ru ? "Написать в книгу" : "Sign the guestbook", "gbadd:" + domain));
                    break;
                }
                default:
                    o.add(r);
            }
        }
        if (hdr && o.size() > 1 && ex != null && ex.suspicious && o.get(0).kind != 'H') {
            o.add(0, o.remove(1));
        }
        WebPage p = new WebPage(o);
        p.bg = pg.bg;
        p.title = pg.title;
        p.price = pg.price;
        return p;
    }

    /** Страница «платный доступ» (код 402). */
    static WebPage paywall(SiteHost.Resp r, boolean ru) {
        String page = r.page.isEmpty() || r.page.equals("index") ? "" : r.page;
        List<WebRow> o = new ArrayList<WebRow>();
        o.add(row('h', ru ? "Платная страница" : "Paid page", null));
        o.add(row('t', (ru ? "Автор сайта " : "The author of ") + r.domain + (ru ? " открыл эту страницу за плату." : " made this page paid."), null));
        WebRow pr = row('t', (ru ? "Цена доступа: " : "Access price: ") + r.note + (ru ? " К (консов), навсегда." : " kons, forever."), null);
        pr.bold = true;
        o.add(pr);
        o.add(row('b', (ru ? "Купить доступ за " : "Buy access for ") + r.note + " К", "pay:" + r.domain + ":" + (page.isEmpty() ? "index" : page)));
        o.add(row('l', ru ? "Назад на сайт" : "Back to the site", r.domain));
        return new WebPage(o);
    }

    // ------------------------------------------------------------------ каталог search.pc
    /** Адрес search.pc, search.pc/new, search.pc/top или search.pc/запрос. */
    static List<WebRow> searchRows(String url, boolean ru, Src src) {
        String path = url.indexOf('/') < 0 ? "" : url.substring(url.indexOf('/') + 1);
        List<WebRow> o = new ArrayList<WebRow>();
        o.add(row('h', ru ? "Поиск по PC-Net" : "PC-Net search", null));
        o.add(row('b', ru ? "Найти сайт..." : "Find a site...", "search:"));
        o.add(row('l', ru ? "Новые" : "New", "search.pc/new"));
        o.add(row('l', ru ? "Популярные" : "Popular", "search.pc/top"));
        o.add(row('r', "", null));
        if (path.isEmpty()) {
            section(o, ru ? "Новые сайты" : "New sites", src.get("", 1, 5), ru);
            section(o, ru ? "Популярные сайты" : "Popular sites", src.get("", 2, 5), ru);
        } else if (path.equals("new")) section(o, ru ? "Новые сайты" : "New sites", src.get("", 1, 12), ru);
        else if (path.equals("top")) section(o, ru ? "Популярные сайты" : "Popular sites", src.get("", 2, 12), ru);
        else section(o, (ru ? "Результаты: " : "Results: ") + path, src.get(path, 2, 12), ru);
        o.add(row('r', "", null));
        o.add(row('l', ru ? "На начальную страницу" : "Home", "home.pc"));
        return o;
    }

    private static void section(List<WebRow> o, String title, List<SiteStore.Listing> l, boolean ru) {
        o.add(row('s', title, null));
        if (l.isEmpty()) o.add(dim(ru ? "Ничего не найдено." : "Nothing found."));
        for (SiteStore.Listing f : l) {
            o.add(row('l', f.title.isEmpty() ? f.domain : f.title, f.domain));
            String st = f.domain + "  " + (f.votes == 0 ? (ru ? "без оценок" : "no votes") : "* " + rating(f.rating10, ru) + " (" + f.votes + ")")
                    + "  " + f.visits + (ru ? " визитов" : " visits") + (f.tags.isEmpty() ? "" : "  #" + f.tags.replace(" ", " #"));
            o.add(dim(st));
            if (f.suspicious) {
                WebRow w = row('t', ru ? "Подозрительный сайт: поступали жалобы" : "Suspicious site: reports received", null);
                w.tone = 'e';
                o.add(w);
            }
        }
    }

    // ------------------------------------------------------------------ действия-ссылки (для WinBrowser и AppBrowser)
    static boolean isAction(String tg) {
        if (tg == null) return false;
        for (String k : new String[] {"gbadd:", "gbok:", "gbdel:", "form:", "donate:", "pay:", "rate:", "report:", "search:"}) if (tg.startsWith(k)) return true;
        return false;
    }

    /** Подпись поля ввода или null, если действие выполняется сразу. */
    static String prompt(String tg, boolean ru) {
        if (tg.startsWith("gbadd:")) return ru ? "Запись в гостевую книгу" : "Guestbook entry";
        if (tg.startsWith("form:")) return ru ? "Сообщение владельцу сайта" : "Message to the site owner";
        if (tg.startsWith("donate:")) return ru ? "Сумма доната, консов (1-1000)" : "Donation, kons (1-1000)";
        if (tg.startsWith("rate:")) return ru ? "Оценка от 1 до 5" : "Rating 1 to 5";
        if (tg.startsWith("report:")) return ru ? "Причина жалобы" : "Reason for the report";
        if (tg.startsWith("search:")) return ru ? "Что искать (название или тег)" : "What to look for (name or tag)";
        return null;
    }

    static int maxLen(String tg) {
        if (tg.startsWith("gbadd:")) return SiteStore.GB_TEXT;
        if (tg.startsWith("form:")) return 90;
        if (tg.startsWith("donate:")) return 4;
        if (tg.startsWith("rate:")) return 1;
        if (tg.startsWith("report:")) return 30;
        return 24;
    }

    /** Адрес результата поиска: только буквы, цифры, _ и - (как в WinWeb.norm). */
    static String searchUrl(String input) {
        String t = input == null ? "" : input.trim().toLowerCase().replaceAll("[^a-z0-9_а-яё-]", "");
        if (t.length() > 24) t = t.substring(0, 24);
        return t.isEmpty() ? "search.pc" : "search.pc/" + t;
    }
}
