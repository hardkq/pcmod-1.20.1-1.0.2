package ru.pcmod.common;

import java.math.BigDecimal;
import java.math.MathContext;

/** Калькулятор: обычный и научный режимы, выражения со скобками, память, градусы и радианы. */
public final class WinCalc implements WinApp {
    private static final String[][] MEM = {{"MODE"}, {"MC"}, {"MR"}, {"M+"}, {"M-"}, {"MS"}};
    private static final String[] MAIN = {"%", "CE", "C", "BS", "1/x", "x2", "sqrt", "/", "7", "8", "9", "*", "4", "5", "6", "-", "1", "2", "3", "+", "neg", "0", ".", "="};
    private static final String[] SCI = {"DEG", "P", "e", "sin", "cos", "tan", "ln", "log", "^", "(", ")", "!", "10^", "e^", "abs", "flr", "cei", "rnd"};
    private final WinSoft s;
    private final StringBuilder ex = new StringBuilder();
    private String res = "0", hist = "", err;
    private boolean done, sci, deg = true, hasMem;
    private double mem;
    private String hover = "";
    private int aw = 148, ah = 141;

    public WinCalc(WinSoft s) {
        this.s = s;
    }

    @Override public String title() { return "Калькулятор"; }

    @Override public String id() { return "calc"; }

    @Override public int minW() { return 112; }

    @Override public int minH() { return 130; }

    // ------------------------------------------------------------------ вычисление
    private static final class Eval {
        final String s;
        final boolean deg;
        int i;

        Eval(String s, boolean deg) {
            this.s = s;
            this.deg = deg;
        }

        double run() {
            double v = expr();
            if (i < s.length()) throw new ArithmeticException("Неверный ввод");
            if (Double.isNaN(v)) throw new ArithmeticException("Недопустимый ввод");
            if (Double.isInfinite(v)) throw new ArithmeticException("Переполнение");
            return v;
        }

        char c() { return i < s.length() ? s.charAt(i) : '\0'; }

        double expr() {
            double v = term();
            while (c() == '+' || c() == '-') v = s.charAt(i++) == '+' ? v + term() : v - term();
            return v;
        }

        double term() {
            double v = unary();
            while (true) {
                char c = c();
                if (c == '*') {
                    i++;
                    v *= unary();
                } else if (c == '/') {
                    i++;
                    double d = unary();
                    if (d == 0) throw new ArithmeticException("Деление на ноль");
                    v /= d;
                } else if (c == '(' || c == 'P' || Character.isLetter(c)) {
                    v *= power();
                } else {
                    return v;
                }
            }
        }

        double unary() {
            if (c() == '-') {
                i++;
                return -unary();
            }
            if (c() == '+') {
                i++;
                return unary();
            }
            return power();
        }

        double power() {
            double b = postfix();
            if (c() != '^') return b;
            i++;
            return Math.pow(b, unary());
        }

        double postfix() {
            double v = primary();
            while (true) {
                if (c() == '!') {
                    i++;
                    v = fact(v);
                } else if (c() == '%') {
                    i++;
                    v /= 100;
                } else {
                    return v;
                }
            }
        }

        static double fact(double v) {
            if (v < 0 || v != Math.floor(v) || v > 170) throw new ArithmeticException("Недопустимый ввод");
            double r = 1;
            for (int k = 2; k <= v; k++) r *= k;
            return r;
        }

        double primary() {
            char c = c();
            if (c == '(') {
                i++;
                double v = expr();
                if (c() != ')') throw new ArithmeticException("Неверный ввод");
                i++;
                return v;
            }
            if (c == 'P') {
                i++;
                return Math.PI;
            }
            if (Character.isDigit(c) || c == '.') {
                int st = i;
                while (Character.isDigit(c()) || c() == '.') i++;
                try {
                    return Double.parseDouble(s.substring(st, i));
                } catch (NumberFormatException e) {
                    throw new ArithmeticException("Неверный ввод");
                }
            }
            if (Character.isLetter(c)) {
                int st = i;
                while (Character.isLetter(c())) i++;
                String n = s.substring(st, i);
                if (n.equals("e")) return Math.E;
                if (c() != '(') throw new ArithmeticException("Неверный ввод");
                i++;
                double v = expr();
                if (c() != ')') throw new ArithmeticException("Неверный ввод");
                i++;
                return fn(n, v);
            }
            throw new ArithmeticException("Неверный ввод");
        }

        double fn(String n, double v) {
            double r = deg ? Math.toRadians(v) : v;
            switch (n) {
                case "sin": return deg && v % 180 == 0 ? 0 : Math.sin(r);
                case "cos": return deg && (v - 90) % 180 == 0 ? 0 : Math.cos(r);
                case "tan":
                    if (deg && (v - 90) % 180 == 0) throw new ArithmeticException("Недопустимый ввод");
                    return deg && v % 180 == 0 ? 0 : Math.tan(r);
                case "ln":
                    if (v <= 0) throw new ArithmeticException("Недопустимый ввод");
                    return Math.log(v);
                case "log":
                    if (v <= 0) throw new ArithmeticException("Недопустимый ввод");
                    return Math.log10(v);
                case "sqrt":
                    if (v < 0) throw new ArithmeticException("Недопустимый ввод");
                    return Math.sqrt(v);
                case "abs": return Math.abs(v);
                case "flr": return Math.floor(v);
                case "cei": return Math.ceil(v);
                case "rnd": return Math.rint(v);
                default: throw new ArithmeticException("Неверный ввод");
            }
        }
    }

    private String closed(String t) {
        int open = 0;
        for (int i = 0; i < t.length(); i++) {
            if (t.charAt(i) == '(') open++;
            else if (t.charAt(i) == ')') open--;
        }
        StringBuilder b = new StringBuilder(t);
        while (open-- > 0) b.append(')');
        return b.toString();
    }

    private Double tryEval(String t) {
        if (t.isEmpty()) return null;
        char l = t.charAt(t.length() - 1);
        if ("+-*/^".indexOf(l) >= 0) t = t.substring(0, t.length() - 1);
        try {
            return new Eval(closed(t), deg).run();
        } catch (ArithmeticException e) {
            return null;
        }
    }

    static String fmt(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return Long.toString((long) v);
        double a = Math.abs(v);
        if (a >= 1e15 || a < 1e-6) return String.format("%.8e", v).replace(',', '.').replaceAll("0+e", "e").replace(".e", "e");
        return new BigDecimal(v).round(new MathContext(12)).stripTrailingZeros().toPlainString();
    }

    // ------------------------------------------------------------------ ввод кнопок
    private static boolean isNum(char c) { return Character.isDigit(c) || c == '.' || c == 'P' || c == 'e'; }

    private int numStart() {
        int i = ex.length();
        while (i > 0 && (Character.isDigit(ex.charAt(i - 1)) || ex.charAt(i - 1) == '.')) i--;
        return i;
    }

    private int groupStart() {
        int n = ex.length();
        if (n == 0) return 0;
        char l = ex.charAt(n - 1);
        if (l == ')') {
            int d = 0, i = n - 1;
            for (; i >= 0; i--) {
                if (ex.charAt(i) == ')') d++;
                else if (ex.charAt(i) == '(' && --d == 0) break;
            }
            i = Math.max(0, i);
            while (i > 0 && Character.isLetter(ex.charAt(i - 1))) i--;
            return i;
        }
        if (Character.isDigit(l) || l == '.') return numStart();
        if (l == 'P' || l == 'e') return n - 1;
        return n;
    }

    private void fresh() {
        if (!done) return;
        ex.setLength(0);
        hist = "";
        done = false;
    }

    /** Результат прошлого вычисления становится началом выражения. */
    private void carry() {
        if (!done) return;
        ex.setLength(0);
        if (err == null) ex.append(res);
        hist = "";
        done = false;
    }

    private void put(String t) {
        err = null;
        if (ex.length() > 60) return;
        ex.append(t);
    }

    private void implicit() {
        if (ex.length() > 0 && (isNum(ex.charAt(ex.length() - 1)) || ex.charAt(ex.length() - 1) == ')')) ex.append('*');
    }

    private void wrap(String name) {
        carry();
        err = null;
        int g = groupStart();
        if (g < ex.length()) {
            String inner = ex.substring(g);
            ex.setLength(g);
            ex.append(name).append('(').append(inner).append(')');
        } else {
            ex.append(name).append('(');
        }
    }

    private double value() {
        Double v = done ? Double.valueOf(res) : tryEval(ex.toString());
        return v == null ? 0 : v;
    }

    private void press(String a) {
        if (a.length() == 1 && (Character.isDigit(a.charAt(0)) || a.equals("."))) {
            fresh();
            err = null;
            int st = numStart();
            String num = ex.substring(st);
            if (a.equals(".") && num.indexOf('.') >= 0) return;
            if (ex.length() > 0 && (ex.charAt(ex.length() - 1) == ')' || ex.charAt(ex.length() - 1) == 'P' || ex.charAt(ex.length() - 1) == 'e')) ex.append('*');
            if (a.equals(".") && num.isEmpty()) put("0");
            put(a);
            return;
        }
        switch (a) {
            case "+": case "-": case "*": case "/": case "^": {
                carry();
                err = null;
                char o = a.charAt(0);
                if (ex.length() == 0) {
                    ex.append(o == '-' ? "-" : "0" + o);
                    return;
                }
                char l = ex.charAt(ex.length() - 1);
                if (l == '(') {
                    if (o == '-') ex.append('-');
                } else if ("+-*/^".indexOf(l) >= 0) {
                    boolean un = o == '-' && l != '-' && l != '+';
                    if (un) ex.append('-');
                    else {
                        ex.setLength(ex.length() - 1);
                        ex.append(o);
                    }
                } else {
                    put(a);
                }
                return;
            }
            case "(": fresh(); implicit(); put("("); return;
            case ")": {
                int d = 0;
                for (int i = 0; i < ex.length(); i++) d += ex.charAt(i) == '(' ? 1 : ex.charAt(i) == ')' ? -1 : 0;
                if (d > 0 && ex.length() > 0 && "+-*/^(".indexOf(ex.charAt(ex.length() - 1)) < 0) put(")");
                return;
            }
            case "P": case "e": fresh(); implicit(); put(a); return;
            case "%": case "!":
                carry();
                if (ex.length() > 0 && (isNum(ex.charAt(ex.length() - 1)) || ex.charAt(ex.length() - 1) == ')')) put(a);
                return;
            case "x2":
                carry();
                if (ex.length() > 0 && groupStart() < ex.length()) put("^2");
                return;
            case "1/x": {
                carry();
                int g = groupStart();
                String inner = ex.substring(g);
                ex.setLength(g);
                ex.append("1/(").append(inner).append(inner.isEmpty() ? "" : ")");
                return;
            }
            case "10^": case "e^": fresh(); implicit(); put(a.equals("10^") ? "10^(" : "e^("); return;
            case "sqrt": case "sin": case "cos": case "tan": case "ln": case "log": case "abs": case "flr": case "cei": case "rnd":
                wrap(a);
                return;
            case "neg": {
                carry();
                err = null;
                int g = groupStart();
                if (g < ex.length()) {
                    if (g >= 2 && ex.charAt(g - 1) == '-' && "+-*/^(".indexOf(ex.charAt(g - 2)) >= 0) ex.deleteCharAt(g - 1);
                    else if (g == 1 && ex.charAt(0) == '-') ex.deleteCharAt(0);
                    else ex.insert(g, '-');
                }
                return;
            }
            case "CE":
                if (done) {
                    ex.setLength(0);
                    hist = "";
                    done = false;
                    res = "0";
                } else {
                    ex.setLength(groupStart() < ex.length() && isNum(ex.charAt(ex.length() - 1)) ? groupStart() : ex.length());
                }
                err = null;
                return;
            case "C": ex.setLength(0); hist = ""; done = false; res = "0"; err = null; return;
            case "BS":
                if (done) {
                    done = false;
                    hist = "";
                    ex.setLength(0);
                } else if (ex.length() > 0) {
                    int n = ex.length() - 1;
                    if (ex.charAt(n) == '(') {
                        while (n > 0 && Character.isLetter(ex.charAt(n - 1))) n--;
                    }
                    ex.setLength(n);
                }
                err = null;
                return;
            case "=": {
                if (ex.length() == 0 || done) return;
                String src = ex.toString();
                try {
                    double v = new Eval(closed(src), deg).run();
                    res = fmt(v);
                    hist = closed(src) + " =";
                    err = null;
                } catch (ArithmeticException e) {
                    err = e.getMessage();
                    hist = closed(src) + " =";
                    res = "0";
                }
                done = true;
                return;
            }
            case "DEG": deg = !deg; return;
            case "MODE": sci = !sci; return;
            case "MC": hasMem = false; mem = 0; return;
            case "MR":
                if (hasMem) {
                    fresh();
                    implicit();
                    put(fmt(mem));
                }
                return;
            case "MS": mem = value(); hasMem = true; return;
            case "M+": mem += value(); hasMem = true; return;
            case "M-": mem -= value(); hasMem = true; return;
            default: return;
        }
    }

    // ------------------------------------------------------------------ рисование
    private String main() {
        if (err != null) return err;
        if (done) return res;
        if (ex.length() == 0) return "0";
        String t = ex.toString();
        boolean plain = true;
        for (int i = 0; i < t.length(); i++) if (!Character.isDigit(t.charAt(i)) && t.charAt(i) != '.') plain = false;
        if (plain) return t;
        Double v = tryEval(t);
        return v == null ? t.substring(numStart()) : fmt(v);
    }

    private static int gw(char c) { return c == '*' || c == '/' ? 7 : c == 'P' ? 6 : PixelFont.advance(PixelFont.index(c == '.' ? ',' : c)); }

    private static int exW(String t) {
        int w = 0;
        for (int i = 0; i < t.length(); i++) w += gw(t.charAt(i));
        return w;
    }

    private static void exDraw(PixelScreen p, int x, int y, String t, int c) {
        for (int i = 0; i < t.length(); i++) {
            char ch = t.charAt(i);
            if (ch == '*') {
                WinGfx.line(p, x + 1, y + 2, x + 5, y + 6, c);
                WinGfx.line(p, x + 1, y + 6, x + 5, y + 2, c);
            } else if (ch == '/') {
                p.hline(x + 1, y + 4, 5, c);
                p.pixel(x + 3, y + 1, c);
                p.pixel(x + 3, y + 7, c);
            } else if (ch == 'P') {
                p.hline(x, y + 2, 6, c);
                p.vline(x + 1, y + 3, 5, c);
                p.vline(x + 4, y + 3, 5, c);
            } else {
                p.drawText(x, y, String.valueOf(ch == '.' ? ',' : ch), c);
            }
            x += gw(ch);
        }
    }

    private void glyph(PixelScreen p, String a, int cx, int cy, int c) {
        switch (a) {
            case "/": p.hline(cx - 3, cy, 7, c); p.fillRect(cx - 1, cy - 3, 3, 2, c); p.fillRect(cx - 1, cy + 2, 3, 2, c); break;
            case "*": WinGfx.line(p, cx - 3, cy - 3, cx + 3, cy + 3, c); WinGfx.line(p, cx - 3, cy + 3, cx + 3, cy - 3, c); break;
            case "-": p.hline(cx - 3, cy, 7, c); break;
            case "+": p.hline(cx - 3, cy, 7, c); p.vline(cx, cy - 3, 7, c); break;
            case "=": p.hline(cx - 3, cy - 2, 7, c); p.hline(cx - 3, cy + 1, 7, c); break;
            case "BS": WinGfx.line(p, cx - 4, cy, cx - 1, cy - 3, c); WinGfx.line(p, cx - 4, cy, cx - 1, cy + 3, c); p.hline(cx - 4, cy, 9, c); break;
            case "neg": p.hline(cx - 3, cy - 2, 5, c); p.vline(cx - 1, cy - 4, 5, c); p.hline(cx - 3, cy + 3, 7, c); break;
            case "sqrt": WinGfx.line(p, cx - 4, cy, cx - 2, cy + 3, c); WinGfx.line(p, cx - 2, cy + 3, cx + 1, cy - 4, c); p.hline(cx + 1, cy - 4, 5, c); break;
            case "x2": p.drawText(cx - 5, cy - 4, "x", c); p.drawText(cx + 1, cy - 6, "2", c); break;
            case "P": exDraw(p, cx - 3, cy - 4, "P", c); break;
            case "MODE": p.drawTextCentered(cx - 11, 22, cy - 4, sci ? "Науч" : "Обыч", c, 1, false); break;
            case "DEG": p.drawTextCentered(cx - 10, 20, cy - 4, deg ? "ГРД" : "РАД", c, 1, false); break;
            default: p.drawTextCentered(cx - 12, 24, cy - 4, a, c, 1, false); break;
        }
    }

    private int cols() { return sci ? 7 : 4; }

    /** Положение кнопки: {x, y, w, h} относительно содержимого. */
    private int[] cell(int col, int row, boolean memRow) {
        int bw = (aw - 6) / cols(), ky = 49, bh = (ah - ky - 3) / 6;
        if (memRow) {
            int mw = (aw - 6) / 6;
            return new int[] {3 + col * mw, 34, mw - 1, 12};
        }
        return new int[] {3 + col * bw, ky + row * bh, bw - 1, bh - 1};
    }

    private interface Each { void at(String act, int[] r); }

    private void each(Each e) {
        for (int i = 0; i < 6; i++) e.at(MEM[i][0], cell(i, 0, true));
        int off = sci ? 3 : 0;
        for (int i = 0; i < MAIN.length; i++) e.at(MAIN[i], cell(off + i % 4, i / 4, false));
        if (sci) for (int i = 0; i < SCI.length; i++) e.at(SCI[i], cell(i % 3, i / 3, false));
    }

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        String t = ex.length() > 0 && !done ? ex.toString() : hist;
        int max = w - 10;
        while (t.length() > 1 && exW(t) > max) t = t.substring(1);
        exDraw(p, x + w - 6 - exW(t), y + 4, t, th.sub());
        String m = main().replace('.', ',');
        int sc = PixelScreen.textWidth(m, 2, true) <= w - 12 ? 2 : 1;
        if (err != null && sc == 1 && PixelScreen.textWidth(m) > w - 12) m = PixelScreen.fit(m, w - 12, 1, false);
        p.drawTextRight(x + w - 6, y + (sc == 2 ? 15 : 19), m, th.text(), sc, sc == 2);
        if (hasMem) p.drawText(x + 6, y + 4, "M", th.accent());
        each((a, r) -> {
            boolean mem = a.startsWith("M") && a.length() <= 2 || a.equals("MODE");
            boolean num = a.length() == 1 && Character.isDigit(a.charAt(0)) || a.equals(".") || a.equals("neg");
            boolean eq = a.equals("=");
            boolean hv = a.equals(hover);
            int fill, tc = th.text();
            if (eq) {
                fill = hv ? th.accentHover() : th.accent();
                tc = th.onAccent();
            } else if (mem) {
                fill = hv ? th.hover() & 0xFFFFFF | 0x22000000 : 0;
            } else if (num) {
                fill = hv ? (th.dark ? 0xFF3A3A3A : 0xFFF6F6F6) : th.surface();
            } else {
                fill = PixelScreen.lerp(th.bg(), th.dark ? 0xFF000000 : 0xFFFFFFFF, hv ? 0.28f : 0.1f);
            }
            if (mem) {
                if (hv) p.roundRect(x + r[0], y + r[1], r[2], r[3], 3, th.hover());
            } else {
                p.roundRectBorder(x + r[0], y + r[1], r[2], r[3], 3, fill, eq ? fill : th.border());
            }
            glyph(p, a, x + r[0] + r[2] / 2, y + r[1] + r[3] / 2, !hasMem && (a.equals("MC") || a.equals("MR")) ? th.sub() : tc);
        });
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        String[] hit = {""};
        each((a, r) -> {
            if (WinSoft.in(rx, ry, r[0], r[1], r[2], r[3])) hit[0] = a;
        });
        boolean dirty = !hit[0].equals(hover);
        hover = hit[0];
        if (kind == PixelScreen.MOUSE_PRESS && btn == 0 && !hover.isEmpty()) {
            press(hover);
            return true;
        }
        return dirty;
    }

    @Override
    public boolean key(char c, int key) {
        String a = null;
        if (key == WinUi.K_BACK || c == '\b') a = "BS";
        else if (WinUi.isEnter(c, key) || c == '=') a = "=";
        else if (key == WinSoft.K_ESC || key == WinSoft.K_DEL) a = "C";
        else if (c == ',') a = ".";
        else if ("0123456789.+-*/^()!%".indexOf(c) >= 0 && c != 0) a = String.valueOf(c);
        else if (c == 'p' || c == 'P') a = "P";
        else if (c == 'e') a = "e";
        if (a == null) return false;
        press(a);
        return true;
    }
}
