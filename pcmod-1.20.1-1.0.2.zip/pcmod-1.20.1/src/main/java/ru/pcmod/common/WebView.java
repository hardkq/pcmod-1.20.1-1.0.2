package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Единый рендер страниц PC-Net (ПК и телефон): раскладывает WebPage в строки, рисует и собирает области ссылок и кнопок. */
public final class WebView {
    /** Оформление: размеры и цвета рендера (ПК - из WinTheme, телефон - из AndroOs). */
    public static final class Skin {
        /** Отступ слева, отступ сверху, ширина переноса текста. */
        public int pad = 8, padTop = 4, wrapW = 200;
        /** Заголовок: смещение текста, высота строки, добавка после. */
        public int hOff = 2, hLine = 14, hAfter = 0;
        /** Кнопка: высота, радиус, шаг, фиксированная ширина (0 - по тексту), смещение текста по Y. */
        public int btnH = 16, btnR = 4, btnStep = 20, btnW = 0, btnTextY = 4, btnX = 8;
        public boolean underlineAlways;
        public int text, sub, accent, accentHover, onAccent, ok, bad;

        Skin copy() {
            Skin k = new Skin();
            k.pad = pad; k.padTop = padTop; k.wrapW = wrapW; k.hOff = hOff; k.hLine = hLine; k.hAfter = hAfter;
            k.btnH = btnH; k.btnR = btnR; k.btnStep = btnStep; k.btnW = btnW; k.btnTextY = btnTextY; k.btnX = btnX;
            k.underlineAlways = underlineAlways;
            k.text = text; k.sub = sub; k.accent = accent; k.accentHover = accentHover; k.onAccent = onAccent; k.ok = ok; k.bad = bad;
            return k;
        }
    }

    /** Область ссылки или кнопки (координаты относительно точки ox, oy, переданной в draw). */
    public static final class Hit {
        public final int x, y, w, h;
        public final String target;

        Hit(int x, int y, int w, int h, String target) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.target = target;
        }
    }

    public final List<Hit> hits = new ArrayList<Hit>();

    // состояние текущего draw
    private int yy, top, cy, ch, ox, oy;
    private int hover;
    private PixelScreen p;
    private Skin k;

    /** Цвет текста по умолчанию на странице с фоном: чёрный или белый по яркости. */
    private static Skin onBg(Skin s, int bg) {
        Skin k = s.copy();
        k.text = WebPalette.luma(bg) > 0.55f ? 0xFF101010 : 0xFFF4F4F4;
        k.sub = PixelScreen.lerp(k.text, bg, 0.4f);
        if (Math.abs(WebPalette.luma(k.accent) - WebPalette.luma(bg)) < 0.3f) {
            k.accent = PixelScreen.lerp(k.accent, k.text, 0.6f);
            k.accentHover = PixelScreen.lerp(k.accent, k.text, 0.2f);
        }
        return k;
    }

    /**
     * Рисует страницу. (x, y, w) - область содержимого, scroll - прокрутка, (clipY, clipH) - видимая часть по Y
     * (клип выставляет вызывающий), hover - индекс подсвеченной ссылки в hits, (ox, oy) - начало координат для hits.
     * @return высота содержимого в пикселях
     */
    public int draw(PixelScreen p, WebPage pg, Skin skin, int ox, int oy, int x, int y, int w, int scroll, int clipY, int clipH, int hover) {
        this.p = p;
        this.ox = ox;
        this.oy = oy;
        this.hover = hover;
        this.k = pg.bg != 0 ? onBg(skin, pg.bg) : skin;
        this.cy = clipY;
        this.ch = clipH;
        hits.clear();
        if (pg.bg != 0) p.fillRect(x, clipY, w, clipH, pg.bg);
        top = y - scroll;
        yy = top + k.padTop;
        int xx = x + k.pad;
        for (WebRow r : pg.rows) row(r, x, xx, w);
        return yy - top + 4;
    }

    private boolean vis(int h) { return yy + h > cy && yy < cy + ch; }

    private int color(WebRow r, int def) {
        if (r.color != 0) return r.color;
        if (r.tone == 'd') return k.sub;
        if (r.tone == 'k') return k.ok;
        if (r.tone == 'e') return k.bad;
        return def;
    }

    private void row(WebRow r, int x, int xx, int w) {
        switch (r.kind) {
            case 'h': {
                int c = color(r, k.text);
                for (String ln : AppUi.wrap(r.text, k.wrapW * 9 / 10)) {
                    if (vis(k.hLine)) p.drawText(xx, yy + k.hOff, ln, c, 1, true);
                    yy += k.hLine;
                }
                yy += k.hAfter;
                return;
            }
            case 's': {
                int c = color(r, k.text);
                for (String ln : AppUi.wrap(r.text, k.wrapW * 9 / 10)) {
                    if (vis(12)) p.drawText(xx, yy + 1, ln, c, 1, true);
                    yy += 12;
                }
                yy += 2;
                return;
            }
            case 'H': {
                List<String> ls = AppUi.wrap(r.text, (w - 2 * k.pad) * 9 / 10);
                int hh = ls.size() * 13 + 8;
                if (vis(hh)) {
                    p.fillRect(x, yy, w, hh, PixelScreen.alpha(k.accent, 0x44));
                    int c = color(r, k.text);
                    for (int i = 0; i < ls.size(); i++) p.drawText(xx, yy + 4 + i * 13, ls.get(i), c, 1, true);
                }
                yy += hh + 4;
                return;
            }
            case 'F': {
                yy += 4;
                if (vis(2)) p.hline(xx, yy, k.wrapW, PixelScreen.alpha(k.sub, 0x80));
                yy += 5;
                int c = color(r, k.sub);
                for (String ln : AppUi.wrap(r.text, k.wrapW)) {
                    if (vis(11)) p.drawTextCentered(xx, k.wrapW, yy + 1, ln, c, 1, false);
                    yy += 11;
                }
                return;
            }
            case 'r':
                if (vis(7)) p.hline(xx, yy + 3, k.wrapW, PixelScreen.alpha(k.sub, 0x90));
                yy += 7;
                return;
            case 'i': {
                if (vis(r.ph)) {
                    for (int py = 0; py < r.ph; py++) {
                        for (int px = 0; px < r.pw; ) {
                            int c = r.pix[py * r.pw + px];
                            int e = px + 1;
                            while (e < r.pw && r.pix[py * r.pw + e] == c) e++;
                            if (c >= 0) p.fillRect(xx + px, yy + py, e - px, 1, WebPalette.RGB[c]);
                            px = e;
                        }
                    }
                }
                yy += r.ph + 6;
                return;
            }
            case 'p':
                if (vis(38)) SoftPreview.draw(p, r.text, xx + 1, yy + 3);
                yy += 40;
                return;
            case 'T': {
                int n = Math.max(1, r.cells.length), cw = k.wrapW / n, rh = 1;
                List<List<String>> cl = new ArrayList<List<String>>();
                for (String c : r.cells) {
                    List<String> ls = AppUi.wrap(c, (cw - 6) * (r.bold ? 9 : 10) / 10);
                    cl.add(ls);
                    rh = Math.max(rh, ls.size());
                }
                int hh = rh * 11 + 5, c = color(r, k.text);
                if (vis(hh)) {
                    if (r.bold) p.fillRect(xx, yy, cw * n, hh, PixelScreen.alpha(k.sub, 0x30));
                    p.hline(xx, yy + hh - 1, cw * n, PixelScreen.alpha(k.sub, 0x70));
                    for (int i = 0; i < n; i++) {
                        if (i > 0) p.fillRect(xx + i * cw, yy, 1, hh, PixelScreen.alpha(k.sub, 0x50));
                        for (int j = 0; j < cl.get(i).size(); j++) p.drawText(xx + i * cw + 3, yy + 2 + j * 11, cl.get(i).get(j), c, 1, r.bold);
                    }
                }
                yy += hh + 2;
                return;
            }
            case 'b': {
                if (r.text.isEmpty()) return;
                if (k.btnW > 0) {
                    boolean hv = hits.size() == hover;
                    if (vis(k.btnH)) {
                        p.roundRect(x + k.btnX, yy, k.btnW, k.btnH, k.btnR, hv ? k.accentHover : k.accent);
                        p.drawTextCentered(x + k.btnX, k.btnW, yy + k.btnTextY, PixelScreen.fit(r.text, k.btnW - 4, 1, true), k.onAccent, 1, true);
                    }
                    hits.add(new Hit(x + k.btnX - ox, yy - oy, k.btnW, k.btnH, r.target));
                    yy += k.btnStep;
                    return;
                }
                for (String ln : AppUi.wrap(r.text, k.wrapW - 16)) {
                    int bw = PixelScreen.textWidth(ln) + 16;
                    boolean hv = hits.size() == hover;
                    if (vis(k.btnH)) {
                        p.roundRect(x + k.btnX, yy, bw, k.btnH, k.btnR, hv ? k.accentHover : k.accent);
                        p.drawTextCentered(x + k.btnX, bw, yy + k.btnTextY, ln, k.onAccent, 1, false);
                    }
                    hits.add(new Hit(x + k.btnX - ox, yy - oy, bw, k.btnH, r.target));
                    yy += k.btnStep;
                }
                return;
            }
            default:
                break;
        }
        if (r.text.isEmpty()) {
            yy += 6;
            return;
        }
        // t, d, e, k, l, u
        boolean list = r.kind == 'u', link = r.kind == 'l';
        int def = r.kind == 'd' ? k.sub : r.kind == 'e' ? k.bad : r.kind == 'k' ? k.ok : link ? k.accent : k.text;
        int c = color(r, def);
        int ind = list ? 8 : 0;
        int y0 = yy, mw = 0;
        for (String ln : AppUi.wrap(r.text, (k.wrapW - ind) * (r.bold ? 9 : 10) / 10)) {
            if (vis(11)) {
                if (list && yy == y0) p.fillRect(xx + 1, yy + 4, 3, 3, c);
                int tw = p.drawText(xx + ind, yy + 1, ln, c, 1, r.bold) - (xx + ind);
                mw = Math.max(mw, tw);
                if (link && (k.underlineAlways || hits.size() == hover)) p.hline(xx + ind, yy + 10, tw, c);
            }
            yy += 11;
        }
        if (link) hits.add(new Hit(xx - ox, y0 - oy, Math.max(mw, 8) + ind, yy - y0, r.target));
    }
}
