package ru.pcmod.common;

/** Приложение «Сеть»: вкладка подключения (страница Wi-Fi/Ethernet из Параметров) и вкладка диагностики служб сети. */
public final class WinNetApp implements WinApp {
    private static final int TAB = 20;
    private static final String[] TABS = {"Подключение", "Диагностика"};
    private final WinSoft s;
    private final WinSvc svc;
    private final WinPage page;
    private int tab, hover = -1, aw = 248, ah = 130;
    private String sig = "";

    public WinNetApp(WinSoft s) {
        this.s = s;
        this.svc = s.svc;
        this.page = new WinPageNet(s.host);
        page.enter();
    }

    @Override public String title() { return "Сеть"; }

    @Override public String id() { return "net"; }

    @Override public int minW() { return 200; }

    @Override public int minH() { return 90; }

    private static int tx(int i) {
        return 6 + i * 84;
    }

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        p.fillRect(x, y, w, TAB, th.surface());
        p.hline(x, y + TAB - 1, w, th.border());
        for (int i = 0; i < 2; i++) {
            int bx = x + tx(i);
            if (i == hover && i != tab) p.roundRect(bx - 2, y + 2, 80, TAB - 5, 3, th.hover());
            p.drawTextCentered(bx - 2, 80, y + 5, TABS[i], i == tab ? th.accent() : th.text(), 1, i == tab);
            if (i == tab) p.roundRect(bx + 10, y + TAB - 3, 56, 2, 1, th.accent());
        }
        if (tab == 0) {
            page.draw(p, th, x, y + TAB, w, h - TAB);
            return;
        }
        int cy = y + TAB + 6;
        boolean up = svc.netUp();
        String srv = svc.server();
        line(p, th, x, cy, w, "Подключение", s.host.netType() == NetLink.WIRED ? "Ethernet (кабель)" : s.host.netType() == NetLink.WIFI ? "Wi-Fi " + s.host.wifiSaved() : "нет", up ? 2 : 0);
        cy += 20;
        line(p, th, x, cy, w, "Скорость канала", up ? String.format("%.1f КБ/с", svc.linkRate() / 1024).replace('.', ',') : "-", up ? 2 : 0);
        cy += 20;
        line(p, th, x, cy, w, "Сервер сети", srv.isEmpty() ? "не найден" : srv + (svc.servers().size() > 1 ? "  (+" + (svc.servers().size() - 1) + ")" : ""), srv.isEmpty() ? 0 : 2);
        cy += 20;
        line(p, th, x, cy, w, "Чат", !up || srv.isEmpty() ? "недоступен" : svc.chatOnline() ? "вход выполнен: " + svc.chatNick() : "доступен", !up || srv.isEmpty() ? 0 : svc.chatOnline() ? 2 : 1);
        cy += 20;
        line(p, th, x, cy, w, "Банк и магазин", svc.bankReady() ? "доступны" : "недоступны", svc.bankReady() ? 2 : 0);
    }

    /** state: 0 - плохо, 1 - внимание, 2 - хорошо. */
    private static void line(PixelScreen p, WinTheme th, int x, int y, int w, String k, String v, int state) {
        p.roundRectBorder(x + 6, y, w - 12, 17, 4, th.surface(), th.border());
        int c = state == 2 ? th.ok() : state == 1 ? th.warn() : th.bad();
        p.roundRect(x + 12, y + 6, 5, 5, 2, c);
        p.drawText(x + 22, y + 4, k, th.text());
        p.drawTextRight(x + w - 12, y + 4, PixelScreen.fit(v, w - 40 - PixelScreen.textWidth(k), 1, false), th.sub(), 1, false);
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int hv = -1;
        if (ry >= 0 && ry < TAB) for (int i = 0; i < 2; i++) if (rx >= tx(i) - 2 && rx < tx(i) + 78) hv = i;
        boolean d = hv != hover;
        hover = hv;
        if (kind == PixelScreen.MOUSE_PRESS && btn == 0 && hv >= 0 && hv != tab) {
            tab = hv;
            if (tab == 0) page.enter();
            return true;
        }
        if (tab == 0 && ry >= TAB) return page.mouse(rx, ry - TAB, btn, kind) | d;
        return d;
    }

    @Override
    public boolean key(char c, int key) {
        return tab == 0 && page.key(c, key);
    }

    @Override
    public boolean tick(long now) {
        if (tab == 0) return page.tick(now);
        if (now % 20 != 0) return false;
        String n = svc.netUp() + svc.server() + (int) svc.linkRate() + svc.chatOnline() + svc.bankReady() + s.host.netType();
        if (n.equals(sig)) return false;
        sig = n;
        return true;
    }
}
