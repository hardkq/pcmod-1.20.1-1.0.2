package ru.pcmod.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Настройки хостинга сайтов: config/pcmod_sites.cfg (/pcsite reload). Цены - в консах, сроки - в игровых сутках. */
public final class SiteConfig {
    private static final Logger LOG = LogManager.getLogger("pcmod");
    public static final int MIN_NAME = 3, MAX_NAME = 16, MAX_PAGE_NAME = 24, MAX_TITLE = 40, MAX_TAGS = 5, MAX_TAG = 12;
    /** Адреса встроенных сайтов и служебные имена - занимать нельзя. */
    public static final Set<String> RESERVED = new HashSet<String>(Arrays.asList(
            "home", "games", "av", "news", "help", "phone", "apps", "soft", "search", "bank", "chat", "net", "www", "pc", "admin", "server", "mail"));

    private static int price = 100, renew = 50, days = 30, grace = 10, maxSites = 3, maxPages = 8, maxPageBytes = 6000, maxTotalBytes = 24000, maxElements = 120,
            maxPagePrice = 500, flagReports = 3, maxGuests = 30, fee = 10;
    private static final List<String> BAD_WORDS = new ArrayList<String>();
    private static final List<String> BAD_DOMAINS = new ArrayList<String>();
    private static File file;

    static final String DEFAULTS =
            "# PC Mod: site hosting (name.pc). One line per setting, apply with /pcsite reload (op).\n"
            + "# price <kons>          - registering a domain\n"
            + "# renew <kons>          - renewing for one period\n"
            + "# days <n>              - period length in game days (a day = 20 minutes)\n"
            + "# grace <n>             - game days after expiry while the owner can still renew; then the domain is released\n"
            + "# maxsites <n>          - sites per player\n"
            + "# maxpages <n>          - pages per site\n"
            + "# maxpagebytes <n>      - bytes of markup per page\n"
            + "# maxtotalbytes <n>     - bytes of markup per site\n"
            + "# maxelements <n>      - elements (rows, images, table rows) per page\n"
            + "# maxpageprice <kons>   - highest price of a paid page (@price)\n"
            + "# flagreports <n>       - complaints after which a site is marked suspicious in search.pc\n"
            + "# maxguests <n>         - guestbook entries per site (pending + published)\n"
            + "# fee <percent>         - share of a paid page price that is not passed to the owner\n"
            + "# badword <word>        - forbidden in domains, titles, tags and page text (substring, any case)\n"
            + "# baddomain <part>      - forbidden inside domain names\n"
            + "price 100\n"
            + "renew 50\n"
            + "days 30\n"
            + "grace 10\n"
            + "maxsites 3\n"
            + "maxpages 8\n"
            + "maxpagebytes 6000\n"
            + "maxtotalbytes 24000\n"
            + "maxelements 120\n"
            + "maxpageprice 500\n"
            + "flagreports 3\n"
            + "maxguests 30\n"
            + "fee 10\n";

    private SiteConfig() { }

    public static synchronized int price() { return price; }
    public static synchronized int renewPrice() { return renew; }
    public static synchronized int days() { return days; }
    public static synchronized int grace() { return grace; }
    public static synchronized int maxSites() { return maxSites; }
    public static synchronized int maxPages() { return maxPages; }
    public static synchronized int maxPageBytes() { return maxPageBytes; }
    public static synchronized int maxTotalBytes() { return maxTotalBytes; }
    public static synchronized int maxElements() { return maxElements; }
    public static synchronized int maxPagePrice() { return maxPagePrice; }
    public static synchronized int flagReports() { return flagReports; }
    public static synchronized int maxGuests() { return maxGuests; }
    public static synchronized int fee() { return fee; }

    /** Домен из ввода игрока: "Name", "name.pc" -> "name.pc"; null - недопустимое имя. */
    public static String normalize(String raw) {
        if (raw == null) return null;
        String s = raw.trim().toLowerCase(Locale.ROOT);
        if (s.endsWith(".pc")) s = s.substring(0, s.length() - 3);
        if (s.length() < MIN_NAME || s.length() > MAX_NAME) return null;
        if (s.charAt(0) == '-' || s.charAt(s.length() - 1) == '-' || s.contains("--")) return null;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-')) return null;
        }
        return s + ".pc";
    }

    /** Имя страницы: a-z, 0-9, _, - (до 24 знаков); "" и "/" - главная "index". null - недопустимо. */
    public static String pageName(String raw) {
        if (raw == null) return "index";
        String s = raw.trim().toLowerCase(Locale.ROOT);
        while (s.startsWith("/")) s = s.substring(1);
        if (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        if (s.isEmpty()) return "index";
        if (s.length() > MAX_PAGE_NAME) return null;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-')) return null;
        }
        return s;
    }

    /** null - домен можно занять, иначе причина (английский текст). */
    public static String checkDomain(String domain) {
        String n = domain.substring(0, domain.length() - 3);
        if (RESERVED.contains(n)) return "This domain is reserved";
        synchronized (SiteConfig.class) {
            for (String b : BAD_DOMAINS) if (n.contains(b)) return "Domain is not allowed";
            for (String b : BAD_WORDS) if (n.contains(b)) return "Domain is not allowed";
        }
        return null;
    }

    /** true - в тексте есть слово из чёрного списка. */
    public static synchronized boolean hasBadWord(String text) {
        if (text == null || text.isEmpty() || BAD_WORDS.isEmpty()) return false;
        String t = text.toLowerCase(Locale.ROOT);
        for (String b : BAD_WORDS) if (t.contains(b)) return true;
        return false;
    }

    // ===================== конфиг =====================
    public static void setConfigDir(File dir) { file = new File(dir, "pcmod_sites.cfg"); }

    private static int num(String s, int lo, int hi) {
        int v = Integer.parseInt(s);
        if (v < lo || v > hi) throw new NumberFormatException();
        return v;
    }

    /** Читает конфиг (создаёт при первом запуске). Возвращает число применённых строк. */
    public static synchronized int load() {
        price = 100; renew = 50; days = 30; grace = 10; maxSites = 3; maxPages = 8; maxPageBytes = 6000; maxTotalBytes = 24000; maxElements = 120;
        maxPagePrice = 500; flagReports = 3; maxGuests = 30; fee = 10;
        BAD_WORDS.clear();
        BAD_DOMAINS.clear();
        if (file == null) return 0;
        if (!file.exists()) {
            try {
                File dir = file.getParentFile();
                if (dir != null) dir.mkdirs();
                Writer w = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
                try { w.write(DEFAULTS); } finally { w.close(); }
            } catch (Exception e) {
                LOG.warn("Cannot write " + file + ": " + e);
            }
        }
        int n = 0;
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
            try {
                String ln;
                while ((ln = r.readLine()) != null) {
                    ln = ln.trim();
                    if (ln.isEmpty() || ln.startsWith("#")) continue;
                    String[] p = ln.split("\\s+", 2);
                    if (p.length < 2) {
                        LOG.warn("pcmod_sites.cfg: skipped line: " + ln);
                        continue;
                    }
                    try {
                        switch (p[0]) {
                            case "price": price = num(p[1], 0, 1000000); break;
                            case "renew": renew = num(p[1], 0, 1000000); break;
                            case "days": days = num(p[1], 1, 3650); break;
                            case "grace": grace = num(p[1], 0, 3650); break;
                            case "maxsites": maxSites = num(p[1], 0, 100); break;
                            case "maxpages": maxPages = num(p[1], 1, 64); break;
                            case "maxpagebytes": maxPageBytes = num(p[1], 256, 16000); break;
                            case "maxtotalbytes": maxTotalBytes = num(p[1], 256, 200000); break;
                            case "maxelements": maxElements = num(p[1], 10, 1000); break;
                            case "maxpageprice": maxPagePrice = num(p[1], 1, 100000); break;
                            case "flagreports": flagReports = num(p[1], 1, 100); break;
                            case "maxguests": maxGuests = num(p[1], 1, 100); break;
                            case "fee": fee = num(p[1], 0, 100); break;
                            case "badword": BAD_WORDS.add(p[1].trim().toLowerCase(Locale.ROOT)); break;
                            case "baddomain": BAD_DOMAINS.add(p[1].trim().toLowerCase(Locale.ROOT)); break;
                            default:
                                LOG.warn("pcmod_sites.cfg: skipped line: " + ln);
                                continue;
                        }
                        n++;
                    } catch (NumberFormatException e) {
                        LOG.warn("pcmod_sites.cfg: bad value: " + ln);
                    }
                }
            } finally {
                r.close();
            }
        } catch (Exception e) {
            LOG.warn("Cannot read " + file + ": " + e);
        }
        BAD_WORDS.removeIf(String::isEmpty);
        BAD_DOMAINS.removeIf(String::isEmpty);
        if (maxTotalBytes < maxPageBytes) maxTotalBytes = maxPageBytes;
        return n;
    }
}
