package ru.pcmod.common;

import java.util.List;
import net.minecraft.world.entity.player.Player;
import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Банк»: общий со всеми ПК счёт игрока (консы), наличные из инвентаря, внесение и снятие, последние операции. */
final class AppBank implements AndroOs.App {
    private static final class St {
        String msg = "";
        boolean ok;
        long until, sig;
    }

    private static St st(AndroOs os) { return os.state("bank", St::new); }

    private static long sig(AndroOs os) {
        Bank b = Bank.get();
        if (b == null || os.ses == null) return 0;
        String id = AppNet.id(os);
        return b.balance(id) * 31 + Bank.cash(AppNet.player(os)) * 7 + b.history(id).size();
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "bank", os.t("Банк", "Bank"));
        if (!AppNet.ready(os)) { AppNet.offline(os, s); return; }
        Bank b = Bank.get();
        Player p = AppNet.player(os);
        String id = AppNet.id(os);
        s.roundRect(8, 50, 164, 52, 10, os.panel());
        s.drawText(16, 56, os.t("Счёт: ", "Account: ") + PixelScreen.fit(p.getGameProfile().getName(), 100, 1, false), os.sub());
        s.drawText(16, 68, String.valueOf(b.balance(id)), os.text(), 2, true);
        s.drawText(16 + PixelScreen.textWidth(String.valueOf(b.balance(id)), 2, true) + 4, 76, "K", os.sub(), 1, true);
        s.drawText(16, 90, os.t("Наличные: ", "Cash: ") + AppNet.kons(Bank.cash(p)), os.sub());
        AppUi.btn(os, s, 8, 108, 80, 24, os.t("Внести", "Deposit"), true);
        AppUi.btn(os, s, 92, 108, 80, 24, os.t("Снять", "Withdraw"), false);
        AppUi.btn(os, s, 8, 136, 164, 20, os.t("Внести всё", "Deposit all"), false);
        if (st.until > os.now()) s.drawTextCentered(0, AndroOs.W, 160, PixelScreen.fit(st.msg, 168, 1, true), st.ok ? rgb(80, 220, 120) : rgb(240, 110, 100), 1, true);
        s.drawText(10, 174, os.t("Последние операции", "Recent operations"), os.text(), 1, true);
        List<String> h = b.history(id);
        if (h.isEmpty()) s.drawText(10, 190, os.t("Операций пока нет", "No operations yet"), os.sub());
        for (int i = 0; i < h.size() && i < 8; i++) {
            String t = h.get(h.size() - 1 - i);
            s.drawText(10, 188 + i * 13, PixelScreen.fit(t, 160, 1, false), t.startsWith("+") ? rgb(80, 220, 120) : t.startsWith("-") ? rgb(240, 120, 100) : os.text());
        }
    }

    private static void op(AndroOs os, int kind, String v) {
        St st = st(os);
        if (!AppNet.ready(os)) return;
        long a = -1;
        if (kind != 2) {
            try { a = v.isEmpty() ? 0 : Long.parseLong(v); } catch (NumberFormatException e) { a = 0; }
        }
        Bank.Res r = kind == 1 ? Bank.get().withdraw(AppNet.player(os), a) : Bank.get().deposit(AppNet.player(os), a);
        st.msg = AppNet.tr(os, r.msg);
        st.ok = r.ok;
        st.until = os.now() + 100;
        st.sig = sig(os);
        os.dirty();
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        if (kind != 1 || !os.tap(x, y) || !AppNet.ready(os)) return true;
        if (AppUi.in(x, y, 8, 108, 80, 24)) os.input(os.t("Сумма взноса", "Deposit amount"), "", 9, 1, v -> op(os, 0, v));
        else if (AppUi.in(x, y, 92, 108, 80, 24)) os.input(os.t("Сумма снятия", "Withdraw amount"), "", 6, 1, v -> op(os, 1, v));
        else if (AppUi.in(x, y, 8, 136, 164, 20)) op(os, 2, "");
        return true;
    }

    @Override
    public void bg(AndroOs os) {
        if (!AppNet.visible(os, "bank")) return;
        St st = st(os);
        long g = sig(os);
        if (g != st.sig) { st.sig = g; os.dirty(); }
    }
}
