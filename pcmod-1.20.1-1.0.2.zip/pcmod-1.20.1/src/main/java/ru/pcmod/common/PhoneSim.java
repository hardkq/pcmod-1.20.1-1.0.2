package ru.pcmod.common;

import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/** Связь телефона с оператором: SIM из слота телефона, сигнал вышек, номер, расход трафика (всё серверное). */
public final class PhoneSim {
    /** Сколько МБ SIM тратит каждый запрос страницы в браузере по мобильному интернету. */
    public static final int MB_PER_REQUEST = 5;

    private PhoneSim() { }

    public static final class Info {
        /** Полоски сигнала 0..3 (0 - нет SIM, SIM заблокирована, глушилка или нет подходящей вышки). */
        public int bars;
        /** Номер SIM (7 цифр) или "" - SIM нет или она не принадлежит этому игроку. */
        public String number = "";
    }

    private static UUID opId(ItemStack sim) {
        try { return UUID.fromString(ItemSimCard.getOperatorId(sim)); } catch (RuntimeException e) { return null; }
    }

    /** Раз в секунду: проверка SIM, обновление её NBT (трафик, тариф) и расчёт сигнала. */
    public static Info info(ServerPlayer p, ItemStack phone) {
        Info i = new Info();
        ItemStack sim = ItemPhone.getSim(phone);
        OperatorStore st = OperatorStore.get();
        if (sim.isEmpty() || st == null) return i;
        OperatorStore.SimRecord r = st.recordFor(sim, p.getUUID());
        if (r == null) return i;
        sync(phone, sim, r);
        i.number = String.valueOf(r.phoneNumber);
        if (!r.blocked) i.bars = Net.mobileSignal(p.level(), p.blockPosition(), p.getUUID(), ItemSimCard.getOperatorId(sim));
        return i;
    }

    private static void sync(ItemStack phone, ItemStack sim, OperatorStore.SimRecord r) {
        UUID op = opId(sim);
        if (op == null || (ItemSimCard.getDataBalance(sim) == r.dataBalance && ItemSimCard.getTariffId(sim).equals(r.tariffId) && !ItemSimCard.getOperatorName(sim).isEmpty())) return;
        OperatorStore.writeSim(sim, op, r);
        ItemPhone.setSim(phone, sim);
    }

    /** Списать мегабайты с SIM телефона. false - SIM нет, она заблокирована или трафика не хватает. */
    public static boolean spend(AndroOs os, int mb) {
        PhoneSession ses = os.ses;
        OperatorStore st = OperatorStore.get();
        if (ses == null || st == null) return false;
        ItemStack phone = ses.stack(), sim = ItemPhone.getSim(phone);
        UUID op = opId(sim);
        OperatorStore.SimRecord r = op == null ? null : st.recordFor(sim, ses.player.getUUID());
        if (r == null || st.spendData(op, ses.player.getUUID(), mb) < 0) return false;
        sync(phone, sim, r);
        return true;
    }
}
