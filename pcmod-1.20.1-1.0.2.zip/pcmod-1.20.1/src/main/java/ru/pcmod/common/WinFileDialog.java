package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Окно «Открыть»/«Сохранить как» внутри приложения (рисуется поверх содержимого, координаты относительные). */
final class WinFileDialog {
    interface Done { void picked(String path); }

    private static final int IH = 11;
    private final WinFs fs;
    private final boolean save;
    private final String title, defExt;
    private final String[] exts;
    private final Done done;
    private final WinUi.Field name = new WinUi.Field(0, 0, 10);
    private final List<String> items = new ArrayList<String>();
    private String dir;
    private int scroll, sel = -1, lastClick = -1, pw, ph, aw, ah;
    private long lastAt, now;
    private String msg = "";
    private boolean confirm, hoverOk, hoverCancel, hoverUp, fresh;
    boolean closed;

    /** exts - допустимые расширения (null - любые); defExt - расширение по умолчанию при сохранении. */
    WinFileDialog(WinFs fs, boolean save, String title, String dir, String fileName, String defExt, String[] exts, Done done) {
        this.fs = fs;
        this.save = save;
        this.title = title;
        this.dir = fs.isDir(dir) ? dir : fs.home();
        this.defExt = defExt;
        this.exts = exts;
        this.done = done;
        name.max = 60;
        name.h = 16;
        name.sb.append(fileName);
        fresh = !fileName.isEmpty();
        reload();
    }

    private boolean accepts(String n) {
        if (exts == null) return true;
        String e = WinFs.ext(n);
        for (String x : exts) if (x.equals(e)) return true;
        return false;
    }

    private void reload() {
        items.clear();
        List<String> d = new ArrayList<String>(), f = new ArrayList<String>();
        for (String n : fs.list(dir)) {
            if (n.endsWith("/")) d.add(n);
            else if (accepts(n)) f.add(n);
        }
        items.addAll(d);
        items.addAll(f);
        scroll = 0;
        sel = -1;
        confirm = false;
        msg = "";
    }

    private int rows() { return (ph - 72) / IH; }

    private void geom(int w, int h) {
        aw = w;
        ah = h;
        pw = Math.min(w - 8, 230);
        ph = Math.min(h - 8, 132);
    }

    void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h, long tick) {
        geom(w, h);
        p.fillRect(x, y, w, h, 0x50000000);
        int px = x + (w - pw) / 2, py = y + (h - ph) / 2;
        p.shadow(px, py, pw, ph, 6, 8, 0, 3, 0x70000000);
        p.roundRectBorder(px, py, pw, ph, 6, th.surface(), th.border());
        p.drawText(px + 8, py + 5, title, th.text());
        WinSoft.flat(p, th, px + 6, py + 17, 16, 14, "^", hoverUp, false);
        p.roundRectBorder(px + 25, py + 17, pw - 31, 14, 4, th.bg(), th.border());
        p.drawText(px + 30, py + 20, PixelScreen.fit(WinFs.show(dir), pw - 42, 1, false), th.sub());
        int ly = py + 34, lh = rows() * IH;
        p.roundRectBorder(px + 6, ly - 1, pw - 12, lh + 2, 3, th.bg(), th.border());
        p.pushClip(px + 7, ly, pw - 14, lh);
        for (int i = 0; i < rows() && scroll + i < items.size(); i++) {
            String n = items.get(scroll + i);
            boolean isDir = n.endsWith("/");
            int iy = ly + i * IH;
            if (scroll + i == sel) p.roundRect(px + 8, iy, pw - 20, IH - 1, 2, PixelScreen.alpha(th.accent(), 0x48));
            WinSoft.fileIcon(p, n, isDir, px + 10, iy - 1);
            p.drawText(px + 25, iy + 1, PixelScreen.fit(isDir ? n.substring(0, n.length() - 1) : n, pw - 48, 1, false), th.text());
        }
        p.popClip();
        WinSoft.scrollbar(p, th, px + pw - 10, ly, lh, items.size(), rows(), scroll);
        name.x = px + 6;
        name.y = py + ph - 36;
        name.w = pw - 12;
        name.draw(p, th, true, tick);
        String m = msg.isEmpty() ? "" : msg;
        if (!m.isEmpty()) p.drawText(px + 8, py + ph - 18, PixelScreen.fit(m, pw - 100, 1, false), th.bad());
        int by = py + ph - 19;
        WinUi.Button ok = new WinUi.Button(confirm ? "Заменить" : save ? "Сохранить" : "Открыть", px + pw - 108, by, 52, true);
        ok.h = 14;
        ok.hover = hoverOk;
        ok.draw(p, th);
        WinUi.Button no = new WinUi.Button("Отмена", px + pw - 54, by, 48, false);
        no.h = 14;
        no.hover = hoverCancel;
        no.draw(p, th);
    }

    private void accept() {
        String n = name.sb.toString().trim();
        if (n.isEmpty()) {
            msg = "Введите имя файла";
            return;
        }
        if (n.indexOf('/') >= 0 || n.indexOf('\\') >= 0) {
            msg = "Недопустимое имя";
            return;
        }
        if (!save && fs.isDir(WinFs.join(dir, n))) {
            dir = WinFs.join(dir, n);
            name.sb.setLength(0);
            reload();
            return;
        }
        if (WinFs.ext(n).isEmpty() && !defExt.isEmpty() && save) n += "." + defExt;
        String path = WinFs.join(dir, n);
        if (fs.isDir(path)) {
            msg = "Это папка";
        } else if (!save && !fs.isFile(path)) {
            msg = "Файл не найден";
        } else if (save && fs.isFile(path) && !confirm) {
            confirm = true;
            msg = "Файл уже есть";
        } else {
            closed = true;
            done.picked(path);
        }
    }

    boolean key(char c, int key) {
        if (key == WinSoft.K_ESC) {
            closed = true;
            return true;
        }
        boolean bs = key == WinUi.K_BACK || c == '\b';
        if (fresh && (bs || c >= 32)) name.sb.setLength(0);
        fresh = false;
        if (bs && name.sb.length() == 0) return true;
        if (name.key(c, key)) accept();
        else confirm = false;
        return true;
    }

    boolean mouse(int rx, int ry, int btn, int kind, long now) {
        this.now = now;
        int px = (aw - pw) / 2, py = (ah - ph) / 2;
        boolean up = WinSoft.in(rx, ry, px + 6, py + 17, 16, 14);
        boolean ok = WinSoft.in(rx, ry, px + pw - 108, py + ph - 19, 52, 14);
        boolean no = WinSoft.in(rx, ry, px + pw - 54, py + ph - 19, 48, 14);
        boolean dirty = up != hoverUp || ok != hoverOk || no != hoverCancel;
        hoverUp = up;
        hoverOk = ok;
        hoverCancel = no;
        int ly = py + 34, lh = rows() * IH;
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            int s = Math.max(0, Math.min(Math.max(0, items.size() - rows()), scroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -2 : 2)));
            if (s == scroll) return dirty;
            scroll = s;
            return true;
        }
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return dirty;
        if (no) {
            closed = true;
        } else if (ok) {
            accept();
        } else if (up) {
            if (!dir.equals("/")) {
                dir = WinFs.parent(dir);
                reload();
            }
        } else if (WinSoft.in(rx, ry, px + 7, ly, pw - 14, lh)) {
            int i = scroll + (ry - ly) / IH;
            if (i >= items.size()) {
                sel = -1;
            } else {
                String n = items.get(i);
                boolean dbl = i == lastClick && now - lastAt <= 9;
                lastClick = i;
                lastAt = now;
                sel = i;
                confirm = false;
                fresh = false;
                msg = "";
                if (n.endsWith("/")) {
                    if (dbl) {
                        dir = WinFs.join(dir, n.substring(0, n.length() - 1));
                        reload();
                    }
                } else {
                    name.sb.setLength(0);
                    name.sb.append(n);
                    if (dbl) accept();
                }
            }
        }
        return true;
    }
}
