package ru.pcmod.common;

import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Метаданные 1.12.2 (computer0-4, monitor0-4, router0-1, server0-1, miner0-1) -> отдельные блоки; type = бывшая meta. */
public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, "pcmod");
    public static final DeferredRegister<Item> BLOCK_ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "pcmod");

    public static final RegistryObject<Block>[] COMPUTER = arr(5, i -> "computer" + (i == 0 ? "" : i), (t) -> new BlockComputer(t));
    public static final RegistryObject<Block>[] MONITOR  = arr(5, i -> "monitor" + i, (t) -> new BlockMonitor(t));
    public static final RegistryObject<Block>[] ROUTER   = arr(2, i -> "router" + i,  (t) -> new BlockRouter(t));
    public static final RegistryObject<Block>[] SERVER   = arr(2, i -> "server" + i,  (t) -> new BlockServer(t));
    public static final RegistryObject<Block>[] MINER    = arr(2, i -> "miner" + i,   (t) -> new BlockMiner(t));

    public static final RegistryObject<Block> CABLE        = reg("cable",        () -> new BlockCable());
    public static final RegistryObject<Block> VIDEO_CABLE  = reg("video_cable",  () -> new BlockVideoCable());
    public static final RegistryObject<Block> FIBER        = reg("fiber0",       () -> new BlockFiber());
    public static final RegistryObject<Block> CHAMBER_WALL  = reg("chamber_wall",  () -> new BlockChamberWall());
    public static final RegistryObject<Block> CHAMBER_GLASS = reg("chamber_glass", () -> new BlockChamberGlass());
    public static final RegistryObject<Block> CHILLER       = reg("chiller",       () -> new BlockChiller());

    public static final RegistryObject<Block> PHONE_TABLE   = reg("phone_table",   () -> new BlockPhoneTable());
    public static final RegistryObject<Block> PHONE_CHARGER = reg("phone_charger", () -> new BlockCharger());

    // сотовая связь (этап 2)
    public static final RegistryObject<Block> TOWER  = reg("tower",  () -> new BlockTower());
    public static final RegistryObject<Block> JAMMER = reg("jammer", () -> new BlockJammer());
    public static final RegistryObject<Block> GENERATOR = reg("generator", () -> new BlockGenerator());

    // руды телефонных материалов (дроп и генерация - в data/pcmod)
    public static final RegistryObject<Block> SILICON_ORE     = ore("silicon_ore", 3.0f, 2);
    public static final RegistryObject<Block> LITHIUM_ORE     = ore("lithium_ore", 3.5f, 3);
    public static final RegistryObject<Block> RARE_EARTH_ORE  = ore("rare_earth_ore", 4.5f, 4);
    public static final RegistryObject<Block> OIL_SHALE_ORE   = ore("oil_shale_ore", 3.0f, 1);

    private static RegistryObject<Block> ore(String name, float hardness, int maxXp) {
        return reg(name, () -> new DropExperienceBlock(BlockBehaviour.Properties.of().mapColor(MapColor.STONE)
            .strength(hardness, 3.0f).sound(SoundType.STONE).requiresCorrectToolForDrops(), UniformInt.of(0, maxXp)));
    }

    private static RegistryObject<Block> reg(String name, Supplier<Block> s) {
        RegistryObject<Block> b = BLOCKS.register(name, s);
        BLOCK_ITEMS.register(name, () -> new BlockItem(b.get(), new Item.Properties()));
        return b;
    }

    @SuppressWarnings("unchecked")
    private static RegistryObject<Block>[] arr(int n, java.util.function.IntFunction<String> name, Function<Integer, Block> f) {
        RegistryObject<Block>[] a = new RegistryObject[n];
        for (int i = 0; i < n; i++) { final int t = i; a[i] = reg(name.apply(i), () -> f.apply(t)); }
        return a;
    }

    public static void register(IEventBus bus) { BLOCKS.register(bus); BLOCK_ITEMS.register(bus); }
    private ModBlocks() {}
}
