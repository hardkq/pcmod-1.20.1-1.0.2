package ru.pcmod.common;

/**
 * WinCraft 11: загрузка (логотип и круговой индикатор), экран блокировки, вход и рабочий стол с обоями.
 * Работает на пиксельном буфере PixelScreen; вся связь с компьютером идёт через WinHost.
 */
public final class WinCraft extends WinScene {
    enum Phase { BOOT, LOCK, LOGIN, WELCOME, DESKTOP }

    private static final int W = PixelScreen.W, H = PixelScreen.H;

    final WinSpec.Perf perf;
    Phase phase = Phase.BOOT;
    /** Экраны входа всегда тёмные (как в Windows 11), тема рабочего стола - в th. */
    private final WinTheme lth = new WinTheme();

    private final WinUi.Field pass = new WinUi.Field(95, 104, 130);
    private final WinUi.Menu powerMenu = new WinUi.Menu("Перезагрузка", "Завершение работы");
    private final WinWm wm;
    private final WinDesk desk;
    private final WinApps apps;
    private final WinLook look;
    private int pendingPower = -1;
    private String err = "";
    private int attempts;
    private long lockUntil, welcomeEnd, lastStamp = -1, lastInput;
    /** Раздел «Параметров» для следующего нового окна и приложение, которое просили запустить из «Параметров». */
    private int settingsPage = -1;
    private String pendingLaunch;
    /** Запросы приложений (WinSoft.Ctx): запуск и закрытие окон выполняются после обработки события. */
    private String pendingOpen, pendingOpenArg;
    private final java.util.List<WinApp> pendingKill = new java.util.ArrayList<WinApp>();
    private WinSoft soft;
    private boolean signedIn, subHover, powerHover;
    private int mods;

    public WinCraft(WinHost h) {
        super(h);
        perf = WinSpec.perf(h.hw());
        lth.dark = true;
        th.dark = false;
        look = new WinLook(th, perf, h);
        pass.h = 18;
        pass.padRight = 18;
        pass.hint = "Пароль";
        pass.mask = true;
        pass.max = 24;
        apps = new WinApps(h, perf);
        final WinSettings.Ctx ctx = new WinSettings.Ctx() {
            @Override public void power(int action) { pendingPower = action; }

            @Override public void launch(String id) { pendingLaunch = id; }
        };
        apps.add("settings", "Параметры", WinSettings.WIN_W, WinSettings.WIN_H, true, () -> newSettings(ctx, WinSettings.P_SYSTEM));
        apps.add("about", "О системе", WinSettings.WIN_W, WinSettings.WIN_H, true, () -> newSettings(ctx, WinSettings.P_ABOUT));
        apps.desktop("about", "Этот компьютер", "pc");
        wm = new WinWm(th, perf.effects, new WinTaskbar.Env() {
            @Override public long dayTime() { return WinCraft.this.h.dayTime(); }

            @Override public int netType() { return WinCraft.this.h.netType(); }

            @Override public int netSignal() { return WinCraft.this.h.netSignal(); }

            @Override public String userName() { return WinCraft.this.h.userName(); }

            @Override public void power(int action) { pendingPower = action; }

            @Override public int avState() { return WinCraft.this.h.svc().avState(); }

            @Override
            public void open(String appId) {
                pendingOpen = appId;
                pendingOpenArg = "";
            }
        }, apps);
        soft = new WinSoft(apps, h, th, perf, new WinSoft.Ctx() {
            @Override public void open(String appId, String arg) {
                pendingOpen = appId;
                pendingOpenArg = arg == null ? "" : arg;
            }

            @Override public void kill(WinApp app) { pendingKill.add(app); }

            @Override public java.util.List<WinSoft.Proc> procs() {
                java.util.List<WinSoft.Proc> r = new java.util.ArrayList<WinSoft.Proc>();
                for (WinWm.Win w : wm.windows()) r.add(new WinSoft.Proc(w.app, w.min));
                return r;
            }
        });
        apps.desktop("explorer", "Проводник", "explorer");
        apps.desktop("notepad", "Блокнот", "notepad");
        apps.desktop("browser", "Браузер", "browser");
        WinApps.Info st = apps.get("settings");
        wm.bar.pin(st.id, st.title, st.w, st.h, st.make);
        desk = new WinDesk(th, perf.effects, apps, new WinDesk.Host() {
            @Override public int[] open(String appId) { return openApp(appId); }

            @Override public String pref(String key) { return WinCraft.this.h.pref(key); }

            @Override public void setPref(String key, String value) { WinCraft.this.h.setPref(key, value); }
        });
        wm.desk = desk;
    }

    // ================================================================== запуск приложений
    /** Новое окно «Параметров»: раздел, запрошенный через openSettings, иначе dflt. */
    private WinSettings newSettings(WinSettings.Ctx ctx, int dflt) {
        int page = settingsPage >= 0 ? settingsPage : dflt;
        settingsPage = -1;
        return new WinSettings(h, th, look, perf, apps, ctx, page);
    }

    /** Запуск по id; «personal» (меню рабочего стола) - «Персонализация», «about» - «О системе» в «Параметрах». */
    private int[] openApp(String id) {
        if (id.equals("personal")) return openSettings(WinSettings.P_PERSONAL);
        if (id.equals("about")) return openSettings(WinSettings.P_ABOUT);
        if (id.equals("settings")) return openSettings(WinSettings.P_SYSTEM);
        return wm.start.run(id);
    }

    /** Открыть «Параметры» на разделе page: уже открытое окно текущего стола переключается, иначе создаётся новое. */
    private int[] openSettings(int page) {
        for (WinWm.Win w : wm.windows()) {
            if (!(w.app instanceof WinSettings)) continue;
            int[] d = wm.bring(w);
            if (d == null) continue;
            ((WinSettings) w.app).go(page);
            return d;
        }
        settingsPage = page;
        int[] d = wm.start.run("settings");
        settingsPage = -1;
        return d;
    }

    /** Приложения с включённым автозапуском (настройка "autorun") открываются при входе. */
    private void autorun() {
        String s = h.pref("autorun");
        if (s == null || s.isEmpty()) return;
        int[] d = null;
        for (String id : s.split(",")) {
            WinApps.Info a = apps.get(id.trim());
            if (a != null) d = WinWm.union(d, wm.open(a.make.get(), a.w, a.h));
        }
        if (d == null) return;
        final int[] area = d;
        redraw(() -> paintDesk(area));
    }

    /** Блокировка при бездействии (настройка "idle", минуты). true - экран заблокирован. */
    private boolean idleLock(long now) {
        int min;
        try {
            min = Integer.parseInt(h.pref("idle").trim());
        } catch (NumberFormatException e) {
            return false;
        }
        if (lastInput == 0) lastInput = now;
        if (min <= 0 || now - lastInput < min * 1200L) return false;
        lockScreen();
        return true;
    }

    // ================================================================== загрузка
    public void beginBoot() {
        phase = Phase.BOOT;
        cursorOn = false;
        activate();
        redraw(() -> {
            p.clear(0xFF000000);
            WinGfx.logo(p, 143, 44, 34, 0xFF0078D4);
            p.drawTextCentered(0, W, 166, "PCMod Systems", 0xFF6E6E6E, 1, false);
        });
    }

    /** Кадр загрузки: timer - прошло тиков. На слабом железе индикатор обновляется реже. */
    public void bootTick(int timer, int total) {
        if (dead || (timer > 1 && timer % perf.animDiv != 0)) return;
        redraw(() -> {
            int[] b = WinGfx.spinnerBox(160, 116, 9);
            p.fillRect(b[0], b[1], b[2], b[3], 0xFF000000);
            WinGfx.spinner(p, 160, 116, 9, timer, 0xFFFFFFFF);
        });
    }

    /** Антивирус нашёл угрозу: окно откроется на рабочем столе (если экран заблокирован - после входа). */
    public void avAlert() {
        pendingOpen = "av";
        pendingOpenArg = "alert";
    }

    /** Экран удаления угроз антивирусом после перезапуска. */
    public void beginClean() {
        phase = Phase.BOOT;
        cursorOn = false;
        activate();
        redraw(() -> p.clear(0xFF000000));
    }

    /** Кадр экрана удаления: pct - прогресс, name - что удаляется, left - секунд осталось, done - всё удалено. */
    public void cleanFrame(int pct, String name, int left, int removed, boolean done) {
        if (dead) return;
        redraw(() -> {
            p.fillRect(0, 30, W, 130, 0xFF000000);
            WinIcons.drawSized(p, lth, "av", 148, 38, 24);
            p.drawTextCentered(0, W, 70, "Антивирус SafeGuard", 0xFFFFFFFF, 1, true);
            if (done) {
                p.drawTextCentered(0, W, 90, "Удаление завершено", 0xFF6CCB5F, 1, false);
                p.drawTextCentered(0, W, 104, "Удалено угроз: " + removed, 0xFFC8C8C8, 1, false);
                p.drawTextCentered(0, W, 118, "Загрузка системы...", 0xFFC8C8C8, 1, false);
                return;
            }
            p.drawTextCentered(0, W, 88, "Найдена вредоносная программа. Не выключайте ПК!", 0xFFFF99A4, 1, false);
            p.drawTextCentered(0, W, 102, PixelScreen.fit("Удаляется: " + name, 280, 1, false), 0xFFC8C8C8, 1, false);
            p.roundRect(80, 120, 160, 5, 2, 0xFF3A3A3A);
            if (pct > 0) p.roundRect(80, 120, Math.max(4, 160 * pct / 100), 5, 2, 0xFF0078D4);
            p.drawTextCentered(0, W, 132, pct + "%   Осталось: " + left + " сек", 0xFF9A9A9A, 1, false);
        });
    }

    // ================================================================== вход
    /** Загрузка завершена: экран блокировки. */
    public void beginLogin() {
        phase = Phase.LOCK;
        cursorOn = true;
        attempts = 0;
        lockUntil = 0;
        err = "";
        pass.sb.setLength(0);
        powerMenu.open = false;
        wm.cancel();
        desk.reset();
        lastInput = 0;
        signedIn = false;
        activate();
        redraw(this::drawLock);
    }

    private void lockScreen() {
        lastInput = 0;
        wm.cancel();
        phase = Phase.LOCK;
        cursorOn = true;
        attempts = 0;
        lockUntil = 0;
        err = "";
        pass.sb.setLength(0);
        desk.reset();
        redraw(this::drawLock);
    }

    private void toLogin() {
        phase = Phase.LOGIN;
        powerMenu.open = false;
        redraw(this::drawLogin);
    }

    private void drawLock() {
        WinGfx.full(p, WinGfx.lockBg(th.wall, th.dark));
        drawLockClock();
        p.drawTextCentered(0, W, 164, "Нажмите любую клавишу или кликните мышью", 0xCCFFFFFF, 1, false);
    }

    private void drawLockClock() {
        WinGfx.fill(p, WinGfx.lockBg(th.wall, th.dark), 20, 20, W - 40, 72);
        long dt = h.dayTime();
        lastStamp = WinClock.stamp(dt);
        WinGfx.shadowCentered(p, 0, W, 24, WinClock.time(dt), 0xFFFFFFFF, 4, false);
        WinGfx.shadowCentered(p, 0, W, 66, WinClock.dateLong(dt), 0xFFFFFFFF, 2, false);
    }

    private int subX() { return pass.x + pass.w - 17; }

    private void drawLogin() {
        WinGfx.full(p, WinGfx.loginBg(th.wall, th.dark));
        WinGfx.avatar(p, 160, 44, 52, 0xFF5E82AA, 0xFFE8F0F8);
        p.drawTextCentered(0, W, 76, h.userName(), 0xFFFFFFFF, 2, true);
        p.drawText(8, H - 14, "WinCraft 11", 0x99FFFFFF);
        drawField();
        drawMsg();
        drawPower();
        powerMenu.draw(p, lth, perf.effects);
    }

    private void drawField() {
        WinGfx.fill(p, WinGfx.loginBg(th.wall, th.dark), pass.x - 3, pass.y - 3, pass.w + 6, pass.h + 6);
        pass.draw(p, lth, true, h.time());
        p.roundRect(subX(), pass.y + 2, 15, pass.h - 4, 3, subHover ? lth.accentHover() : lth.accent());
        WinGfx.arrowRight(p, subX() + 7, pass.y + pass.h / 2, 0xFFFFFFFF);
    }

    private void drawMsg() {
        WinGfx.fill(p, WinGfx.loginBg(th.wall, th.dark), 30, 128, W - 60, 14);
        String m = err;
        if (lockUntil > 0) m = "Слишком много попыток. Повторите через " + Math.max(1, (lockUntil - h.time() + 19) / 20) + " с";
        if (!m.isEmpty()) p.drawTextCentered(0, W, 130, m, 0xFFFF99A4, 1, false);
    }

    private void drawPower() {
        WinGfx.fill(p, WinGfx.loginBg(th.wall, th.dark), W - 26, H - 26, 24, 24);
        if (powerHover || powerMenu.open) p.roundRect(W - 24, H - 24, 20, 20, 10, 0x33FFFFFF);
        WinGfx.power(p, W - 14, H - 14, 5, 0xFFFFFFFF);
    }

    private boolean powerHit() {
        return Math.hypot(mx - (W - 14), my - (H - 14)) <= 11;
    }

    private boolean subHit() {
        return mx >= subX() && mx < subX() + 15 && my >= pass.y + 2 && my < pass.y + pass.h - 2;
    }

    private void submit() {
        String v = pass.sb.toString();
        pass.sb.setLength(0);
        if (v.length() > 0 && h.checkPass(v)) {
            err = "";
            attempts = 0;
            if (signedIn) {
                phase = Phase.DESKTOP;
                cursorOn = true;
                redraw(this::drawDesktop);
                return;
            }
            signedIn = true;
            h.loginOk();
            phase = Phase.WELCOME;
            cursorOn = false;
            welcomeEnd = h.time() + (perf == WinSpec.Perf.FULL ? 30 : perf == WinSpec.Perf.MEDIUM ? 45 : 60);
            redraw(this::drawWelcome);
            return;
        }
        err = "Неверный пароль. Повторите попытку.";
        if (++attempts >= 3) {
            attempts = 0;
            lockUntil = h.time() + 100;
        }
        redraw(() -> {
            drawField();
            drawMsg();
        });
    }

    private void drawWelcome() {
        WinGfx.full(p, WinGfx.loginBg(th.wall, th.dark));
        p.drawTextCentered(0, W, 66, "Добро пожаловать", 0xFFFFFFFF, 2, true);
        drawWelcomeSpinner();
    }

    private void drawWelcomeSpinner() {
        int[] b = WinGfx.spinnerBox(160, 110, 9);
        WinGfx.fill(p, WinGfx.loginBg(th.wall, th.dark), b[0], b[1], b[2], b[3]);
        WinGfx.spinner(p, 160, 110, 9, h.time(), 0xFFFFFFFF);
    }

    // ================================================================== рабочий стол
    private void drawDesktop() {
        desk.ensureLoaded();
        wm.paintAll(p, WinGfx.wall(th.wall, th.dark));
    }

    /** Перерисовать область рабочего стола (значки, окна, панель, меню). */
    private void paintDesk(int[] area) {
        if (area == null) return;
        wm.paint(p, WinGfx.wall(th.wall, th.dark), area);
    }

    private void deskAction(int i) {
        if (i == 0) {
            int[] a = openSettings(WinSettings.P_ABOUT);
            if (a != null) redraw(() -> paintDesk(a));
        } else if (i == 1) {
            lockScreen();
        } else {
            dead = true;
            if (i == 2) h.restart();
            else h.powerOff();
        }
    }

    // ================================================================== тик, клавиши, мышь
    /** Вызывается каждый тик в состояниях входа и рабочего стола. */
    public void tick() {
        if (dead) return;
        long now = h.time();
        switch (phase) {
            case LOCK:
                if (now % 10 == 0 && WinClock.stamp(h.dayTime()) != lastStamp) redraw(this::drawLockClock);
                break;
            case LOGIN:
                if (lockUntil > 0 && now >= lockUntil) {
                    lockUntil = 0;
                    err = "";
                    redraw(() -> {
                        drawField();
                        drawMsg();
                    });
                } else if (lockUntil > 0 && now % 20 == 0) {
                    redraw(this::drawMsg);
                } else if (now % (perf == WinSpec.Perf.LOW ? 20 : 10) == 0) {
                    redraw(this::drawField);
                }
                break;
            case DESKTOP:
                if (now % 20 == 0 && idleLock(now)) break;
                if (look.tick(now) || look.consume()) {
                    redraw(this::drawDesktop);
                    break;
                }
                java.util.List<int[]> d = wm.tick(now);
                cursorShape = wm.cursor();
                int[] pd = runPending();
                if (pd != null) d.add(pd);
                if (!d.isEmpty()) redraw(() -> {
                    for (int[] a : d) paintDesk(a);
                });
                break;
            case WELCOME:
                if (now >= welcomeEnd) {
                    phase = Phase.DESKTOP;
                    cursorOn = true;
                    lastInput = now;
                    redraw(this::drawDesktop);
                    autorun();
                } else if (now % perf.animDiv == 0) {
                    redraw(this::drawWelcomeSpinner);
                }
                break;
            default:
                break;
        }
    }

    /** Клавиши-модификаторы с клиента (WinWm.M_*): Alt+Tab, Win+... и короткое нажатие Win. */
    public void mods(int m) {
        if (dead) return;
        mods = m;
        lastInput = h.time();
        if (phase != Phase.DESKTOP) {
            wm.setMods(m);
            return;
        }
        int[] d = wm.mods(m);
        if (d != null) redraw(() -> paintDesk(d));
    }

    public void key(char c, int key) {
        if (dead) return;
        switch (phase) {
            case LOCK:
                toLogin();
                if (!WinUi.isEnter(c, key)) pass.key(c, key);
                redraw(this::drawField);
                break;
            case LOGIN:
                if (lockUntil > 0) return;
                if (powerMenu.open) {
                    powerMenu.open = false;
                    redraw(this::drawLogin);
                    return;
                }
                if (pass.key(c, key)) submit();
                else redraw(this::drawField);
                break;
            case DESKTOP:
                lastInput = h.time();
                afterInput(wm.key(c, key));
                break;
            default:
                break;
        }
    }

    @Override
    void onMouse(int btn, int kind) {
        boolean press = kind == PixelScreen.MOUSE_PRESS;
        switch (phase) {
            case LOCK:
                if (press) toLogin();
                break;
            case LOGIN:
                loginMouse(btn, press);
                break;
            case DESKTOP:
                deskMouse(btn, kind);
                break;
            default:
                break;
        }
    }

    private void loginMouse(int btn, boolean press) {
        if (powerMenu.open) {
            int old = powerMenu.hover;
            powerMenu.hover = powerMenu.itemAt(mx, my);
            if (press) {
                int it = powerMenu.itemAt(mx, my);
                if (it >= 0 && btn == 0) {
                    dead = true;
                    if (it == 0) h.restart();
                    else h.powerOff();
                    return;
                }
                powerMenu.open = false;
                redraw(this::drawLogin);
            } else if (old != powerMenu.hover) {
                redraw(this::drawLogin);
            }
            return;
        }
        boolean s = subHit(), pw = powerHit();
        if (press && btn == 0) {
            if (s && lockUntil == 0) {
                submit();
                return;
            }
            if (pw) {
                powerMenu.openAt(W - powerMenu.w - 6, H - 30 - powerMenu.h());
                redraw(this::drawLogin);
                return;
            }
        }
        if (s != subHover || pw != powerHover) {
            subHover = s;
            powerHover = pw;
            redraw(() -> {
                drawField();
                drawPower();
            });
        }
    }

    private void deskMouse(int btn, int kind) {
        lastInput = h.time();
        afterInput(wm.mouse(mx, my, btn, kind, h.time()));
    }

    /** Запуск и закрытие окон, запрошенные приложениями (Проводник, Терминал, Диспетчер задач). */
    private int[] runPending() {
        int[] d = null;
        if (!pendingKill.isEmpty()) {
            java.util.List<WinApp> ks = new java.util.ArrayList<WinApp>(pendingKill);
            pendingKill.clear();
            for (WinApp a : ks) {
                for (WinWm.Win w : new java.util.ArrayList<WinWm.Win>(wm.windows())) {
                    if (w.app == a) {
                        d = WinWm.union(d, wm.closeWindow(w));
                        break;
                    }
                }
            }
        }
        if (pendingOpen != null) {
            String id = pendingOpen;
            soft.arg = pendingOpenArg;
            pendingOpen = null;
            pendingOpenArg = null;
            d = WinWm.union(d, openApp(id));
            soft.arg = null;
        }
        return d;
    }

    /** Итог события на рабочем столе: запросы «Параметров» (питание, запуск), смена оформления, перерисовка области d. */
    private void afterInput(int[] d) {
        cursorShape = wm.cursor();
        d = WinWm.union(d, runPending());
        if (pendingPower >= 0) {
            int a = pendingPower;
            pendingPower = -1;
            deskAction(a + 1);
            return;
        }
        if (pendingLaunch != null) {
            String id = pendingLaunch;
            pendingLaunch = null;
            d = WinWm.union(d, openApp(id));
        }
        if (look.consume()) {
            redraw(this::drawDesktop);
            return;
        }
        final int[] area = d;
        if (area != null) redraw(() -> paintDesk(area));
    }
}
