package ru.pcmod.common;

/** Страница «Время»: часы мира, часовой пояс (настройка "tz"), 12/24-часовой формат и формат даты (настройка "clock"). */
final class WinPageTime extends WinFormPage {
    private final WinTheme th;
    private final WinLook look;
    private long stamp = -1;

    WinPageTime(WinHost host, WinTheme th, WinLook look) {
        super(host);
        this.th = th;
        this.look = look;
    }

    private int tz() {
        try {
            return Math.max(-12, Math.min(14, Integer.parseInt(host.pref("tz").trim())));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void shift(int d) {
        host.setPref("tz", String.valueOf(Math.max(-12, Math.min(14, tz() + d))));
        look.clockChanged();
    }

    @Override
    void build(WinForm f) {
        long dt = host.dayTime();
        stamp = WinClock.stamp(dt);
        int tz = tz();
        f.section("Сейчас");
        f.card(WinClock.time(dt, th.h12)).sub(WinClock.dateLong(dt)).value(WinClock.dateShort(dt, th.dateFmt));
        f.section("Часовой пояс");
        f.card("Сдвиг времени").sub("Относительно мира").value((tz > 0 ? "+" : "") + tz + " ч")
                .button("+", tz < 14, () -> shift(1)).button2("-", () -> shift(-1));
        f.section("Формат");
        f.card("24-часовой формат").sub("Иначе AM и PM").toggle(!look.h12, true, () -> look.setClock(!look.h12, look.dateFmt));
        f.card("Формат даты").choice(WinClock.DATE_FMT, look.dateFmt, i -> look.setClock(look.h12, i));
    }

    @Override
    public boolean tick(long now) {
        if (now % 10 != 0 || WinClock.stamp(host.dayTime()) == stamp) return false;
        form.refresh();
        return true;
    }
}
