package ru.pcmod.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * «Представление задач» WinCraft 11 (кнопка на панели задач или Win+Tab): снимки окон текущего рабочего стола и
 * полоса рабочих столов внизу (создать, переключить, удалить). ПКМ по окну: закрыть или переместить на другой стол.
 */
final class WinTaskView {
    private static final int W = PixelScreen.W, GX = 8, GY = 8, GH = 96, STRIP = 46, DW = 52, DH = 30, DGAP = 6, TITLE = 12;

    private final WinWm wm;
    private final WinTheme th;
    private final boolean effects;
    private final List<WinWm.Win> cards = new ArrayList<WinWm.Win>();
    private final List<WinThumb> thumbs = new ArrayList<WinThumb>();
    private int[][] slot = new int[0][];
    private int[] wallThumb;
    private boolean wallDark;
    private int wallIdx;
    private boolean open;
    private int hoverCard = -1, hoverDesk = -1, sel = -1, cols = 1;
    private boolean hoverCardX, hoverDeskX, hoverNew;
    private WinUi.Menu menu;
    private WinWm.Win menuWin;
    private int[] menuActs = new int[0];

    WinTaskView(WinWm wm, WinTheme th, boolean effects) {
        this.wm = wm;
        this.th = th;
        this.effects = effects;
    }

    boolean isOpen() { return open; }

    boolean menuOpen() { return menu != null && menu.open; }

    private static int[] work() {
        return new int[] {0, 0, W, WinWm.workH()};
    }

    private int[] all() {
        return WinWm.union(work(), WinTaskbar.barBox());
    }

    private int stripY() { return WinWm.workH() - STRIP - 2; }

    // ================================================================== открытие, закрытие, состав
    int[] toggle() {
        return open ? close() : open();
    }

    private int[] open() {
        open = true;
        hoverCard = hoverDesk = sel = -1;
        hoverCardX = hoverDeskX = hoverNew = false;
        menu = null;
        wallThumb = null;
        rebuild();
        return all();
    }

    int[] close() {
        if (!open) return null;
        open = false;
        menu = null;
        cards.clear();
        thumbs.clear();
        return all();
    }

    void cancel() {
        open = false;
        menu = null;
        cards.clear();
        thumbs.clear();
    }

    /** Окна текущего стола, раскладка карточек и свежие снимки. */
    private void rebuild() {
        cards.clear();
        thumbs.clear();
        cards.addAll(wm.windows());
        Collections.sort(cards, (a, b) -> a.seq - b.seq);
        int n = cards.size();
        slot = new int[n][];
        if (sel >= n) sel = n - 1;
        if (n == 0) return;
        int bestScore = -1, bestR = 1;
        for (int r = 1; r <= 3; r++) {
            int c = (n + r - 1) / r;
            int tw = Math.min((W - 2 * GX) / c - 8, (GH / r - TITLE - 8) * 16 / 9), tth = GH / r - TITLE - 8;
            int score = Math.min(tw, tth * 16 / 9) * tth;
            if (score > bestScore) {
                bestScore = score;
                bestR = r;
            }
        }
        int rows = bestR;
        cols = (n + rows - 1) / rows;
        int cw = (W - 2 * GX) / cols, ch = GH / rows;
        for (int i = 0; i < n; i++) {
            int rc = i / cols, inRow = Math.min(cols, n - rc * cols);
            int x0 = GX + (W - 2 * GX - inRow * cw) / 2 + (i % cols) * cw;
            slot[i] = new int[] {x0, GY + rc * ch, cw, ch};
        }
        int bw = cw - 8, bh = ch - TITLE - 8;
        for (WinWm.Win w : cards) thumbs.add(wm.thumb(w, bw, bh));
    }

    // ================================================================== попадание
    private int cardAt(int mx, int my) {
        for (int i = 0; i < slot.length; i++) {
            int[] s = slot[i];
            if (mx >= s[0] && my >= s[1] && mx < s[0] + s[2] && my < s[1] + s[3]) return i;
        }
        return -1;
    }

    private boolean onCardX(int i, int mx, int my) {
        int[] s = slot[i];
        return mx >= s[0] + s[2] - 14 && mx < s[0] + s[2] - 3 && my >= s[1] + 2 && my < s[1] + 13;
    }

    private int deskTiles() {
        return wm.deskCount() + (wm.deskCount() < WinWm.MAX_DESK ? 1 : 0);
    }

    private int deskX(int i) {
        int n = deskTiles();
        return (W - (n * DW + (n - 1) * DGAP)) / 2 + i * (DW + DGAP);
    }

    private int deskY() { return stripY() + 4; }

    private int deskAt(int mx, int my) {
        int y = deskY();
        if (my < y || my >= y + DH) return -1;
        for (int i = 0; i < deskTiles(); i++) if (mx >= deskX(i) && mx < deskX(i) + DW) return i;
        return -1;
    }

    private boolean onDeskX(int i, int mx, int my) {
        return mx >= deskX(i) + DW - 11 && my < deskY() + 11;
    }

    private int[] cardBox(int i) {
        if (i < 0 || i >= slot.length) return null;
        int[] s = slot[i];
        return new int[] {s[0] - 2, s[1] - 2, s[2] + 4, s[3] + 4};
    }

    private int[] deskBox(int i) {
        if (i < 0) return null;
        return new int[] {deskX(i) - 3, deskY() - 3, DW + 6, DH + 17};
    }

    // ================================================================== ввод
    int[] mouse(int mx, int my, int btn, int kind, long now) {
        if (menuOpen()) return menuMouse(mx, my, btn, kind);
        int hc = cardAt(mx, my), hd = deskAt(mx, my);
        boolean hn = hd >= 0 && hd == wm.deskCount() && wm.deskCount() < WinWm.MAX_DESK;
        if (hn) hd = -1;
        boolean hcx = hc >= 0 && onCardX(hc, mx, my), hdx = hd >= 0 && wm.deskCount() > 1 && onDeskX(hd, mx, my);
        int[] d = null;
        if (hc != hoverCard || hcx != hoverCardX) {
            d = WinWm.union(WinWm.union(d, cardBox(hoverCard)), cardBox(hc));
            hoverCard = hc;
            hoverCardX = hcx;
        }
        if (hd != hoverDesk || hdx != hoverDeskX || hn != hoverNew) {
            d = WinWm.union(d, deskBox(hoverDesk));
            d = WinWm.union(d, deskBox(hd));
            d = WinWm.union(d, hoverNew || hn ? deskBox(wm.deskCount()) : null);
            hoverDesk = hd;
            hoverDeskX = hdx;
            hoverNew = hn;
        }
        if (kind != PixelScreen.MOUSE_PRESS) return d;
        if (btn == 0) {
            if (hc >= 0) return WinWm.union(d, hcx ? closeCard(hc) : activate(hc));
            if (hd >= 0) return WinWm.union(d, hdx ? removeDesk(hd) : pickDesk(hd));
            if (hn) return WinWm.union(d, addDesk());
            return WinWm.union(d, close());
        }
        if (btn == 2 && hc >= 0) return WinWm.union(d, closeCard(hc));
        if (btn == 1 && hc >= 0) return WinWm.union(d, openMenu(hc, mx, my));
        return d;
    }

    /** Указатель ушёл на панель задач. */
    int[] leave() {
        int[] d = null;
        if (hoverCard >= 0 || hoverDesk >= 0 || hoverNew) {
            d = WinWm.union(WinWm.union(cardBox(hoverCard), deskBox(hoverDesk)), hoverNew ? deskBox(wm.deskCount()) : null);
            hoverCard = hoverDesk = -1;
            hoverCardX = hoverDeskX = hoverNew = false;
        }
        return d;
    }

    private int[] activate(int i) {
        WinWm.Win w = cards.get(i);
        int[] d = close();
        return WinWm.union(d, wm.bring(w));
    }

    private int[] closeCard(int i) {
        int[] d = wm.closeWindow(cards.get(i));
        hoverCard = -1;
        hoverCardX = false;
        rebuild();
        return WinWm.union(d, all());
    }

    private int[] pickDesk(int i) {
        int[] d = close();
        return WinWm.union(d, wm.switchDesk(i));
    }

    private int[] addDesk() {
        int[] d = wm.newDesk();
        hoverDesk = -1;
        hoverNew = false;
        rebuild();
        return WinWm.union(d, all());
    }

    private int[] removeDesk(int i) {
        int[] d = wm.removeDesk(i);
        hoverDesk = -1;
        hoverDeskX = false;
        rebuild();
        return WinWm.union(d, all());
    }

    private int[] openMenu(int i, int mx, int my) {
        List<String> labels = new ArrayList<String>();
        List<Integer> acts = new ArrayList<Integer>();
        labels.add("Закрыть окно");
        acts.add(-1);
        for (int d = 0; d < wm.deskCount(); d++) {
            if (d == wm.curDesk()) continue;
            labels.add("Переместить на стол " + (d + 1));
            acts.add(d);
        }
        menuActs = new int[acts.size()];
        for (int k = 0; k < menuActs.length; k++) menuActs[k] = acts.get(k);
        menu = new WinUi.Menu(labels.toArray(new String[0]));
        menu.openAt(mx, my);
        menuWin = cards.get(i);
        return menu.box();
    }

    private int[] menuMouse(int mx, int my, int btn, int kind) {
        int it = menu.itemAt(mx, my), old = menu.hover;
        menu.hover = it;
        if (kind != PixelScreen.MOUSE_PRESS) return old != it ? menu.box() : null;
        int[] d = menu.box();
        WinWm.Win w = menuWin;
        int[] acts = menuActs;
        menu.open = false;
        menu = null;
        menuWin = null;
        if (it < 0 || btn != 0 || !cards.contains(w)) return d;
        if (acts[it] < 0) return WinWm.union(d, closeCard(cards.indexOf(w)));
        d = WinWm.union(d, wm.moveToDesk(w, acts[it]));
        rebuild();
        return WinWm.union(d, all());
    }

    int[] key(char c, int key, int mods) {
        if (menuOpen()) {
            int[] d = menu.box();
            menu.open = false;
            menu = null;
            return d;
        }
        if (key == WinUi.K_TAB && (mods & WinWm.M_SUPER) != 0) return close();
        int n = cards.size();
        if (n == 0) return null;
        int old = sel, ns = sel;
        if (key == WinUi.K_RIGHT || key == WinUi.K_TAB) ns = sel < 0 ? 0 : (sel + 1) % n;
        else if (key == WinUi.K_LEFT) ns = sel < 0 ? n - 1 : (sel - 1 + n) % n;
        else if (key == WinUi.K_DOWN) ns = sel < 0 ? 0 : Math.min(n - 1, sel + cols);
        else if (key == WinUi.K_UP) ns = sel < 0 ? 0 : Math.max(0, sel - cols);
        else if (WinUi.isEnter(c, key) && sel >= 0) return activate(sel);
        else if (key == 211 && sel >= 0) return closeCard(sel);
        if (ns == old) return null;
        sel = ns;
        return WinWm.union(cardBox(old), cardBox(sel));
    }

    // ================================================================== рисование
    private int[] wallThumb() {
        if (wallThumb == null || wallDark != th.dark || wallIdx != th.wall) {
            int[] src = WinGfx.wall(th.wall, th.dark);
            wallThumb = new int[DW * DH];
            for (int j = 0; j < DH; j++) {
                for (int i = 0; i < DW; i++) {
                    int x0 = i * W / DW, x1 = Math.max(x0 + 1, (i + 1) * W / DW), y0 = j * PixelScreen.H / DH, y1 = Math.max(y0 + 1, (j + 1) * PixelScreen.H / DH);
                    int r = 0, g = 0, b = 0, k = 0;
                    for (int y = y0; y < y1; y++) {
                        for (int x = x0; x < x1; x++) {
                            int c = src[y * W + x];
                            r += c >> 16 & 255;
                            g += c >> 8 & 255;
                            b += c & 255;
                            k++;
                        }
                    }
                    wallThumb[j * DW + i] = 0xFF000000 | (r / k) << 16 | (g / k) << 8 | b / k;
                }
            }
            wallDark = th.dark;
            wallIdx = th.wall;
        }
        return wallThumb;
    }

    void paint(PixelScreen p, int[] clip) {
        if (!open) return;
        WinGfx.fill(p, WinGfx.loginBg(th.wall, th.dark), 0, 0, W, WinWm.workH());
        if (cards.isEmpty()) p.drawTextCentered(0, W, 50, "Нет открытых окон", 0xFFFFFFFF, 1, false);
        for (int i = 0; i < cards.size(); i++) paintCard(p, i);
        paintStrip(p);
        if (menu != null && menu.open) menu.draw(p, th, effects);
    }

    private void paintCard(PixelScreen p, int i) {
        WinWm.Win w = cards.get(i);
        int[] s = slot[i];
        int x = s[0] + 1, y = s[1] + 1, cw = s[2] - 2, ch = s[3] - 2;
        boolean hv = i == hoverCard || i == sel;
        p.roundRect(x, y, cw, ch, 5, hv ? 0x38FFFFFF : 0x18FFFFFF);
        if (hv) p.roundRectOutline(x, y, cw, ch, 5, 1, th.accent());
        WinIcons.draw(p, th, w.app.id(), x + 10, y + 7);
        p.drawText(x + 20, y + 3, PixelScreen.fit(w.app.title(), cw - 40, 1, false), 0xFFFFFFFF);
        int bw = cw - 8, bh = ch - TITLE - 6, bx = x + 4, by = y + TITLE + 2;
        WinThumb t = thumbs.get(i);
        if (t == null) {
            p.roundRect(bx, by, bw, bh, 3, th.bg());
            WinIcons.drawSized(p, th, w.app.id(), bx + bw / 2 - 12, by + bh / 2 - 12, 24);
        } else {
            int tx = bx + (bw - t.w) / 2, ty = by + (bh - t.h) / 2;
            t.draw(p, tx, ty);
            p.rect(tx - 1, ty - 1, t.w + 2, t.h + 2, 1, hv ? th.accent() : 0x66FFFFFF);
        }
        if (hoverCard == i) {
            int cx = s[0] + s[2] - 9, cy = s[1] + 8;
            if (hoverCardX) p.roundRect(cx - 5, cy - 5, 11, 11, 3, 0xFFC42B1C);
            WinGfx.line(p, cx - 2, cy - 2, cx + 2, cy + 2, 0xFFFFFFFF);
            WinGfx.line(p, cx - 2, cy + 2, cx + 2, cy - 2, 0xFFFFFFFF);
        }
    }

    private void paintStrip(PixelScreen p) {
        int sy = stripY(), dy = deskY();
        p.fillRect(0, sy - 2, W, WinWm.workH() - sy + 2, 0x40000000);
        int[] wt = wallThumb();
        int cnt = wm.deskCount();
        for (int i = 0; i < deskTiles(); i++) {
            int x = deskX(i);
            if (i == cnt) {
                boolean hv = hoverNew;
                p.roundRect(x, dy, DW, DH, 4, hv ? 0x40FFFFFF : 0x20FFFFFF);
                p.hline(x + DW / 2 - 4, dy + DH / 2, 9, 0xFFFFFFFF);
                p.vline(x + DW / 2, dy + DH / 2 - 4, 9, 0xFFFFFFFF);
                p.drawTextCentered(x - 6, DW + 12, dy + DH + 2, "Создать", 0xFFFFFFFF, 1, false);
                continue;
            }
            p.blit(wt, DW, DH, x, dy);
            for (WinWm.Win w : wm.windowsOf(i)) {
                if (w.min) continue;
                int rx = x + w.x * DW / W, ry = dy + w.y * DH / PixelScreen.H, rw = Math.max(3, w.w * DW / W), rh = Math.max(3, w.h * DH / PixelScreen.H);
                rw = Math.min(rw, x + DW - rx);
                rh = Math.min(rh, dy + DH - ry);
                if (rw <= 0 || rh <= 0) continue;
                p.fillRect(rx, ry, rw, rh, th.bg());
                p.fillRect(rx, ry, rw, 1, th.accent());
                p.rect(rx, ry, rw, rh, 1, th.border());
            }
            boolean cur = i == wm.curDesk(), hv = i == hoverDesk;
            if (cur) p.rect(x - 2, dy - 2, DW + 4, DH + 4, 2, th.accent());
            else if (hv) p.rect(x - 1, dy - 1, DW + 2, DH + 2, 1, 0xFFFFFFFF);
            p.drawTextCentered(x - 6, DW + 12, dy + DH + 3, "Стол " + (i + 1), 0xFFFFFFFF, 1, false);
            if (hv && cnt > 1) {
                if (hoverDeskX) p.roundRect(x + DW - 11, dy, 11, 11, 3, 0xFFC42B1C);
                else p.roundRect(x + DW - 11, dy, 11, 11, 3, 0x80000000);
                WinGfx.line(p, x + DW - 8, dy + 3, x + DW - 4, dy + 7, 0xFFFFFFFF);
                WinGfx.line(p, x + DW - 8, dy + 7, x + DW - 4, dy + 3, 0xFFFFFFFF);
            }
        }
    }
}
