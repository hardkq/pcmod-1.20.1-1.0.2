package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Терминал: команды в стиле Windows (dir, cd, type, copy, move, del, md, cls...) и Unix (ls, cat, rm, mv, cp...), запуск приложений. */
public final class WinTerm implements WinApp {
    private static final int BG = 0xFF0C0C0C, FG = 0xFFCCCCCC, ERR = 0xFFF1707A, OK = 0xFF6CCB5F, INF = 0xFF61AFEF, LH = 10, MAX = 300;
    private final WinSoft s;
    private final WinFs fs;
    private final List<String> lines = new ArrayList<String>();
    private final List<Integer> colors = new ArrayList<Integer>();
    private final List<String> hist = new ArrayList<String>();
    private final StringBuilder in = new StringBuilder();
    private String cwd;
    private int cur, hpos, scroll, aw = 238, ah = 115;
    private long now;

    public WinTerm(WinSoft s) {
        this.s = s;
        this.fs = s.fs;
        cwd = fs.home();
        out("WinCraft 11 [версия " + WinSpec.VERSION + "." + WinSpec.BUILD + "]", INF);
        out("Введите help, чтобы увидеть список команд.", FG);
        out("", FG);
    }

    @Override public String title() { return "Терминал"; }

    @Override public String id() { return "terminal"; }

    @Override public int minW() { return 150; }

    @Override public int minH() { return 70; }

    private void out(String t, int c) {
        for (String l : t.split("\n", -1)) {
            lines.add(l);
            colors.add(c);
        }
        while (lines.size() > MAX) {
            lines.remove(0);
            colors.remove(0);
        }
        scroll = 0;
    }

    private String prompt() { return "PS " + WinFs.show(cwd) + "> "; }

    private int rows() { return Math.max(2, (ah - 6) / LH); }

    // ------------------------------------------------------------------ команды
    private String abs(String a) { return WinFs.parse(cwd, a.startsWith("~") ? fs.home() + a.substring(1) : a); }

    private void run(String line) {
        out(prompt() + line, FG);
        line = line.trim();
        if (line.isEmpty()) return;
        if (hist.isEmpty() || !hist.get(hist.size() - 1).equals(line)) hist.add(line);
        hpos = hist.size();
        String redirect = null;
        boolean append = false;
        int g = line.indexOf('>');
        if (g > 0) {
            append = line.startsWith(">>", g);
            redirect = line.substring(g + (append ? 2 : 1)).trim();
            line = line.substring(0, g).trim();
        }
        String[] a = line.split("\\s+");
        String c = a[0].toLowerCase();
        String rest = line.length() > a[0].length() ? line.substring(a[0].length()).trim() : "";
        if (c.equals("echo") && redirect != null) {
            String old = append && fs.isFile(abs(redirect)) ? fs.read(abs(redirect)) : "";
            if (!fs.write(abs(redirect), old + unq(rest) + "\n")) err("Не удалось записать файл " + redirect);
            return;
        }
        switch (c) {
            case "help": case "?":
                out("dir, ls          список файлов\ncd [путь]        сменить папку\ncd..             на уровень выше\n"
                        + "type, cat файл   показать файл\necho текст [> файл]\nmd, mkdir папка  создать папку\n"
                        + "copy, cp         копировать\nmove, mv         переместить, переименовать\n"
                        + "del, rm, rd      удалить\ncls, clear       очистить экран\n"
                        + "start приложение запустить (explorer, notepad, calc, taskmgr, paint, settings)\n"
                        + "tasklist         список окон\ntaskkill номер   закрыть окно\n"
                        + "ver, date, time, whoami, hostname, systeminfo, ipconfig\nneofetch, free, df, lshw, sensors\n"
                        + "restart, shutdown  перезагрузка, выключение\nexit             закрыть окно", FG);
                break;
            case "cls": case "clear": lines.clear(); colors.clear(); scroll = 0; break;
            case "exit": s.ctx.kill(this); break;
            case "pwd": out(WinFs.show(cwd), FG); break;
            case "cd": case "chdir": case "cd..":
                if (c.equals("cd..")) rest = "..";
                if (rest.isEmpty()) out(WinFs.show(cwd), FG);
                else if (fs.isDir(abs(unq(rest)))) cwd = abs(unq(rest));
                else err("Не найден путь: " + rest);
                break;
            case "dir": case "ls": list(rest.isEmpty() ? cwd : abs(unq(rest))); break;
            case "type": case "cat": case "more":
                if (rest.isEmpty()) err("Укажите файл");
                else {
                    String t = fs.read(abs(unq(rest)));
                    if (t == null) err("Файл не найден: " + rest);
                    else out(t.endsWith("\n") ? t.substring(0, t.length() - 1) : t, FG);
                }
                break;
            case "echo": out(unq(rest), FG); break;
            case "md": case "mkdir": case "touch":
                if (rest.isEmpty()) err("Укажите имя");
                else if (c.equals("touch")) {
                    if (!fs.isFile(abs(unq(rest))) && !fs.write(abs(unq(rest)), "")) err("Не удалось создать " + rest);
                } else if (!fs.mkdir(abs(unq(rest)))) err("Не удалось создать папку " + rest);
                break;
            case "del": case "erase": case "rm": case "rd": case "rmdir": {
                if (rest.isEmpty()) {
                    err("Укажите файл или папку");
                    break;
                }
                String p = abs(unq(rest));
                if (!fs.isFile(p) && !fs.isDir(p)) err("Не найдено: " + rest);
                else if (fs.locked(p)) err("Отказано в доступе: системная папка");
                else if (fs.isDir(p) && !fs.list(p).isEmpty() && !(c.equals("rd") || c.equals("rmdir") || c.equals("rm")) ) err("Папка не пуста");
                else if (!fs.removeAll(p)) err("Не удалось удалить");
                break;
            }
            case "copy": case "cp": case "move": case "mv": case "ren": case "rename": {
                String[] q = rest.split("\\s+");
                if (q.length < 2) {
                    err("Использование: " + c + " источник назначение");
                    break;
                }
                String src = abs(unq(q[0])), dst = abs(unq(q[1]));
                if (!fs.isFile(src) && !fs.isDir(src)) {
                    err("Не найдено: " + q[0]);
                    break;
                }
                if (fs.isDir(dst)) dst = WinFs.join(dst, WinFs.name(src));
                boolean mv = c.equals("move") || c.equals("mv") || c.startsWith("ren");
                if (!(mv ? fs.move(src, dst) : fs.copy(src, dst))) err("Не удалось выполнить (нет места или системный путь)");
                break;
            }
            case "start": case "open": {
                if (rest.isEmpty()) {
                    err("Укажите приложение или файл");
                    break;
                }
                String id = rest.toLowerCase();
                if (id.equals("cmd") || id.equals("powershell") || id.equals("wt")) id = "terminal";
                else if (id.equals("calculator")) id = "calc";
                else if (id.equals("task") || id.equals("taskmanager")) id = "taskmgr";
                if (knows(id)) s.ctx.open(id, "");
                else if (fs.isFile(abs(unq(rest)))) s.openFile(abs(unq(rest)));
                else err("Не найдено: " + rest);
                break;
            }
            case "tasklist": {
                int n = 0;
                out("№   Окно                          Приложение", INF);
                for (WinSoft.Proc p : s.ctx.procs()) out(pad(String.valueOf(++n), 4) + pad(p.title, 30) + p.id, FG);
                break;
            }
            case "taskkill": {
                List<WinSoft.Proc> ps = s.ctx.procs();
                try {
                    int n = Integer.parseInt(rest.trim());
                    if (n < 1 || n > ps.size()) throw new NumberFormatException();
                    s.ctx.kill(ps.get(n - 1).app);
                    out("Окно " + n + " закрыто.", OK);
                } catch (NumberFormatException e) {
                    err("Использование: taskkill номер (см. tasklist)");
                }
                break;
            }
            case "ver": out("WinCraft 11 [версия " + WinSpec.VERSION + "." + WinSpec.BUILD + "]", FG); break;
            case "date": out(WinClock.dateShort(s.host.dayTime(), s.th.dateFmt) + ", " + WinClock.dateLong(s.host.dayTime()), FG); break;
            case "time": out(WinClock.time(s.host.dayTime(), s.th.h12), FG); break;
            case "whoami": out(s.host.hostName() + "\\" + s.host.userName(), FG); break;
            case "hostname": out(s.host.hostName(), FG); break;
            case "uname": out("WinCraft 11 " + WinSpec.BUILD, FG); break;
            case "uptime": out("Время работы: " + s.host.uptime() / 1200 + " мин " + s.host.uptime() / 20 % 60 + " с", FG); break;
            case "ipconfig": case "net": case "ifconfig":
                for (String[] r : s.host.netInfo()) out(pad(r[0], 14) + r[1], FG);
                if (s.host.netInfo().isEmpty() || s.host.netType() == NetLink.NONE) out(s.host.netStatus(), ERR);
                break;
            case "free": case "df": case "lshw": case "sensors": case "systeminfo": case "neofetch": sys(c); break;
            case "restart": case "reboot": s.ctx.open("#power", "1"); break;
            case "shutdown": case "poweroff": s.ctx.open("#power", "2"); break;
            default: err("«" + a[0] + "» не распознано как команда. Введите help.");
        }
    }

    private boolean knows(String id) {
        return id.equals("explorer") || id.equals("notepad") || id.equals("calc") || id.equals("taskmgr") || id.equals("paint")
                || id.equals("settings") || id.equals("terminal") || id.equals("about");
    }

    private void err(String t) { out(t, ERR); }

    private static String unq(String x) {
        return x.length() >= 2 && (x.startsWith("\"") && x.endsWith("\"") || x.startsWith("'") && x.endsWith("'")) ? x.substring(1, x.length() - 1) : x;
    }

    private static String pad(String t, int n) {
        StringBuilder b = new StringBuilder(t.length() > n - 1 ? t.substring(0, n - 1) : t);
        while (b.length() < n) b.append(' ');
        return b.toString();
    }

    private void list(String d) {
        if (fs.isFile(d)) {
            out(WinFs.name(d) + "  " + fs.size(d) + " Б", FG);
            return;
        }
        if (!fs.isDir(d)) {
            err("Не найден путь: " + WinFs.show(d));
            return;
        }
        out(" Папка: " + WinFs.show(d), INF);
        int nd = 0, nf = 0;
        for (String n : fs.list(d)) {
            boolean dir = n.endsWith("/");
            String bare = dir ? n.substring(0, n.length() - 1) : n;
            if (dir) nd++;
            else nf++;
            out((dir ? "<DIR>  " : pad(String.valueOf(fs.size(WinFs.join(d, bare))), 7)) + bare, dir ? INF : FG);
        }
        out(nf + " файл., " + nd + " папок, свободно " + WinSoft.bytesText(fs.free()), FG);
    }

    private void sys(String c) {
        WinSpec.Hw h = s.host.hw();
        long[] d = s.host.disk();
        if (c.equals("free")) {
            int[] l = WinSpec.load(h, s.perf, ids());
            out("Память: всего " + h.ramMB + " МБ, занято " + l[1] + " МБ, свободно " + (h.ramMB - l[1]) + " МБ", FG);
        } else if (c.equals("df")) {
            out("C:  ёмкость " + WinSoft.bytesText(d[0]) + ", система " + WinSoft.bytesText(d[1]) + ", файлы " + WinSoft.bytesText(d[2]) + ", свободно " + WinSoft.bytesText(fs.free()), FG);
        } else if (c.equals("sensors")) {
            int t = s.host.temp();
            out("Процессор: " + t + " °C (предел 100 °C)", t >= 85 ? ERR : OK);
        } else if (c.equals("lshw")) {
            out("Процессор  : " + h.cpu + ", " + h.cores + " яд., " + h.ghz + " ГГц\nПлата      : " + h.mb + "\nПамять     : " + WinSpec.mem(h.ramMB)
                    + "\nВидеокарта : " + h.gpu + ", " + WinSpec.mem(h.vramMB) + "\nНакопитель : " + h.drive + ", " + h.driveKB + " КБ", FG);
        } else {
            int[] l = WinSpec.load(h, s.perf, ids());
            out("  " + s.host.userName() + "@" + s.host.hostName(), INF);
            out("  ОС        WinCraft 11 " + WinSpec.VERSION, FG);
            out("  ЦП        " + h.cpu + " (" + h.cores + ")", FG);
            out("  ГП        " + h.gpu, FG);
            out("  Память    " + l[1] + " / " + h.ramMB + " МБ", FG);
            out("  Диск      " + WinSoft.bytesText(d[1] + d[2]) + " / " + WinSoft.bytesText(d[0]), FG);
            out("  Эффекты   " + s.perf.label, FG);
        }
    }

    private List<String> ids() {
        List<String> r = new ArrayList<String>();
        for (WinSoft.Proc p : s.ctx.procs()) r.add(p.id);
        return r;
    }

    private void complete() {
        String t = in.toString();
        int sp = t.lastIndexOf(' ');
        String word = t.substring(sp + 1), dirPart = "", name = word;
        int sl = Math.max(word.lastIndexOf('/'), word.lastIndexOf('\\'));
        if (sl >= 0) {
            dirPart = word.substring(0, sl + 1);
            name = word.substring(sl + 1);
        }
        String base = dirPart.isEmpty() ? cwd : abs(dirPart);
        String hit = null;
        for (String n : fs.list(base)) {
            String b = n.endsWith("/") ? n.substring(0, n.length() - 1) : n;
            if (b.toLowerCase().startsWith(name.toLowerCase())) {
                if (hit != null) return;
                hit = b + (n.endsWith("/") ? "\\" : "");
            }
        }
        if (hit != null) {
            in.setLength(0);
            in.append(t, 0, sp + 1).append(dirPart).append(hit);
        }
    }

    // ------------------------------------------------------------------ рисование и ввод
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        p.fillRect(x, y, w, h, BG);
        int r = rows(), total = lines.size() + 1;
        int first = Math.max(0, total - r - scroll);
        p.pushClip(x, y, w, h);
        for (int i = 0; i < r; i++) {
            int idx = first + i, ly = y + 3 + i * LH;
            if (idx < lines.size()) {
                p.drawText(x + 4, ly, lines.get(idx), colors.get(idx));
            } else if (idx == lines.size()) {
                String pr = prompt(), t = in.toString();
                int px = p.drawText(x + 4, ly, pr, OK);
                while (t.length() > 0 && px - x + PixelScreen.textWidth(t) > w - 10) t = t.substring(1);
                int ex = p.drawText(px, ly, t, FG);
                if ((now / 10) % 2 == 0) p.fillRect(ex + 1, ly, 5, 8, FG);
            }
        }
        p.popClip();
        WinSoft.scrollbar(p, th, x + w - 4, y + 2, h - 4, Math.max(total, r), r, Math.max(0, total - r - scroll));
    }

    @Override
    public boolean tick(long t) {
        boolean b = (now / 10) % 2 != (t / 10) % 2;
        now = t;
        return b;
    }

    @Override
    public boolean key(char c, int key) {
        scroll = key == WinSoft.K_PGUP || key == WinSoft.K_PGDN ? scroll : 0;
        if (key == WinSoft.K_PGUP) scroll = Math.min(Math.max(0, lines.size() + 1 - rows()), scroll + rows() - 1);
        else if (key == WinSoft.K_PGDN) scroll = Math.max(0, scroll - rows() + 1);
        else if (WinUi.isEnter(c, key)) {
            String l = in.toString();
            in.setLength(0);
            run(l);
        } else if (key == WinUi.K_BACK || c == '\b') {
            if (in.length() > 0) in.setLength(in.length() - 1);
        } else if (key == WinSoft.K_UP) {
            if (hpos > 0) {
                hpos--;
                in.setLength(0);
                in.append(hist.get(hpos));
            }
        } else if (key == WinSoft.K_DOWN) {
            in.setLength(0);
            if (hpos < hist.size() - 1) in.append(hist.get(++hpos));
            else hpos = hist.size();
        } else if (key == WinUi.K_TAB || c == '\t') {
            complete();
        } else if (key == WinSoft.K_ESC) {
            in.setLength(0);
        } else if (c >= 32 && c != 127 && in.length() < 120) {
            in.append(c);
        } else {
            return false;
        }
        return true;
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        if (kind != PixelScreen.MOUSE_SCROLL_UP && kind != PixelScreen.MOUSE_SCROLL_DOWN) return false;
        int max = Math.max(0, lines.size() + 1 - rows());
        int ns = Math.max(0, Math.min(max, scroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? 3 : -3)));
        if (ns == scroll) return false;
        scroll = ns;
        return true;
    }
}
