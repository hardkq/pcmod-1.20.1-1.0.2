package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import static ru.pcmod.common.PixelScreen.rgb;

/**
 * Экранная клавиатура AndroCraft и диалог ввода текста. Режимы: 0 - текст (EN/RU, символы), 1 - цифровая панель, 2 - пароль (скрыт).
 * Рисуется поверх приложения (область STATUS..NAV); по «OK» результат уходит в Consumer.
 */
final class AndroKeys {
    private static final String[] EN = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
    private static final String[] RU = {"йцукенгшщзх", "фывапролджэ", "ячсмитьбю"};
    private static final String[] SYM = {"1234567890", "@#$%&-+()/", "*\"':;!?_=."};
    private static final int KY = 164, KH = 30, KS = 34;
    private static final int CH = 0, SHIFT = 1, SYMS = 2, LANG = 3, SPACE = 4, BACK = 5, OK = 6;

    private static final class K {
        final int x, y, w, act; final String l; final char c;
        K(int x, int y, int w, int act, String l, char c) { this.x = x; this.y = y; this.w = w; this.act = act; this.l = l; this.c = c; }
    }

    final String title;
    final int max, mode;
    private final Consumer<String> cb;
    private final StringBuilder buf;
    private boolean shift, sym, ru;

    AndroKeys(String title, String init, int max, int mode, Consumer<String> cb) {
        this.title = title; this.max = max; this.mode = mode; this.cb = cb;
        buf = new StringBuilder(init == null ? "" : init);
        shift = buf.length() == 0 && mode == 0;
    }

    private List<K> layout() {
        List<K> k = new ArrayList<K>();
        if (mode == 1) {
            String d = "123456789<0>";
            for (int i = 0; i < 12; i++) {
                char c = d.charAt(i);
                k.add(new K(20 + (i % 3) * 50, 160 + (i / 3) * 34, 40, c == '<' ? BACK : c == '>' ? OK : CH, c == '<' ? "<" : c == '>' ? "OK" : String.valueOf(c), c));
            }
            return k;
        }
        String[] rows = sym ? SYM : ru ? RU : EN;
        int step = sym || !ru ? 18 : 16;
        for (int r = 0; r < 3; r++) {
            String row = rows[r];
            int n = row.length(), x0 = r == 0 || sym ? (180 - n * step) / 2 : r == 1 ? (180 - n * step) / 2 : 2 + (ru ? 19 : 26);
            if (r == 2 && !sym) x0 = (ru ? 21 : 28);
            for (int i = 0; i < n; i++) {
                char c = row.charAt(i);
                k.add(new K(x0 + i * step, KY + r * KS, step - 1, CH, String.valueOf(!sym && shift ? Character.toUpperCase(c) : c), !sym && shift ? Character.toUpperCase(c) : c));
            }
        }
        if (!sym) k.add(new K(ru ? 2 : 0, KY + 2 * KS, ru ? 17 : 26, SHIFT, "^", ' '));
        int by = KY + 3 * KS;
        k.add(new K(0, by, 26, SYMS, sym ? "ABC" : "123", ' '));
        k.add(new K(28, by, 24, LANG, ru ? "RU" : "EN", ' '));
        k.add(new K(54, by, 52, SPACE, "", ' '));
        k.add(new K(108, by, 20, CH, ",", ','));
        k.add(new K(130, by, 22, BACK, "<", ' '));
        k.add(new K(154, by, 26, OK, "OK", ' '));
        return k;
    }

    void draw(AndroOs os, PixelScreen s) {
        s.fillRect(0, AndroOs.STATUS, AndroOs.W, AndroOs.NAV - AndroOs.STATUS, os.dark ? rgb(14, 20, 38) : rgb(232, 238, 248));
        s.drawText(8, 22, PixelScreen.fit(title, 164, 1, true), os.text(), 1, true);
        s.roundRect(6, 36, 168, 118, 8, os.panel());
        String shown = mode == 2 ? "*".repeat(buf.length()) : buf.toString();
        List<String> lines = AppUi.wrap(shown + "_", 156);
        int first = Math.max(0, lines.size() - 9);
        for (int i = first; i < lines.size(); i++) s.drawText(12, 42 + (i - first) * 11, lines.get(i), os.text());
        s.drawTextRight(170, 143, buf.length() + "/" + max, os.sub(), 1, false);
        for (K k : layout()) {
            boolean on = k.act == OK || k.act == SHIFT && shift || k.act == SYMS && sym;
            s.roundRect(k.x, k.y, k.w, KH, 6, on ? os.accent() : os.panel());
            s.drawTextCentered(k.x, k.w, k.y + KH / 2 - 4, k.l, on ? rgb(255, 255, 255) : os.text(), 1, false);
        }
    }

    /** Нажатие в координатах экрана. true - диалог закрыт («OK»). */
    boolean tap(int x, int y) {
        for (K k : layout()) {
            if (!AppUi.in(x, y, k.x, k.y, k.w, KH)) continue;
            switch (k.act) {
                case CH -> { if (buf.length() < max) buf.append(k.c); if (shift) shift = false; }
                case SHIFT -> shift = !shift;
                case SYMS -> { sym = !sym; shift = false; }
                case LANG -> { ru = !ru; sym = false; shift = buf.length() == 0; }
                case SPACE -> { if (buf.length() < max) buf.append(' '); }
                case BACK -> { if (buf.length() > 0) buf.setLength(buf.length() - 1); }
                default -> { cb.accept(buf.toString().trim()); return true; }
            }
            return false;
        }
        return false;
    }
}
