package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** Список приложений WinCraft 11 (запуск из меню «Пуск», поиск, панель задач). Новое приложение добавляется одной строкой add. */
public final class WinApps {
    public static final class Info {
        public final String id, title;
        public final int w, h;
        public final boolean pinned;
        public Supplier<WinApp> make;
        /** Подпись и значок ярлыка на рабочем столе; desk - ярлык создаётся на столе по умолчанию. */
        public String label, icon;
        public boolean desk;
        /** Приложение видно в «Пуске», поиске и на рабочем столе, только пока возвращается true (null - всегда). */
        public BooleanSupplier avail;

        Info(String id, String title, int w, int h, boolean pinned, Supplier<WinApp> make) {
            this.id = id;
            this.title = title;
            this.w = w;
            this.h = h;
            this.pinned = pinned;
            this.make = make;
            this.label = title;
            this.icon = id;
        }
    }

    private final List<Info> list = new ArrayList<Info>();

    private final WinHost host;
    private List<Info> shown = new ArrayList<Info>();
    private long shownAt = Long.MIN_VALUE / 2;

    public WinApps(WinHost h, WinSpec.Perf perf) {
        this.host = h;
    }

    /** Приложение получает ярлык на рабочем столе по умолчанию (подпись и значок ярлыка). */
    public WinApps desktop(String id, String label, String icon) {
        Info i = get(id);
        if (i != null) {
            i.desk = true;
            i.label = label;
            i.icon = icon;
        }
        return this;
    }

    public void add(String id, String title, int w, int h, boolean pinned, Supplier<WinApp> make) {
        list.add(new Info(id, title, w, h, pinned, make));
        refresh();
    }

    /** Показывать приложение в списках, только пока avail даёт true (запуск по id работает всегда). */
    public WinApps gate(String id, BooleanSupplier avail) {
        Info i = get(id);
        if (i != null) i.avail = avail;
        refresh();
        return this;
    }

    /** Запуск приложения разрешён, только пока allowed даёт true (иначе открывается окно «Нет лицензии»). */
    public WinApps lock(String id, BooleanSupplier allowed) {
        final Info i = get(id);
        if (i == null) return this;
        final Supplier<WinApp> orig = i.make;
        i.make = () -> allowed.getAsBoolean() ? orig.get() : new WinNoLicense(i.title);
        return this;
    }

    /** Сбросить кэш видимых приложений (после установки или удаления программы). */
    public void refresh() {
        shownAt = Long.MIN_VALUE / 2;
    }

    public Info get(String id) {
        for (Info i : list) if (i.id.equals(id)) return i;
        return null;
    }

    /** Видимые приложения; проверка доступности - раз в секунду. */
    public List<Info> all() {
        long now = host.time();
        if (now - shownAt >= 20 || now < shownAt) {
            List<Info> r = new ArrayList<Info>();
            for (Info i : list) if (i.avail == null || i.avail.getAsBoolean()) r.add(i);
            shown = r;
            shownAt = now;
        }
        return shown;
    }
}
