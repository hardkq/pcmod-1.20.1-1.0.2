package ru.pcmod.common;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * SIM-карта: хранит данные оператора, номер, баланс трафика в NBT.
 * NBT: operatorId (String), phoneNumber (int, 7 цифр), dataBalance (int, МБ), tariffId (String).
 * Крафт: золотой самородок + редстоун + бумага (3x3 shapeless) — см. sim_card.json.
 */
public class ItemSimCard extends Item {

    public ItemSimCard(Item.Properties props) {
        super(props);
    }

    // --- NBT-геттеры ---

    public static String getOperatorId(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null ? t.getString("operatorId") : "";
    }

    public static String getOperatorName(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null ? t.getString("operatorName") : "";
    }

    public static int getPhoneNumber(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null ? t.getInt("phoneNumber") : 0;
    }

    public static int getDataBalance(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null ? t.getInt("dataBalance") : 0;
    }

    public static String getTariffId(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null ? t.getString("tariffId") : "";
    }

    // --- NBT-сеттеры ---

    public static void setOperatorId(ItemStack stack, String operatorId) {
        stack.getOrCreateTag().putString("operatorId", operatorId);
    }

    public static void setOperatorName(ItemStack stack, String name) {
        stack.getOrCreateTag().putString("operatorName", name == null ? "" : name);
    }

    public static void setPhoneNumber(ItemStack stack, int phoneNumber) {
        stack.getOrCreateTag().putInt("phoneNumber", phoneNumber);
    }

    public static void setDataBalance(ItemStack stack, int dataBalanceMb) {
        stack.getOrCreateTag().putInt("dataBalance", dataBalanceMb);
    }

    public static void setTariffId(ItemStack stack, String tariffId) {
        stack.getOrCreateTag().putString("tariffId", tariffId);
    }

    /** Форматированный номер телефона (7 цифр): ####-### */
    public static String formatNumber(int num) {
        if (num <= 0) return "---";
        String s = String.format("%07d", num);
        return s.substring(0, 4) + "-" + s.substring(4);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        String op = getOperatorName(stack);
        if (op.isEmpty() && !getOperatorId(stack).isEmpty()) op = "?";
        int num = getPhoneNumber(stack);
        int data = getDataBalance(stack);
        String tariff = getTariffId(stack);

        if (!op.isEmpty()) {
            tips.add(Component.translatable("tooltip.pcmod.sim_card.operator", op)
                .withStyle(ChatFormatting.AQUA));
        } else {
            tips.add(Component.translatable("tooltip.pcmod.sim_card.no_operator")
                .withStyle(ChatFormatting.GRAY));
        }

        if (num > 0) {
            tips.add(Component.translatable("tooltip.pcmod.sim_card.number", formatNumber(num))
                .withStyle(ChatFormatting.WHITE));
        }

        tips.add(Component.translatable("tooltip.pcmod.sim_card.data", data)
            .withStyle(data > 0 ? ChatFormatting.GREEN : ChatFormatting.RED));

        if (!tariff.isEmpty()) {
            tips.add(Component.translatable("tooltip.pcmod.sim_card.tariff", tariff)
                .withStyle(ChatFormatting.GRAY));
        }
    }
}
