package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Раскладка страниц «Параметров»: карточки в стиле Windows 11 (значок, заголовок, описание, значение, переключатель,
 * кнопки, выбор из вариантов, шкала, поле ввода, свои элементы), разделы и пояснения, вертикальная прокрутка.
 * Страница описывает карточки в Builder.build(); после любого действия форма пересобирается сама.
 */
final class WinForm {
    interface Act { void run(); }

    interface Pick { void pick(int i); }

    interface Builder { void build(WinForm f); }

    /** Рисование своего элемента внутри карточки (x, y - левый верхний угол, w - ширина). */
    interface Painter { void paint(PixelScreen p, int x, int y, int w); }

    /** Мышь над своим элементом (координаты внутри карточки); (-1, -1) - указатель ушёл. true - перерисовать. */
    interface Touch { boolean at(int rx, int ry, boolean press); }

    private static final int PAD = 8, GAP = 3, SEC_H = 17, SW_W = 28, SW_H = 14, BTN_H = 16, SEG_H = 14, FIELD_H = 24;
    private static final int K_SEC = 0, K_CARD = 1, K_NOTE = 2, K_FIELD = 3, K_CUSTOM = 4;
    private static final int C_NONE = 0, C_TOGGLE = 1, C_BTN = 2, C_BTN2 = 3, C_CARD = 4, C_SEG = 10;

    /** Элемент формы. Методы-настройки возвращают сам элемент (цепочкой). */
    static final class Row {
        private int kind = K_CARD, y, h, sel, state = -1, bars = -1, customH;
        private String title = "", sub = "", value = "", icon, btn, btn2;
        private String[] opts, lines;
        private Act onToggle, onBtn, onBtn2, onClick;
        private Pick onPick;
        private boolean on, tEnabled = true, bEnabled = true, logo, spin, bad;
        private float bar = -1;
        private WinUi.Field field;
        private Painter painter;
        private Touch touch;

        /** Пояснение под заголовком. */
        Row sub(String s) { sub = s == null ? "" : s; return this; }

        /** Значение справа (серым). */
        Row value(String s) { value = s == null ? "" : s; return this; }

        /** Значок приложения (WinIcons) слева. */
        Row icon(String id) { icon = id; return this; }

        /** Значок состояния слева: 2 - хорошо, 1 - внимание, 0 - плохо. */
        Row state(int s) { state = s; return this; }

        /** Логотип WinCraft слева, крупный заголовок. */
        Row logo() { logo = true; return this; }

        /** Круговой индикатор ожидания слева. */
        Row spin() { spin = true; return this; }

        Row toggle(boolean on, boolean enabled, Act a) { this.on = on; tEnabled = enabled; onToggle = a; return this; }

        /** Основная кнопка справа (рядом с переключателем - левее него). */
        Row button(String label, boolean enabled, Act a) { btn = label; bEnabled = enabled; onBtn = a; return this; }

        /** Вторая кнопка, левее первой. */
        Row button2(String label, Act a) { btn2 = label; onBtn2 = a; return this; }

        /** Выбор одного из вариантов отдельной строкой под заголовком. */
        Row choice(String[] options, int selected, Pick p) { opts = options; sel = selected; onPick = p; return this; }

        /** Шкала под заголовком, 0..1. */
        Row bar(float f) { bar = Math.max(0f, Math.min(1f, f)); return this; }

        /** Уровень сигнала 0..4 справа. */
        Row signal(int n) { bars = Math.max(0, Math.min(4, n)); return this; }

        /** Вся карточка нажимается. */
        Row click(Act a) { onClick = a; return this; }
    }

    private final Builder builder;
    private final List<Row> rows = new ArrayList<Row>();
    private boolean stale = true;
    private int scroll, total, px, py, pw = 200, ph = 100, laidW = -1, hr = -1, hc = C_NONE;

    WinForm(Builder b) {
        builder = b;
    }

    // ------------------------------------------------------------------ состав
    private Row add(int kind) {
        Row r = new Row();
        r.kind = kind;
        rows.add(r);
        return r;
    }

    Row section(String t) { Row r = add(K_SEC); r.title = t; return r; }

    Row card(String title) { Row r = add(K_CARD); r.title = title == null ? "" : title; return r; }

    Row note(String text, boolean bad) { Row r = add(K_NOTE); r.title = text; r.bad = bad; return r; }

    /** Поле ввода с кнопкой справа (Enter обрабатывает страница). */
    Row field(WinUi.Field f, String button, Act a) { Row r = add(K_FIELD); r.field = f; r.btn = button; r.onBtn = a; return r; }

    /** Свой элемент: высота h, рисует painter, мышь - touch. */
    Row custom(int h, Painter p, Touch t) { Row r = add(K_CUSTOM); r.customH = h; r.painter = p; r.touch = t; return r; }

    /** Состояние страницы изменилось: карточки соберутся заново при следующем показе. */
    void refresh() {
        stale = true;
    }

    // ------------------------------------------------------------------ полезное
    /** «12 КБ», «1,5 МБ». */
    static String size(long bytes) {
        if (bytes >= 1048576L) {
            long t = bytes * 10 / 1048576L;
            return (t / 10) + "," + (t % 10) + " МБ";
        }
        return ((bytes + 1023) / 1024) + " КБ";
    }

    static String[] wrap(String s, int maxW) {
        List<String> out = new ArrayList<String>();
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            String t = cur.length() == 0 ? word : cur + " " + word;
            if (cur.length() > 0 && PixelScreen.textWidth(t) > maxW) {
                out.add(cur.toString());
                cur.setLength(0);
                cur.append(word);
            } else {
                cur.setLength(0);
                cur.append(t);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        if (out.isEmpty()) out.add("");
        return out.toArray(new String[0]);
    }

    // ------------------------------------------------------------------ раскладка
    private static int lineH(Row r) {
        return r.logo ? 40 : r.sub.isEmpty() ? 22 : 30;
    }

    private static int bw(String s) {
        return PixelScreen.textWidth(s) + 14;
    }

    /** Правые элементы карточки: {x переключателя, x кнопки, x второй кнопки, x сигнала, правая граница текста}. */
    private static int[] geo(Row r, int cx, int cw) {
        int rx = cx + cw - 8, tx = -1, bx = -1, b2x = -1, sx = -1;
        if (r.onToggle != null) {
            rx -= SW_W;
            tx = rx;
            rx -= 6;
        }
        if (r.btn != null) {
            rx -= bw(r.btn);
            bx = rx;
            rx -= 6;
        }
        if (r.btn2 != null) {
            rx -= bw(r.btn2);
            b2x = rx;
            rx -= 6;
        }
        if (r.bars >= 0) {
            rx -= 15;
            sx = rx;
            rx -= 6;
        }
        return new int[] {tx, bx, b2x, sx, rx};
    }

    private void ensure() {
        if (stale) {
            rows.clear();
            builder.build(this);
            stale = false;
            laidW = -1;
        }
        if (laidW != pw) layout();
    }

    private void layout() {
        laidW = pw;
        int cw = pw - 2 * PAD, y = 2;
        for (Row r : rows) {
            r.y = y;
            if (r.kind == K_SEC) {
                r.h = SEC_H;
                y += r.h;
                continue;
            }
            if (r.kind == K_NOTE) {
                r.lines = wrap(r.title, cw - 4);
                r.h = r.lines.length * 10 + 4;
            } else if (r.kind == K_FIELD) {
                r.h = FIELD_H;
            } else if (r.kind == K_CUSTOM) {
                r.h = r.customH;
            } else {
                r.h = lineH(r) + (r.opts != null ? SEG_H + 5 : 0) + (r.bar >= 0 ? 11 : 0);
            }
            y += r.h + GAP;
        }
        total = y + 4;
        clampScroll();
    }

    private void clampScroll() {
        scroll = Math.max(0, Math.min(scroll, Math.max(0, total - ph)));
    }

    // ------------------------------------------------------------------ рисование
    private static int btnFill(WinTheme th, boolean hover) {
        return th.dark ? (hover ? 0xFF454545 : 0xFF3A3A3A) : (hover ? 0xFFE6E6E6 : 0xFFF3F3F3);
    }

    private static void drawSwitch(PixelScreen p, WinTheme th, int x, int y, boolean on, boolean enabled) {
        int track = on ? th.accent() : th.dark ? 0xFF5A5A5A : 0xFFB5B5B5;
        if (!enabled) track = PixelScreen.alpha(track, 0x70);
        p.roundRect(x, y, SW_W, SW_H, 7, track);
        p.roundRect(on ? x + 16 : x + 2, y + 2, 10, 10, 5, 0xFFFFFFFF);
    }

    private static void drawButton(PixelScreen p, WinTheme th, int x, int y, String label, boolean enabled, boolean hover, boolean primary) {
        int w = bw(label), tc;
        if (!enabled) {
            p.roundRectBorder(x, y, w, BTN_H, 4, th.dark ? 0xFF2A2A2A : 0xFFF0F0F0, th.border());
            tc = PixelScreen.alpha(th.sub(), 0x99);
        } else if (primary) {
            p.roundRect(x, y, w, BTN_H, 4, hover ? th.accentHover() : th.accent());
            tc = th.onAccent();
        } else {
            p.roundRectBorder(x, y, w, BTN_H, 4, btnFill(th, hover), th.border());
            tc = th.text();
        }
        p.drawTextCentered(x, w, y + (BTN_H - PixelFont.H) / 2, label, tc, 1, false);
    }

    private static void drawBars(PixelScreen p, WinTheme th, int x, int y, int n) {
        for (int i = 0; i < 4; i++) {
            int bh = 3 + 2 * i;
            p.fillRect(x + i * 4, y + 9 - bh, 3, bh, i < n ? th.text() : th.border());
        }
    }

    void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h, long tick) {
        px = x;
        py = y;
        pw = w;
        ph = h;
        ensure();
        clampScroll();
        p.pushClip(x, y, w, h);
        int cx = x + PAD, cw = w - 2 * PAD;
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            int ry = y + r.y - scroll;
            if (ry + r.h <= y || ry >= y + h) continue;
            drawRow(p, th, r, i, cx, ry, cw, tick);
        }
        if (total > h) {
            int th2 = Math.max(10, h * h / total), max = total - h;
            int ty = y + (h - th2) * scroll / Math.max(1, max);
            p.roundRect(x + w - 4, ty, 2, th2, 1, PixelScreen.alpha(th.sub(), 0x90));
        }
        p.popClip();
    }

    private void drawRow(PixelScreen p, WinTheme th, Row r, int i, int cx, int cy, int cw, long tick) {
        boolean hv = i == hr;
        if (r.kind == K_SEC) {
            p.drawText(cx + 2, cy + 6, r.title, th.text(), 1, true);
            return;
        }
        if (r.kind == K_NOTE) {
            for (int k = 0; k < r.lines.length; k++) p.drawText(cx + 2, cy + 2 + k * 10, r.lines[k], r.bad ? th.bad() : th.sub());
            return;
        }
        boolean cardHover = hv && hc == C_CARD && r.onClick != null;
        p.roundRectBorder(cx, cy, cw, r.h, 4, cardHover ? (th.dark ? 0xFF343434 : 0xFFF8F8F8) : th.surface(), th.border());
        if (r.kind == K_CUSTOM) {
            r.painter.paint(p, cx, cy, cw);
            return;
        }
        if (r.kind == K_FIELD) {
            int b = bw(r.btn);
            r.field.x = cx + 4;
            r.field.y = cy + 3;
            r.field.w = cw - b - 14;
            r.field.h = 18;
            r.field.draw(p, th, true, tick);
            drawButton(p, th, cx + cw - b - 6, cy + 4, r.btn, r.bEnabled, hv && hc == C_BTN, true);
            return;
        }
        int lh = lineH(r), left = cx + 10;
        int[] g = geo(r, cx, cw);
        if (r.logo) {
            WinGfx.logo(p, cx + 10, cy + 8, 24, th.accent());
            left = cx + 44;
        } else if (r.spin) {
            WinGfx.spinner(p, cx + 16, cy + lh / 2, 6, tick, th.accent());
            left = cx + 30;
        } else if (r.state >= 0) {
            WinGfx.state(p, cx + 16, cy + lh / 2, r.state, th);
            left = cx + 30;
        } else if (r.icon != null) {
            WinIcons.drawSized(p, th, r.icon, cx + 9, cy + (lh - 14) / 2, 14);
            left = cx + 30;
        }
        int avail = g[4] - left, vw = 0;
        String v = r.value;
        if (!v.isEmpty()) {
            v = PixelScreen.fit(v, avail * 3 / 5, 1, false);
            vw = PixelScreen.textWidth(v);
        }
        int tw = Math.max(10, avail - vw - (vw > 0 ? 8 : 0)), sc = r.logo ? 2 : 1;
        int ty = r.logo ? cy + 6 : r.sub.isEmpty() ? cy + (lh - PixelFont.H) / 2 : cy + 5;
        p.drawText(left, ty, PixelScreen.fit(r.title, tw, sc, r.logo), th.text(), sc, r.logo);
        if (!r.sub.isEmpty()) p.drawText(left, cy + (r.logo ? 27 : 16), PixelScreen.fit(r.sub, tw, 1, false), th.sub());
        if (vw > 0) p.drawText(g[4] - vw, cy + (lh - PixelFont.H) / 2, v, th.sub());
        if (r.onToggle != null) drawSwitch(p, th, g[0], cy + (lh - SW_H) / 2, r.on, r.tEnabled);
        if (r.btn != null) drawButton(p, th, g[1], cy + (lh - BTN_H) / 2, r.btn, r.bEnabled, hv && hc == C_BTN, false);
        if (r.btn2 != null) drawButton(p, th, g[2], cy + (lh - BTN_H) / 2, r.btn2, true, hv && hc == C_BTN2, false);
        if (r.bars >= 0) drawBars(p, th, g[3], cy + (lh - 9) / 2, r.bars);
        if (r.opts != null) {
            int n = r.opts.length, sw = (cw - 20 - (n - 1) * 2) / n, sy = cy + lh;
            for (int k = 0; k < n; k++) {
                int sx = cx + 10 + k * (sw + 2);
                boolean sel = k == r.sel;
                if (sel) p.roundRect(sx, sy, sw, SEG_H, 4, th.accent());
                else p.roundRectBorder(sx, sy, sw, SEG_H, 4, btnFill(th, hv && hc == C_SEG + k), th.border());
                p.drawTextCentered(sx, sw, sy + (SEG_H - PixelFont.H) / 2, PixelScreen.fit(r.opts[k], sw - 4, 1, false),
                        sel ? th.onAccent() : th.text(), 1, false);
            }
        }
        if (r.bar >= 0) {
            int by = cy + lh, bwid = cw - 20;
            p.roundRect(cx + 10, by, bwid, 6, 3, th.dark ? 0xFF4A4A4A : 0xFFE1E1E1);
            int fw = Math.round(bwid * r.bar);
            if (fw > 0) p.roundRect(cx + 10, by, Math.max(6, fw), 6, 3, th.accent());
        }
    }

    // ------------------------------------------------------------------ ввод
    private static boolean in(int x, int y, int bx, int by, int bw, int bh) {
        return x >= bx && y >= by && x < bx + bw && y < by + bh;
    }

    /** Определяет элемент под указателем: hr - карточка, hc - часть карточки (C_*). */
    private void locate(int rx, int ry) {
        hr = -1;
        hc = C_NONE;
        if (rx < 0 || ry < 0 || rx >= pw || ry >= ph) return;
        ensure();
        int cx = PAD, cw = pw - 2 * PAD;
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            int top = r.y - scroll;
            if (ry < top || ry >= top + r.h) continue;
            if (r.kind == K_SEC || r.kind == K_NOTE || rx < cx || rx >= cx + cw) return;
            hr = i;
            int ly = ry - top;
            if (r.kind == K_CUSTOM) {
                hc = C_CARD;
            } else if (r.kind == K_FIELD) {
                if (r.bEnabled && in(rx, ly, cx + cw - bw(r.btn) - 6, 4, bw(r.btn), BTN_H)) hc = C_BTN;
            } else {
                int lh = lineH(r);
                int[] g = geo(r, cx, cw);
                if (r.onToggle != null && r.tEnabled && in(rx, ly, g[0], (lh - SW_H) / 2, SW_W, SW_H)) hc = C_TOGGLE;
                else if (r.btn != null && r.bEnabled && in(rx, ly, g[1], (lh - BTN_H) / 2, bw(r.btn), BTN_H)) hc = C_BTN;
                else if (r.btn2 != null && in(rx, ly, g[2], (lh - BTN_H) / 2, bw(r.btn2), BTN_H)) hc = C_BTN2;
                else if (r.opts != null && ly >= lh && ly < lh + SEG_H && rx >= cx + 10) {
                    int n = r.opts.length, sw = (cw - 20 - (n - 1) * 2) / n, k = (rx - cx - 10) / (sw + 2);
                    if (k < n && (rx - cx - 10) % (sw + 2) < sw) hc = C_SEG + k;
                } else if (r.onClick != null) hc = C_CARD;
            }
            return;
        }
    }

    private boolean scrollBy(int d) {
        ensure();
        int old = scroll;
        scroll += d;
        clampScroll();
        hr = -1;
        hc = C_NONE;
        return scroll != old;
    }

    /** Мышь; rx, ry - внутри области формы. true - перерисовать. */
    boolean mouse(int rx, int ry, int btn, int kind) {
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            return scrollBy(kind == PixelScreen.MOUSE_SCROLL_UP ? -24 : 24);
        }
        int oldR = hr, oldC = hc;
        Row old = oldR >= 0 && oldR < rows.size() ? rows.get(oldR) : null;
        locate(rx, ry);
        Row cur = hr >= 0 ? rows.get(hr) : null;
        boolean dirty = oldR != hr || oldC != hc, press = kind == PixelScreen.MOUSE_PRESS && btn == 0;
        if (old != null && old != cur && old.kind == K_CUSTOM && old.touch != null && old.touch.at(-1, -1, false)) dirty = true;
        if (cur == null) return dirty;
        if (cur.kind == K_CUSTOM && cur.touch != null) {
            if (cur.touch.at(rx - PAD, ry - (cur.y - scroll), press)) dirty = true;
            if (press) stale = true;
            return dirty;
        }
        if (!press) return dirty;
        Act a = null;
        if (hc == C_TOGGLE) a = cur.onToggle;
        else if (hc == C_BTN) a = cur.onBtn;
        else if (hc == C_BTN2) a = cur.onBtn2;
        else if (hc == C_CARD) a = cur.onClick;
        else if (hc >= C_SEG && cur.onPick != null) {
            cur.onPick.pick(hc - C_SEG);
            stale = true;
            return true;
        }
        if (a == null) return dirty;
        a.run();
        stale = true;
        return true;
    }

    /** Клавиши прокрутки (LWJGL 2): вверх, вниз, PgUp, PgDn, Home, End. */
    boolean key(int key) {
        if (key == WinUi.K_UP) return scrollBy(-16);
        if (key == WinUi.K_DOWN) return scrollBy(16);
        if (key == 201) return scrollBy(-Math.max(16, ph - 16));
        if (key == 209) return scrollBy(Math.max(16, ph - 16));
        if (key == 199) return scrollBy(-1000000);
        if (key == 207) return scrollBy(1000000);
        return false;
    }
}
