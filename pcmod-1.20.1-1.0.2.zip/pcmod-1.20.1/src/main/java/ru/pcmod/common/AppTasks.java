package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import static ru.pcmod.common.PixelScreen.rgb;

/** «Диспетчер задач»: запущенные приложения и занятая ОЗУ, закрытие приложений. Слабое железо выгружает старые приложения само. */
final class AppTasks implements AndroOs.App {
    private static final int Y0 = 104, ROW = 34;

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        AppUi.header(os, s, "tasks", os.t("Диспетчер задач", "Task manager"));
        int used = os.memUsedMB(), total = Math.max(1, os.ramMB);
        s.roundRect(8, 48, 164, 48, 10, os.panel());
        s.drawText(16, 54, "RAM " + os.ramLabel, os.text(), 1, true);
        s.drawTextRight(166, 54, String.format(java.util.Locale.ROOT, "%.1f / %.1f GB", used / 1024.0, total / 1024.0), os.sub(), 1, false);
        int w = (int) Math.min(148L, 148L * used / total);
        s.roundRect(16, 70, 148, 8, 4, os.panel());
        s.roundRect(16, 70, Math.max(6, w), 8, 4, used * 100 / total > 85 ? rgb(240, 100, 80) : os.accent());
        String[] perf = {os.t("Плавно", "Smooth"), os.t("Лаги", "Laggy"), os.t("Сильные лаги", "Very laggy"), os.t("Сбои", "Unstable")};
        s.drawText(16, 83, os.t("Скорость: ", "Performance: ") + perf[os.lag()], os.sub());
        List<String> r = running(os);
        if (r.isEmpty()) { s.drawTextCentered(0, AndroOs.W, 170, os.t("Нет запущенных приложений", "No running apps"), os.sub(), 1, false); return; }
        for (int i = 0; i < r.size() && i < 5; i++) {
            int y = Y0 + i * ROW;
            s.roundRect(8, y, 164, ROW - 3, 8, os.panel());
            AndroIcons.draw(s, r.get(i), 12, y + 3, 24);
            s.drawText(42, y + 6, PixelScreen.fit(os.name(r.get(i)), 90, 1, true), os.text(), 1, true);
            s.drawText(42, y + 17, "150 MB", os.sub());
            s.drawTextRight(166, y + 10, "x", rgb(240, 120, 100), 1, true);
        }
        AppUi.btn(os, s, 30, 282, 120, 14, os.t("Закрыть все", "Close all"), false);
    }

    private static List<String> running(AndroOs os) {
        List<String> r = new ArrayList<String>();
        for (int i = os.running.size() - 1; i >= 0; i--) r.add(os.running.get(i));
        return r;
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        if (kind != 1 || !os.tap(x, y)) return true;
        if (AppUi.in(x, y, 30, 282, 120, 14)) { os.running.clear(); return true; }
        List<String> r = running(os);
        int i = (y - Y0) / ROW;
        if (y < Y0 || i >= r.size() || i >= 5) return true;
        if (x >= 150) os.running.remove(r.get(i));
        else os.open(r.get(i));
        return true;
    }
}
