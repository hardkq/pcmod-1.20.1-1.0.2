package ru.pcmod.common;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import static ru.pcmod.common.PixelScreen.argb;
import static ru.pcmod.common.PixelScreen.rgb;

/**
 * ОС «AndroCraft» (экран 180x320): загрузка, установка (язык, версия, PIN), блокировка, домашний экран, шторка, навигация.
 * Версии 8 / 10 / 13 / 15: у каждой свои требования к железу и новые функции (10: тёмная тема и жесты, 13: цвет акцента
 * и экономия заряда, 15: всегда включённый экран). Слабое железо даёт задержку ввода, редкие кадры, зависания и вылеты приложений.
 * Настройки хранятся в NBT телефона ("Os"). Приложения подключаются через {@link #APPS}.
 */
public final class AndroOs {
    /** Приложение: рисует область между статус-баром и панелью навигации; получает сырые касания (0 нажатие, 1 отпускание, 2 движение). */
    public interface App {
        void draw(AndroOs os, PixelScreen s);
        default boolean touch(AndroOs os, int kind, int x, int y) { return false; }
        /** Кнопка «Назад»: true - приложение обработало само. */
        default boolean back(AndroOs os) { return false; }
        /** Фоновая работа раз в секунду (будильники, входящие), даже если приложение закрыто. */
        default void bg(AndroOs os) { }
        /** Каждый тик, пока приложение открыто (игры): true - нужен новый кадр. */
        default boolean tick(AndroOs os, long now) { return false; }
    }

    public static final Map<String, App> APPS = new HashMap<String, App>();
    static {
        APPS.put("settings", new AppSettings());
        APPS.put("phone", new AppPhone());
        APPS.put("messages", new AppMessages());
        APPS.put("camera", new AppCamera());
        APPS.put("gallery", new AppGallery());
        APPS.put("calc", new AppCalc());
        APPS.put("notes", new AppNotes());
        APPS.put("clock", new AppClock());
        APPS.put("files", new AppFiles());
        APPS.put("tasks", new AppTasks());
        APPS.put("browser", new AppBrowser());
        APPS.put("store", new AppStore());
        APPS.put("bank", new AppBank());
        APPS.put("shop", new AppShop());
        APPS.put("snake", new AppSnake());
        APPS.put("dice", new AppDice());
        APPS.put("mines", new AppMines());
    }

    public enum Phase { OFF, BOOT, SETUP, LOCK, PIN, HOME, APP }

    public static final int W = 180, H = 320, STATUS = 14, NAV = 300;
    /** Версии ОС и требования: {SoC tier, ОЗУ МБ, ПЗУ ГБ, занимает ОЗУ система МБ}. */
    public static final int[] VER = {8, 10, 13, 15};
    private static final int[][] REQ = {{1, 2048, 16, 600}, {2, 3072, 32, 900}, {4, 6144, 64, 1500}, {5, 8192, 128, 2200}};
    private static final String[][] VFEAT = {{"Базовая система", "Basic system"}, {"Тёмная тема, жесты", "Dark theme, gestures"},
        {"Цвет акцента, экономия", "Accent color, battery saver"}, {"Всегда включённый экран", "Always-on display"}};
    private static final int[][] ACC = {{100, 180, 255, 30, 110, 220}, {110, 220, 140, 30, 150, 80}, {190, 150, 255, 110, 70, 200},
        {255, 170, 90, 220, 110, 20}, {255, 140, 190, 210, 60, 130}};
    private static final String[] HOME = {"settings", "gallery", "store", "bank", "shop", "tools"};
    private static final String[] DOCK = {"phone", "messages", "browser", "camera"};
    private static final String[] TOOLS = {"calc", "notes", "clock", "files", "tasks"};
    private static final String[][] NAME = {
        {"settings", "Настройки", "Settings"}, {"gallery", "Галерея", "Gallery"}, {"store", "Приложения", "Apps"}, {"bank", "Банк", "Bank"},
        {"shop", "Магазин", "Shop"}, {"tools", "Утилиты", "Tools"}, {"phone", "Телефон", "Phone"}, {"messages", "Сообщения", "Messages"},
        {"browser", "Браузер", "Browser"}, {"camera", "Камера", "Camera"}, {"calc", "Калькулятор", "Calculator"}, {"notes", "Заметки", "Notes"},
        {"clock", "Часы", "Clock"}, {"files", "Файлы", "Files"}, {"tasks", "Диспетчер", "Tasks"},
        {"snake", "Змейка", "Snake"}, {"dice", "Кубики", "Dice"}, {"mines", "Сапёр", "Minesweeper"}};

    public Phase phase;
    private boolean awake = true, init, dirty = true, nbtDirty;
    private long now, phaseStart, lastDraw, freezeUntil;
    // железо
    public final int socTier, ramMB, romGB;
    public final String socLabel, ramLabel, romLabel, scrLabel, caseName, batLabel;
    // сохраняемые настройки
    public boolean installed, off, dark = true, dnd, wifi = true, bt, flash, air, gest, saver, aod;
    public int lang, bright = 100, ver = 13, acc;
    public String pin = "", wifiSsid = "", wifiPass = "";
    // состояние интерфейса
    public String app = "";
    public int page, a1 = -1;
    public final List<String> running = new ArrayList<String>();
    private boolean shade, folder, down, sliding, captured, updating, settingPin;
    private int step, sx, sy, tx, ty;
    private String pinBuf = "", crash;
    private long wrongUntil;
    public int minute, pct, net, px0, py0;
    /** Сессия телефона (сервер), Wi-Fi подключение, текущий звонок. */
    public PhoneSession ses;
    public NetLink link = new NetLink();
    public PhoneBook.Call call;
    public boolean callOut;
    private AndroKeys kb;
    private final Map<String, Object> states = new HashMap<String, Object>();
    private String num = "";
    public long day;
    private final List<String[]> notifs = new ArrayList<String[]>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<int[]>();
    private final Random rnd = new Random();

    public AndroOs(ItemStack st) {
        socTier = ItemPhone.socTier(st);
        ramMB = ItemPhone.ramMB(st);
        romGB = ItemPhone.romGB(st);
        PartSpec soc = ItemPhone.part(st, PartSpec.Cat.PH_SOC), scr = ItemPhone.part(st, PartSpec.Cat.PH_SCREEN), rom = ItemPhone.part(st, PartSpec.Cat.PH_ROM);
        socLabel = soc == null ? "-" : soc.label;
        scrLabel = scr == null ? "-" : scr.label;
        romLabel = rom == null ? "-" : rom.label;
        ramLabel = ramMB / 1024 + " GB";
        batLabel = ItemPhone.capacityMah(st) + " mAh";
        String m = st.getTag() == null ? "" : st.getTag().getString("Model");
        caseName = m.startsWith("ph_case_") ? m.substring(8) : m;
        CompoundTag t = st.getTag() == null ? null : st.getTag().getCompound("Os");
        if (t != null && !t.isEmpty()) {
            installed = t.getBoolean("Installed"); off = t.getBoolean("Off"); lang = t.getInt("Lang"); pin = t.getString("Pin");
            dark = t.getBoolean("Dark"); dnd = t.getBoolean("Dnd"); wifi = t.getBoolean("Wifi"); bt = t.getBoolean("Bt");
            flash = t.getBoolean("Flash"); air = t.getBoolean("Air"); bright = Math.max(20, Math.min(100, t.getInt("Bright")));
            if (t.contains("Ver")) ver = t.getInt("Ver");
            wifiSsid = t.getString("Ssid"); wifiPass = t.getString("SsidPass");
            gest = t.getBoolean("Gest"); saver = t.getBoolean("Saver"); aod = t.getBoolean("Aod"); acc = Math.max(0, Math.min(4, t.getInt("Acc")));
        }
        if (verIdx(ver) < 0) ver = 13;
        clampFeatures();
        phase = off ? Phase.OFF : installed ? Phase.LOCK : Phase.BOOT;
        if (phase == Phase.OFF) awake = false;
    }

    // ---- версии и железо
    public static int verIdx(int v) { for (int i = 0; i < VER.length; i++) if (VER[i] == v) return i; return -1; }

    /** 0 - плавно, 1 - лёгкие лаги, 2 - сильные лаги и сбои, 3 - нестабильно (частые вылеты). */
    public int lagFor(int v) {
        int[] r = REQ[Math.max(0, verIdx(v))];
        return Math.min(3, Math.max(0, r[0] - socTier) + (ramMB < r[1] ? 1 : 0) + (ramMB * 2 < r[1] ? 1 : 0) + (romGB < r[2] ? 1 : 0));
    }

    public int lag() { return lagFor(ver); }

    public static String verName(int v) { return "Android " + v; }
    public String verFeature(int v) { return VFEAT[Math.max(0, verIdx(v))][lang]; }
    /** Занято системой во встроенной памяти, МБ. */
    public int sysMB() { return new int[] {4000, 6000, 9000, 12000}[Math.max(0, verIdx(ver))]; }
    public int memUsedMB() { return REQ[Math.max(0, verIdx(ver))][3] + 150 * running.size(); }
    public int bootTicks() { return (50 + 12 * Math.max(0, 7 - socTier)) * (2 + lag()) / 2; }
    private int installTicks() { return 90 + Math.max(0, 7 - socTier) * 10; }
    public int drainFactorPct() { return saver && ver >= 13 ? 60 : 100; }
    public boolean aodOn() { return !awake && phase != Phase.OFF && aod && ver >= 15; }

    private void clampFeatures() {
        if (ver < 10) { dark = false; gest = false; }
        if (ver < 13) { acc = 0; saver = false; }
        if (ver < 15) aod = false;
    }

    /** Установка другой версии ОС (из «Настроек»): прогресс установки, затем перезагрузка. */
    public void installVersion(int v) {
        if (v == ver || verIdx(v) < 0) return;
        ver = v;
        clampFeatures();
        updating = true;
        running.clear();
        folder = false; shade = false;
        nbtDirty = true;
        setPhase(Phase.SETUP);
        step = 2;
    }

    public void startPinSet() { settingPin = true; pinBuf = ""; setPhase(Phase.PIN); }
    public void markSave() { nbtDirty = true; dirty = true; }
    public void setBrightFromRange(int v) { bright = Math.max(20, Math.min(100, v)); }

    /** Состояние приложения на этом телефоне (приложения общие для всех телефонов, данные - у ОС). */
    @SuppressWarnings("unchecked")
    public <T> T state(String key, Supplier<T> make) {
        Object o = states.get(key);
        if (o == null) { o = make.get(); states.put(key, o); }
        return (T) o;
    }

    public boolean tap(int x, int y) { return Math.abs(x - px0) <= 8 && Math.abs(y - py0) <= 8; }
    public long now() { return now; }
    public void dirty() { dirty = true; }
    public ItemStack stack() { return ses == null ? ItemStack.EMPTY : ses.stack(); }
    public void open(String id) { openApp(id); }
    public String num() { return simNumber; }
    /** Мобильная связь есть: режим «в самолёте» выключен, SIM работает и поймана вышка оператора (net - полоски 0..3). */
    public boolean cellular() { return !air && net >= 1; }
    /** Номер вставленной SIM-карты этого игрока ("" - нет SIM): обновляется PhoneSession раз в секунду. */
    public String simNumber = "";

    /** Номер телефона = номер вставленной SIM ("" - SIM нет). */
    public String number() { return simNumber; }

    /** Диалог ввода текста с экранной клавиатурой. mode: 0 текст, 1 цифры, 2 пароль. */
    public void input(String title, String init, int max, int mode, Consumer<String> cb) { kb = new AndroKeys(title, init, max, mode, cb); dirty = true; }

    /** Уведомление, которое будит экран (будильник, входящий вызов). */
    public void alert(String title, String text) {
        notify(title, text);
        if (phase == Phase.OFF) return;
        if (!awake) { awake = true; if (phase == Phase.HOME || phase == Phase.APP || phase == Phase.PIN) { settingPin = false; phase = Phase.LOCK; pinBuf = ""; } }
        dirty = true;
    }

    public boolean awake() { return awake && phase != Phase.OFF; }
    public String t(String ru, String en) { return lang == 0 ? ru : en; }
    public String name(String id) {
        for (String[] n : NAME) if (n[0].equals(id)) return lang == 0 ? n[1] : n[2];
        return id;
    }

    // ---- тема
    public int text() { return dark ? rgb(240, 245, 255) : rgb(20, 28, 45); }
    public int sub() { return dark ? rgb(150, 165, 190) : rgb(90, 100, 120); }
    public int panel() { return dark ? argb(55, 255, 255, 255) : argb(150, 255, 255, 255); }
    public int accent() {
        int[] a = ACC[ver >= 13 ? acc : 0];
        return dark ? rgb(a[0], a[1], a[2]) : rgb(a[3], a[4], a[5]);
    }
    public static int accentOf(int i, boolean dark) { int[] a = ACC[i]; return dark ? rgb(a[0], a[1], a[2]) : rgb(a[3], a[4], a[5]); }
    public int bg1() { return dark ? rgb(22, 36, 70) : rgb(196, 222, 250); }
    public int bg2() { return dark ? rgb(8, 12, 28) : rgb(236, 243, 251); }

    public void notify(String title, String text) {
        notifs.add(0, new String[] {title, text});
        while (notifs.size() > 10) notifs.remove(notifs.size() - 1);
        dirty = true;
    }

    public void dead() { call = null; kb = null; phase = Phase.OFF; awake = false; off = true; shade = false; folder = false; nbtDirty = true; dirty = true; }

    private void setPhase(Phase p) { if (p != Phase.APP) kb = null; phase = p; phaseStart = now; dirty = true; if (p == Phase.SETUP) step = 0; }

    private void openApp(String id) {
        folder = false; shade = false;
        if (AppStore.isExtra(id) && (!AppStore.has(stack(), id) || !AppStore.runnable(this, id))) return;
        boolean warm = running.remove(id);
        if (!warm && !id.equals("settings") && !id.equals("tasks")) {
            int chance = lag() == 2 ? 20 : lag() >= 3 ? 55 : 0;
            if (chance > 0 && rnd.nextInt(100) < chance) { crash = id; dirty = true; return; }
        }
        if (!id.equals("tasks")) {
            running.add(id);
            while (memUsedMB() > ramMB && running.size() > 1) running.remove(0);
        }
        app = id; page = 0; a1 = -1;
        setPhase(Phase.APP);
    }

    // ---- питание
    public void power() {
        if (phase == Phase.OFF) { off = false; awake = true; nbtDirty = true; setPhase(Phase.BOOT); }
        else if (awake) { awake = false; shade = false; folder = false; sliding = false; down = false; queue.clear(); }
        else {
            awake = true;
            if (phase == Phase.HOME || phase == Phase.APP || phase == Phase.PIN) { settingPin = false; phase = Phase.LOCK; pinBuf = ""; }
        }
        dirty = true;
    }

    private void shutdown() { if (call != null) PhoneBook.hangup(this); kb = null; off = true; nbtDirty = true; awake = false; shade = false; folder = false; running.clear(); phase = Phase.OFF; dirty = true; }

    private void save(ItemStack st) {
        CompoundTag t = new CompoundTag();
        t.putBoolean("Installed", installed); t.putBoolean("Off", off); t.putInt("Lang", lang); t.putString("Pin", pin);
        t.putBoolean("Dark", dark); t.putBoolean("Dnd", dnd); t.putBoolean("Wifi", wifi); t.putBoolean("Bt", bt);
        t.putBoolean("Flash", flash); t.putBoolean("Air", air); t.putInt("Bright", bright);
        t.putInt("Ver", ver); t.putBoolean("Gest", gest); t.putBoolean("Saver", saver); t.putBoolean("Aod", aod); t.putInt("Acc", acc); t.putString("Ssid", wifiSsid); t.putString("SsidPass", wifiPass);
        st.getOrCreateTag().put("Os", t);
    }

    /** Серверный тик. true - кадр нужно перерисовать. */
    public boolean tick(long gt, ItemStack st, int minute, long day, int pct, int net) {
        now = gt;
        if (!init) { init = true; phaseStart = gt; }
        if (minute != this.minute || pct != this.pct || day != this.day || net != this.net) dirty = true;
        this.minute = minute; this.day = day; this.pct = pct; this.net = net;
        if (nbtDirty) { clampFeatures(); save(st); nbtDirty = false; }
        if (awake()) {
            int lag = lag();
            if (lag >= 2 && freezeUntil < now && rnd.nextInt(180) == 0) freezeUntil = now + 10 + rnd.nextInt(16);
            if (now < freezeUntil) return false;
            if (installed && gt % 20 == 0) for (App a : APPS.values()) a.bg(this);
            while (!queue.isEmpty() && queue.peek()[3] <= now) { int[] e = queue.poll(); handle(e[0], e[1], e[2]); }
            if (phase == Phase.BOOT && now - phaseStart >= bootTicks()) setPhase(installed ? Phase.LOCK : Phase.SETUP);
            if (phase == Phase.SETUP && step == 2 && now - phaseStart >= installTicks()) {
                if (updating) { updating = false; setPhase(Phase.BOOT); }
                else { step = 3; pinBuf = ""; phaseStart = now; dirty = true; }
            }
            if ((phase == Phase.BOOT || phase == Phase.SETUP && step == 2) && gt % 2 == 0) dirty = true;
            if (phase == Phase.APP && !shade && crash == null) { App cur = APPS.get(app); if (cur != null && cur.tick(this, now)) dirty = true; }
            if (wrongUntil != 0 && now >= wrongUntil) { wrongUntil = 0; dirty = true; }
            if (dirty && lag > 0 && now - lastDraw < lag * 2L) return false;
        }
        boolean r = dirty;
        if (r) { dirty = false; lastDraw = now; }
        return r;
    }

    // ---- ввод
    /** Касание с клиента; при слабом железе обрабатывается с задержкой. */
    public void touch(int kind, int x, int y) {
        if (!awake() || phase == Phase.BOOT) return;
        int delay = lag() * 3;
        if (delay == 0 && queue.isEmpty()) handle(kind, x, y);
        else queue.add(new int[] {kind, x, y, (int) Math.min(Integer.MAX_VALUE, now + delay)});
    }

    private void handle(int kind, int x, int y) {
        if (crash != null) {
            if (kind == 1 && in(x, y, 60, 170, 60, 22)) { running.remove(crash); crash = null; setPhase(Phase.HOME); }
            dirty = true;
            return;
        }
        if (call != null && !callOut && call.state == 0 && phase != Phase.BOOT && phase != Phase.SETUP) {
            if (kind == 1) {
                if (in(x, y, 20, 250, 60, 30)) PhoneBook.hangup(this);
                else if (in(x, y, 100, 250, 60, 30)) PhoneBook.answer(this);
            }
            dirty = true;
            return;
        }
        if (kb != null && phase == Phase.APP && !shade && (kind == 1 ? sy : y) < NAV) {
            if (kind == 0) { down = true; sx = tx = x; sy = ty = y; px0 = x; py0 = y; }
            else if (kind == 2) { tx = x; ty = y; }
            else if (down) { down = false; AndroKeys k = kb; if (tap(x, y) && k.tap(x, y) && kb == k) kb = null; }
            dirty = true;
            return;
        }
        boolean edge = gest && (x < 14 || x >= 166);
        if (kind == 0) {
            down = true; sx = tx = x; sy = ty = y; px0 = x; py0 = y; sliding = false; captured = false;
            if (shade && y >= 142 && y <= 164 && x >= 10 && x <= 170) { sliding = true; setBright(x); }
            else if (phase == Phase.APP && !shade && !edge && y >= STATUS + 8 && y < NAV) {
                App a = APPS.get(app);
                captured = a != null && a.touch(this, 0, x, y);
            }
        } else if (kind == 2) {
            if (!down) return;
            tx = x; ty = y;
            if (sliding) setBright(x);
            else if (captured) APPS.get(app).touch(this, 2, x, y);
        } else if (kind == 1) {
            if (!down) return;
            down = false; tx = x; ty = y;
            if (sliding) { sliding = false; nbtDirty = true; }
            else if (captured) { captured = false; APPS.get(app).touch(this, 1, x, y); }
            else release();
        }
        dirty = true;
    }

    private void setBright(int x) { setBrightFromRange(20 + (x - 14) * 80 / 152); }

    private void release() {
        int dx = tx - sx, dy = ty - sy;
        boolean up = dy <= -30 && -dy > Math.abs(dx), downSw = dy >= 22 && dy > Math.abs(dx), tap = Math.abs(dx) <= 8 && Math.abs(dy) <= 8;
        boolean sys = phase == Phase.LOCK || phase == Phase.HOME || phase == Phase.APP, main = phase == Phase.HOME || phase == Phase.APP;
        if (main && sy >= NAV) {
            if (!gest) { if (tap) nav(sx); }
            else if (up) { if (-dy >= 90) recents(); else goHome(); }
            return;
        }
        if (gest && main && !shade && Math.abs(dx) >= 30 && Math.abs(dx) > Math.abs(dy) && (sx < 14 || sx >= 166)) { back(); return; }
        if (shade) {
            if (up) shade = false; else if (tap) shadeTap(sx, sy);
            return;
        }
        if (sys && sy < 22 && (downSw || tap && sy < STATUS)) { shade = true; return; }
        switch (phase) {
            case LOCK -> { if (up) { pinBuf = ""; setPhase(pin.isEmpty() ? Phase.HOME : Phase.PIN); } }
            case PIN -> {
                if (!tap) return;
                if (sy >= 284 && sx >= 55 && sx <= 125) { if (settingPin) { settingPin = false; setPhase(Phase.APP); } else setPhase(Phase.LOCK); }
                else padTap(padKey(sx, sy));
            }
            case SETUP -> { if (tap) setupTap(sx, sy); }
            case HOME -> { if (tap) homeTap(sx, sy); }
            default -> { }
        }
    }

    private void goHome() { shade = false; folder = false; if (phase == Phase.APP) setPhase(Phase.HOME); }
    private void recents() { shade = false; folder = false; openApp("tasks"); }
    private void back() {
        if (kb != null) kb = null;
        else if (shade) shade = false;
        else if (folder) folder = false;
        else if (phase == Phase.APP) { App a = APPS.get(app); if (a == null || !a.back(this)) setPhase(Phase.HOME); }
    }
    private void nav(int x) { if (x < 65) back(); else if (x < 115) goHome(); else recents(); }

    private void shadeTap(int x, int y) {
        if (x >= 148 && y >= 18 && y <= 44) { shutdown(); return; }
        if (x >= 120 && y >= 166 && y <= 184) { notifs.clear(); return; }
        for (int i = 0; i < 6; i++) {
            int bx = 8 + (i % 3) * 57, by = 62 + (i / 3) * 42;
            if (x < bx || x >= bx + 52 || y < by || y >= by + 36) continue;
            switch (i) {
                case 0 -> { if (!air) wifi = !wifi; }
                case 1 -> { if (!air) bt = !bt; }
                case 2 -> dnd = !dnd;
                case 3 -> { if (ver >= 10) dark = !dark; }
                case 4 -> flash = !flash;
                default -> { air = !air; if (air) { wifi = false; bt = false; } }
            }
            nbtDirty = true;
        }
    }

    /** Значки главного экрана: системные + установленные из магазина приложений (до 12). */
    private List<String> homeIds() {
        List<String> l = new ArrayList<String>(java.util.Arrays.asList(HOME));
        for (String id : AppStore.installed(stack())) if (l.size() < 12) l.add(id);
        return l;
    }

    private static int hx(int i) { return 7 + (i % 4) * 45; }
    private static int hy(int i) { return 102 + (i / 4) * 56; }
    private static boolean in(int x, int y, int rx, int ry, int rw, int rh) { return x >= rx && y >= ry && x < rx + rw && y < ry + rh; }

    private void homeTap(int x, int y) {
        if (folder) {
            for (int i = 0; i < TOOLS.length; i++) if (in(x, y, 18 + (i % 3) * 50, 134 + (i / 3) * 48, 44, 46)) { openApp(TOOLS[i]); return; }
            if (!in(x, y, 15, 110, 150, 126)) folder = false;
            return;
        }
        List<String> ids = homeIds();
        for (int i = 0; i < ids.size(); i++)
            if (in(x, y, hx(i) - 7, hy(i) - 3, 44, 46)) { if (ids.get(i).equals("tools")) folder = true; else openApp(ids.get(i)); return; }
        for (int i = 0; i < DOCK.length; i++) if (in(x, y, 8 + i * 41, 262, 41, 34)) { openApp(DOCK[i]); return; }
    }

    private void setupTap(int x, int y) {
        if (step == 0) {
            if (in(x, y, 20, 130, 140, 34)) { lang = 0; step = 1; }
            else if (in(x, y, 20, 176, 140, 34)) { lang = 1; step = 1; }
        } else if (step == 1) {
            for (int i = 0; i < VER.length; i++)
                if (in(x, y, 10, 44 + i * 62, 160, 56)) { ver = VER[i]; clampFeatures(); step = 2; phaseStart = now; nbtDirty = true; }
        } else if (step == 3) {
            if (y >= 284) { pin = ""; step = 4; nbtDirty = true; } else padTap(padKey(x, y));
        } else if (step == 4 && in(x, y, 50, 220, 80, 32)) {
            installed = true; nbtDirty = true; setPhase(Phase.HOME);
            notify("AndroCraft", t("Система установлена. Добро пожаловать!", "Setup complete. Welcome!"));
        }
    }

    private static int padKey(int x, int y) {
        if (x < 20 || y < 142 || (x - 20) % 50 >= 40 || (y - 142) % 38 >= 32) return -1;
        int c = (x - 20) / 50, r = (y - 142) / 38;
        return c > 2 || r > 3 ? -1 : r * 3 + c;
    }

    private void padTap(int k) {
        if (k < 0 || k == 11) return;
        if (k == 9) { if (!pinBuf.isEmpty()) pinBuf = pinBuf.substring(0, pinBuf.length() - 1); return; }
        if (pinBuf.length() >= 4) return;
        pinBuf += k == 10 ? 0 : k + 1;
        if (pinBuf.length() < 4) return;
        if (phase == Phase.SETUP) { pin = pinBuf; pinBuf = ""; step = 4; phaseStart = now; nbtDirty = true; }
        else if (settingPin) { pin = pinBuf; pinBuf = ""; settingPin = false; nbtDirty = true; setPhase(Phase.APP); }
        else if (pinBuf.equals(pin)) { pinBuf = ""; setPhase(Phase.HOME); }
        else { pinBuf = ""; wrongUntil = now + 30; }
    }

    // ---- рисование
    private String time() { return String.format("%02d:%02d", minute / 60, minute % 60); }
    private String date() { return t("День ", "Day ") + (day + 1); }

    private void wallpaper(PixelScreen s) {
        s.gradientV(0, 0, W, H, bg1(), bg2());
        s.roundRect(100, 120, 80, 80, 40, argb(dark ? 16 : 40, 255, 255, 255));
        s.roundRect(0, 210, 90, 90, 45, argb(dark ? 12 : 30, 255, 255, 255));
    }

    public void draw(PixelScreen s) {
        if (!awake()) {
            s.clear(0x000000);
            if (aodOn()) {
                s.drawTextCentered(0, W, 120, time(), rgb(110, 120, 140), 3, false);
                s.drawTextCentered(0, W, 152, date() + "  " + pct + "%", rgb(80, 90, 110), 1, false);
            }
            return;
        }
        switch (phase) {
            case BOOT -> drawBoot(s);
            case SETUP -> drawSetup(s);
            case LOCK -> drawLock(s);
            case PIN -> { wallpaper(s); drawPad(s, settingPin ? t("Новый PIN-код", "New PIN") : t("Введите PIN-код", "Enter PIN")); }
            case HOME -> drawHome(s);
            case APP -> drawApp(s);
            default -> s.clear(0x000000);
        }
        boolean sys = phase == Phase.LOCK || phase == Phase.HOME || phase == Phase.APP;
        if (kb != null && phase == Phase.APP) kb.draw(this, s);
        if (shade && sys) drawShade(s);
        if (sys) status(s);
        if (phase == Phase.HOME || phase == Phase.APP) navBar(s);
        if (crash != null) drawCrash(s);
        if (call != null && !callOut && call.state == 0 && awake()) AppPhone.incoming(this, s);
        if (down && !sliding) s.roundRect(tx - 6, ty - 6, 12, 12, 6, argb(70, 255, 255, 255));
        if (bright < 100) s.fillRect(0, 0, W, H, argb((100 - bright) * 2, 0, 0, 0));
    }

    private void drawCrash(PixelScreen s) {
        s.fillRect(0, STATUS, W, NAV - STATUS, argb(150, 0, 0, 0));
        s.roundRect(20, 116, 140, 84, 14, dark ? rgb(40, 50, 80) : rgb(250, 252, 255));
        s.drawTextCentered(20, 140, 130, PixelScreen.fit("\"" + name(crash) + "\"", 128, 1, true), text(), 1, true);
        s.drawTextCentered(20, 140, 146, t("остановлено", "has stopped"), sub(), 1, false);
        s.roundRect(60, 170, 60, 22, 10, accent());
        s.drawTextCentered(60, 60, 177, "OK", rgb(255, 255, 255), 1, true);
    }

    private void drawBoot(PixelScreen s) {
        s.clear(0x000000);
        int g = rgb(61, 220, 132);
        s.roundRect(66, 104, 48, 36, 18, g);
        s.fillRect(66, 124, 48, 18, g);
        s.roundRect(80, 116, 5, 5, 2, rgb(0, 0, 0)); s.roundRect(95, 116, 5, 5, 2, rgb(0, 0, 0));
        s.fillRect(74, 98, 2, 8, g); s.fillRect(104, 98, 2, 8, g);
        s.drawTextCentered(0, W, 158, "AndroCraft", rgb(255, 255, 255), 2, true);
        s.drawTextCentered(0, W, 182, verName(ver), rgb(150, 160, 170), 1, false);
        s.roundRect(40, 214, 100, 4, 2, rgb(50, 55, 65));
        s.roundRect(40, 214, Math.max(4, (int) Math.min(100, (now - phaseStart) * 100 / Math.max(1, bootTicks()))), 4, 2, g);
    }

    private void button(PixelScreen s, int x, int y, int w, int h, String label, boolean on) {
        s.roundRect(x, y, w, h, 10, on ? accent() : panel());
        s.drawTextCentered(x, w, y + h / 2 - 4, label, on ? rgb(255, 255, 255) : text(), 1, true);
    }

    private void drawSetup(PixelScreen s) {
        wallpaper(s);
        if (step == 0) {
            s.drawTextCentered(0, W, 56, "Welcome / Добро пожаловать", text(), 1, true);
            s.drawTextCentered(0, W, 100, "Выберите язык / Choose language", sub(), 1, false);
            button(s, 20, 130, 140, 34, "Русский", lang == 0);
            button(s, 20, 176, 140, 34, "English", lang == 1);
        } else if (step == 1) {
            s.drawTextCentered(0, W, 24, t("Версия AndroCraft", "AndroCraft version"), text(), 1, true);
            for (int i = 0; i < VER.length; i++) {
                int y = 44 + i * 62, lg = lagFor(VER[i]), r[] = REQ[i];
                s.roundRect(10, y, 160, 56, 10, panel());
                s.drawText(18, y + 8, verName(VER[i]), text(), 1, true);
                String[] st = {t("Плавно", "Smooth"), t("Лаги", "Laggy"), t("Сильные лаги", "Very laggy"), t("Сбои", "Unstable")};
                int[] col = {rgb(80, 220, 120), rgb(240, 200, 60), rgb(240, 140, 50), rgb(240, 80, 70)};
                s.drawTextRight(164, y + 8, st[lg], col[lg], 1, true);
                s.drawText(18, y + 22, PixelScreen.fit(verFeature(VER[i]), 144, 1, false), sub());
                s.drawText(18, y + 36, t("Нужно: ", "Needs: ") + "SoC " + r[0] + "+, " + r[1] / 1024.0 + " GB", text());
            }
        } else if (step == 2) {
            s.drawTextCentered(0, W, 110, updating ? t("Обновление системы", "Updating system") : t("Установка AndroCraft", "Installing AndroCraft"), text(), 1, true);
            s.drawTextCentered(0, W, 124, verName(ver), sub(), 1, false);
            int p = (int) Math.min(100, (now - phaseStart) * 100 / installTicks());
            s.roundRect(30, 148, 120, 6, 3, panel());
            s.roundRect(30, 148, Math.max(6, p * 120 / 100), 6, 3, accent());
            s.drawTextCentered(0, W, 164, p + "%", sub(), 1, false);
        } else if (step == 3) {
            drawPad(s, t("Создайте PIN-код", "Create a PIN"));
            s.drawTextCentered(0, W, 292, t("Пропустить", "Skip"), accent(), 1, true);
        } else {
            s.drawTextCentered(0, W, 100, t("Готово!", "All set!"), text(), 3, true);
            s.drawTextCentered(0, W, 150, "AndroCraft - " + verName(ver), sub(), 1, false);
            button(s, 50, 220, 80, 32, t("Начать", "Start"), true);
        }
    }

    private void drawPad(PixelScreen s, String title) {
        s.drawTextCentered(0, W, 60, title, text(), 1, true);
        for (int i = 0; i < 4; i++) {
            if (i < pinBuf.length()) s.roundRect(60 + i * 20, 100, 10, 10, 5, text());
            else s.roundRectOutline(60 + i * 20, 100, 10, 10, 5, 1, sub());
        }
        if (wrongUntil > now) s.drawTextCentered(0, W, 120, t("Неверный PIN", "Wrong PIN"), rgb(240, 90, 80), 1, true);
        for (int k = 0; k < 12; k++) {
            if (k == 11) continue;
            int bx = 20 + (k % 3) * 50, by = 142 + (k / 3) * 38;
            s.roundRect(bx, by, 40, 32, 12, panel());
            String l = k < 9 ? String.valueOf(k + 1) : k == 9 ? "<" : "0";
            s.drawTextCentered(bx, 40, by + 8, l, text(), 2, false);
        }
        if (phase == Phase.PIN) s.drawTextCentered(0, W, 290, t("Отмена", "Cancel"), accent(), 1, true);
    }

    private void drawLock(PixelScreen s) {
        wallpaper(s);
        s.drawTextCentered(0, W, 64, time(), text(), 5, false);
        s.drawTextCentered(0, W, 116, date(), sub(), 1, false);
        if (!notifs.isEmpty() && !dnd) {
            String[] n = notifs.get(0);
            s.roundRect(14, 150, 152, 30, 8, panel());
            s.drawText(20, 154, PixelScreen.fit(n[0], 140, 1, true), text(), 1, true);
            s.drawText(20, 166, PixelScreen.fit(n[1], 140, 1, false), sub());
        }
        s.drawTextCentered(0, W, 268, t("Проведите вверх", "Swipe up"), sub(), 1, false);
        s.roundRect(70, 290, 40, 3, 1, sub());
    }

    private void drawHome(PixelScreen s) {
        wallpaper(s);
        s.drawText(14, 22, time(), text(), 3, false);
        s.drawText(14, 52, date(), sub());
        s.roundRect(10, 68, 160, 20, 10, panel());
        s.roundRectOutline(20, 73, 8, 8, 4, 1, sub());
        s.drawText(34, 74, t("Поиск", "Search"), sub());
        List<String> ids = homeIds();
        for (int i = 0; i < ids.size(); i++) {
            int x = hx(i), y = hy(i);
            if (ids.get(i).equals("tools")) AndroIcons.folder(s, TOOLS, x, y, 30); else AndroIcons.draw(s, ids.get(i), x, y, 30);
            s.drawTextCentered(x - 8, 46, y + 33, PixelScreen.fit(name(ids.get(i)), 46, 1, false), text(), 1, false);
        }
        s.roundRect(8, 262, 164, 34, 14, dark ? argb(70, 255, 255, 255) : argb(170, 255, 255, 255));
        for (int i = 0; i < DOCK.length; i++) AndroIcons.draw(s, DOCK[i], 16 + i * 41, 266, 26);
        if (folder) {
            s.fillRect(0, STATUS, W, NAV - STATUS, argb(120, 0, 0, 0));
            s.roundRect(15, 110, 150, 126, 14, dark ? rgb(36, 46, 76) : rgb(246, 249, 253));
            s.drawTextCentered(15, 150, 118, name("tools"), text(), 1, true);
            for (int i = 0; i < TOOLS.length; i++) {
                int x = 25 + (i % 3) * 50, y = 138 + (i / 3) * 48;
                AndroIcons.draw(s, TOOLS[i], x, y, 30);
                s.drawTextCentered(x - 10, 50, y + 33, PixelScreen.fit(name(TOOLS[i]), 48, 1, false), text(), 1, false);
            }
        }
    }

    private void drawApp(PixelScreen s) {
        App a = APPS.get(app);
        if (a != null) { a.draw(this, s); return; }
        s.gradientV(0, 0, W, H, bg1(), bg2());
        s.fillRect(0, STATUS, W, 30, AndroIcons.colorOf(app));
        AndroIcons.draw(s, app, 8, STATUS + 4, 22);
        s.drawText(38, STATUS + 11, name(app), rgb(255, 255, 255), 1, true);
        AndroIcons.draw(s, app, 75, 110, 30);
        s.drawTextCentered(0, W, 160, t("Скоро", "Coming soon"), text(), 2, true);
        s.drawTextCentered(0, W, 186, t("Приложение в разработке", "App under development"), sub(), 1, false);
    }

    private void status(PixelScreen s) {
        int c = text();
        s.fillRect(0, 0, W, STATUS, dark ? argb(90, 0, 0, 0) : argb(70, 255, 255, 255));
        s.drawText(6, 3, time(), c);
        int x = 36;
        if (call != null && call.state == 1) { s.drawText(x, 3, "CALL", rgb(80, 220, 120)); x += 26; }
        if (dnd) { s.drawText(x, 3, "DND", accent()); x += 22; }
        if (saver && ver >= 13) { s.roundRect(x, 4, 6, 6, 3, rgb(240, 200, 60)); x += 9; }
        if (flash) s.roundRect(x, 4, 6, 6, 3, rgb(255, 255, 255));
        if (wifi && !air) { s.hline(98, 4, 9, c); s.hline(100, 7, 5, c); s.hline(102, 10, 1, c); }
        if (!air) for (int i = 0; i < 3; i++) s.fillRect(112 + i * 4, 10 - i * 2, 3, 2 + i * 2, i < net ? c : sub());
        s.roundRectOutline(150, 3, 18, 8, 2, 1, c);
        s.fillRect(152, 5, Math.max(0, pct * 14 / 100), 4, pct > 20 ? rgb(80, 220, 120) : rgb(230, 70, 60));
        s.fillRect(168, 5, 2, 4, c);
    }

    private void navBar(PixelScreen s) {
        int c = text();
        if (gest) { s.roundRect(65, 311, 50, 3, 1, c); return; }
        s.fillRect(0, NAV, W, H - NAV, dark ? argb(120, 0, 0, 0) : argb(80, 255, 255, 255));
        for (int i = 0; i < 6; i++) s.vline(50 + i, 310 - i, 2 * i + 1, c);
        s.roundRectOutline(85, 304, 12, 12, 6, 1, c);
        s.roundRectOutline(128, 305, 10, 10, 2, 1, c);
    }

    private void drawShade(PixelScreen s) {
        s.fillRect(0, STATUS, W, NAV - STATUS, dark ? argb(242, 14, 20, 38) : argb(242, 232, 238, 248));
        s.drawText(10, 20, time(), text(), 2, false);
        s.drawText(10, 40, date(), sub());
        s.roundRect(150, 20, 22, 22, 11, panel());
        s.roundRectOutline(156, 26, 10, 10, 5, 1, text());
        s.vline(161, 24, 5, text());
        boolean[] on = {wifi && !air, bt && !air, dnd, dark, flash, air};
        String[] ru = {"Wi-Fi", "Bluetooth", "Не беспок.", "Тёмная", "Фонарик", "Авиарежим"}, en = {"Wi-Fi", "Bluetooth", "DND", "Dark", "Torch", "Airplane"};
        for (int i = 0; i < 6; i++) {
            int x = 8 + (i % 3) * 57, y = 62 + (i / 3) * 42;
            s.roundRect(x, y, 52, 36, 10, on[i] ? accent() : panel());
            int fc = on[i] ? rgb(255, 255, 255) : text();
            s.drawTextCentered(x, 52, y + 8, PixelScreen.fit(lang == 0 ? ru[i] : en[i], 48, 1, true), fc, 1, true);
            String st = i == 3 && ver < 10 ? "10+" : on[i] ? t("Вкл", "On") : t("Выкл", "Off");
            s.drawTextCentered(x, 52, y + 21, st, on[i] ? rgb(220, 235, 255) : sub(), 1, false);
        }
        s.roundRect(14, 152, 152, 4, 2, panel());
        int kx = 14 + (bright - 20) * 152 / 80;
        s.roundRect(14, 152, Math.max(4, kx - 14), 4, 2, accent());
        s.roundRect(kx - 5, 148, 10, 12, 5, accent());
        s.drawText(10, 172, t("Уведомления", "Notifications"), text(), 1, true);
        s.drawTextRight(172, 172, t("Очистить", "Clear"), accent(), 1, false);
        if (notifs.isEmpty()) s.drawTextCentered(0, W, 226, t("Нет уведомлений", "No notifications"), sub(), 1, false);
        for (int i = 0; i < Math.min(3, notifs.size()); i++) {
            int y = 188 + i * 34;
            s.roundRect(8, y, 164, 30, 8, panel());
            s.drawText(14, y + 4, PixelScreen.fit(notifs.get(i)[0], 152, 1, true), text(), 1, true);
            s.drawText(14, y + 16, PixelScreen.fit(notifs.get(i)[1], 152, 1, false), sub());
        }
        s.roundRect(70, 292, 40, 3, 1, sub());
    }
}
