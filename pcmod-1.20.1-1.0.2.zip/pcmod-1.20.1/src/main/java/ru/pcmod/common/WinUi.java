package ru.pcmod.common;

/** Элементы интерфейса WinCraft 11: поле ввода, кнопка, всплывающее меню. */
public final class WinUi {
    private WinUi() {}

    /** Коды клавиш LWJGL 2 (так их присылает клиент). */
    public static final int K_BACK = 14, K_TAB = 15, K_ENTER = 28, K_NENTER = 156, K_F10 = 68,
            K_UP = 200, K_LEFT = 203, K_RIGHT = 205, K_DOWN = 208;

    public static boolean isEnter(char c, int key) {
        return key == K_ENTER || key == K_NENTER || c == '\r' || c == '\n';
    }

    // ------------------------------------------------------------------ поле ввода
    public static final class Field {
        public final StringBuilder sb = new StringBuilder();
        public boolean mask;
        public int max = 16;
        public String hint = "";
        public int x, y, w, h = 16, padRight;

        public Field(int x, int y, int w) {
            this.x = x;
            this.y = y;
            this.w = w;
        }

        public boolean hit(int mx, int my) {
            return mx >= x && my >= y && mx < x + w && my < y + h;
        }

        /** Ввод символа; true - нажат Enter. */
        public boolean key(char c, int key) {
            if (isEnter(c, key)) return true;
            if (key == K_BACK || c == '\b') {
                if (sb.length() > 0) sb.setLength(sb.length() - 1);
            } else if (c >= 32 && c != 127 && sb.length() < max) {
                sb.append(c);
            }
            return false;
        }

        public void draw(PixelScreen p, WinTheme th, boolean focus, long tick) {
            p.roundRectBorder(x, y, w, h, 4, th.surface(), th.border());
            if (focus) p.fillRect(x + 3, y + h - 2, w - 6, 2, th.accent());
            String shown = sb.toString();
            if (mask) {
                StringBuilder m = new StringBuilder();
                for (int i = 0; i < shown.length(); i++) m.append('\u2022');
                shown = m.toString();
            }
            int maxW = w - 12 - padRight, tw = PixelScreen.textWidth(shown);
            while (tw > maxW && shown.length() > 0) {
                shown = shown.substring(1);
                tw = PixelScreen.textWidth(shown);
            }
            int ty = y + (h - PixelFont.H) / 2;
            if (shown.isEmpty()) p.drawText(x + 6, ty, hint, th.sub());
            else p.drawText(x + 6, ty, shown, th.text());
            if (focus && (tick / 10) % 2 == 0) p.fillRect(x + 6 + (tw > 0 ? tw + 1 : 0), y + 3, 1, h - 7, th.text());
        }
    }

    // ------------------------------------------------------------------ кнопка
    public static final class Button {
        public int x, y, w, h = 16;
        public String label;
        public boolean primary, hover, enabled = true;

        public Button(String label, int x, int y, int w, boolean primary) {
            this.label = label;
            this.x = x;
            this.y = y;
            this.w = w;
            this.primary = primary;
        }

        public boolean hit(int mx, int my) {
            return enabled && mx >= x && my >= y && mx < x + w && my < y + h;
        }

        public void draw(PixelScreen p, WinTheme th) {
            int tc;
            if (!enabled) {
                p.roundRectBorder(x, y, w, h, 4, th.dark ? 0xFF2A2A2A : 0xFFF0F0F0, th.border());
                tc = th.sub() & 0x00FFFFFF | 0x99000000;
            } else if (primary) {
                p.roundRect(x, y, w, h, 4, hover ? th.accentHover() : th.accent());
                tc = th.onAccent();
            } else {
                p.roundRectBorder(x, y, w, h, 4, hover ? (th.dark ? 0xFF3A3A3A : 0xFFF6F6F6) : th.surface(), th.border());
                tc = th.text();
            }
            p.drawTextCentered(x, w, y + (h - PixelFont.H) / 2, label, tc, 1, false);
        }
    }

    // ------------------------------------------------------------------ меню
    public static final class Menu {
        public static final int IH = 14;
        public final String[] items;
        public int x, y, w, hover = -1;
        public boolean open;

        public Menu(String... items) {
            this.items = items;
            int mw = 0;
            for (String s : items) mw = Math.max(mw, PixelScreen.textWidth(s));
            w = mw + 22;
        }

        public int h() {
            return items.length * IH + 8;
        }

        /** Открыть меню у точки; сдвигается так, чтобы влезть в экран. */
        public void openAt(int px, int py) {
            x = Math.max(2, Math.min(PixelScreen.W - w - 2, px));
            y = Math.max(2, Math.min(PixelScreen.H - h() - 2, py));
            hover = -1;
            open = true;
        }

        public boolean contains(int mx, int my) {
            return open && mx >= x && my >= y && mx < x + w && my < y + h();
        }

        public int itemAt(int mx, int my) {
            if (!contains(mx, my)) return -1;
            int i = (my - y - 4) / IH;
            return my - y - 4 < 0 || i >= items.length ? -1 : i;
        }

        /** Область, которую меню занимает вместе с тенью: {x, y, w, h}. */
        public int[] box() {
            return new int[] {x - 8, y - 6, w + 16, h() + 16};
        }

        public void draw(PixelScreen p, WinTheme th, boolean shadow) {
            if (!open) return;
            if (shadow) p.shadow(x, y, w, h(), 5, 6, 0, 2, 0x70000000);
            if (th.glass) {
                WinGfx.glass(p, th, x, y, w, h(), 5, th.surface(), 0xE6);
                p.roundRectOutline(x, y, w, h(), 5, 1, th.border());
            } else {
                p.roundRectBorder(x, y, w, h(), 5, th.surface(), th.border());
            }
            for (int i = 0; i < items.length; i++) {
                int iy = y + 4 + i * IH;
                if (i == hover) p.roundRect(x + 3, iy, w - 6, IH - 1, 3, th.hover());
                p.drawText(x + 10, iy + (IH - 1 - PixelFont.H) / 2, items[i], th.text());
            }
        }
    }
}
