package ru.pcmod.common;

import java.util.Collection;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Вышка связи: NBT operatorId, linkedServerId, isActive. Активна только после привязки линкером к TileServer. */
public class TileTower extends BlockEntity {
    public static final int MIN_RADIUS = 64, MAX_RADIUS = 512;
    private static final TileIndex<TileTower> INDEX = new TileIndex<>();

    public String operatorId = "";
    public long linkedServerId;
    public boolean linked;
    public boolean isActive;
    /** Абоненты оператора вышки онлайн в зоне покрытия. */
    public int subscribers;

    public TileTower(BlockPos pos, BlockState st) { super(ModBlockEntities.TOWER.get(), pos, st); }

    /** Радиус покрытия: 64 + Y*2, не меньше 64 и не больше 512. */
    public static int radiusAt(int y) { return Math.max(MIN_RADIUS, Math.min(MAX_RADIUS, 64 + y * 2)); }
    public int radius() { return radiusAt(worldPosition.getY()); }
    public BlockPos linkedServer() { return BlockPos.of(linkedServerId); }
    public boolean covers(BlockPos p) { double r = radius(); return worldPosition.distSqr(p) <= r * r; }

    /** Все загруженные вышки измерения (только сервер). */
    public static Collection<TileTower> towers(Level l) { return INDEX.in(l); }

    public void bindToServer(BlockPos server, String opId) {
        linked = true;
        linkedServerId = server.asLong();
        operatorId = opId == null ? "" : opId;
        isActive = true;
        sync();
    }

    public void unbind() {
        linked = false;
        isActive = false;
        operatorId = "";
        sync();
    }

    private void sync() {
        setChanged();
        if (level != null && !level.isClientSide) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    /** Серверный тик (ticker в BlockTower). */
    public void tick() {
        if (!(level instanceof ServerLevel sl)) return;
        long t = sl.getGameTime();
        boolean dirty = false;
        if (t % 100 == 7 && linked && sl.isLoaded(linkedServer()) && !(sl.getBlockEntity(linkedServer()) instanceof TileServer)) {
            unbind();
            return;
        }
        if (t % 20 == 3) {
            int n = 0;
            double r2 = (double) radius() * radius();
            OperatorStore st = linked && !operatorId.isEmpty() ? OperatorStore.get() : null;
            OperatorStore.Operator op = st == null ? null : st.get(operatorId);
            if (op != null)
                for (ServerPlayer p : sl.players())
                    if (!p.isSpectator() && st.isActiveSubscriber(op.id, p.getUUID())
                            && p.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) <= r2) n++;
            if (n != subscribers) { subscribers = n; dirty = true; }
            boolean act = linked;
            if (act != isActive) { isActive = act; dirty = true; }
        }
        if (dirty) sync();
    }

    @Override public void onLoad() { super.onLoad(); INDEX.add(this); }
    @Override public void setRemoved() { INDEX.remove(this); super.setRemoved(); }
    @Override public void onChunkUnloaded() { INDEX.remove(this); super.onChunkUnloaded(); }

    @Override public void load(CompoundTag t) {
        super.load(t);
        operatorId = t.getString("operatorId");
        linked = t.getBoolean("linked");
        linkedServerId = t.getLong("linkedServerId");
        isActive = t.getBoolean("isActive");
        subscribers = t.getInt("subscribers");
    }

    @Override protected void saveAdditional(CompoundTag t) {
        super.saveAdditional(t);
        t.putString("operatorId", operatorId);
        t.putBoolean("linked", linked);
        t.putLong("linkedServerId", linkedServerId);
        t.putBoolean("isActive", isActive);
        t.putInt("subscribers", subscribers);
    }

    @Override public CompoundTag getUpdateTag() { return saveWithoutMetadata(); }
    @Override public Packet<ClientGamePacketListener> getUpdatePacket() { return ClientboundBlockEntityDataPacket.create(this); }
}
