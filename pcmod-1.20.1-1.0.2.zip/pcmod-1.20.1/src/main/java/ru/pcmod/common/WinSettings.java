package ru.pcmod.common;

/**
 * Окно «Параметры» WinCraft 11: слева разделы (Система, Персонализация, Приложения, Сеть, Время, Обновление, О системе),
 * справа страница выбранного раздела. Все настройки применяются сразу и сохраняются на накопителе (WinHost.setPref).
 */
public final class WinSettings implements WinApp {
    /** Действия, которые «Параметры» просят у рабочего стола (выполняются после обработки события мыши). */
    public interface Ctx {
        /** 0 - заблокировать, 1 - перезагрузка, 2 - завершение работы. */
        void power(int action);

        /** Запустить приложение. */
        void launch(String id);
    }

    public static final int P_SYSTEM = 0, P_PERSONAL = 1, P_APPS = 2, P_NET = 3, P_TIME = 4, P_UPDATE = 5, P_ABOUT = 6, COUNT = 7;
    static final String[] NAMES = {"Система", "Персонализация", "Приложения", "Сеть", "Время", "Обновление", "О системе"};
    /** Размер окна по умолчанию. */
    public static final int WIN_W = 316, WIN_H = 156;
    private static final int NW = 94, HEAD = 22, TOP = 27, IH = 15;

    private final WinHost host;
    private final WinTheme th;
    private final WinLook look;
    private final WinSpec.Perf perf;
    private final WinApps apps;
    private final Ctx ctx;
    private final WinPage[] pages = new WinPage[COUNT];
    private int cur, hover = -1;

    public WinSettings(WinHost host, WinTheme th, WinLook look, WinSpec.Perf perf, WinApps apps, Ctx ctx, int page) {
        this.host = host;
        this.th = th;
        this.look = look;
        this.perf = perf;
        this.apps = apps;
        this.ctx = ctx;
        go(page);
    }

    @Override public String title() { return "Параметры"; }

    @Override public String id() { return "settings"; }

    @Override public boolean resizable() { return false; }

    /** Открыть раздел. */
    public void go(int page) {
        cur = Math.max(0, Math.min(COUNT - 1, page));
        page(cur).enter();
    }

    private WinPage page(int i) {
        if (pages[i] == null) {
            switch (i) {
                case P_SYSTEM: pages[i] = new WinPageSystem(host, th, perf, ctx); break;
                case P_PERSONAL: pages[i] = new WinPersonal(host, th, look, perf); break;
                case P_APPS: pages[i] = new WinPageApps(host, apps, ctx); break;
                case P_NET: pages[i] = new WinPageNet(host); break;
                case P_TIME: pages[i] = new WinPageTime(host, th, look); break;
                case P_UPDATE: pages[i] = new WinPageUpdate(host, th, perf, ctx); break;
                default: pages[i] = new WinPageAbout(host, perf); break;
            }
        }
        return pages[i];
    }

    // ------------------------------------------------------------------ рисование
    /** Значок раздела 11x11 с центром (cx, cy). */
    private static void navIcon(PixelScreen p, int i, int cx, int cy, int c) {
        switch (i) {
            case P_SYSTEM:
                p.roundRectOutline(cx - 5, cy - 5, 11, 8, 2, 1, c);
                p.fillRect(cx - 2, cy + 4, 5, 1, c);
                break;
            case P_PERSONAL:
                WinGfx.line(p, cx - 4, cy + 4, cx + 1, cy - 1, c);
                p.fillRect(cx + 1, cy - 5, 4, 4, c);
                break;
            case P_APPS:
                p.fillRect(cx - 5, cy - 5, 4, 4, c);
                p.fillRect(cx + 1, cy - 5, 4, 4, c);
                p.fillRect(cx - 5, cy + 1, 4, 4, c);
                p.fillRect(cx + 1, cy + 1, 4, 4, c);
                break;
            case P_NET:
                p.roundRectOutline(cx - 5, cy - 5, 11, 11, 5, 1, c);
                p.vline(cx, cy - 5, 11, c);
                p.hline(cx - 5, cy, 11, c);
                break;
            case P_TIME:
                p.roundRectOutline(cx - 5, cy - 5, 11, 11, 5, 1, c);
                p.vline(cx, cy - 3, 4, c);
                p.hline(cx, cy, 3, c);
                break;
            case P_UPDATE:
                p.roundRectOutline(cx - 4, cy - 4, 9, 9, 4, 1, c);
                p.fillRect(cx + 2, cy - 6, 4, 1, c);
                p.fillRect(cx + 5, cy - 6, 1, 4, c);
                break;
            default:
                p.roundRectOutline(cx - 5, cy - 5, 11, 11, 5, 1, c);
                p.pixel(cx, cy - 3, c);
                p.vline(cx, cy - 1, 5, c);
                break;
        }
    }

    @Override
    public void draw(PixelScreen p, WinTheme t, int x, int y, int w, int h) {
        WinGfx.avatar(p, x + 16, y + 14, 18, 0xFF5E82AA, 0xFFE8F0F8);
        p.drawText(x + 30, y + 5, PixelScreen.fit(host.userName(), NW - 34, 1, false), t.text());
        p.drawText(x + 30, y + 15, PixelScreen.fit("Локальная запись", NW - 34, 1, false), t.sub());
        for (int i = 0; i < COUNT; i++) {
            int iy = y + TOP + i * IH;
            boolean sel = i == cur;
            if (sel) {
                p.roundRect(x + 4, iy, NW - 8, IH - 1, 3, t.dark ? 0xFF383838 : 0xFFE6E6E6);
                p.roundRect(x + 4, iy + 3, 2, IH - 7, 1, t.accent());
            } else if (i == hover) {
                p.roundRect(x + 4, iy, NW - 8, IH - 1, 3, t.hover());
            }
            navIcon(p, i, x + 15, iy + 7, sel ? t.accent() : t.text());
            p.drawText(x + 25, iy + (IH - 1 - PixelFont.H) / 2, PixelScreen.fit(NAMES[i], NW - 28, 1, false), t.text());
        }
        int px = x + NW;
        p.drawText(px + 8, y + 3, NAMES[cur], t.text(), 2, false);
        page(cur).draw(p, t, px, y + HEAD, w - NW, h - HEAD);
    }

    // ------------------------------------------------------------------ ввод
    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        boolean dirty = false;
        if (rx >= 0 && rx < NW && ry >= TOP && ry < TOP + COUNT * IH) {
            int i = (ry - TOP) / IH;
            if (kind == PixelScreen.MOUSE_PRESS && btn == 0 && i != cur) {
                cur = i;
                page(cur).enter();
                dirty = true;
            }
            if (i != hover) {
                hover = i;
                dirty = true;
            }
            return page(cur).mouse(-1, -1, 0, PixelScreen.MOUSE_MOVE) | dirty;
        }
        if (hover != -1) {
            hover = -1;
            dirty = true;
        }
        if (rx >= NW && ry >= HEAD) return page(cur).mouse(rx - NW, ry - HEAD, btn, kind) | dirty;
        return page(cur).mouse(-1, -1, 0, PixelScreen.MOUSE_MOVE) | dirty;
    }

    /** Клавиши страницы; если она их не взяла: Tab и стрелки влево/вправо переключают разделы. */
    @Override
    public boolean key(char c, int key) {
        if (page(cur).key(c, key)) return true;
        int d = key == WinUi.K_TAB || key == WinUi.K_RIGHT ? 1 : key == WinUi.K_LEFT ? -1 : 0;
        if (d == 0) return false;
        cur = (cur + d + COUNT) % COUNT;
        page(cur).enter();
        return true;
    }

    @Override public boolean tick(long now) { return page(cur).tick(now); }
}
