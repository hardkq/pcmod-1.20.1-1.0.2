package ru.pcmod.common;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.items.SlotItemHandler;

/** Меню генератора: слот топлива + инвентарь игрока; горение и энергия идут клиенту через DataSlot. */
public class ContainerGenerator extends ContainerBlank {
    public static final int BURN = 0, TOTAL = 1, ENERGY = 2, ACTIVE = 3;
    public static final int HEIGHT = 172, INV_X = 19, INV_Y = 90, HOTBAR_Y = 148, FUEL_X = 30, FUEL_Y = 50;
    public final TileGenerator gen;
    public final int[] d = new int[4];

    public ContainerGenerator(int id, Inventory inv, BlockEntity te) {
        super(ModMenus.GENERATOR.get(), id, te);
        this.gen = (TileGenerator) te;
        addSlot(new SlotItemHandler(gen.items(), 0, FUEL_X, FUEL_Y));
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c + r * 9 + 9, INV_X + c * 18, INV_Y + r * 18));
        for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c, INV_X + c * 18, HOTBAR_Y));
        for (int i = 0; i < 4; i++) {
            final int k = i;
            addDataSlot(new DataSlot() {
                @Override public int get() { return live(k); }
                @Override public void set(int v) { d[k] = v; }
            });
        }
    }

    public ContainerGenerator(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, inv.player.level().getBlockEntity(buf.readBlockPos()));
    }

    private int live(int k) {
        return switch (k) {
            case BURN -> Math.min(gen.burn, 32767);
            case TOTAL -> Math.min(gen.burnTotal, 32767);
            case ENERGY -> gen.stored();
            default -> gen.producing ? 1 : 0;
        };
    }

    @Override
    public ItemStack quickMoveStack(Player p, int idx) {
        Slot slot = slots.get(idx);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
        ItemStack st = slot.getItem(), copy = st.copy();
        if (idx == 0) {
            if (!moveItemStackTo(st, 1, slots.size(), true)) return ItemStack.EMPTY;
        } else if (TileGenerator.burnTime(st) > 0) {
            if (!moveItemStackTo(st, 0, 1, false)) return ItemStack.EMPTY;
        } else return ItemStack.EMPTY;
        if (st.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        return copy;
    }
}
