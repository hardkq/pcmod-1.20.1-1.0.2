package ru.pcmod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** USB-кабель: ПКМ по включённому ПК с телефоном в другой руке подключает телефон (заряд идёт, пока ПК включён и игрок рядом); ПКМ в воздух - отключает. */
public class ItemUsbCable extends Item {
    public ItemUsbCable(Item.Properties props) { super(props); }

    private static ItemStack otherPhone(Player p, InteractionHand h) {
        ItemStack o = p.getItemInHand(h == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        return o.getItem() instanceof ItemPhone ? o : ItemStack.EMPTY;
    }

    @Override
    public InteractionResult useOn(UseOnContext c) {
        Level level = c.getLevel();
        Player p = c.getPlayer();
        if (p == null) return InteractionResult.PASS;
        BlockPos pos = c.getClickedPos();
        if (!(level.getBlockEntity(pos) instanceof TileComputer tc)) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ItemStack ph = otherPhone(p, c.getHand());
        if (ph.isEmpty()) { p.displayClientMessage(Component.translatable("gui.pcmod.phone.cable.no_phone"), true); return InteractionResult.CONSUME; }
        if (!ItemPhone.assembled(ph)) { p.displayClientMessage(Component.translatable("gui.pcmod.phone.unassembled"), true); return InteractionResult.CONSUME; }
        if (!tc.isOn()) { p.displayClientMessage(Component.translatable("gui.pcmod.phone.cable.pc_off"), true); return InteractionResult.CONSUME; }
        CompoundTag t = ph.getOrCreateTag();
        t.putLong("Plug", pos.asLong());
        t.putString("PlugDim", level.dimension().location().toString());
        p.displayClientMessage(Component.translatable("gui.pcmod.phone.cable.plugged"), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack me = p.getItemInHand(hand);
        ItemStack ph = otherPhone(p, hand);
        if (!level.isClientSide && !ph.isEmpty() && ph.getTag() != null && ph.getTag().contains("Plug")) {
            ph.getTag().remove("Plug");
            ph.getTag().remove("PlugDim");
            p.displayClientMessage(Component.translatable("gui.pcmod.phone.unplugged"), true);
            return InteractionResultHolder.success(me);
        }
        return InteractionResultHolder.pass(me);
    }
}
