package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Программа «Мобильный оператор»: покупка лицензии (2 500 000 К) и вкладки Обзор / Вышки / Тарифы / Абоненты / SIM.
 * Вся логика и проверки - на сервере (SoftMobileOperator через WinSvc); окно только показывает снимок состояния.
 */
public final class WinMobileOp implements WinApp {
    private static final int TAB = 20, ROW = 11, T_OVER = 0, T_TOWERS = 1, T_TARIFFS = 2, T_SUBS = 3, T_SIM = 4;
    private static final String[] NAMES = {"Обзор", "Вышки", "Тарифы", "Абоненты", "SIM"};

    private final WinSoft s;
    private final WinSvc svc;
    private final WinUi.Field fName = new WinUi.Field(0, 0, 150), fTn = new WinUi.Field(0, 0, 80), fAct = new WinUi.Field(0, 0, 50),
            fMb = new WinUi.Field(0, 0, 50), fDay = new WinUi.Field(0, 0, 50), fBuy = new WinUi.Field(0, 0, 50);
    private final WinUi.Button bLic = new WinUi.Button("Купить лицензию", 0, 0, 100, true), bPay = new WinUi.Button("Вывести выручку", 0, 0, 100, true),
            bAdd = new WinUi.Button("Создать", 0, 0, 56, true), bDel = new WinUi.Button("Удалить", 0, 0, 50, false),
            bIssue = new WinUi.Button("Выпустить SIM", 0, 0, 84, true), bBuy = new WinUi.Button("Купить МБ", 0, 0, 56, false);
    private final List<WinUi.Button> act = new ArrayList<WinUi.Button>();
    private SoftMobileOperator.View v = new SoftMobileOperator.View();
    private WinUi.Field focus;
    private WinUi.Button hoverBtn;
    private String msg = "";
    private boolean msgOk;
    private int tab = T_OVER, sel = -1, scroll, ox, oy, aw = 330, ah = 170, listTop, listRows, listCount;

    public WinMobileOp(WinSoft s) {
        this.s = s;
        this.svc = s.svc;
        fName.max = OperatorStore.MAX_NAME;
        fName.hint = "Название оператора";
        fTn.max = 16;
        fTn.hint = "Название";
        fAct.max = 7;
        fAct.hint = "Подкл.";
        fMb.max = 6;
        fMb.hint = "К/МБ";
        fDay.max = 6;
        fDay.hint = "К/сутки";
        fBuy.max = 6;
        fBuy.hint = "МБ";
        refresh();
    }

    @Override public String title() { return "Мобильный оператор" + (v.licensed ? " - " + v.name : ""); }

    @Override public String id() { return "mobileop"; }

    @Override public int minW() { return 310; }

    @Override public int minH() { return 150; }

    private void refresh() {
        v = svc.mobState();
        if (!visible(tab)) tab = firstTab();
    }

    private boolean visible(int t) { return v.owner || t == T_SIM; }

    private int firstTab() { return v.owner ? T_OVER : T_SIM; }

    private int[] tabs() { return v.owner ? new int[] {0, 1, 2, 3, 4} : new int[] {T_SIM}; }

    private void result(WinSvc.Res r) {
        msg = r.msg;
        msgOk = r.ok;
        refresh();
    }

    private static int num(WinUi.Field f) {
        try { return f.sb.length() == 0 ? -1 : Integer.parseInt(f.sb.toString()); } catch (NumberFormatException e) { return -1; }
    }

    private List<WinUi.Field> fields() {
        List<WinUi.Field> l = new ArrayList<WinUi.Field>();
        if (!v.licensed) l.add(fName);
        else if (tab == T_TARIFFS) { l.add(fTn); l.add(fAct); l.add(fMb); l.add(fDay); }
        else if (tab == T_SIM) l.add(fBuy);
        return l;
    }

    // ------------------------------------------------------------------ рисование
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        ox = x;
        oy = y;
        aw = w;
        ah = h;
        act.clear();
        listCount = 0;
        if (!v.ready) {
            p.drawTextCentered(x, w, y + h / 2 - 10, svc.netUp() ? "Сервер недоступен" : "Нет подключения к сети", th.bad(), 1, true);
            p.drawTextCentered(x, w, y + h / 2 + 2, "Нужна сеть с сервером и банком", th.sub(), 1, false);
            return;
        }
        if (!v.licensed) {
            drawLicense(p, th, x, y, w, h);
        } else {
            drawTabs(p, th, x, y, w);
            int cy = y + TAB + 4;
            switch (tab) {
                case T_OVER: drawOverview(p, th, x, cy, w); break;
                case T_TOWERS: drawTable(p, th, x, cy, w, h, new String[] {"Координаты", "Высота", "Радиус", "Статус"}, new int[] {8, 118, 168, 218}, v.towers, 3, false, y + h - 4); break;
                case T_TARIFFS: drawTariffs(p, th, x, cy, w, h, y); break;
                case T_SUBS: drawTable(p, th, x, cy, w, h, new String[] {"Игрок", "Номер", "Тариф", "МБ", "Статус"}, new int[] {8, 88, 140, 226, 262}, v.subs, 4, false, y + h - 4); break;
                default: drawSim(p, th, x, cy, w, h, y); break;
            }
        }
        if (!msg.isEmpty()) p.drawText(x + 8, y + h - 12, PixelScreen.fit(msg, w - 16, 1, false), msgOk ? th.ok() : th.bad());
        for (WinUi.Button b : act) {
            b.hover = b == hoverBtn;
            b.draw(p, th);
        }
    }

    private void place(WinUi.Button b, int bx, int by, boolean enabled) {
        b.w = PixelScreen.textWidth(b.label) + 16;
        b.x = bx;
        b.y = by;
        b.enabled = enabled;
        act.add(b);
    }

    private void field(PixelScreen p, WinTheme th, WinUi.Field f, int fx, int fy, int fw) {
        f.x = fx;
        f.y = fy;
        f.w = fw;
        f.draw(p, th, f == focus, s.host.time());
    }

    private void drawLicense(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        p.drawTextCentered(x, w, y + 10, "Лицензия мобильного оператора", th.text(), 1, true);
        p.drawTextCentered(x, w, y + 24, "Стоимость: " + WinSoft.kons(v.price) + " К", th.text(), 1, false);
        p.drawTextCentered(x, w, y + 35, "Ваш счёт: " + WinSoft.kons(v.bank) + " К", v.bank >= v.price ? th.ok() : th.bad(), 1, false);
        p.drawTextCentered(x, w, y + 49, "Откроются вышки, тарифы, абоненты и выпуск SIM.", th.sub(), 1, false);
        if (focus == null) focus = fName;
        field(p, th, fName, x + (w - 150) / 2, y + 66, 150);
        place(bLic, x + (w - (PixelScreen.textWidth(bLic.label) + 16)) / 2, y + 90, fName.sb.length() >= 3);
    }

    private void drawTabs(PixelScreen p, WinTheme th, int x, int y, int w) {
        p.fillRect(x, y, w, TAB, th.surface());
        p.hline(x, y + TAB - 1, w, th.border());
        int i = 0;
        for (int t : tabs()) {
            int bx = x + 6 + i++ * 62;
            p.drawTextCentered(bx - 2, 60, y + 5, NAMES[t], t == tab ? th.accent() : th.text(), 1, t == tab);
            if (t == tab) p.roundRect(bx + 8, y + TAB - 3, 42, 2, 1, th.accent());
        }
    }

    private void line(PixelScreen p, WinTheme th, int x, int y, int w, String k, String val) {
        p.roundRectBorder(x + 6, y, w - 12, 17, 4, th.surface(), th.border());
        p.drawText(x + 14, y + 4, k, th.sub());
        p.drawTextRight(x + w - 14, y + 4, val, th.text(), 1, true);
    }

    private void drawOverview(PixelScreen p, WinTheme th, int x, int cy, int w) {
        line(p, th, x, cy, w, "Оператор", v.name);
        line(p, th, x, cy + 20, w, "Баланс оператора", WinSoft.kons(v.balance) + " К");
        line(p, th, x, cy + 40, w, "Вышек", String.valueOf(v.towers.size()));
        line(p, th, x, cy + 60, w, "Абонентов", String.valueOf(v.subs.size()));
        place(bPay, x + 6, cy + 84, v.balance > 0);
    }

    /** Таблица со строками-массивами; cols - смещения столбцов, statusCol - столбец, окрашиваемый по слову «актив». */
    private void drawTable(PixelScreen p, WinTheme th, int x, int cy, int w, int h, String[] head, int[] cols, List<String[]> rows, int statusCol, boolean selectable, int bottom) {
        for (int i = 0; i < head.length; i++) p.drawText(x + cols[i], cy, head[i], th.sub());
        p.hline(x + 4, cy + 10, w - 8, th.border());
        listTop = cy + 13;
        listRows = Math.max(1, (bottom - listTop) / ROW);
        listCount = rows.size();
        scroll = Math.max(0, Math.min(Math.max(0, listCount - listRows), scroll));
        if (rows.isEmpty()) p.drawText(x + 8, listTop, "Пока пусто", th.sub());
        for (int r = 0; r < listRows && r + scroll < rows.size(); r++) {
            int ry = listTop + r * ROW;
            String[] row = rows.get(r + scroll);
            if (selectable && r + scroll == sel) p.roundRect(x + 4, ry - 1, w - 8, ROW, 2, th.hover());
            for (int i = 0; i < row.length && i < cols.length; i++) {
                int next = i + 1 < cols.length ? cols[i + 1] : w - 6;
                boolean st = i == statusCol;
                int c = !st ? th.text() : row[i].equals("активна") ? th.ok() : th.bad();
                p.drawText(x + cols[i], ry, PixelScreen.fit(row[i], next - cols[i] - 4, 1, false), c);
            }
        }
        WinSoft.scrollbar(p, th, x + w - 5, listTop, listRows * ROW, listCount, listRows, scroll);
    }

    private List<String[]> tariffRows() {
        List<String[]> r = new ArrayList<String[]>();
        for (OperatorStore.Tariff t : v.tariffs) r.add(new String[] {t.name, t.activationCost + " К", t.mbPrice + " К", t.dailyFee + " К"});
        return r;
    }

    private void drawTariffs(PixelScreen p, WinTheme th, int x, int cy, int w, int h, int y) {
        drawTable(p, th, x, cy, w, h, new String[] {"Тариф", "Подключение", "За МБ", "В сутки"}, new int[] {8, 128, 198, 254}, tariffRows(), -1, true, y + h - 50);
        int fy = y + h - 46;
        field(p, th, fTn, x + 6, fy, 84);
        field(p, th, fAct, x + 94, fy, 52);
        field(p, th, fMb, x + 150, fy, 52);
        field(p, th, fDay, x + 206, fy, 52);
        place(bAdd, x + 6, fy + 19, true);
        place(bDel, x + 6 + bAdd.w + 4, fy + 19, sel >= 0 && sel < v.tariffs.size());
    }

    private void drawSim(PixelScreen p, WinTheme th, int x, int cy, int w, int h, int y) {
        drawTable(p, th, x, cy, w, h, new String[] {"Тариф", "Подключение", "За МБ", "В сутки"}, new int[] {8, 128, 198, 254}, tariffRows(), -1, true, y + h - 54);
        int iy = y + h - 50;
        String mine = v.myMb < 0 ? "Ваша SIM: не оформлена" : "Ваша SIM: " + v.myNumber + "  тариф " + v.myTariff + "  " + v.myMb + " МБ";
        p.drawText(x + 8, iy, PixelScreen.fit(mine, w - 16, 1, false), th.text());
        place(bIssue, x + 6, iy + 12, sel >= 0 && sel < v.tariffs.size());
        field(p, th, fBuy, x + 6 + bIssue.w + 8, iy + 12, 52);
        place(bBuy, fBuy.x + 56, iy + 12, v.myMb >= 0 && num(fBuy) > 0);
    }

    // ------------------------------------------------------------------ действия
    private void press(WinUi.Button b) {
        if (b == bLic) result(svc.mobBuyLicense(fName.sb.toString()));
        else if (b == bPay) result(svc.mobPayout());
        else if (b == bAdd) {
            WinSvc.Res r = svc.mobAddTariff(fTn.sb.toString(), Math.max(0, num(fAct)), Math.max(0, num(fMb)), Math.max(0, num(fDay)));
            if (r.ok) { fTn.sb.setLength(0); fAct.sb.setLength(0); fMb.sb.setLength(0); fDay.sb.setLength(0); }
            result(r);
        } else if (b == bDel && sel >= 0 && sel < v.tariffs.size()) {
            String id = v.tariffs.get(sel).id;
            sel = -1;
            result(svc.mobDelTariff(id));
        } else if (b == bIssue && sel >= 0 && sel < v.tariffs.size()) result(svc.mobIssueSim(v.tariffs.get(sel).id));
        else if (b == bBuy) {
            WinSvc.Res r = svc.mobBuyData(num(fBuy));
            if (r.ok) fBuy.sb.setLength(0);
            result(r);
        }
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int ax = rx + ox, ay = ry + oy;
        WinUi.Button hv = null;
        for (WinUi.Button b : act) if (b.hit(ax, ay)) hv = b;
        boolean d = hv != hoverBtn;
        hoverBtn = hv;
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            scroll = Math.max(0, scroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -1 : 1));
            return true;
        }
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return d;
        if (hv != null) { press(hv); return true; }
        if (v.licensed && ry >= 0 && ry < TAB) {
            int i = (rx - 4) / 62;
            int[] t = tabs();
            if (rx >= 4 && i >= 0 && i < t.length && t[i] != tab) {
                tab = t[i];
                sel = -1;
                scroll = 0;
                focus = null;
                msg = "";
                return true;
            }
        }
        for (WinUi.Field f : fields()) if (f.hit(ax, ay)) { focus = f; return true; }
        if (v.licensed && (tab == T_TARIFFS || tab == T_SIM) && ay >= listTop && ay < listTop + listRows * ROW) {
            int i = (ay - listTop) / ROW + scroll;
            sel = i < listCount ? i : -1;
            return true;
        }
        return d;
    }

    @Override
    public boolean key(char c, int key) {
        List<WinUi.Field> fs = fields();
        if (fs.isEmpty() || !v.ready) return false;
        if (focus == null || !fs.contains(focus)) focus = fs.get(0);
        if (key == WinUi.K_TAB) {
            focus = fs.get((fs.indexOf(focus) + 1) % fs.size());
            return true;
        }
        if (WinUi.isEnter(c, key)) {
            press(!v.licensed ? bLic : tab == T_TARIFFS ? bAdd : bBuy);
            return true;
        }
        boolean text = focus == fName || focus == fTn;
        if (text || key == WinUi.K_BACK || c == '\b' || (c >= '0' && c <= '9')) {
            focus.key(c, key);
            msg = "";
            return true;
        }
        return false;
    }

    @Override
    public boolean tick(long now) {
        boolean d = now % 10 == 0;
        if (now % 20 == 0) {
            SoftMobileOperator.View n = svc.mobState();
            if (n.ready != v.ready || n.licensed != v.licensed || n.owner != v.owner || n.balance != v.balance || n.bank != v.bank
                    || n.subs.size() != v.subs.size() || n.towers.size() != v.towers.size() || n.tariffs.size() != v.tariffs.size() || n.myMb != v.myMb) {
                v = n;
                if (!visible(tab)) tab = firstTab();
                d = true;
            }
        }
        return d;
    }
}
