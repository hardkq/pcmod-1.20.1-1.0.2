package ru.pcmod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.EnergyStorage;

/** Глушилка: радиус 16–128, потребляет 50 FE/tick × (радиус / 16). Без энергии — не глушит. */
public class TileJammer extends BlockEntity {
    public static final int MIN_RADIUS = 16, MAX_RADIUS = 128, CAPACITY = 16000, FE_BASE = 50;
    private static final TileIndex<TileJammer> INDEX = new TileIndex<>();

    private final Fe energy = new Fe();
    private final LazyOptional<EnergyStorage> energyCap = LazyOptional.of(() -> energy);
    public int radius = 32;
    public boolean enabled;
    public boolean active;

    public TileJammer(BlockPos pos, BlockState st) { super(ModBlockEntities.JAMMER.get(), pos, st); }

    private final class Fe extends EnergyStorage {
        Fe() { super(CAPACITY, 2000, 0); }
        int use(int n) { int e = Math.min(energy, n); energy -= e; return e; }
        void set(int v) { energy = Math.max(0, Math.min(capacity, v)); }
        @Override public int receiveEnergy(int max, boolean sim) {
            int r = super.receiveEnergy(max, sim);
            if (r > 0 && !sim) setChanged();
            return r;
        }
    }

    public static int cost(int radius) { return FE_BASE * radius / 16; }
    public int cost() { return cost(radius); }
    public int stored() { return energy.getEnergyStored(); }

    public void setRadius(int r) { radius = Math.max(MIN_RADIUS, Math.min(MAX_RADIUS, r)); setChanged(); }
    public void toggle() { enabled = !enabled; if (!enabled) active = false; setChanged(); }

    /** Попадает ли точка в зону действующей глушилки (только сервер). Используется в Net. */
    public static boolean isJammed(Level l, BlockPos p) {
        for (TileJammer j : INDEX.in(l)) {
            double r = j.radius;
            if (j.active && j.worldPosition.distSqr(p) <= r * r) return true;
        }
        return false;
    }

    /** Серверный тик (ticker в BlockJammer). */
    public void tick() {
        boolean on = false;
        if (enabled) {
            int need = cost();
            if (energy.getEnergyStored() >= need) { energy.use(need); on = true; }
        }
        if (on != active) { active = on; setChanged(); }
    }

    @Override public void onLoad() { super.onLoad(); INDEX.add(this); }
    @Override public void setRemoved() { INDEX.remove(this); energyCap.invalidate(); super.setRemoved(); }
    @Override public void onChunkUnloaded() { INDEX.remove(this); super.onChunkUnloaded(); }

    @Override public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
        return cap == ForgeCapabilities.ENERGY ? energyCap.cast() : super.getCapability(cap, side);
    }

    @Override public void load(CompoundTag t) {
        super.load(t);
        radius = Math.max(MIN_RADIUS, Math.min(MAX_RADIUS, t.contains("radius") ? t.getInt("radius") : 32));
        enabled = t.getBoolean("enabled");
        active = t.getBoolean("active");
        energy.set(t.getInt("energy"));
    }

    @Override protected void saveAdditional(CompoundTag t) {
        super.saveAdditional(t);
        t.putInt("radius", radius);
        t.putBoolean("enabled", enabled);
        t.putBoolean("active", active);
        t.putInt("energy", energy.getEnergyStored());
    }
}
