package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Настройки» AndroCraft: сеть, экран (тема, яркость, акцент, AOD), безопасность (PIN), язык, система (жесты, экономия, обновление), о телефоне. */
final class AppSettings implements AndroOs.App {
    private static final int TOP = 50, STEP = 30, ROW_H = 26;
    private static final String[][] TITLE = {{"Настройки", "Settings"}, {"Экран", "Display"}, {"Безопасность", "Security"}, {"Язык", "Language"},
        {"Система", "System"}, {"О телефоне", "About phone"}, {"Обновление системы", "System update"}, {"Wi-Fi", "Wi-Fi"}};

    /** type: 0 - обычная строка, 1 - ползунок яркости, 2 - палитра акцента, 3 - только информация. */
    private static final class Row {
        final String label, value; final int type; final Runnable act;
        Row(String label, String value, int type, Runnable act) { this.label = label; this.value = value; this.type = type; this.act = act; }
    }

    private static String onOff(AndroOs os, boolean v) { return v ? os.t("Вкл", "On") : os.t("Выкл", "Off"); }

    private static Row gated(AndroOs os, String ru, String en, int minVer, boolean val, Runnable act) {
        if (os.ver < minVer) return new Row(os.t(ru, en), "Android " + minVer + "+", 3, null);
        return new Row(os.t(ru, en), onOff(os, val), 0, act);
    }

    private List<Row> rows(AndroOs os) {
        List<Row> r = new ArrayList<Row>();
        switch (os.page) {
            case 0 -> {
                r.add(new Row("Wi-Fi", os.wifi && !os.air ? (os.link.up() ? os.link.ssid : os.t("Вкл", "On")) : onOff(os, false), 0, () -> os.page = 7));
                r.add(new Row("Bluetooth", onOff(os, os.bt && !os.air), 0, () -> { if (!os.air) os.bt = !os.bt; }));
                r.add(new Row(os.t("Экран", "Display"), ">", 0, () -> os.page = 1));
                r.add(new Row(os.t("Безопасность", "Security"), ">", 0, () -> os.page = 2));
                r.add(new Row(os.t("Язык", "Language"), ">", 0, () -> os.page = 3));
                r.add(new Row(os.t("Система", "System"), ">", 0, () -> os.page = 4));
                r.add(new Row(os.t("О телефоне", "About phone"), ">", 0, () -> os.page = 5));
            }
            case 1 -> {
                if (os.ver < 10) r.add(new Row(os.t("Тёмная тема", "Dark theme"), "Android 10+", 3, null));
                else r.add(new Row(os.t("Тёмная тема", "Dark theme"), onOff(os, os.dark), 0, () -> os.dark = !os.dark));
                r.add(new Row(os.t("Яркость", "Brightness"), "", 1, null));
                if (os.ver < 13) r.add(new Row(os.t("Цвет акцента", "Accent color"), "Android 13+", 3, null));
                else r.add(new Row(os.t("Цвет акцента", "Accent color"), "", 2, null));
                r.add(gated(os, "Всегда вкл. экран", "Always-on display", 15, os.aod, () -> os.aod = !os.aod));
            }
            case 2 -> {
                r.add(new Row("PIN-код", onOff(os, !os.pin.isEmpty()), 0, () -> { if (os.pin.isEmpty()) os.startPinSet(); else os.pin = ""; }));
                if (!os.pin.isEmpty()) r.add(new Row(os.t("Сменить PIN", "Change PIN"), ">", 0, os::startPinSet));
            }
            case 3 -> {
                r.add(new Row("Русский", os.lang == 0 ? "*" : "", 0, () -> os.lang = 0));
                r.add(new Row("English", os.lang == 1 ? "*" : "", 0, () -> os.lang = 1));
            }
            case 4 -> {
                r.add(gated(os, "Навигация жестами", "Gesture navigation", 10, os.gest, () -> os.gest = !os.gest));
                r.add(gated(os, "Режим экономии", "Battery saver", 13, os.saver, () -> os.saver = !os.saver));
                r.add(new Row(os.t("Обновление ОС", "System update"), AndroOs.verName(os.ver), 0, () -> os.page = 6));
            }
            case 5 -> {
                String[] perf = {os.t("Плавно", "Smooth"), os.t("Лаги", "Laggy"), os.t("Сильные лаги", "Very laggy"), os.t("Сбои", "Unstable")};
                r.add(new Row(os.t("Модель", "Model"), os.caseName, 3, null));
                r.add(new Row(os.t("Номер", "Number"), PhoneData.fmt(os.number()), 3, null));
                r.add(new Row("SoC", os.socLabel, 3, null));
                r.add(new Row(os.t("ОЗУ", "RAM"), os.ramLabel + " (" + os.memUsedMB() / 1024 + "." + os.memUsedMB() % 1024 * 10 / 1024 + " GB)", 3, null));
                r.add(new Row(os.t("Память", "Storage"), os.romLabel, 3, null));
                r.add(new Row(os.t("Экран", "Screen"), os.scrLabel, 3, null));
                r.add(new Row(os.t("Батарея", "Battery"), os.batLabel, 3, null));
                r.add(new Row("AndroCraft", AndroOs.verName(os.ver), 3, null));
                r.add(new Row(os.t("Скорость", "Performance"), perf[os.lag()], 3, null));
            }
            case 7 -> {
                r.add(new Row("Wi-Fi", onOff(os, os.wifi && !os.air), 0, () -> { if (!os.air) os.wifi = !os.wifi; }));
                if (os.wifi && !os.air && os.ses != null) {
                    var pl = os.ses.player;
                    int n = 0;
                    for (Net.Ap ap : Net.scanAt(pl.level(), pl.getX(), pl.getY(), pl.getZ())) {
                        if (n++ >= 6) break;
                        boolean cur = ap.ssid.equals(os.wifiSsid);
                        String st = (ap.secured ? "# " : "") + NetLink.bars(ap.signal) + (cur ? (os.link.up() ? " *" : " !") : "");
                        r.add(new Row(ap.ssid, st, 0, () -> {
                            if (cur) { os.wifiSsid = ""; os.wifiPass = ""; }
                            else if (ap.secured) os.input(os.t("Пароль: ", "Password: ") + ap.ssid, "", 20, 2, p -> { os.wifiSsid = ap.ssid; os.wifiPass = p; os.markSave(); });
                            else { os.wifiSsid = ap.ssid; os.wifiPass = ""; }
                        }));
                    }
                    if (n == 0) r.add(new Row(os.t("Сети не найдены", "No networks found"), "", 3, null));
                } else r.add(new Row(os.t("Wi-Fi выключен", "Wi-Fi is off"), "", 3, null));
                if (!os.wifiSsid.isEmpty() && !os.link.up()) r.add(new Row(PixelScreen.fit(os.link.status, 150, 1, false), "", 3, null));
            }
            default -> {
                for (int v : AndroOs.VER) {
                    String[] st = {os.t("Плавно", "Smooth"), os.t("Лаги", "Laggy"), os.t("Сильные лаги", "Very laggy"), os.t("Сбои", "Unstable")};
                    r.add(new Row(AndroOs.verName(v), v == os.ver ? os.t("Текущая", "Current") : st[os.lagFor(v)], v == os.ver ? 3 : 0, () -> os.installVersion(v)));
                }
            }
        }
        return r;
    }

    private static int rowAt(int y, int n) {
        if (y < TOP || (y - TOP) % STEP >= ROW_H) return -1;
        int i = (y - TOP) / STEP;
        return i < n ? i : -1;
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        s.gradientV(0, 0, AndroOs.W, AndroOs.H, os.bg1(), os.bg2());
        s.fillRect(0, AndroOs.STATUS, AndroOs.W, 30, AndroIcons.colorOf("settings"));
        AndroIcons.draw(s, "settings", 8, AndroOs.STATUS + 4, 22);
        s.drawText(38, AndroOs.STATUS + 11, TITLE[os.page][os.lang], rgb(255, 255, 255), 1, true);
        List<Row> rows = rows(os);
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            int y = TOP + i * STEP;
            s.roundRect(8, y, 164, ROW_H, 8, os.panel());
            s.drawText(16, y + 9, PixelScreen.fit(r.label, r.type == 1 || r.type == 2 ? 70 : 100, 1, false), os.text());
            if (r.type == 1) {
                int kx = 90 + (os.bright - 20) * 70 / 80;
                s.roundRect(90, y + 11, 70, 4, 2, os.panel());
                s.roundRect(90, y + 11, Math.max(4, kx - 90), 4, 2, os.accent());
                s.roundRect(kx - 4, y + 7, 8, 12, 4, os.accent());
            } else if (r.type == 2) {
                for (int k = 0; k < 5; k++) {
                    int x = 92 + k * 15;
                    s.roundRect(x, y + 7, 12, 12, 6, AndroOs.accentOf(k, os.dark));
                    if (k == os.acc) s.roundRectOutline(x - 2, y + 5, 16, 16, 8, 1, os.text());
                }
            } else {
                s.drawTextRight(164, y + 9, PixelScreen.fit(r.value, 90, 1, false), r.type == 3 ? os.sub() : os.accent(), 1, false);
            }
        }
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        List<Row> rows = rows(os);
        int i = rowAt(y, rows.size());
        if (kind == 0) {
            os.a1 = i;
            if (i >= 0 && rows.get(i).type == 1) os.setBrightFromRange(20 + (x - 90) * 80 / 70);
        } else if (kind == 2) {
            if (os.a1 >= 0 && os.a1 < rows.size() && rows.get(os.a1).type == 1) os.setBrightFromRange(20 + (x - 90) * 80 / 70);
        } else if (kind == 1) {
            if (i >= 0 && i == os.a1) {
                Row r = rows.get(i);
                if (r.type == 2) os.acc = Math.max(0, Math.min(4, (x - 92) / 15));
                else if (r.type == 0 && r.act != null) r.act.run();
                os.markSave();
            } else if (os.a1 >= 0 && os.a1 < rows.size() && rows.get(os.a1).type == 1) os.markSave();
            os.a1 = -1;
        }
        return true;
    }

    @Override
    public boolean back(AndroOs os) {
        if (os.page == 0) return false;
        os.page = os.page == 6 ? 4 : 0;
        return true;
    }
}
