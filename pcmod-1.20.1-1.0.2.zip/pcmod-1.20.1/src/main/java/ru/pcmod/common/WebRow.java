package ru.pcmod.common;

/**
 * Строка страницы PC-Net: общая модель для встроенных сайтов, магазина и сайтов игроков (ПК и телефон рисуют её одним WebView).
 * kind: h заголовок, s подзаголовок, t текст, d серый, e ошибка, k успех, l ссылка, b кнопка, u пункт списка, r разделитель,
 * T строка таблицы (cells), i пиксельная картинка (pix, pw, ph), p превью товара (text - id), H шапка, F подвал.
 */
public final class WebRow {
    public final char kind;
    public final String text, target;
    /** Цвет ARGB (0 - по умолчанию для вида строки). */
    public int color;
    public boolean bold;
    /** Тон вместо цвета: 'd' серый, 'k' зелёный, 'e' красный, 0 - обычный. */
    public char tone;
    public String[] cells;
    /** Картинка: индексы палитры 0-15 построчно, -1 - прозрачно. */
    public byte[] pix;
    public int pw, ph;

    public WebRow(char kind, String text, String target) {
        this.kind = kind;
        this.text = text == null ? "" : text;
        this.target = target;
    }

    public WebRow color(int c) {
        this.color = c;
        return this;
    }

    public WebRow bold() {
        this.bold = true;
        return this;
    }

    public WebRow tone(char t) {
        this.tone = t;
        return this;
    }
}
