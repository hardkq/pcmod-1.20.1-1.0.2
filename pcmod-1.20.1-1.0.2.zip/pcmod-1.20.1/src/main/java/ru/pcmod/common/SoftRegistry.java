package ru.pcmod.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Реестр товаров магазина программ. Новый товар - одна строка register(...) ниже.
 * Цены и снятие с продажи читаются из config/pcmod_soft.cfg (/pcsoft reload).
 */
public final class SoftRegistry {
    private static final Logger LOG = LogManager.getLogger("pcmod");
    private static final Map<String, SoftItem> ITEMS = new LinkedHashMap<String, SoftItem>();
    private static final Map<String, Integer> PRICE = new HashMap<String, Integer>();
    private static final Set<String> OFF = new HashSet<String>();
    private static final int MAX_PRICE = 1000000;
    private static File file;

    static final String DEFAULTS =
            "# PC Mod: software store (soft.pc). One line per setting:\n"
            + "#   price <product id> <kons>     - price in kons, 0 = free\n"
            + "#   off <product id>              - hide the product from sale (installed copies keep working)\n"
            + "# Apply with /pcsoft reload (op).\n"
            + "price doom 0\n"
            + "price av 0\n"
            + "price snake 0\n"
            + "price dice 5\n"
            + "price mines 10\n"
            + "price sitebuilder 150\n";

    static {
        // ---- товары ПК, перенесённые из старых загрузок
        register(SoftItem.pc("doom", SoftItem.Type.PC_GAME, "DOOM (shareware)", "DOOM (shareware)")
                .noun("DOOM").desc("Классический шутер, версия shareware.", "Classic shooter, shareware version.")
                .req("WinCraft 11", 0, 0).preview("doom").app("doom").legacy()
                .setup(Desktop.SETUP_FILE, Desktop.SETUP_MAGIC, Desktop.SETUP_SIZE)
                .install(Desktop.DOOM_WAD, "IWAD DOOM1\n", Desktop.WAD_SIZE, Desktop.WAD_SIZE + "IWAD DOOM1\n".length() + 16 * 3,
                        "/games", Desktop.DOOM_DIR));
        register(SoftItem.pc("av", SoftItem.Type.PC_PROGRAM, "SafeGuard Antivirus", "SafeGuard Antivirus")
                .noun("Антивирус").desc("Находит и удаляет вирусы.", "Finds and removes viruses.")
                .req("WinCraft 11", 0, 0).preview("av").app("av").legacy().post(Antivirus::onInstalled)
                .setup(Antivirus.SETUP_FILE, Antivirus.SETUP_MAGIC, Antivirus.SETUP_SIZE)
                .install(Antivirus.FILE, Antivirus.CORE_TEXT, Antivirus.INSTALLED_SIZE, Antivirus.INSTALLED_SIZE + 16 * 4,
                        "/programs", Antivirus.DIR));
        // ---- платная программа ПК (приложение появится на этапе 7)
        register(SoftItem.pc("sitebuilder", SoftItem.Type.PC_PROGRAM, "Конструктор сайтов", "Site Builder")
                .noun("Конструктор сайтов").price(150)
                .desc("Редактор сайтов для PC-Net: разметка, предпросмотр, публикация.", "Site editor for PC-Net: markup, preview, publishing.")
                .req("WinCraft 11", 2048, 0).preview("sitebuilder").app("sitebuilder")
                .setup("sitebuilder_setup.exe", "MZ\nSITEBUILDER-SETUP 1.0\n", 16 * 1024)
                .install("/programs/sitebuilder/sitebuilder.sys", "SITEBUILDER-CORE 1.0\n", 24 * 1024, 24 * 1024 + 16 * 4,
                        "/programs", "/programs/sitebuilder"));
        // ---- бесплатная программа ПК: мобильный оператор (лицензия оператора покупается внутри программы)
        register(SoftItem.pc("mobileop", SoftItem.Type.PC_PROGRAM, "Мобильный оператор", "Mobile Operator")
                .noun("Мобильный оператор")
                .desc("Вышки, тарифы, абоненты и выпуск SIM-карт. Лицензия оператора - 2 500 000 К.", "Towers, tariffs, subscribers and SIM issue. Operator license: 2,500,000 K.")
                .req("WinCraft 11", 1024, 0).preview("mobileop").app("mobileop")
                .setup("mobileop_setup.exe", "MZ\nMOBILEOP-SETUP 1.0\n", 12 * 1024)
                .install("/programs/mobileop/mobileop.sys", "MOBILEOP-CORE 1.0\n", 16 * 1024, 16 * 1024 + 16 * 4,
                        "/programs", "/programs/mobileop"));
        // ---- приложения телефона (раньше AppStore.CAT)
        register(SoftItem.phone("snake", "Змейка", "Snake").desc("Классическая змейка", "Classic snake game").phoneReq(24, 8, 2048).preview("snake"));
        register(SoftItem.phone("dice", "Кубики", "Dice").desc("Кубики и монетка", "Dice and coin toss").phoneReq(12, 8, 2048).price(5).preview("dice"));
        register(SoftItem.phone("mines", "Сапёр", "Minesweeper").desc("Поле 8x8, 10 мин", "8x8 field, 10 mines").phoneReq(40, 10, 3072).price(10).preview("mines"));
    }

    private SoftRegistry() { }

    public static synchronized SoftItem register(SoftItem i) {
        ITEMS.put(i.id, i);
        return i;
    }

    public static synchronized SoftItem get(String id) { return id == null ? null : ITEMS.get(id); }

    /** Все товары, включая снятые с продажи. */
    public static synchronized List<SoftItem> allIncludingOff() { return new ArrayList<SoftItem>(ITEMS.values()); }

    /** Товары в продаже (все типы, если types пуст). */
    public static synchronized List<SoftItem> all(SoftItem.Type... types) {
        List<SoftItem> r = new ArrayList<SoftItem>();
        for (SoftItem i : ITEMS.values()) {
            if (OFF.contains(i.id)) continue;
            boolean ok = types.length == 0;
            for (SoftItem.Type t : types) if (t == i.type) ok = true;
            if (ok) r.add(i);
        }
        return r;
    }

    public static synchronized boolean onSale(SoftItem i) { return !OFF.contains(i.id); }

    public static synchronized int price(SoftItem i) {
        Integer p = PRICE.get(i.id);
        return p == null ? i.price : p.intValue();
    }

    /** Какой товар соответствует содержимому установщика (\"\" - никакой). */
    public static synchronized String setupId(String content) {
        if (content == null) return "";
        for (SoftItem i : ITEMS.values()) {
            if (i.isPc() && !i.setupMagic.isEmpty() && content.startsWith(i.setupMagic)) return i.id;
        }
        return "";
    }

    // ===================== конфиг =====================
    public static void setConfigDir(File dir) { file = new File(dir, "pcmod_soft.cfg"); }

    /** Читает конфиг (создаёт при первом запуске). Возвращает число применённых строк. */
    public static synchronized int load() {
        PRICE.clear();
        OFF.clear();
        if (file == null) return 0;
        if (!file.exists()) {
            try {
                File dir = file.getParentFile();
                if (dir != null) dir.mkdirs();
                Writer w = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
                try { w.write(DEFAULTS); } finally { w.close(); }
            } catch (Exception e) {
                LOG.warn("Cannot write " + file + ": " + e);
            }
        }
        int n = 0;
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
            try {
                String ln;
                while ((ln = r.readLine()) != null) {
                    ln = ln.trim();
                    if (ln.isEmpty() || ln.startsWith("#")) continue;
                    String[] p = ln.split("\\s+");
                    if (p.length < 2 || !ITEMS.containsKey(p[1])) {
                        LOG.warn("pcmod_soft.cfg: skipped line: " + ln);
                        continue;
                    }
                    if (p[0].equals("price") && p.length >= 3) {
                        try {
                            int v = Integer.parseInt(p[2]);
                            if (v < 0 || v > MAX_PRICE) throw new NumberFormatException();
                            PRICE.put(p[1], Integer.valueOf(v));
                            n++;
                        } catch (NumberFormatException e) {
                            LOG.warn("pcmod_soft.cfg: bad price: " + ln);
                        }
                    } else if (p[0].equals("off")) {
                        OFF.add(p[1]);
                        n++;
                    } else {
                        LOG.warn("pcmod_soft.cfg: skipped line: " + ln);
                    }
                }
            } finally {
                r.close();
            }
        } catch (Exception e) {
            LOG.warn("Cannot read " + file + ": " + e);
        }
        return n;
    }
}
