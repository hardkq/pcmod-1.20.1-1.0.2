package ru.pcmod.common;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import ru.pcmod.common.PartSpec.Cat;

/**
 * Предметы (не блоки). Список деталей и PartSpec взяты из ModItems 1.12.2 без изменений; id совпадают с именами
 * из прежнего registerItems (рецепты, модели, lang). Купюры - 7 отдельных предметов bill_1..bill_1000 (раньше метадата).
 * Предметы-блоки регистрирует {@link ModBlocks}. Вкладка творчества - {@link ModTabs}.
 */
public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "pcmod");

    /** Детали по id в порядке регистрации. */
    public static final Map<String, RegistryObject<Item>> PART = new LinkedHashMap<String, RegistryObject<Item>>();
    /** Характеристики деталей по id. */
    public static final Map<String, PartSpec> SPEC = new LinkedHashMap<String, PartSpec>();

    public static final RegistryObject<Item> CIRCUIT = ITEMS.register("circuit", () -> new Item(new Item.Properties()));

    private static void reg(String id, PartSpec spec) {
        SPEC.put(id, spec);
        PART.put(id, ITEMS.register(id, () -> new ItemPart(new Item.Properties().stacksTo(1), spec)));
    }

    static {
        reg("mb_basic", new PartSpec(Cat.MOTHERBOARD, "PCM-A100").socket(1).ramType(1).ramSlots(2));
        reg("mb_plus", new PartSpec(Cat.MOTHERBOARD, "PCM-B200").socket(1).ramType(1).ramSlots(4));
        reg("mb_mid", new PartSpec(Cat.MOTHERBOARD, "PCM-X300").socket(2).ramType(2).ramSlots(2));
        reg("mb_pro", new PartSpec(Cat.MOTHERBOARD, "PCM-X500").socket(2).ramType(2).ramSlots(4));
        reg("mb_elite", new PartSpec(Cat.MOTHERBOARD, "PCM-Z900").socket(3).ramType(3).ramSlots(4));
        reg("cpu_solo", new PartSpec(Cat.CPU, "Solo S1").socket(1).cores(1).ghz(1.6).watts(35));
        reg("cpu_dual", new PartSpec(Cat.CPU, "Duo C2").socket(1).cores(2).ghz(2.0).watts(65));
        reg("cpu_tri", new PartSpec(Cat.CPU, "Tri T3").socket(1).cores(3).ghz(2.6).watts(80));
        reg("cpu_quad", new PartSpec(Cat.CPU, "Quad Q4").socket(1).cores(4).ghz(3.0).watts(95));
        reg("cpu_hexa", new PartSpec(Cat.CPU, "Hexa X6").socket(2).cores(6).ghz(3.6).watts(105));
        reg("cpu_octa", new PartSpec(Cat.CPU, "Octa X8").socket(2).cores(8).ghz(4.2).watts(125));
        reg("cpu_deca", new PartSpec(Cat.CPU, "Deca Z10").socket(3).cores(10).ghz(4.8).watts(140));
        reg("cpu_dodeca", new PartSpec(Cat.CPU, "Dodeca Z12").socket(3).cores(12).ghz(5.2).watts(170));
        reg("cooler_stock", new PartSpec(Cat.COOLER, "Stock Cooler").cooling(70));
        reg("cooler_tower", new PartSpec(Cat.COOLER, "Tower Cooler").cooling(160));
        reg("cooler_liquid", new PartSpec(Cat.COOLER, "Liquid Cooler").cooling(260));
        reg("ram_d3_1", new PartSpec(Cat.RAM, "DDR3 1 GB").ramType(1).memMB(1024));
        reg("ram_d3_2", new PartSpec(Cat.RAM, "DDR3 2 GB").ramType(1).memMB(2048));
        reg("ram_d3_4", new PartSpec(Cat.RAM, "DDR3 4 GB").ramType(1).memMB(4096));
        reg("ram_d4_2", new PartSpec(Cat.RAM, "DDR4 2 GB").ramType(2).memMB(2048));
        reg("ram_d4_4", new PartSpec(Cat.RAM, "DDR4 4 GB").ramType(2).memMB(4096));
        reg("ram_d4_8", new PartSpec(Cat.RAM, "DDR4 8 GB").ramType(2).memMB(8192));
        reg("ram_d4_16", new PartSpec(Cat.RAM, "DDR4 16 GB").ramType(2).memMB(16384));
        reg("ram_d5_8", new PartSpec(Cat.RAM, "DDR5 8 GB").ramType(3).memMB(8192));
        reg("ram_d5_16", new PartSpec(Cat.RAM, "DDR5 16 GB").ramType(3).memMB(16384));
        reg("ram_d5_32", new PartSpec(Cat.RAM, "DDR5 32 GB").ramType(3).memMB(32768));
        reg("gpu_1", new PartSpec(Cat.GPU, "GT-100").tier(1).vram(256).watts(40).hash(2));
        reg("gpu_300", new PartSpec(Cat.GPU, "GT-300").tier(2).vram(512).watts(60).hash(6));
        reg("gpu_2", new PartSpec(Cat.GPU, "GT-500").tier(2).vram(1024).watts(90).hash(12));
        reg("gpu_700", new PartSpec(Cat.GPU, "GT-700").tier(3).vram(2048).watts(120).hash(24));
        reg("gpu_3", new PartSpec(Cat.GPU, "GT-900").tier(3).vram(4096).watts(160).hash(40));
        reg("gpu_1200", new PartSpec(Cat.GPU, "GX-1200").tier(3).vram(8192).watts(220).hash(70));
        reg("gpu_2000", new PartSpec(Cat.GPU, "GX-2000").tier(3).vram(16384).watts(300).hash(120));
        reg("hdd_250", new PartSpec(Cat.STORAGE, "HDD 250").storageKB(48).speed(1).hdd());
        reg("hdd", new PartSpec(Cat.STORAGE, "HDD 500").storageKB(64).speed(1).hdd());
        reg("hdd_1000", new PartSpec(Cat.STORAGE, "HDD 1000").storageKB(128).speed(1).hdd());
        reg("hdd_2000", new PartSpec(Cat.STORAGE, "HDD 2000").storageKB(256).speed(1).hdd());
        reg("hdd_4000", new PartSpec(Cat.STORAGE, "HDD 4000").storageKB(512).speed(2).hdd());
        reg("hdd_8000", new PartSpec(Cat.STORAGE, "HDD 8000 Enterprise").storageKB(768).speed(2).hdd());
        reg("ssd", new PartSpec(Cat.STORAGE, "SSD 2000").storageKB(256).speed(3));
        reg("nvme", new PartSpec(Cat.STORAGE, "NVMe X").storageKB(1024).speed(6));
        reg("psu_300", new PartSpec(Cat.PSU, "PSU 300W").watts(300));
        reg("psu_500", new PartSpec(Cat.PSU, "PSU 500W").watts(500));
        reg("psu_750", new PartSpec(Cat.PSU, "PSU 750W").watts(750));
        reg("psu_1000", new PartSpec(Cat.PSU, "PSU 1000W").watts(1000));
        reg("install_disk", new PartSpec(Cat.MEDIA, "PCOS Installer"));
        reg("install_disk_pixel", new PartSpec(Cat.MEDIA, "PixelOS Installer").os("pixel"));
        reg("install_disk_wincraft", new PartSpec(Cat.MEDIA, "WinCraft 11 Installer").os(WinSpec.ID));
        reg("virus_disk", new PartSpec(Cat.DATA, "Virus Disk"));
        reg("wifi_module", new PartSpec(Cat.NET, "Wi-Fi Module"));
        // комплектующие телефона (этап 2); рецепты - только из материалов мода (data/pcmod/recipes/ph_*.json)
        reg("ph_soc_l100", new PartSpec(Cat.PH_SOC, "Andro L100").socket(1).cores(4).ghz(1.4).tier(1).watts(3));
        reg("ph_soc_m300", new PartSpec(Cat.PH_SOC, "Andro M300").socket(1).cores(6).ghz(1.9).tier(2).watts(4));
        reg("ph_soc_m500", new PartSpec(Cat.PH_SOC, "Andro M500").socket(2).cores(8).ghz(2.2).tier(3).watts(5));
        reg("ph_soc_p700", new PartSpec(Cat.PH_SOC, "Andro P700").socket(2).cores(8).ghz(2.8).tier(4).watts(6));
        reg("ph_soc_x900", new PartSpec(Cat.PH_SOC, "Andro X900").socket(3).cores(8).ghz(3.2).tier(5).watts(7));
        reg("ph_soc_x1200", new PartSpec(Cat.PH_SOC, "Andro X1200").socket(3).cores(10).ghz(3.6).tier(6).watts(8));
        reg("ph_ram_lp3_2", new PartSpec(Cat.PH_RAM, "LPDDR3 2 GB").ramType(1).memMB(2048));
        reg("ph_ram_lp4_4", new PartSpec(Cat.PH_RAM, "LPDDR4 4 GB").ramType(2).memMB(4096));
        reg("ph_ram_lp4_6", new PartSpec(Cat.PH_RAM, "LPDDR4 6 GB").ramType(2).memMB(6144));
        reg("ph_ram_lp5_8", new PartSpec(Cat.PH_RAM, "LPDDR5 8 GB").ramType(3).memMB(8192));
        reg("ph_ram_lp5_12", new PartSpec(Cat.PH_RAM, "LPDDR5 12 GB").ramType(3).memMB(12288));
        reg("ph_ram_lp5_16", new PartSpec(Cat.PH_RAM, "LPDDR5 16 GB").ramType(3).memMB(16384));
        reg("ph_rom_16", new PartSpec(Cat.PH_ROM, "eMMC 16 GB").gb(16).speed(1));
        reg("ph_rom_64", new PartSpec(Cat.PH_ROM, "UFS 2.1 64 GB").gb(64).speed(2));
        reg("ph_rom_128", new PartSpec(Cat.PH_ROM, "UFS 3.1 128 GB").gb(128).speed(3));
        reg("ph_rom_256", new PartSpec(Cat.PH_ROM, "UFS 4.0 256 GB").gb(256).speed(4));
        reg("ph_rom_512", new PartSpec(Cat.PH_ROM, "UFS 4.0 512 GB").gb(512).speed(5));
        reg("ph_batt_2500", new PartSpec(Cat.PH_BATT, "2500 mAh").mah(2500).size(1));
        reg("ph_batt_3500", new PartSpec(Cat.PH_BATT, "3500 mAh").mah(3500).size(2));
        reg("ph_batt_4500", new PartSpec(Cat.PH_BATT, "4500 mAh").mah(4500).size(2));
        reg("ph_batt_6000", new PartSpec(Cat.PH_BATT, "6000 mAh").mah(6000).size(3));
        reg("ph_screen_5_hd", new PartSpec(Cat.PH_SCREEN, "5.0\" 720x1280").size(1).inch(5.0).res(720, 1280).hz(60));
        reg("ph_screen_6_hd", new PartSpec(Cat.PH_SCREEN, "6.1\" 720x1560").size(2).inch(6.1).res(720, 1560).hz(60));
        reg("ph_screen_6_fhd", new PartSpec(Cat.PH_SCREEN, "6.4\" 1080x2340").size(2).inch(6.4).res(1080, 2340).hz(90));
        reg("ph_screen_6_amoled", new PartSpec(Cat.PH_SCREEN, "6.5\" 1080x2400").size(2).inch(6.5).res(1080, 2400).hz(120));
        reg("ph_screen_7_qhd", new PartSpec(Cat.PH_SCREEN, "6.8\" 1440x3120").size(3).inch(6.8).res(1440, 3120).hz(120));
        reg("ph_cam_8", new PartSpec(Cat.PH_CAM, "8 MP").mp(8));
        reg("ph_cam_13", new PartSpec(Cat.PH_CAM, "13 MP").mp(13));
        reg("ph_cam_48", new PartSpec(Cat.PH_CAM, "48 MP").mp(48));
        reg("ph_cam_108", new PartSpec(Cat.PH_CAM, "108 MP").mp(108));
        reg("ph_board_lite", new PartSpec(Cat.PH_BOARD, "PB-100").socket(1).ramType(1).ramSlots(1).size(1).net(1));
        reg("ph_board_std", new PartSpec(Cat.PH_BOARD, "PB-200").socket(1).ramType(2).ramSlots(2).size(2).net(2));
        reg("ph_board_mid", new PartSpec(Cat.PH_BOARD, "PB-300").socket(2).ramType(2).ramSlots(2).size(2).net(3));
        reg("ph_board_pro", new PartSpec(Cat.PH_BOARD, "PB-500").socket(2).ramType(3).ramSlots(2).size(3).net(3));
        reg("ph_board_ultra", new PartSpec(Cat.PH_BOARD, "PB-900").socket(3).ramType(3).ramSlots(2).size(3).net(3));
        reg("ph_case_mini", new PartSpec(Cat.PH_CASE, "Mini M1").size(1).mah(3000));
        reg("ph_case_classic", new PartSpec(Cat.PH_CASE, "Classic C2").size(2).mah(4500));
        reg("ph_case_slim", new PartSpec(Cat.PH_CASE, "Slim S2").size(2).mah(3500));
        reg("ph_case_max", new PartSpec(Cat.PH_CASE, "Max X3").size(3).mah(6000));
        reg("ph_case_flagship", new PartSpec(Cat.PH_CASE, "Flagship Z3").size(3).mah(6000));
        reg("ph_modem_wifi", new PartSpec(Cat.PH_MODEM, "Wi-Fi Module").net(1));
        reg("ph_modem_4g", new PartSpec(Cat.PH_MODEM, "4G Modem").net(2));
        reg("ph_modem_5g", new PartSpec(Cat.PH_MODEM, "5G Modem").net(3));
    }

    /** Купюры «Конс» по номиналам {@link Bank#DENOM}: bill_1, bill_5, ... bill_1000. */
    @SuppressWarnings("unchecked")
    public static final RegistryObject<Item>[] BILLS = new RegistryObject[Bank.DENOM.length];
    static {
        for (int i = 0; i < Bank.DENOM.length; i++) {
            final int idx = i;
            BILLS[i] = ITEMS.register("bill_" + Bank.DENOM[i], () -> new ItemBill(new Item.Properties(), idx));
        }
    }

    // провода между коннекторами (провисают дугой, как в Create: Power Grid)
    public static final RegistryObject<Item> WIRE_NET     = ITEMS.register("wire_net",     () -> new ItemWire(new Item.Properties(), Ports.NET));
    public static final RegistryObject<Item> WIRE_VIDEO   = ITEMS.register("wire_video",   () -> new ItemWire(new Item.Properties(), Ports.VIDEO));
    public static final RegistryObject<Item> CABLE_PLIERS = ITEMS.register("cable_pliers", () -> new ItemPliers(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FIBER_SPOOL  = ITEMS.register("fiber_spool",  () -> new ItemFiberSpool(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> PHONE = ITEMS.register("phone", () -> new ItemPhone(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> USB_CABLE = ITEMS.register("usb_cable", () -> new ItemUsbCable(new Item.Properties().stacksTo(16)));

    // --- Этап 1: сотовая сеть ---
    public static final RegistryObject<Item> SIM_CARD     = ITEMS.register("sim_card",     () -> new ItemSimCard(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> TOWER_LINKER = ITEMS.register("tower_linker", () -> new ItemTowerLinker(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ANTENNA      = ITEMS.register("antenna",      () -> new ItemAntenna(new Item.Properties()));

    /** Материалы телефонов (сырьё, выпадение руд, полуфабрикаты): простые предметы без PartSpec. */
    public static final String[] MATERIALS = {
        "silicon", "lithium", "copper_wire", "gold_wire", "plastic", "glass_panel", "rare_earth",
        "raw_silicon", "raw_lithium", "oil_shale",
        "silicon_wafer", "memory_die", "lithium_cell", "pcb_blank", "microchip", "microchip_adv",
        "case_blank", "case_blank_premium", "sensor", "lens", "glass_matrix", "flex_cable", "antenna_coil", "etherite"
    };
    public static final Map<String, RegistryObject<Item>> MAT = new LinkedHashMap<String, RegistryObject<Item>>();
    static {
        for (final String id : MATERIALS) MAT.put(id, ITEMS.register(id, () -> new Item(new Item.Properties())));
    }

    /** Материал по id (например "silicon", "microchip"). */
    public static Item mat(String id) {
        return MAT.get(id).get();
    }

    /** Деталь по id (например "nvme", "mb_basic"). */
    public static Item part(String id) {
        return PART.get(id).get();
    }

    public static Item bill(int denomIndex) {
        return BILLS[Math.max(0, Math.min(BILLS.length - 1, denomIndex))].get();
    }

    public static void register(IEventBus bus) { ITEMS.register(bus); }
    private ModItems() {}
}
