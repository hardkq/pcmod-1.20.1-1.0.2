package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Страница: строки, фон (ARGB, 0 - по теме) и название. */
public final class WebPage {
    public final List<WebRow> rows;
    public int bg;
    public String title = "";
    /** Цена доступа к странице в консах (директива @price, 0 - бесплатно). */
    public int price;

    public WebPage(List<WebRow> rows) {
        this.rows = rows == null ? new ArrayList<WebRow>() : rows;
    }

    public static WebPage of(List<WebRow> rows) { return new WebPage(rows); }
}
