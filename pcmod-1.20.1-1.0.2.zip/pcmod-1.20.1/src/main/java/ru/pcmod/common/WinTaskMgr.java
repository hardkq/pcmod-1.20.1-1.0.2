package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Диспетчер задач: процессы (окна) с нагрузкой на ЦП и память, снятие задач, графики производительности. */
public final class WinTaskMgr implements WinApp {
    private static final int TAB = 16, HEAD = 12, IH = 11, FOOT = 18, N = 60;
    private static final int[] COL = {0xFF117DBB, 0xFF8B12AE, 0xFF4DA600, 0xFF117DBB};
    private static final String[] RES = {"ЦП", "Память", "Диск", "Графика"};
    private final WinSoft s;
    private final int[][] hist = new int[4][N];
    private int tab, sel = -1, res, scroll, hover = -1, aw = 250, ah = 134;
    private long now = -1;
    private final int[] cur = new int[4];
    private int diskKick;

    public WinTaskMgr(WinSoft s) {
        this.s = s;
    }

    @Override public String title() { return "Диспетчер задач"; }

    @Override public String id() { return "taskmgr"; }

    @Override public int minW() { return 200; }

    @Override public int minH() { return 120; }

    // ------------------------------------------------------------------ данные
    private List<WinSoft.Proc> procs() { return s.ctx.procs(); }

    private int rows() { return Math.max(1, (ah - TAB - HEAD - FOOT) / IH); }

    private void sample(long t) {
        WinSpec.Hw hw = s.host.hw();
        List<String> ids = new ArrayList<String>();
        for (WinSoft.Proc p : procs()) ids.add(p.id);
        int[] l = WinSpec.load(hw, s.perf, ids);
        long sec = t / 20;
        int j = (int) (((sec * 2654435761L) >>> 9) % 5) - 2;
        cur[0] = Math.max(1, Math.min(100, l[0] + j));
        cur[1] = Math.max(0, Math.min(hw.ramMB, l[1] + j * 9));
        diskKick = Math.max(0, diskKick - 1);
        cur[2] = Math.max(0, Math.min(100, (int) (((sec * 40503L) >>> 3) % 3) + diskKick * 12));
        cur[3] = Math.max(0, Math.min(100, l[2] + (j > 1 ? 1 : 0)));
        for (int r = 0; r < 4; r++) {
            System.arraycopy(hist[r], 1, hist[r], 0, N - 1);
            hist[r][N - 1] = r == 1 ? cur[1] * 100 / Math.max(1, hw.ramMB) : cur[r];
        }
    }

    @Override
    public boolean tick(long t) {
        boolean first = now < 0;
        long old = now;
        now = t;
        if (first) {
            for (int i = 0; i < N; i++) {
                sample(t);
            }
            return true;
        }
        if (t / 20 == old / 20) return false;
        sample(t);
        return true;
    }

    private static String pct(double v) {
        return v >= 10 || v == 0 ? Math.round(v) + "%" : String.format("%.1f%%", v).replace('.', ',');
    }

    // ------------------------------------------------------------------ рисование
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        if (now < 0) tick(s.host.time());
        String[] tn = {"Процессы", "Производительность"};
        int tx = x + 4;
        for (int i = 0; i < 2; i++) {
            int tw = PixelScreen.textWidth(tn[i]) + 14;
            WinSoft.flat(p, th, tx, y + 2, tw, TAB - 3, tn[i], hover == 50 + i, false);
            if (tab == i) p.roundRect(tx + 5, y + TAB - 2, tw - 10, 2, 1, th.accent());
            tx += tw + 2;
        }
        p.hline(x, y + TAB, w, th.border());
        if (tab == 0) drawProcs(p, th, x, y, w, h);
        else drawPerf(p, th, x, y, w, h);
    }

    private void drawProcs(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        WinSpec.Hw hw = s.host.hw();
        int by = y + TAB + 1;
        p.fillRect(x, by, w, h - TAB - 1 - FOOT, th.surface());
        p.drawText(x + 8, by + 2, "Имя", th.sub());
        p.drawTextRight(x + w - 62, by + 2, "ЦП", th.sub(), 1, false);
        p.drawTextRight(x + w - 12, by + 2, "Память", th.sub(), 1, false);
        p.hline(x, by + HEAD - 1, w, th.border());
        List<WinSoft.Proc> ps = procs();
        List<Object[]> rows = new ArrayList<Object[]>();
        rows.add(new Object[] {"Приложения (" + ps.size() + ")", null});
        for (WinSoft.Proc pr : ps) rows.add(new Object[] {pr.title, pr});
        rows.add(new Object[] {"Фоновые процессы (" + WinSpec.SYS_NAMES.length + ")", null});
        for (int i = 0; i < WinSpec.SYS_NAMES.length; i++) rows.add(new Object[] {WinSpec.SYS_NAMES[i], i});
        int vis = rows(), max = Math.max(0, rows.size() - vis);
        scroll = Math.min(scroll, max);
        p.pushClip(x, by + HEAD, w, vis * IH);
        for (int i = 0; i < vis && scroll + i < rows.size(); i++) {
            Object[] r = rows.get(scroll + i);
            int ry = by + HEAD + i * IH;
            WinSoft.Proc pr = r[1] instanceof WinSoft.Proc ? (WinSoft.Proc) r[1] : null;
            if (r[1] == null) {
                p.drawText(x + 8, ry + 1, (String) r[0], th.accent());
                continue;
            }
            int[] c = pr != null ? WinSpec.cost(pr.id) : new int[] {WinSpec.SYS_RAM[(Integer) r[1]], WinSpec.SYS_CPU[(Integer) r[1]]};
            if (pr != null && pr.app == selApp()) p.roundRect(x + 3, ry, w - 9, IH - 1, 2, PixelScreen.alpha(th.accent(), 0x48));
            else if (hover == 100 + scroll + i) p.roundRect(x + 3, ry, w - 9, IH - 1, 2, th.hover());
            String t = (String) r[0] + (pr != null && pr.min ? " (свёрнуто)" : "");
            p.drawText(x + 12, ry + 1, PixelScreen.fit(t, w - 90, 1, false), th.text());
            double cp = WinSpec.cpuShare(hw, c[1]);
            int heat = (int) Math.min(0x50, cp * 8);
            p.fillRect(x + w - 76, ry, 26, IH - 1, PixelScreen.alpha(0xFFFFB900, heat));
            p.drawTextRight(x + w - 52, ry + 1, pct(cp), th.text(), 1, false);
            p.drawTextRight(x + w - 12, ry + 1, c[0] + " МБ", th.text(), 1, false);
        }
        p.popClip();
        WinSoft.scrollbar(p, th, x + w - 5, by + HEAD + 1, vis * IH - 2, rows.size(), vis, scroll);
        int fy = y + h - FOOT;
        p.fillRect(x, fy, w, FOOT, th.bg());
        p.hline(x, fy, w, th.border());
        p.drawText(x + 8, fy + 5, "ЦП " + cur[0] + "%   Память " + cur[1] * 100 / Math.max(1, hw.ramMB) + "%", th.sub());
        WinUi.Button b = new WinUi.Button("Снять задачу", x + w - 78, fy + 2, 72, true);
        b.h = 14;
        b.enabled = selApp() != null;
        b.hover = hover == 60;
        b.draw(p, th);
    }

    private WinApp selApp;

    private WinApp selApp() {
        if (selApp == null) return null;
        for (WinSoft.Proc pr : procs()) if (pr.app == selApp) return selApp;
        selApp = null;
        return null;
    }

    private void drawPerf(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        WinSpec.Hw hw = s.host.hw();
        int top = y + TAB + 1, lw = 76;
        p.fillRect(x, top, w, h - TAB - 1, th.surface());
        p.vline(x + lw, top, h - TAB - 1, th.border());
        String[] val = {cur[0] + "%", cur[1] * 100 / Math.max(1, hw.ramMB) + "%", cur[2] + "%", cur[3] + "%"};
        String[] sub = {"", cur[1] + "/" + hw.ramMB + " МБ", "", ""};
        for (int i = 0; i < 4; i++) {
            int ry = top + 3 + i * 28;
            if (i == res) p.roundRect(x + 3, ry, lw - 6, 26, 3, th.dark ? 0xFF383838 : 0xFFE6E6E6);
            else if (hover == 70 + i) p.roundRect(x + 3, ry, lw - 6, 26, 3, th.hover());
            graph(p, th, x + 6, ry + 3, 22, 20, hist[i], COL[i], false);
            p.drawText(x + 32, ry + 3, RES[i], th.text());
            p.drawText(x + 32, ry + 13, val[i], th.sub());
        }
        int rx = x + lw + 8, rw = w - lw - 14;
        p.drawText(rx, top + 3, RES[res], th.text(), 1, true);
        String name = res == 0 ? hw.cpu : res == 1 ? WinSpec.mem(hw.ramMB) : res == 2 ? hw.drive : hw.gpu;
        p.drawTextRight(x + w - 6, top + 3, PixelScreen.fit(name, rw - 50, 1, false), th.sub(), 1, false);
        String[][] info = info(hw);
        int gh = Math.max(18, h - TAB - 1 - 14 - 12 - info.length * 10 - 5);
        graph(p, th, rx, top + 14, rw, gh, hist[res], COL[res], true);
        p.drawText(rx, top + 16 + gh, "60 секунд", th.sub());
        p.drawTextRight(rx + rw, top + 16 + gh, res == 1 ? "100% = " + WinSpec.mem(hw.ramMB) : "100%", th.sub(), 1, false);
        int iy = top + 28 + gh;
        for (int i = 0; i < info.length; i++) {
            p.drawText(rx, iy + i * 10, info[i][0], th.sub());
            p.drawText(rx + 78, iy + i * 10, PixelScreen.fit(info[i][1], rw - 78, 1, false), th.text());
        }
    }

    private String[][] info(WinSpec.Hw hw) {
        long sec = s.host.uptime() / 20, nproc = procs().size() + WinSpec.SYS_NAMES.length;
        String up = String.format("%d:%02d:%02d", sec / 3600, sec / 60 % 60, sec % 60);
        long[] d = s.host.disk();
        if (res == 0) {
            return new String[][] {{"Загрузка", cur[0] + "%"}, {"Скорость", String.format("%.1f ГГц", hw.ghz).replace('.', ',')},
                    {"Ядра", String.valueOf(hw.cores)}, {"Процессы", String.valueOf(nproc)}, {"Температура", s.host.temp() + " °C"}, {"Время работы", up}};
        }
        if (res == 1) {
            int sys = WinSpec.sum(WinSpec.SYS_RAM);
            return new String[][] {{"Используется", cur[1] + " МБ"}, {"Доступно", Math.max(0, hw.ramMB - cur[1]) + " МБ"},
                    {"Система", sys + " МБ"}, {"Приложения", Math.max(0, cur[1] - sys) + " МБ"}, {"Всего", hw.ramMB + " МБ"}};
        }
        if (res == 2) {
            return new String[][] {{"Активность", cur[2] + "%"}, {"Ёмкость", WinSoft.bytesText(d[0])}, {"Система", WinSoft.bytesText(d[1])},
                    {"Файлы", WinSoft.bytesText(d[2])}, {"Свободно", WinSoft.bytesText(s.fs.free())}};
        }
        return new String[][] {{"Загрузка", cur[3] + "%"}, {"Видеопамять", WinSpec.mem(hw.vramMB)}, {"Уровень GT", String.valueOf(hw.gpuTier)},
                {"Эффекты", s.perf.label}, {"Кадров/с", String.valueOf(20 / s.perf.animDiv)}};
    }

    private static void graph(PixelScreen p, WinTheme th, int x, int y, int w, int h, int[] v, int c, boolean grid) {
        p.rect(x, y, w, h, 1, PixelScreen.alpha(c, 0xC0));
        p.fillRect(x + 1, y + 1, w - 2, h - 2, PixelScreen.alpha(c, th.dark ? 0x18 : 0x0C));
        if (grid) for (int i = 1; i < 4; i++) p.hline(x + 1, y + h * i / 4, w - 2, PixelScreen.alpha(c, 0x30));
        int iw = w - 2, ih = h - 2;
        for (int i = 0; i < iw; i++) {
            int k = i * N / iw, a = v[k], bh = a * ih / 100;
            if (a > 0) bh = Math.max(1, bh);
            p.fillRect(x + 1 + i, y + h - 1 - bh, 1, bh, PixelScreen.alpha(c, 0x60));
            if (bh > 0) p.pixel(x + 1 + i, y + h - 1 - bh, c);
        }
    }

    // ------------------------------------------------------------------ ввод
    private int hit(int rx, int ry) {
        if (rx < 0 || ry < 0) return -1;
        if (ry < TAB) {
            int tx = 4;
            for (int i = 0; i < 2; i++) {
                int tw = PixelScreen.textWidth(i == 0 ? "Процессы" : "Производительность") + 14;
                if (WinSoft.in(rx, ry, tx, 2, tw, TAB - 3)) return 50 + i;
                tx += tw + 2;
            }
            return -1;
        }
        if (tab == 0) {
            if (WinSoft.in(rx, ry, aw - 78, ah - FOOT + 2, 72, 14)) return 60;
            int i = scroll + (ry - TAB - 1 - HEAD) / IH;
            if (ry >= TAB + 1 + HEAD && ry < ah - FOOT) return 100 + i;
            return -1;
        }
        for (int i = 0; i < 4; i++) if (WinSoft.in(rx, ry, 3, TAB + 4 + i * 28, 70, 26)) return 70 + i;
        return -1;
    }

    private int total() { return procs().size() + 2 + WinSpec.SYS_NAMES.length; }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int hv = hit(rx, ry);
        boolean dirty = hv != hover;
        hover = hv;
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            if (tab != 0) return dirty;
            int ns = Math.max(0, Math.min(Math.max(0, total() - rows()), scroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -2 : 2)));
            if (ns == scroll) return dirty;
            scroll = ns;
            return true;
        }
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return dirty;
        if (hv >= 50 && hv < 52) {
            tab = hv - 50;
        } else if (hv == 60) {
            if (selApp() != null) {
                s.ctx.kill(selApp);
                selApp = null;
                diskKick = 2;
            }
        } else if (hv >= 70 && hv < 74) {
            res = hv - 70;
        } else if (hv >= 100) {
            int i = hv - 100 - 1;
            List<WinSoft.Proc> ps = procs();
            selApp = i >= 0 && i < ps.size() ? ps.get(i).app : null;
        }
        return true;
    }

    @Override
    public boolean key(char c, int key) {
        if (tab != 0 || selApp() == null) return false;
        if (key == WinSoft.K_DEL) {
            s.ctx.kill(selApp);
            selApp = null;
            return true;
        }
        return false;
    }
}
