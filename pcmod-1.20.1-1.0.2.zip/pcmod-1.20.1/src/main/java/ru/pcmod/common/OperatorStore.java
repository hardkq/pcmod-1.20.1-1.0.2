package ru.pcmod.common;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.LongArrayTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.server.ServerLifecycleHooks;

/**
 * Хранилище операторов связи (SavedData основного мира, как Bank).
 * Оператор: id, name, owner (UUID владельца строкой = счёт в Bank), color, balance, towers, subscribers (UUID игрока -> SimRecord), tariffs.
 * Деньги абонентов идут со счёта Bank на balance оператора; владелец забирает их через payout().
 */
public class OperatorStore extends SavedData {
    public static final String ID = "pcmod_operators";
    public static final long DAY = 24000L;
    public static final int MAX_TARIFFS = 16, MAX_NAME = 24, MAX_BUY_MB = 100000;

    public static final class Tariff {
        public String id = "", name = "";
        public int activationCost, mbPrice, dailyFee;
    }

    public static final class SimRecord {
        public int phoneNumber;
        public String tariffId = "";
        public int dataBalance;
        public long lastDailyCharge;
        /** SIM заблокирована за неуплату ежедневного платежа. */
        public boolean blocked;
    }

    public static final class Operator {
        public UUID id;
        public String name = "", owner = "";
        public int color;
        public long balance;
        public final List<BlockPos> towers = new ArrayList<>();
        public final Map<UUID, SimRecord> subscribers = new LinkedHashMap<>();
        public final List<Tariff> tariffs = new ArrayList<>();

        public Tariff tariff(String tid) {
            for (Tariff t : tariffs) if (t.id.equals(tid)) return t;
            return null;
        }
    }

    private final Map<UUID, Operator> ops = new LinkedHashMap<>();
    private long lastDay = -1;

    public OperatorStore() {}

    /** Хранилище основного мира или null, если сервер ещё не запущен. */
    public static OperatorStore get() {
        MinecraftServer srv = ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return null;
        ServerLevel w = srv.overworld();
        return w == null ? null : w.getDataStorage().computeIfAbsent(OperatorStore::load, OperatorStore::new, ID);
    }

    // ===================== операторы =====================
    public Operator createOperator(String name, String owner, int color) {
        Operator o = new Operator();
        o.id = UUID.randomUUID();
        o.name = clip(name);
        o.owner = owner == null ? "" : owner;
        o.color = color & 0xFFFFFF;
        ops.put(o.id, o);
        setDirty();
        return o;
    }

    public Operator get(UUID id) { return id == null ? null : ops.get(id); }

    /** Оператор по id-строке (как хранится в NBT SIM/вышки/сервера) или null. */
    public Operator get(String id) {
        try { return id == null || id.isEmpty() ? null : ops.get(UUID.fromString(id)); }
        catch (IllegalArgumentException e) { return null; }
    }

    public Operator byOwner(String owner) {
        for (Operator o : ops.values()) if (o.owner.equals(owner)) return o;
        return null;
    }

    public Operator byTower(BlockPos p) {
        for (Operator o : ops.values()) if (o.towers.contains(p)) return o;
        return null;
    }

    public List<Operator> all() { return new ArrayList<>(ops.values()); }

    public void rename(UUID op, String name) {
        Operator o = get(op);
        if (o != null) { o.name = clip(name); setDirty(); }
    }

    private static String clip(String s) {
        s = s == null ? "" : s.trim();
        return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s;
    }

    // ===================== вышки =====================
    public boolean addTower(UUID op, BlockPos pos) {
        Operator o = get(op);
        if (o == null) return false;
        BlockPos p = pos.immutable();
        Operator other = byTower(p);
        if (other != null && other != o) other.towers.remove(p);
        if (!o.towers.contains(p)) o.towers.add(p);
        setDirty();
        return true;
    }

    public boolean removeTower(UUID op, BlockPos pos) {
        Operator o = get(op);
        boolean r = o != null && o.towers.remove(pos);
        if (r) setDirty();
        return r;
    }

    // ===================== тарифы =====================
    /** @return новый тариф или null (оператор не найден, лимит, неверные значения). */
    public Tariff addTariff(UUID op, String name, int activationCost, int mbPrice, int dailyFee) {
        Operator o = get(op);
        if (o == null || o.tariffs.size() >= MAX_TARIFFS || clip(name).isEmpty()) return null;
        if (activationCost < 0 || mbPrice < 0 || dailyFee < 0) return null;
        Tariff t = new Tariff();
        t.id = UUID.randomUUID().toString().substring(0, 8);
        t.name = clip(name);
        t.activationCost = activationCost;
        t.mbPrice = mbPrice;
        t.dailyFee = dailyFee;
        o.tariffs.add(t);
        setDirty();
        return t;
    }

    /** Тариф с абонентами удалить нельзя. */
    public boolean removeTariff(UUID op, String tariffId) {
        Operator o = get(op);
        Tariff t = o == null ? null : o.tariff(tariffId);
        if (t == null) return false;
        for (SimRecord r : o.subscribers.values()) if (r.tariffId.equals(tariffId)) return false;
        o.tariffs.remove(t);
        setDirty();
        return true;
    }

    // ===================== абоненты =====================
    public SimRecord subscriber(UUID op, UUID player) {
        Operator o = get(op);
        return o == null ? null : o.subscribers.get(player);
    }

    /** Абонент с рабочей (не заблокированной) SIM. */
    public boolean isActiveSubscriber(UUID op, UUID player) {
        SimRecord r = subscriber(op, player);
        return r != null && !r.blocked;
    }

    /**
     * Подключить игрока к тарифу. Новый абонент или смена тарифа списывают activationCost со счёта игрока в Bank.
     * Повторный выпуск на том же тарифе бесплатен.
     * @return null при успехе, иначе текст ошибки.
     */
    public String addSubscriber(UUID op, UUID player, String tariffId, long day) {
        Operator o = get(op);
        if (o == null) return "Operator not found";
        Tariff t = o.tariff(tariffId);
        if (t == null) return "Tariff not found";
        SimRecord r = o.subscribers.get(player);
        if (r != null && r.tariffId.equals(tariffId)) return null;
        if (!charge(o, player, t.activationCost, "SIM activation " + o.name)) return "Not enough kons: need " + Bank.fmt(t.activationCost);
        if (r == null) {
            r = new SimRecord();
            r.phoneNumber = freeNumber();
            r.lastDailyCharge = day;
            o.subscribers.put(player, r);
        }
        r.tariffId = tariffId;
        r.blocked = false;
        setDirty();
        return null;
    }

    /** Новая SIM-карта по записи абонента (NBT: operatorId, phoneNumber, dataBalance, tariffId) или EMPTY. */
    public ItemStack issueSimCard(UUID op, UUID player) {
        SimRecord r = subscriber(op, player);
        if (r == null) return ItemStack.EMPTY;
        ItemStack s = new ItemStack(ModItems.SIM_CARD.get());
        writeSim(s, op, r);
        return s;
    }

    public static void writeSim(ItemStack s, UUID op, SimRecord r) {
        ItemSimCard.setOperatorId(s, op.toString());
        OperatorStore st = get();
        Operator o = st == null ? null : st.get(op);
        if (o != null) ItemSimCard.setOperatorName(s, o.name);
        ItemSimCard.setPhoneNumber(s, r.phoneNumber);
        ItemSimCard.setDataBalance(s, r.dataBalance);
        ItemSimCard.setTariffId(s, r.tariffId);
    }

    /** Запись абонента, которой соответствует SIM (оператор и номер совпадают) или null. */
    public SimRecord recordFor(ItemStack sim, UUID player) {
        if (sim.isEmpty() || !(sim.getItem() instanceof ItemSimCard)) return null;
        Operator o = get(ItemSimCard.getOperatorId(sim));
        SimRecord r = o == null ? null : o.subscribers.get(player);
        return r != null && r.phoneNumber == ItemSimCard.getPhoneNumber(sim) ? r : null;
    }

    private int freeNumber() {
        java.util.Random rnd = new java.util.Random();
        for (;;) {
            int n = 1000000 + rnd.nextInt(4000000); // 1000000..4999999: не пересекается с PhoneBook (5000000+)
            boolean used = false;
            for (Operator o : ops.values()) {
                for (SimRecord r : o.subscribers.values()) if (r.phoneNumber == n) { used = true; break; }
                if (used) break;
            }
            if (!used) return n;
        }
    }

    // ===================== трафик и деньги =====================
    /** Списать мегабайты. @return остаток или -1 (нет абонента, SIM заблокирована, не хватает трафика). */
    public int spendData(UUID op, UUID player, int mb) {
        SimRecord r = subscriber(op, player);
        if (r == null || r.blocked || mb < 0 || r.dataBalance < mb) return -1;
        r.dataBalance -= mb;
        setDirty();
        return r.dataBalance;
    }

    /** Купить трафик по mbPrice тарифа. @return null при успехе, иначе текст ошибки. */
    public String buyData(UUID op, UUID player, int mb) {
        Operator o = get(op);
        SimRecord r = o == null ? null : o.subscribers.get(player);
        Tariff t = r == null ? null : o.tariff(r.tariffId);
        if (t == null) return "Not a subscriber";
        if (r.blocked) return "SIM is blocked";
        if (mb <= 0 || mb > MAX_BUY_MB || (long) r.dataBalance + mb > Integer.MAX_VALUE) return "Wrong amount";
        if (!charge(o, player, (long) mb * t.mbPrice, "data " + mb + " MB")) return "Not enough kons: need " + Bank.fmt((long) mb * t.mbPrice);
        r.dataBalance += mb;
        setDirty();
        return null;
    }

    /** Ежедневный платёж: за каждые сутки с lastDailyCharge списывается dailyFee; при неуплате SIM блокируется. @return число списаний. */
    public int chargeDaily(long day) {
        int n = 0;
        for (Operator o : ops.values()) {
            for (Map.Entry<UUID, SimRecord> e : o.subscribers.entrySet()) {
                SimRecord r = e.getValue();
                Tariff t = o.tariff(r.tariffId);
                if (t == null || day <= r.lastDailyCharge) continue;
                if (t.dailyFee == 0 || charge(o, e.getKey(), t.dailyFee, "daily fee " + o.name)) {
                    r.lastDailyCharge = day;
                    r.blocked = false;
                    n++;
                } else if (!r.blocked) {
                    r.blocked = true;
                }
                setDirty();
            }
        }
        return n;
    }

    /** Перевести выручку оператора на счёт Bank. @return переведённая сумма. */
    public long payout(UUID op, String account) {
        Operator o = get(op);
        Bank b = Bank.get();
        if (o == null || b == null || o.balance <= 0) return 0;
        long room = Bank.MAX_BALANCE - b.balance(account);
        long amt = Math.min(o.balance, Math.max(0, room));
        if (amt <= 0) return 0;
        b.setBalance(account, b.balance(account) + amt);
        b.log(account, "+" + Bank.fmt(amt) + " operator " + o.name);
        o.balance -= amt;
        setDirty();
        return amt;
    }

    private boolean charge(Operator o, UUID player, long amt, String why) {
        if (amt <= 0) return true;
        Bank b = Bank.get();
        if (b == null) return false;
        String id = player.toString();
        long have = b.balance(id);
        if (have < amt) return false;
        b.setBalance(id, have - amt);
        b.log(id, "-" + Bank.fmt(amt) + " " + why);
        o.balance += amt;
        setDirty();
        return true;
    }

    // ===================== NBT =====================
    public static OperatorStore load(CompoundTag tag) {
        OperatorStore s = new OperatorStore();
        s.lastDay = tag.contains("lastDay") ? tag.getLong("lastDay") : -1L;
        ListTag list = tag.getList("ops", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            if (!c.hasUUID("id")) continue;
            Operator o = new Operator();
            o.id = c.getUUID("id");
            o.name = c.getString("name");
            o.owner = c.getString("owner");
            o.color = c.getInt("color");
            o.balance = c.getLong("balance");
            for (long l : c.getLongArray("towers")) o.towers.add(BlockPos.of(l));
            ListTag tl = c.getList("tariffs", Tag.TAG_COMPOUND);
            for (int j = 0; j < tl.size(); j++) {
                CompoundTag tc = tl.getCompound(j);
                Tariff t = new Tariff();
                t.id = tc.getString("id");
                t.name = tc.getString("name");
                t.activationCost = tc.getInt("act");
                t.mbPrice = tc.getInt("mb");
                t.dailyFee = tc.getInt("daily");
                o.tariffs.add(t);
            }
            ListTag sl = c.getList("subs", Tag.TAG_COMPOUND);
            for (int j = 0; j < sl.size(); j++) {
                CompoundTag sc = sl.getCompound(j);
                if (!sc.hasUUID("uuid")) continue;
                SimRecord r = new SimRecord();
                r.phoneNumber = sc.getInt("number");
                r.tariffId = sc.getString("tariff");
                r.dataBalance = sc.getInt("data");
                r.lastDailyCharge = sc.getLong("last");
                r.blocked = sc.getBoolean("blocked");
                o.subscribers.put(sc.getUUID("uuid"), r);
            }
            s.ops.put(o.id, o);
        }
        return s;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("lastDay", lastDay);
        ListTag list = new ListTag();
        for (Operator o : ops.values()) {
            CompoundTag c = new CompoundTag();
            c.putUUID("id", o.id);
            c.putString("name", o.name);
            c.putString("owner", o.owner);
            c.putInt("color", o.color);
            c.putLong("balance", o.balance);
            long[] tw = new long[o.towers.size()];
            for (int i = 0; i < tw.length; i++) tw[i] = o.towers.get(i).asLong();
            c.put("towers", new LongArrayTag(tw));
            ListTag tl = new ListTag();
            for (Tariff t : o.tariffs) {
                CompoundTag tc = new CompoundTag();
                tc.putString("id", t.id);
                tc.putString("name", t.name);
                tc.putInt("act", t.activationCost);
                tc.putInt("mb", t.mbPrice);
                tc.putInt("daily", t.dailyFee);
                tl.add(tc);
            }
            c.put("tariffs", tl);
            ListTag sl = new ListTag();
            for (Map.Entry<UUID, SimRecord> e : o.subscribers.entrySet()) {
                SimRecord r = e.getValue();
                CompoundTag sc = new CompoundTag();
                sc.putUUID("uuid", e.getKey());
                sc.putInt("number", r.phoneNumber);
                sc.putString("tariff", r.tariffId);
                sc.putInt("data", r.dataBalance);
                sc.putLong("last", r.lastDailyCharge);
                sc.putBoolean("blocked", r.blocked);
                sl.add(sc);
            }
            c.put("subs", sl);
            list.add(c);
        }
        tag.put("ops", list);
        return tag;
    }

    // ===================== тик =====================
    /** Раз в минуту проверяет смену игровых суток и запускает chargeDaily. Регистрируется в PCMod. */
    public static final class Events {
        @SubscribeEvent
        public void onServerTick(TickEvent.ServerTickEvent e) {
            if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 1200 != 0) return;
            OperatorStore s = get();
            if (s == null || s.ops.isEmpty()) return;
            long day = e.getServer().overworld().getDayTime() / DAY;
            if (day != s.lastDay) {
                s.chargeDaily(day);
                s.lastDay = day;
                s.setDirty();
            }
        }
    }
}
