package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Магазин: каталог товаров за консы с ротацией, лимитами и запасом; покупка по одной штуке или на максимум. */
public final class WinStore implements WinApp {
    private static final int HEAD = 24, ST = 14, RH = 20;
    private final WinSoft s;
    private final WinSvc svc;
    private List<WinSvc.Offer> cat = new ArrayList<WinSvc.Offer>();
    private long stamp = Long.MIN_VALUE;
    private String msg = "";
    private boolean msgOk, lastUp = true;
    private int scroll, sel = -1, aw = 260, ah = 130, hoverBtn = -1, secs = -1, ox, oy;
    private long bal = -1;

    public WinStore(WinSoft s) {
        this.s = s;
        this.svc = s.svc;
        refresh(false);
    }

    @Override public String title() { return "Магазин"; }

    @Override public String id() { return "store"; }

    @Override public int minW() { return 220; }

    @Override public int minH() { return 90; }

    private boolean ready() { return svc.bankReady(); }

    private void refresh(boolean note) {
        if (!ready()) {
            cat = new ArrayList<WinSvc.Offer>();
            stamp = Long.MIN_VALUE;
            return;
        }
        stamp = svc.shopStamp();
        cat = svc.catalog();
        bal = svc.balance();
        secs = svc.shopSeconds();
        if (note) {
            msg = "Каталог обновлён";
            msgOk = true;
            sel = -1;
        }
    }

    private static String left(int v) {
        return v == Integer.MAX_VALUE ? "без лимита" : "осталось " + v;
    }

    private int rows() { return Math.max(1, (ah - HEAD - ST) / RH); }

    // ------------------------------------------------------------------ рисование
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        ox = x;
        oy = y;
        p.fillRect(x, y, w, HEAD, th.surface());
        p.hline(x, y + HEAD - 1, w, th.border());
        p.drawText(x + 8, y + 8, "Магазин", th.text(), 1, true);
        if (ready()) {
            p.drawTextRight(x + w - 8, y + 4, "Баланс: " + WinSoft.kons(bal) + " К", th.text(), 1, true);
            p.drawTextRight(x + w - 8, y + 14, "Обновление через " + secs / 60 + ":" + (secs % 60 < 10 ? "0" : "") + secs % 60, th.sub(), 1, false);
        }
        int top = y + HEAD, rows = rows();
        if (!ready()) {
            p.drawTextCentered(x, w, y + h / 2 - 10, svc.netUp() ? "Сервер недоступен" : "Нет подключения к сети", th.bad(), 1, true);
            p.drawTextCentered(x, w, y + h / 2 + 2, "Подключитесь к сети с сервером, чтобы покупать", th.sub(), 1, false);
        } else if (cat.isEmpty()) {
            p.drawTextCentered(x, w, y + h / 2 - 4, "Каталог пуст", th.sub(), 1, false);
        }
        scroll = Math.max(0, Math.min(Math.max(0, cat.size() - rows), scroll));
        int bw1 = PixelScreen.textWidth("x1") + 12, bw2 = PixelScreen.textWidth("Макс") + 12;
        for (int i = 0; i < rows && scroll + i < cat.size(); i++) {
            WinSvc.Offer o = cat.get(scroll + i);
            int ry = top + 2 + i * RH;
            boolean sl = scroll + i == sel;
            p.roundRectBorder(x + 5, ry, w - 14, RH - 2, 4, sl ? PixelScreen.lerp(th.surface(), th.accent(), 0.12f) : th.surface(), sl ? th.accent() : th.border());
            int ic = 0xFF000000 | ((o.key.hashCode() * 0x9E3779B1) & 0x00B0B0B0) + 0x00404040;
            p.roundRect(x + 9, ry + 3, 12, 12, 3, ic);
            p.drawTextCentered(x + 9, 12, ry + 5, o.name.isEmpty() ? "?" : o.name.substring(0, 1).toUpperCase(), 0xFFFFFFFF, 1, false);
            int bx = x + w - 9 - bw2, bx1 = bx - 3 - bw1;
            boolean can = o.playerLeft > 0 && o.stockLeft > 0 && bal >= o.price;
            int tw = bx1 - (x + 26) - 4;
            p.drawText(x + 26, ry + 2, PixelScreen.fit(o.name, tw, 1, false), th.text());
            String info = WinSoft.kons(o.price) + " К";
            int lim = Math.min(o.playerLeft, o.stockLeft);
            String sub = o.stockLeft <= 0 ? "распродано" : o.playerLeft <= 0 ? "лимит исчерпан" : left(lim);
            p.drawText(x + 26, ry + 10, PixelScreen.fit(info + "  " + sub, tw, 1, false), o.stockLeft <= 0 || o.playerLeft <= 0 ? th.bad() : th.sub());
            mini(p, th, bx1, ry + 2, bw1, "x1", can, hoverBtn == (scroll + i) * 2);
            mini(p, th, bx, ry + 2, bw2, "Макс", can, hoverBtn == (scroll + i) * 2 + 1);
        }
        WinSoft.scrollbar(p, th, x + w - 5, top + 2, rows * RH, cat.size(), rows, scroll);
        int sy = y + h - ST;
        p.fillRect(x, sy, w, ST, th.surface());
        p.hline(x, sy, w, th.border());
        String m = msg.isEmpty() ? (ready() ? "Товаров: " + cat.size() : "") : msg;
        p.drawText(x + 6, sy + 3, PixelScreen.fit(m, w - 12, 1, false), msg.isEmpty() ? th.sub() : msgOk ? th.ok() : th.bad());
    }

    private static void mini(PixelScreen p, WinTheme th, int x, int y, int w, String t, boolean en, boolean hv) {
        if (en) p.roundRect(x, y, w, 14, 4, hv ? th.accentHover() : th.accent());
        else p.roundRectBorder(x, y, w, 14, 4, th.surface(), th.border());
        p.drawTextCentered(x, w, y + 3, t, en ? th.onAccent() : PixelScreen.alpha(th.sub(), 0xA0), 1, false);
    }

    // ------------------------------------------------------------------ ввод
    /** Номер кнопки под указателем: строка * 2 + (0 - x1, 1 - Макс) или -1. */
    private int btnAt(int rx, int ry) {
        int rows = rows();
        if (ry < HEAD + 2 || ry >= HEAD + 2 + rows * RH) return -1;
        int i = (ry - HEAD - 2) / RH;
        if ((ry - HEAD - 2) % RH > 16 || scroll + i >= cat.size()) return -1;
        int bw1 = PixelScreen.textWidth("x1") + 12, bw2 = PixelScreen.textWidth("Макс") + 12;
        int bx = aw - 9 - bw2, bx1 = bx - 3 - bw1;
        if (rx >= bx && rx < bx + bw2) return (scroll + i) * 2 + 1;
        if (rx >= bx1 && rx < bx1 + bw1) return (scroll + i) * 2;
        return -1;
    }

    private void buy(int idx, boolean max) {
        if (!ready()) return;
        if (stamp != svc.shopStamp()) {
            refresh(true);
            return;
        }
        WinSvc.Res r = svc.buy(idx, max ? 0 : 1, stamp);
        msg = r.msg;
        msgOk = r.ok;
        bal = svc.balance();
        cat = svc.catalog();
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int hb = btnAt(rx, ry);
        boolean d = hb != hoverBtn;
        hoverBtn = hb;
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            int ns = Math.max(0, Math.min(Math.max(0, cat.size() - rows()), scroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -1 : 1)));
            if (ns == scroll) return d;
            scroll = ns;
            return true;
        }
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return d;
        if (hb >= 0) {
            sel = hb / 2;
            buy(sel, (hb & 1) == 1);
            return true;
        }
        if (ry >= HEAD + 2) {
            int i = (ry - HEAD - 2) / RH + scroll;
            if (i < cat.size() && ry < ah - ST) sel = i;
        }
        return true;
    }

    @Override
    public boolean key(char c, int key) {
        int n = cat.size();
        if (key == WinSoft.K_UP && n > 0) sel = Math.max(0, sel - 1);
        else if (key == WinSoft.K_DOWN && n > 0) sel = Math.min(n - 1, sel + 1);
        else if (WinUi.isEnter(c, key) && sel >= 0) buy(sel, false);
        else if ((c == 'm' || c == 'M') && sel >= 0) buy(sel, true);
        else return false;
        if (sel >= 0) {
            int r = rows();
            if (sel < scroll) scroll = sel;
            else if (sel >= scroll + r) scroll = sel - r + 1;
        }
        return true;
    }

    @Override
    public boolean tick(long now) {
        if (now % 20 != 0) return false;
        boolean up = ready();
        if (up != lastUp) {
            lastUp = up;
            refresh(false);
            return true;
        }
        if (!up) return false;
        if (stamp != svc.shopStamp()) {
            refresh(true);
            return true;
        }
        int sc = svc.shopSeconds();
        long b = svc.balance();
        boolean d = sc != secs || b != bal;
        secs = sc;
        bal = b;
        return d;
    }
}
