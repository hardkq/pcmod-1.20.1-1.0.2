package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Язык разметки сайтов PC-Net: построчный, без скриптов; текст всегда выводится как текст (экранирование не нужно).
 * Один разбор для сервера (строгая проверка перед публикацией) и клиентов (мягкий разбор для показа).
 * <pre>
 * ; комментарий                      {red,b} строка со стилем (цвет, b, dim, ok, err)
 * # Заголовок    ## Подзаголовок     - пункт списка      --- разделитель
 * => цель текст ссылка               &gt;&gt; цель текст кнопка
 * | a | b |  строка таблицы (|! - шапка, до 4 ячеек)
 * @img ... @end  пиксельная картинка до 32x32 (строки из 0-9 a-f и точки - прозрачно)
 * @bg цвет   @header текст   @footer текст       \ строка, которая начинается с символа разметки
 * Живые элементы (данные подставляет сервер, см. SiteWidgets): @counter, @guestbook, @card, @rate, @report, @donate [текст],
 * @form имя подпись (сообщение владельцу в чат), @price N (платный доступ к странице, не к главной)
 * </pre>
 * Цели ссылок: name.pc, name.pc/page, /page (этот сайт), phone:id, soft:id. Служебные действия (dl:, buy:, inst:, app:)
 * и @preview разрешены только в доверенном режиме (встроенные сайты) - пользовательская страница не может запустить покупку.
 */
public final class Markup {
    public static final int MAX_LINE = 240, MAX_IMAGES = 4, MAX_COLS = 4, MAX_CELL = 60, MAX_IMG = 32;
    private static final Pattern DOMAIN = Pattern.compile("[a-z0-9][a-z0-9-]{0,15}\\.pc(/[a-z0-9_-]{1,24})?");
    private static final Pattern PAGE = Pattern.compile("/?[a-z0-9_-]{0,24}");
    private static final Pattern ID = Pattern.compile("[a-z0-9_-]{1,24}");
    private static final Pattern FORM = Pattern.compile("[a-z0-9_-]{1,12}");
    private static final Pattern ACTION = Pattern.compile("(dl|buy|inst|app):[a-z0-9_-]{1,24}");

    /** Проверка существования товаров для ссылок phone: и soft: (null - принимать любые id). */
    public interface Env {
        boolean phoneApp(String id);

        boolean soft(String id);
    }

    public static final class Result {
        public final WebPage page;
        /** null - разбор без ошибок; иначе "Line N: причина" (английский текст). */
        public final String error;

        Result(WebPage page, String error) {
            this.page = page;
            this.error = error;
        }
    }

    private static final class Fail extends RuntimeException {
        final String msg;
        final boolean fatal;

        Fail(String msg, boolean fatal) {
            super(msg, null, false, false);
            this.msg = msg;
            this.fatal = fatal;
        }
    }

    private static final class Style {
        int color;
        boolean bold;
        char tone;
        String rest = "";
    }

    private Markup() { }

    /**
     * @param strict true - первая ошибка отменяет разбор (публикация); false - плохие строки пропускаются, лимиты обрезают страницу (показ)
     * @param trusted разрешить служебные действия и @preview (только встроенные сайты)
     */
    public static Result parse(String src, String domain, boolean strict, Env env, boolean trusted) {
        List<WebRow> rows = new ArrayList<WebRow>();
        WebRow header = null, footer = null;
        int bg = 0, price = 0, count = 0, images = 0, tableCols = -1, imgLine = 0;
        int maxEl = SiteConfig.maxElements();
        List<String> img = null;
        boolean imgBad = false;
        String first = null;
        String[] lines = (src == null ? "" : src).replace("\r", "").replace('\t', ' ').split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            int ln = i + 1;
            String s = stripEnd(lines[i]);
            try {
                if (s.length() > MAX_LINE) throw new Fail("Line is too long (max " + MAX_LINE + ")", false);
                if (img != null) {
                    String t = s.trim();
                    if (t.isEmpty() && i == lines.length - 1) continue;
                    if (t.equals("@end")) {
                        List<String> done = img;
                        boolean bad = imgBad;
                        img = null;
                        imgBad = false;
                        if (bad) continue;
                        rows.add(image(done));
                        if (++count > maxEl) throw new Fail("Too many elements (max " + maxEl + ")", true);
                        tableCols = -1;
                    } else if (!imgBad) {
                        if (img.size() >= MAX_IMG) throw new Fail("Image: bad size (1-32 x 1-32)", false);
                        checkPixels(t, img);
                        img.add(t);
                    }
                    continue;
                }
                if (s.trim().isEmpty()) {
                    if (!rows.isEmpty() && !isSpacer(rows.get(rows.size() - 1))) rows.add(new WebRow('t', "", null));
                    tableCols = -1;
                    continue;
                }
                String t = s.trim();
                if (t.startsWith(";")) continue;
                Style st = new Style();
                style(t, st);
                String b = st.rest;
                if (b.isEmpty()) continue;
                WebRow row;
                if (b.startsWith("\\")) {
                    row = styled(new WebRow('t', b.substring(1).trim(), null), st);
                    tableCols = -1;
                } else if (b.startsWith("@")) {
                    int sp = b.indexOf(' ');
                    String d = sp < 0 ? b : b.substring(0, sp), arg = sp < 0 ? "" : b.substring(sp + 1).trim();
                    switch (d) {
                        case "@img":
                            img = new ArrayList<String>();
                            imgLine = ln;
                            if (++images > MAX_IMAGES) {
                                imgBad = true;
                                throw new Fail("Too many images (max " + MAX_IMAGES + ")", false);
                            }
                            continue;
                        case "@bg": {
                            int c = WebPalette.index(arg.toLowerCase(Locale.ROOT));
                            if (c < 0) throw new Fail("Bad color", false);
                            bg = WebPalette.RGB[c];
                            continue;
                        }
                        case "@header":
                            if (arg.isEmpty()) throw new Fail("Empty text", false);
                            if (header == null && ++count > maxEl) throw new Fail("Too many elements (max " + maxEl + ")", true);
                            header = styled(new WebRow('H', arg, null), st);
                            continue;
                        case "@footer":
                            if (arg.isEmpty()) throw new Fail("Empty text", false);
                            if (footer == null && ++count > maxEl) throw new Fail("Too many elements (max " + maxEl + ")", true);
                            footer = styled(new WebRow('F', arg, null), st);
                            continue;
                        case "@counter": row = new WebRow('C', "", null); break;
                        case "@guestbook": row = new WebRow('G', "", null); break;
                        case "@card": row = new WebRow('A', "", null); break;
                        case "@rate": row = new WebRow('R', "", null); break;
                        case "@report": row = new WebRow('X', "", null); break;
                        case "@donate": row = new WebRow('D', arg, null); break;
                        case "@form": {
                            int fs = arg.indexOf(' ');
                            String fn = fs < 0 ? arg : arg.substring(0, fs), fl = fs < 0 ? "" : arg.substring(fs + 1).trim();
                            if (domain == null || domain.isEmpty() || !FORM.matcher(fn).matches() || fl.isEmpty()) throw new Fail("Bad form (name label)", false);
                            row = new WebRow('M', fl, fn);
                            break;
                        }
                        case "@price": {
                            int pr;
                            try { pr = Integer.parseInt(arg); } catch (NumberFormatException e) { pr = -1; }
                            if (pr < 1 || pr > SiteConfig.maxPagePrice()) throw new Fail("Bad price", false);
                            price = pr;
                            continue;
                        }
                        case "@preview":
                            if (!trusted || !ID.matcher(arg).matches()) throw new Fail("Unknown directive", false);
                            row = new WebRow('p', arg, null);
                            break;
                        default:
                            throw new Fail("Unknown directive", false);
                    }
                    tableCols = -1;
                } else if (b.equals("---")) {
                    row = new WebRow('r', "", null);
                    tableCols = -1;
                } else if (b.equals("#") || b.startsWith("# ")) {
                    row = styled(new WebRow('h', b.substring(1).trim(), null), st);
                    tableCols = -1;
                } else if (b.equals("##") || b.startsWith("## ")) {
                    row = styled(new WebRow('s', b.substring(2).trim(), null), st);
                    tableCols = -1;
                } else if (b.startsWith("- ")) {
                    row = styled(new WebRow('u', b.substring(2).trim(), null), st);
                    tableCols = -1;
                } else if (b.startsWith("=> ") || b.startsWith(">> ")) {
                    String rest = b.substring(3).trim();
                    int sp = rest.indexOf(' ');
                    String raw = sp < 0 ? rest : rest.substring(0, sp), text = sp < 0 ? "" : rest.substring(sp + 1).trim();
                    String tg = resolve(raw, domain, env, trusted);
                    if (tg == null) throw new Fail("Bad link target", false);
                    row = styled(new WebRow(b.charAt(0) == '=' ? 'l' : 'b', text.isEmpty() ? raw : text, tg), st);
                    tableCols = -1;
                } else if (b.startsWith("|")) {
                    boolean head = b.startsWith("|!");
                    String body = b.substring(head ? 2 : 1);
                    if (body.endsWith("|")) body = body.substring(0, body.length() - 1);
                    String[] raw = body.split("\\|", -1);
                    if (raw.length > MAX_COLS) throw new Fail("Too many table columns (max " + MAX_COLS + ")", false);
                    String[] cells = new String[raw.length];
                    for (int k = 0; k < raw.length; k++) {
                        cells[k] = raw[k].trim();
                        if (cells[k].length() > MAX_CELL) throw new Fail("Table cell is too long (max " + MAX_CELL + ")", false);
                    }
                    if (tableCols >= 0 && tableCols != cells.length) {
                        if (strict) throw new Fail("Table rows must have the same number of cells", false);
                        cells = java.util.Arrays.copyOf(cells, tableCols);
                        for (int k = 0; k < cells.length; k++) if (cells[k] == null) cells[k] = "";
                    }
                    tableCols = cells.length;
                    row = styled(new WebRow('T', "", null), st);
                    row.cells = cells;
                    if (head) row.bold = true;
                } else {
                    row = styled(new WebRow('t', b, null), st);
                    tableCols = -1;
                }
                rows.add(row);
                if (++count > maxEl) throw new Fail("Too many elements (max " + maxEl + ")", true);
            } catch (Fail f) {
                if (strict) return new Result(null, "Line " + ln + ": " + f.msg);
                if (first == null) first = "Line " + ln + ": " + f.msg;
                if (f.fatal) {
                    if (!rows.isEmpty()) rows.remove(rows.size() - 1);
                    break;
                }
                if (img != null && f.msg.startsWith("Image")) imgBad = true;
            }
        }
        if (img != null && strict) return new Result(null, "Line " + imgLine + ": Image is not closed (@end)");
        while (!rows.isEmpty() && isSpacer(rows.get(rows.size() - 1))) rows.remove(rows.size() - 1);
        while (!rows.isEmpty() && isSpacer(rows.get(0))) rows.remove(0);
        if (header != null) rows.add(0, header);
        if (footer != null) rows.add(footer);
        WebPage pg = new WebPage(rows);
        pg.bg = bg;
        pg.price = price;
        return new Result(pg, strict ? null : first);
    }

    private static boolean isSpacer(WebRow r) { return r.kind == 't' && r.text.isEmpty() && r.cells == null; }

    private static String stripEnd(String s) {
        int e = s.length();
        while (e > 0 && s.charAt(e - 1) == ' ') e--;
        return s.substring(0, e);
    }

    private static WebRow styled(WebRow r, Style st) {
        r.color = st.color;
        r.bold = r.bold || st.bold;
        r.tone = st.tone;
        return r;
    }

    /** Разбор префикса {цвет,b,dim,ok,err}; остаток строки - в st.rest. */
    private static void style(String t, Style st) {
        st.rest = t;
        if (!t.startsWith("{")) return;
        int e = t.indexOf('}');
        if (e < 0) throw new Fail("Bad style (colors, b, dim, ok, err)", false);
        for (String tok : t.substring(1, e).toLowerCase(Locale.ROOT).split(",")) {
            tok = tok.trim();
            if (tok.equals("b")) st.bold = true;
            else if (tok.equals("dim")) st.tone = 'd';
            else if (tok.equals("ok")) st.tone = 'k';
            else if (tok.equals("err")) st.tone = 'e';
            else {
                int c = WebPalette.index(tok);
                if (c < 0) throw new Fail("Bad style (colors, b, dim, ok, err)", false);
                st.color = WebPalette.RGB[c];
            }
        }
        st.rest = t.substring(e + 1).trim();
    }

    private static void checkPixels(String row, List<String> prev) {
        if (row.isEmpty() || row.length() > MAX_IMG) throw new Fail("Image: bad size (1-32 x 1-32)", false);
        if (!prev.isEmpty() && prev.get(0).length() != row.length()) throw new Fail("Image: rows must have equal width", false);
        for (int i = 0; i < row.length(); i++) {
            char c = row.charAt(i);
            if (c != '.' && Character.digit(c, 16) < 0 || Character.isUpperCase(c)) throw new Fail("Image: bad pixel (0-9, a-f, .)", false);
        }
    }

    private static WebRow image(List<String> img) {
        if (img.isEmpty()) throw new Fail("Image: bad size (1-32 x 1-32)", false);
        int w = img.get(0).length(), h = img.size();
        WebRow r = new WebRow('i', "", null);
        r.pw = w;
        r.ph = h;
        r.pix = new byte[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                char c = img.get(y).charAt(x);
                r.pix[y * w + x] = (byte) (c == '.' ? -1 : Character.digit(c, 16));
            }
        return r;
    }

    /** Цель ссылки -> адрес для браузера; null - недопустимо. */
    static String resolve(String raw, String domain, Env env, boolean trusted) {
        String t = raw.toLowerCase(Locale.ROOT);
        if (trusted && ACTION.matcher(t).matches()) return t;
        if (DOMAIN.matcher(t).matches()) return t.endsWith("/index") ? t.substring(0, t.length() - 6) : t;
        if (t.startsWith("phone:") || t.startsWith("soft:")) {
            boolean phone = t.startsWith("phone:");
            String id = t.substring(phone ? 6 : 5);
            if (!ID.matcher(id).matches()) return null;
            if (env != null && !(phone ? env.phoneApp(id) : env.soft(id))) return null;
            return "soft.pc/" + id;
        }
        if (domain != null && !domain.isEmpty() && PAGE.matcher(t).matches()) {
            String p = t.startsWith("/") ? t.substring(1) : t;
            return p.isEmpty() || p.equals("index") ? domain : domain + "/" + p;
        }
        return null;
    }
}
