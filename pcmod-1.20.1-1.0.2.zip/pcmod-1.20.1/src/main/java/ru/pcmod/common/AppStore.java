package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.world.item.ItemStack;
import static ru.pcmod.common.PixelScreen.rgb;

/**
 * «Магазин приложений»: каталог дополнительных приложений (Змейка, Кубики, Сапёр). Проверяет версию ОС, ОЗУ и свободную память,
 * платные приложения покупаются с общего банковского счёта (повторная установка купленного бесплатна), загрузка идёт по Wi-Fi.
 * Установленные приложения хранятся в NBT телефона ("Data/Apps"), занимают встроенную память и появляются на домашнем экране.
 */
final class AppStore implements AndroOs.App {
    static final class Info {
        final String id, ru, en, dRu, dEn;
        final int mb, ver, ram, price;

        Info(String id, String ru, String en, String dRu, String dEn, int mb, int ver, int ram, int price) {
            this.id = id; this.ru = ru; this.en = en; this.dRu = dRu; this.dEn = dEn; this.mb = mb; this.ver = ver; this.ram = ram; this.price = price;
        }
    }

    /** Каталог телефонных товаров из реестра SoftRegistry (цены - из конфига). */
    static Info[] cat() {
        List<Info> r = new ArrayList<Info>();
        for (SoftItem s : SoftRegistry.all(SoftItem.Type.PHONE_APP)) r.add(mk(s));
        return r.toArray(new Info[0]);
    }

    private static Info mk(SoftItem s) {
        return new Info(s.id, s.ru, s.en, s.dRu, s.dEn, s.phoneMB, s.phoneVer, s.phoneRamMB, SoftRegistry.price(s));
    }

    private static final int TOP = 70, VIEW = 208;

    private static final class St {
        int tab;
        final AppUi.Scroll sc = new AppUi.Scroll();
        String pending;
        long start, dur;
        String msg = "";
        boolean ok;
        long until;
    }

    private static St st(AndroOs os) { return os.state("store", St::new); }

    static Info info(String id) {
        SoftItem s = SoftRegistry.get(id);
        return s != null && s.type == SoftItem.Type.PHONE_APP ? mk(s) : null;
    }
    static boolean isExtra(String id) { return info(id) != null; }

    /** Старые покупки из NBT телефона переносятся в лицензии аккаунта (по UUID на сервере). */
    private static void migrate(AndroOs os) {
        if (os.ses == null) return;
        ItemStack st = os.stack();
        if (st.isEmpty()) return;
        ListTag l = PhoneData.strings(st, "AppsBought");
        if (l.isEmpty()) return;
        SoftLicenses s = SoftLicenses.get();
        if (s == null) return;
        String u = AppNet.id(os);
        for (int k = 0; k < l.size(); k++) if (isExtra(l.getString(k))) s.grant(u, l.getString(k), "migrate phone");
        PhoneData.d(st).remove("AppsBought");
        os.dirty();
    }

    /** Лицензия на приложение есть (бесплатное или куплено на этом аккаунте). */
    static boolean owned(AndroOs os, String id) {
        Info i = info(id);
        if (i == null) return false;
        if (i.price <= 0) return true;
        migrate(os);
        SoftLicenses s = SoftLicenses.get();
        return os.ses != null && s != null && s.has(AppNet.id(os), id);
    }

    /** Приложение можно запускать (лицензия не отозвана). */
    static boolean runnable(AndroOs os, String id) { return owned(os, id); }

    private static boolean listed(ItemStack st, String key, String id) {
        if (st.isEmpty()) return false;
        ListTag l = PhoneData.strings(st, key);
        for (int i = 0; i < l.size(); i++) if (l.getString(i).equals(id)) return true;
        return false;
    }

    static boolean has(ItemStack st, String id) { return listed(st, "Apps", id); }

    /** Установленные дополнительные приложения в порядке установки. */
    static List<String> installed(ItemStack st) {
        List<String> r = new ArrayList<String>();
        if (st.isEmpty()) return r;
        ListTag l = PhoneData.strings(st, "Apps");
        for (int i = 0; i < l.size(); i++) if (isExtra(l.getString(i))) r.add(l.getString(i));
        return r;
    }

    static int installedMB(AndroOs os) {
        int sum = 0;
        for (String id : installed(os.stack())) sum += info(id).mb;
        return sum;
    }

    private static void add(ItemStack st, String key, String id) {
        ListTag l = PhoneData.strings(st, key);
        l.add(StringTag.valueOf(id));
        PhoneData.d(st).put(key, l);
    }

    private static void remove(ItemStack st, String key, String id) {
        ListTag l = PhoneData.strings(st, key);
        for (int i = l.size() - 1; i >= 0; i--) if (l.getString(i).equals(id)) l.remove(i);
        PhoneData.d(st).put(key, l);
    }

    private static int freeMB(AndroOs os) { return os.romGB * 1000 - os.sysMB() - 150 - installedMB(os); }

    /** Причина, по которой приложение нельзя поставить (null - можно). */
    static String blocked(AndroOs os, Info i) {
        if (os.ver < i.ver) return os.t("Нужен Android ", "Needs Android ") + i.ver + "+";
        if (os.ramMB < i.ram) return os.t("Мало ОЗУ: нужно ", "Not enough RAM: needs ") + i.ram / 1024 + " GB";
        if (freeMB(os) < i.mb) return os.t("Мало памяти: нужно ", "Not enough storage: needs ") + i.mb + " MB";
        return null;
    }

    /** Начать установку (из магазина или браузера). Возвращает сообщение для экрана; ok - установка началась. */
    static String begin(AndroOs os, String id, boolean[] ok) {
        ok[0] = false;
        St st = st(os);
        Info i = info(id);
        ItemStack stack = os.stack();
        if (i == null || stack.isEmpty()) return "?";
        if (!AppNet.wifi(os)) return os.t("Нет подключения к сети", "No network connection");
        if (has(stack, id)) return os.t("Уже установлено", "Already installed");
        if (st.pending != null) return os.t("Уже идёт загрузка", "A download is already running");
        String why = blocked(os, i);
        if (why != null) return why;
        if (i.price > 0 && !owned(os, id)) {
            if (!AppNet.ready(os)) return os.t("Для покупки нужен сервер банка", "Purchase needs the bank server");
            Bank.Res r = SoftLicenses.buy(AppNet.player(os), id);
            if (!r.ok) return AppNet.tr(os, r.msg);
        }
        st.pending = id;
        st.start = os.now();
        st.dur = (40 + i.mb * 2L) * (1 + os.lag());
        ok[0] = true;
        os.dirty();
        return os.t("Загрузка: ", "Downloading: ") + os.t(i.ru, i.en);
    }

    /** Только покупка лицензии (без загрузки): страница товара в браузере телефона. */
    static String buy(AndroOs os, String id, boolean[] ok) {
        ok[0] = false;
        Info i = info(id);
        if (i == null) return "?";
        if (i.price <= 0) return os.t("Бесплатно", "Free");
        if (owned(os, id)) return os.t("Уже куплено", "Already owned");
        if (!AppNet.wifi(os)) return os.t("Нет подключения к сети", "No network connection");
        if (!AppNet.ready(os)) return os.t("Для покупки нужен сервер банка", "Purchase needs the bank server");
        Bank.Res r = SoftLicenses.buy(AppNet.player(os), id);
        ok[0] = r.ok;
        return AppNet.tr(os, r.msg);
    }

    private static void delete(AndroOs os, String id) {
        remove(os.stack(), "Apps", id);
        os.running.remove(id);
        if (os.app.equals(id)) os.app = "";
        os.dirty();
    }

    private static void say(AndroOs os, St st, String m, boolean ok) { st.msg = m; st.ok = ok; st.until = os.now() + 100; }

    // ---------------- рисование
    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "store", os.t("Приложения", "Apps"));
        AppUi.tabs(os, s, new String[] {os.t("Каталог", "Catalog"), os.t("Установлено", "Installed")}, st.tab);
        if (!AppNet.wifi(os) && st.tab == 0) { AppNet.offline(os, s); return; }
        ItemStack stack = os.stack();
        List<String> inst = installed(stack);
        Info[] cat = cat();
        int n = st.tab == 0 ? cat.length : inst.size();
        s.pushClip(0, TOP - 2, AndroOs.W, VIEW + 2);
        for (int k = 0; k < n; k++) {
            int y = TOP + k * 42 - st.sc.off;
            if (y < TOP - 42 || y > TOP + VIEW) continue;
            Info i = st.tab == 0 ? cat[k] : info(inst.get(k));
            s.roundRect(8, y, 164, 39, 8, os.panel());
            AndroIcons.draw(s, i.id, 13, y + 6, 26);
            s.drawText(46, y + 5, PixelScreen.fit(os.t(i.ru, i.en), 66, 1, true), os.text(), 1, true);
            s.drawText(46, y + 16, i.mb + " MB, Android " + i.ver + "+", os.sub());
            boolean paid = i.price > 0 && !owned(os, i.id);
            s.drawText(46, y + 27, i.price == 0 ? os.t("Бесплатно", "Free") : paid ? i.price + " K" : os.t("Куплено", "Owned"), paid ? os.accent() : os.sub());
            if (st.tab == 1) { AppUi.btn(os, s, 116, y + 10, 52, 20, os.t("Удалить", "Delete"), false); continue; }
            boolean has = has(stack, i.id), busy = i.id.equals(st.pending), bad = !has && blocked(os, i) != null;
            if (busy) {
                int p = (int) Math.min(99, (os.now() - st.start) * 100 / Math.max(1, st.dur));
                s.roundRect(116, y + 10, 52, 20, 8, os.panel());
                s.roundRect(116, y + 10, Math.max(6, p * 52 / 100), 20, 8, os.accent());
                s.drawTextCentered(116, 52, y + 16, p + "%", rgb(255, 255, 255), 1, true);
            } else if (bad) {
                s.roundRect(116, y + 10, 52, 20, 8, os.panel());
                s.drawTextCentered(116, 52, y + 16, "N/A", os.sub(), 1, true);
            } else AppUi.btn(os, s, 116, y + 10, 52, 20, has ? os.t("Открыть", "Open") : paid ? os.t("Купить", "Buy") : os.t("Скачать", "Get"), !has);
        }
        s.popClip();
        if (st.tab == 1 && inst.isEmpty()) {
            s.drawTextCentered(0, AndroOs.W, 150, os.t("Нет загруженных приложений", "No downloaded apps"), os.sub(), 1, false);
            s.drawTextCentered(0, AndroOs.W, 164, os.t("Системные приложения удалить нельзя", "System apps cannot be removed"), os.sub(), 1, false);
        }
        s.drawText(10, 284, os.t("Свободно: ", "Free: ") + freeMB(os) / 1000 + " GB", os.sub());
        if (st.until > os.now()) s.drawTextRight(172, 284, PixelScreen.fit(st.msg, 100, 1, true), st.ok ? rgb(80, 220, 120) : rgb(240, 110, 100), 1, true);
    }

    // ---------------- ввод
    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St st = st(os);
        if (kind == 0) { st.sc.down(y); return true; }
        if (kind == 2) { st.sc.drag(y, (st.tab == 0 ? cat().length : installed(os.stack()).size()) * 42, VIEW); return true; }
        if (!os.tap(x, y) || st.sc.moved) return true;
        int t = AppUi.tabAt(2, x, y);
        if (t >= 0) { st.tab = t; st.sc.off = 0; return true; }
        if (y < TOP || y >= TOP + VIEW) return true;
        int k = (y - TOP + st.sc.off) / 42, ry = (y - TOP + st.sc.off) % 42;
        List<String> inst = installed(os.stack());
        Info[] cat = cat();
        if (k >= (st.tab == 0 ? cat.length : inst.size()) || ry > 39 || x < 116 || x >= 168 || ry < 10 || ry >= 30) return true;
        Info i = st.tab == 0 ? cat[k] : info(inst.get(k));
        if (st.tab == 1) { delete(os, i.id); say(os, st, os.t("Удалено", "Deleted"), true); return true; }
        if (has(os.stack(), i.id)) { os.open(i.id); return true; }
        if (i.id.equals(st.pending)) return true;
        boolean[] ok = new boolean[1];
        say(os, st, begin(os, i.id, ok), ok[0]);
        return true;
    }

    @Override
    public void bg(AndroOs os) {
        St st = st(os);
        if (st.pending == null) return;
        if (!AppNet.wifi(os)) { st.pending = null; os.notify(os.t("Магазин приложений", "App store"), os.t("Загрузка прервана: нет сети", "Download failed: no network")); return; }
        if (os.now() - st.start >= st.dur) {
            Info i = info(st.pending);
            st.pending = null;
            if (i != null && !has(os.stack(), i.id)) {
                add(os.stack(), "Apps", i.id);
                os.notify(os.t("Установлено", "Installed"), os.t(i.ru, i.en));
            }
            os.dirty();
        } else if (AppNet.visible(os, "store")) os.dirty();
    }
}
