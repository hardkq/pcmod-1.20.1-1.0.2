package ru.pcmod.common;

import java.util.List;
import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Галерея»: сетка миниатюр фото камеры, просмотр на весь экран, удаление. */
final class AppGallery implements AndroOs.App {
    private static final int TW = 52, TH = 70, LIST_Y = 48, LIST_H = 250;

    private static final class St { int open = -1; final AppUi.Scroll sc = new AppUi.Scroll(); }

    private static St st(AndroOs os) { return os.state("gallery", St::new); }

    private static List<PhoneBook.Photo> photos(AndroOs os) {
        return os.ses == null ? List.of() : PhoneBook.get(os.ses.player.server).photos(PhoneData.uid(os.stack()));
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        List<PhoneBook.Photo> l = photos(os);
        if (st.open >= l.size()) st.open = -1;
        if (st.open >= 0) {
            PhoneBook.Photo p = l.get(st.open);
            s.fillRect(0, 0, AndroOs.W, AndroOs.H, rgb(0, 0, 0));
            AppCamera.paint(s, p.d, p.w, p.h, 0, AndroOs.STATUS, 180, p.min);
            s.drawText(6, AndroOs.STATUS + 4, "IMG_" + AppUi.two(st.open + 1) + "  " + AppUi.hhmm(p.min), rgb(255, 255, 255), 1, true);
            AppUi.btn(os, s, 8, 262, 76, 28, os.t("Назад", "Back"), false);
            AppUi.btn(os, s, 96, 262, 76, 28, os.t("Удалить", "Delete"), true);
            return;
        }
        AppUi.header(os, s, "gallery", os.t("Галерея", "Gallery") + " (" + l.size() + ")");
        if (l.isEmpty()) { s.drawTextCentered(0, AndroOs.W, 150, os.t("Фотографий нет", "No photos"), os.sub(), 1, false); return; }
        s.pushClip(0, LIST_Y, AndroOs.W, LIST_H);
        for (int i = 0; i < l.size(); i++) {
            int x = 6 + (i % 3) * (TW + 4), y = LIST_Y + 4 - st.sc.off + (i / 3) * (TH + 4);
            if (y < LIST_Y - TH || y > LIST_Y + LIST_H) continue;
            PhoneBook.Photo p = l.get(i);
            s.pushClip(x, y, TW, TH);
            // миниатюра: каждая ячейка фото - прямоугольник нужного размера
            int[] sky = {rgb(110, 175, 235)};
            for (int j = 0; j < p.h; j++)
                for (int k = 0; k < p.w; k++) {
                    int b = p.d[j * p.w + k] & 255, c;
                    if (b == 0) c = sky[0];
                    else { int a = net.minecraft.world.level.material.MapColor.getColorFromPackedId(b); c = rgb(a & 255, a >> 8 & 255, a >> 16 & 255); }
                    int x0 = x + k * TW / p.w, x1 = x + (k + 1) * TW / p.w, y0 = y + j * TH / p.h, y1 = y + (j + 1) * TH / p.h;
                    s.fillRect(x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), c);
                }
            s.popClip();
        }
        s.popClip();
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St st = st(os);
        if (kind == 0) { st.sc.down(y); return true; }
        if (kind == 2) { st.sc.drag(y, (photos(os).size() + 2) / 3 * (TH + 4) + 8, LIST_H); return true; }
        if (!os.tap(x, y) || st.sc.moved) return true;
        List<PhoneBook.Photo> l = photos(os);
        if (st.open >= 0) {
            if (AppUi.in(x, y, 8, 262, 76, 28)) st.open = -1;
            else if (AppUi.in(x, y, 96, 262, 76, 28) && st.open < l.size()) { l.remove(st.open); PhoneBook.get(os.ses.player.server).changed(); st.open = -1; }
            return true;
        }
        if (y < LIST_Y) return true;
        int c = (x - 6) / (TW + 4), r = (y - LIST_Y - 4 + st.sc.off) / (TH + 4), i = r * 3 + c;
        if (x >= 6 && c < 3 && i >= 0 && i < l.size()) st.open = i;
        return true;
    }

    @Override
    public boolean back(AndroOs os) {
        St st = st(os);
        if (st.open >= 0) { st.open = -1; return true; }
        return false;
    }
}
