package ru.pcmod.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Лицензии магазина программ: по UUID игрока, в сохранении мира (общие для всех ПК и телефонов, не зависят от ОС и накопителя).
 * Покупка списывает консы с общего банковского счёта; все проверки выполняются на сервере.
 */
public class SoftLicenses extends SavedData {
    public static final String ID = "pcmod_soft";
    private static final Logger LOG = LogManager.getLogger("pcmod");
    static final int AUDIT_MAX = 200;

    private final Map<String, Set<String>> lic = new HashMap<String, Set<String>>();
    private final List<String> audit = new ArrayList<String>();

    public SoftLicenses() { }

    public static SoftLicenses load(CompoundTag tag) {
        SoftLicenses s = new SoftLicenses();
        ListTag l = tag.getList("lic", 10);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            String u = c.getString("u");
            if (u.isEmpty()) continue;
            Set<String> set = new LinkedHashSet<String>();
            ListTag ids = c.getList("ids", 8);
            for (int j = 0; j < ids.size(); j++) set.add(ids.getString(j));
            s.lic.put(u, set);
        }
        ListTag a = tag.getList("audit", 8);
        for (int i = 0; i < a.size(); i++) s.audit.add(a.getString(i));
        return s;
    }

    /** Лицензии основного мира или null, если сервер ещё не запущен. */
    public static SoftLicenses get() {
        MinecraftServer srv = ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return null;
        ServerLevel w = srv.overworld();
        if (w == null) return null;
        return w.getDataStorage().computeIfAbsent(SoftLicenses::load, SoftLicenses::new, ID);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (Map.Entry<String, Set<String>> e : lic.entrySet()) {
            if (e.getValue().isEmpty()) continue;
            CompoundTag c = new CompoundTag();
            c.putString("u", e.getKey());
            ListTag ids = new ListTag();
            for (String id : e.getValue()) ids.add(StringTag.valueOf(id));
            c.put("ids", ids);
            l.add(c);
        }
        tag.put("lic", l);
        ListTag a = new ListTag();
        for (String s : audit) a.add(StringTag.valueOf(s));
        tag.put("audit", a);
        return tag;
    }

    // ===================== лицензии =====================
    public boolean has(String uuid, String id) {
        Set<String> s = lic.get(uuid);
        return s != null && s.contains(id);
    }

    public List<String> of(String uuid) {
        Set<String> s = lic.get(uuid);
        return s == null ? new ArrayList<String>() : new ArrayList<String>(s);
    }

    /** Выдать лицензию; false - уже была. */
    public boolean grant(String uuid, String id, String why) {
        if (uuid == null || uuid.isEmpty() || SoftRegistry.get(id) == null) return false;
        Set<String> s = lic.get(uuid);
        if (s == null) {
            s = new LinkedHashSet<String>();
            lic.put(uuid, s);
        }
        if (!s.add(id)) return false;
        audit("grant " + uuid + " " + id + " (" + why + ")");
        setDirty();
        return true;
    }

    /** Отозвать лицензию; false - не было. */
    public boolean revoke(String uuid, String id, String why) {
        Set<String> s = lic.get(uuid);
        if (s == null || !s.remove(id)) return false;
        audit("revoke " + uuid + " " + id + " (" + why + ")");
        setDirty();
        return true;
    }

    public void audit(String text) {
        audit.add(text);
        while (audit.size() > AUDIT_MAX) audit.remove(0);
        LOG.info("[pcsoft] " + text);
        setDirty();
    }

    public List<String> auditLog() { return new ArrayList<String>(audit); }

    // ===================== проверки и покупка =====================
    /** Можно ли игроку пользоваться товаром: бесплатный или есть лицензия. */
    public static boolean allowed(String uuid, SoftItem it) {
        if (it == null) return false;
        if (SoftRegistry.price(it) <= 0) return true;
        SoftLicenses s = get();
        return s != null && s.has(uuid, it.id);
    }

    /** Покупка лицензии с общего банковского счёта (тексты ошибок - английские, как в Bank). */
    public static Bank.Res buy(Player p, String id) {
        try {
            return buy0(p, id);
        } catch (RuntimeException e) {
            LOG.warn("[pcsoft] purchase failed: " + e);
            return new Bank.Res(false, "Internal error");
        }
    }

    private static Bank.Res buy0(Player p, String id) {
        SoftItem it = SoftRegistry.get(id);
        if (it == null || !SoftRegistry.onSale(it)) return new Bank.Res(false, "Item is not on sale");
        int price = SoftRegistry.price(it);
        if (price <= 0) return new Bank.Res(false, "This item is free");
        SoftLicenses s = get();
        Bank b = Bank.get();
        if (s == null || b == null) return new Bank.Res(false, "Bank is unavailable");
        String u = p.getUUID().toString();
        if (s.has(u, id)) return new Bank.Res(false, "You already own this");
        b.rename(u, p.getGameProfile().getName());
        if (b.balance(u) < price) return new Bank.Res(false, "Not enough kons (need " + Bank.fmt(price) + ")");
        b.setBalance(u, b.balance(u) - price);
        b.log(u, "-" + Bank.fmt(price) + (it.type == SoftItem.Type.PHONE_APP ? " app " : " soft ") + it.en);
        s.grant(u, id, "buy " + price);
        return new Bank.Res(true, "Bought " + it.en + " for " + Bank.fmt(price));
    }
}
