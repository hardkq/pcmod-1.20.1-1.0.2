package ru.pcmod.common;

import java.util.function.Consumer;

/**
 * Товар магазина программ (soft.pc): программа или игра для ПК, приложение для телефона.
 * Новый товар - одна запись в {@link SoftRegistry} (цепочка вызовов), без правки браузера и установщика.
 */
public final class SoftItem {
    public enum Type { PC_PROGRAM, PC_GAME, PHONE_APP }

    public final String id;
    public final Type type;
    public String ru, en, dRu = "", dEn = "";
    /** Короткое русское название для сообщений («Антивирус уже установлен»). */
    public String noun;
    /** Цена по умолчанию в консах (конфиг переопределяет, 0 - бесплатно). */
    public int price;
    /** Требования: ОС, ОЗУ (МБ), место на диске (КБ), размер загрузки (КБ). */
    public String reqOs = "";
    public int reqRamMB, reqDiskKB, sizeKB;
    /** Телефон: занимаемая память (МБ), минимальная версия Android, ОЗУ (МБ). */
    public int phoneMB, phoneVer, phoneRamMB;
    /** Идентификатор пиксельного превью (рисует страница товара). */
    public String preview = "";
    /** ПК: приложение в WinApps, установщик, главный файл, папки, размер установки. */
    public String appId = "", setupFile = "", setupMagic = "", mainFile = "", mainMagic = "";
    public int setupSize, installedSize, needBytes;
    public String[] dirs = new String[0];
    /** Действие после установки (необязательно). */
    public Consumer<ComputerLogic> post;
    /** Уже установленные копии работают без покупки, даже если цену потом задали в конфиге. */
    public boolean legacy;

    private SoftItem(String id, Type type, String ru, String en) {
        this.id = id;
        this.type = type;
        this.ru = ru;
        this.en = en;
        this.noun = ru;
    }

    public static SoftItem pc(String id, Type type, String ru, String en) { return new SoftItem(id, type, ru, en); }

    public static SoftItem phone(String id, String ru, String en) { return new SoftItem(id, Type.PHONE_APP, ru, en); }

    public SoftItem desc(String dRu, String dEn) { this.dRu = dRu; this.dEn = dEn; return this; }

    public SoftItem noun(String n) { this.noun = n; return this; }

    public SoftItem price(int p) { this.price = p; return this; }

    public SoftItem req(String os, int ramMB, int diskKB) { this.reqOs = os; this.reqRamMB = ramMB; this.reqDiskKB = diskKB; return this; }

    public SoftItem preview(String p) { this.preview = p; return this; }

    public SoftItem app(String appId) { this.appId = appId; return this; }

    public SoftItem legacy() { this.legacy = true; return this; }

    public SoftItem post(Consumer<ComputerLogic> c) { this.post = c; return this; }

    /** Установщик: имя файла, заголовок (magic) и размер в байтах. */
    public SoftItem setup(String file, String magic, int size) {
        this.setupFile = file;
        this.setupMagic = magic;
        this.setupSize = size;
        this.sizeKB = (size + 1023) / 1024;
        return this;
    }

    /** Установленная программа: главный файл, его начало, размер, нужно места (байт), папки (родительские первыми). */
    public SoftItem install(String file, String magic, int size, int need, String... dirs) {
        this.mainFile = file;
        this.mainMagic = magic;
        this.installedSize = size;
        this.needBytes = need;
        this.dirs = dirs;
        if (reqDiskKB == 0) reqDiskKB = (need + 1023) / 1024;
        return this;
    }

    /** Телефон: память (МБ), версия Android, ОЗУ (МБ). */
    public SoftItem phoneReq(int mb, int ver, int ramMB) {
        this.phoneMB = mb;
        this.phoneVer = ver;
        this.phoneRamMB = ramMB;
        this.reqOs = "Android " + ver + "+";
        this.reqRamMB = ramMB;
        this.reqDiskKB = mb * 1024;
        this.sizeKB = mb * 1024;
        return this;
    }

    public boolean isPc() { return type != Type.PHONE_APP; }

    /** Папка установки (последняя в списке папок). */
    public String folder() { return dirs.length == 0 ? "/" : dirs[dirs.length - 1]; }
}
