package ru.pcmod.common;

/**
 * Хостинг сайтов: отдаёт страницы только при исправной сети и работающем TileServer (иначе 503).
 * Общая точка для ПК (WinSvcImpl) и телефона.
 */
public final class SiteHost {
    public static final int NO_NET = 0, OK = 200, PAYWALL = 402, BLOCKED = 403, NOT_FOUND = 404, UNAVAILABLE = 503;

    private SiteHost() { }

    /** Ответ сервера на запрос страницы. body - исходный текст разметки (только при OK). */
    public static final class Resp {
        public final int code;
        public final String domain, page, title, owner, body, note;
        /** Данные интерактива (счётчик, рейтинг, книга, права) - при OK и PAYWALL. */
        public final SiteStore.Extra x;

        Resp(int code, String domain, String page, String title, String owner, String body, String note, SiteStore.Extra x) {
            this.x = x;
            this.code = code;
            this.domain = domain;
            this.page = page;
            this.title = title;
            this.owner = owner;
            this.body = body;
            this.note = note;
        }

        static Resp err(int code, String domain, String page, String note) {
            return new Resp(code, domain, page, "", "", "", note, null);
        }
    }

    /** null - сервер сети отвечает, иначе причина (английский текст для WinSvcImpl.ru). */
    public static String reach(boolean netUp, TileServer srv) {
        if (!netUp || srv == null) return "Not connected to the server";
        if (srv.siteGate() != null) return "Site hosting is unavailable (503)";
        return null;
    }

    /** Запрос страницы: адрес "name.pc", страница "" или "about". */
    public static Resp fetch(boolean netUp, TileServer srv, String domainRaw, String pageRaw) { return fetch(netUp, srv, domainRaw, pageRaw, ""); }

    /** viewer - UUID смотрящего игрока ("" - никто не у монитора): от него зависят счётчик, права владельца и платные страницы. */
    public static Resp fetch(boolean netUp, TileServer srv, String domainRaw, String pageRaw, String viewer) {
        try {
            return fetch0(netUp, srv, domainRaw, pageRaw, viewer);
        } catch (RuntimeException e) {
            return Resp.err(UNAVAILABLE, String.valueOf(domainRaw), "", "Server is down");
        }
    }

    private static Resp fetch0(boolean netUp, TileServer srv, String domainRaw, String pageRaw, String viewer) {
        String d = SiteConfig.normalize(domainRaw);
        String pg = SiteConfig.pageName(pageRaw);
        String dd = d == null ? String.valueOf(domainRaw) : d;
        if (!netUp) return Resp.err(NO_NET, dd, "", "No network");
        if (srv == null || srv.siteGate() != null) return Resp.err(UNAVAILABLE, dd, "", "Server is down");
        SiteStore s = SiteStore.get();
        if (s == null) return Resp.err(UNAVAILABLE, dd, "", "Server is down");
        if (d == null || pg == null) return Resp.err(NOT_FOUND, dd, "", "Not found");
        SiteStore.Site x = s.site(d, false);
        if (x == null) return Resp.err(NOT_FOUND, d, pg, "Not found");
        if (x.banned) return Resp.err(BLOCKED, d, pg, x.banReason);
        String body = x.pages.get(pg);
        if (body == null) return Resp.err(NOT_FOUND, d, pg, "Not found");
        SiteStore.Extra ex = s.open(x, pg, viewer);
        int price = pg.equals("index") ? 0 : Markup.parse(body, d, false, null, false).page.price;
        ex.price = price;
        if (price > 0 && !ex.owner && !ex.paid) return new Resp(PAYWALL, d, pg, x.title, x.ownerName, "", String.valueOf(price), ex);
        return new Resp(OK, d, pg, x.title, x.ownerName, body, "", ex);
    }
}
