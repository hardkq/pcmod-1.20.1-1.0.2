package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Конструктор сайтов (платная программа ПК, лицензия проверяется при запуске и на сервере при каждой операции).
 * Редактор - встроенный Блокнот (файлы и черновики на накопителе), справа предпросмотр общим рендером WebView,
 * вкладки «Сайты» (регистрация, продление, освобождение домена) и «Страницы» (открыть, удалить, название и теги).
 * Публикация - svc.sitePut: владельца, лицензию, лимиты и разметку снова проверяет сервер.
 */
public final class WinSiteBuilder implements WinApp {
    private static final int BAR = 18, STAT = 12, M_EDIT = 0, M_SITES = 1, M_PAGES = 2, MAX_SRC = 32000;
    private static final String TEMPLATE = "; Страница сайта. Строки, начинающиеся с точки с запятой, - комментарии.\n"
            + "@header Мой сайт\n# Добро пожаловать!\nЭто моя страница в PC-Net.\n\n- Первый пункт\n- Второй пункт\n---\n"
            + "=> home.pc На главную\n@footer Сделано в Конструкторе сайтов\n";

    private final WinSoft s;
    private final WinSvc svc;
    private final WinNotepad np;
    private final WebView view = new WebView();
    private final WinUi.Button bSites = new WinUi.Button("Сайты", 0, 0, 44, false), bPages = new WinUi.Button("Страницы", 0, 0, 58, false),
            bDraft = new WinUi.Button("Черновик", 0, 0, 52, false), bTpl = new WinUi.Button("Шаблон", 0, 0, 44, false),
            bPub = new WinUi.Button("Опубликовать", 0, 0, 84, true), bBack = new WinUi.Button("< К редактору", 0, 0, 80, false),
            bSel = new WinUi.Button("Править сайт", 0, 0, 80, true), bRenew = new WinUi.Button("Продлить", 0, 0, 80, false),
            bRelease = new WinUi.Button("Освободить", 0, 0, 80, false), bReg = new WinUi.Button("Занять", 0, 0, 84, true),
            bOpen = new WinUi.Button("Открыть", 0, 0, 58, true), bSrv = new WinUi.Button("С сервера", 0, 0, 64, false),
            bDel = new WinUi.Button("Удалить", 0, 0, 50, false), bMeta = new WinUi.Button("Сохранить название", 0, 0, 100, false),
            bNewPage = new WinUi.Button("Создать", 0, 0, 52, false);
    private final WinUi.Field fNew = new WinUi.Field(0, 0, 96), fTitle = new WinUi.Field(0, 0, 100), fTags = new WinUi.Field(0, 0, 100),
            fPage = new WinUi.Field(0, 0, 100);
    private final List<WinUi.Button> vis = new ArrayList<WinUi.Button>();
    private List<SiteStore.Info> mine = new ArrayList<SiteStore.Info>();
    private int[] terms = new int[7];
    private String curSite = "", curPage = "index", msg = "", err, armed = "", selPage = "";
    private boolean msgOk, npDrag;
    private int mode, selSite = -1, ox, oy, aw = 316, ah = 150, ew, pscroll, contentH, lscroll, rev = -1, bytes;
    private long now, bal = -1;
    private WebPage prev;
    private String prevDom = "";
    private WinUi.Field focus;

    public WinSiteBuilder(WinSoft s) {
        this.s = s;
        this.svc = s.svc;
        np = new WinNotepad(s, "");
        fNew.max = 16;
        fNew.hint = "новый адрес";
        fTitle.max = SiteConfig.MAX_TITLE;
        fTitle.hint = "Название сайта";
        fTags.max = 60;
        fTags.hint = "Теги через пробел";
        fPage.max = SiteConfig.MAX_PAGE_NAME;
        fPage.hint = "Новая страница";
        np.startDir(draftDir());
        np.replace(TEMPLATE);
        refresh();
    }

    @Override public String title() { return "Конструктор сайтов" + (curSite.isEmpty() ? "" : " - " + curSite); }

    @Override public String id() { return "sitebuilder"; }

    @Override public boolean resizable() { return false; }

    @Override public int minW() { return 300; }

    @Override public int minH() { return 150; }

    // ------------------------------------------------------------------ данные
    private void refresh() {
        terms = svc.siteTerms();
        mine = svc.siteMine();
        bal = svc.bankReady() ? svc.balance() : -1;
        if (selSite >= mine.size()) selSite = mine.size() - 1;
    }

    private SiteStore.Info info(String d) {
        for (SiteStore.Info i : mine) if (i.domain.equals(d)) return i;
        return null;
    }

    private void say(String m, boolean ok) { msg = m; msgOk = ok; }

    private void result(WinSvc.Res r) {
        say(r.msg, r.ok);
        refresh();
    }

    private String draftDir() {
        String docs = s.fs.home() + "/Documents", d = docs + "/Sites";
        if (!s.fs.isDir(docs)) s.fs.mkdir(docs);
        if (!s.fs.isDir(d)) s.fs.mkdir(d);
        return s.fs.isDir(d) ? d : docs;
    }

    private String draftPath() { return draftDir() + "/" + curSite.replace(".pc", "") + "_" + curPage + ".txt"; }

    /** Открыть страницу сайта: черновик с накопителя, иначе версия с сервера, иначе шаблон. */
    private void openPage(String page, boolean forceServer) {
        if (curSite.isEmpty()) {
            say("Сначала выберите сайт", false);
            return;
        }
        curPage = page;
        String d = draftPath();
        if (!forceServer && s.fs.isFile(d)) {
            np.openPath(d);
            say("Открыт черновик: " + WinFs.name(d), true);
        } else {
            SiteHost.Resp r = svc.siteFetch(curSite, page.equals("index") ? "" : page);
            if (r.code == SiteHost.OK) {
                np.replace(r.body);
                say("Загружена версия с сервера", true);
            } else {
                np.replace(TEMPLATE);
                say("Новая страница (шаблон)", true);
            }
        }
        mode = M_EDIT;
        focus = null;
    }

    private void saveDraft() {
        if (curSite.isEmpty()) {
            say("Сначала выберите сайт", false);
            return;
        }
        boolean ok = s.fs.write(draftPath(), np.text());
        say(ok ? "Черновик сохранён: " + WinFs.name(draftPath()) : "Не удалось сохранить: нет места", ok);
    }

    private void publish() {
        if (curSite.isEmpty()) {
            say("Сначала выберите сайт (кнопка «Сайты»)", false);
            return;
        }
        String t = np.text();
        String e = SiteStore.checkMarkup(t, curSite);
        if (e != null) {
            say(WinSvcImpl.ru(e), false);
            return;
        }
        WinSvc.Res r = svc.sitePut(curSite, curPage, t);
        result(r);
        if (r.ok) saveDraft2();
    }

    /** После успешной публикации черновик обновляется тихо. */
    private void saveDraft2() { s.fs.write(draftPath(), np.text()); }

    private void checkPreview() {
        String dom = curSite.isEmpty() ? "preview.pc" : curSite;
        if (np.rev() == rev && dom.equals(prevDom)) return;
        rev = np.rev();
        prevDom = dom;
        String t = np.text();
        bytes = t.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
        if (t.length() > MAX_SRC) {
            err = "Страница слишком большая (до " + terms[5] + " байт)";
            List<WebRow> o = new ArrayList<WebRow>();
            o.add(new WebRow('e', err, null));
            prev = WebPage.of(o);
            return;
        }
        String e = SiteStore.checkMarkup(t, dom);
        err = e == null ? null : WinSvcImpl.ru(e);
        prev = SiteWidgets.expand(Markup.parse(t, dom, false, null, false).page, dom, null, true);
    }

    // ------------------------------------------------------------------ рисование
    private WebView.Skin skin(WinTheme th, int w) {
        WebView.Skin k = new WebView.Skin();
        k.wrapW = Math.max(40, w - 14);
        k.text = th.text();
        k.sub = th.sub();
        k.accent = th.accent();
        k.accentHover = th.accentHover();
        k.onAccent = th.onAccent();
        k.ok = th.ok();
        k.bad = th.bad();
        return k;
    }

    private void place(WinUi.Button b, int x, int y, int w) {
        b.x = x;
        b.y = y;
        b.w = w;
        b.enabled = true;
        vis.add(b);
    }

    private void drawBtn(PixelScreen p, WinTheme th, WinUi.Button b) { b.draw(p, th); }

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        ox = x;
        oy = y;
        aw = w;
        ah = h;
        vis.clear();
        boolean busy = mode == M_EDIT && np.busy();
        // верхняя панель
        p.fillRect(x, y, w, BAR, th.bg());
        p.hline(x, y + BAR - 1, w, th.border());
        int by = y + BAR, bh = h - BAR - STAT;
        if (mode == M_EDIT) {
            int bx = x + 3;
            place(bSites, bx, y + 1, 44);
            place(bPages, bx += 47, y + 1, 58);
            place(bDraft, bx += 61, y + 1, 52);
            place(bTpl, bx += 55, y + 1, 44);
            place(bPub, bx += 47, y + 1, 84);
            bTpl.label = armed.equals("tpl") ? "Точно?" : "Шаблон";
            bPub.enabled = !busy;
            for (WinUi.Button b : vis) {
                if (busy) b.enabled = false;
                drawBtn(p, th, b);
            }
            drawEdit(p, th, x, by, w, bh, busy);
        } else {
            place(bBack, x + 3, y + 1, 80);
            drawBtn(p, th, bBack);
            p.drawTextRight(x + w - 6, y + 5, bal < 0 ? "Банк недоступен" : "Баланс: " + bal + " К", bal < 0 ? th.bad() : th.sub(), 1, false);
            if (mode == M_SITES) drawSites(p, th, x, by, w, bh);
            else drawPages(p, th, x, by, w, bh);
        }
        // строка состояния
        int sy = y + h - STAT;
        p.fillRect(x, sy, w, STAT, th.bg());
        String left;
        int col;
        if (!msg.isEmpty()) {
            left = msg;
            col = msgOk ? th.ok() : th.bad();
        } else if (mode == M_EDIT && err != null) {
            left = err;
            col = th.bad();
        } else {
            left = curSite.isEmpty() ? "Выберите сайт: кнопка «Сайты»" : curSite + "/" + (curPage.equals("index") ? "" : curPage);
            col = th.sub();
        }
        p.drawText(x + 6, sy + 2, PixelScreen.fit(left, w - 92, 1, false), col);
        if (mode == M_EDIT) p.drawTextRight(x + w - 6, sy + 2, bytes + "/" + terms[5] + " Б", bytes > terms[5] ? th.bad() : th.sub(), 1, false);
    }

    private void drawEdit(PixelScreen p, WinTheme th, int x, int by, int w, int bh, boolean busy) {
        checkPreview();
        ew = busy ? w : w * 11 / 20;
        np.draw(p, th, x, by, ew, bh);
        if (busy) return;
        int px = x + ew + 2, pw = w - ew - 2;
        p.fillRect(px, by, pw, bh, th.surface());
        p.hline(px, by, pw, th.border());
        p.vline(px - 1, by, bh, th.border());
        p.drawText(px + 4, by + 2, "Предпросмотр", th.sub());
        int cy = by + 13, ch = bh - 13;
        p.pushClip(px, cy, pw, ch);
        contentH = view.draw(p, prev, skin(th, pw), px, cy, px, cy, pw - 6, pscroll, cy, ch, -1);
        p.popClip();
        WinSoft.scrollbar(p, th, px + pw - 5, cy + 1, ch - 2, contentH, ch, pscroll);
    }

    private void drawSites(PixelScreen p, WinTheme th, int x, int by, int w, int bh) {
        p.drawText(x + 6, by + 3, "Мои сайты " + mine.size() + "/" + terms[3], th.text(), 1, true);
        int ly = by + 14, lh = bh - 14 - 24, rows = Math.max(1, lh / 14);
        p.roundRectBorder(x + 4, ly, 142, lh, 4, th.surface(), th.border());
        lscroll = Math.max(0, Math.min(lscroll, Math.max(0, mine.size() - rows)));
        for (int i = 0; i < rows && lscroll + i < mine.size(); i++) {
            SiteStore.Info f = mine.get(lscroll + i);
            int ry = ly + 2 + i * 14;
            if (lscroll + i == selSite) p.roundRect(x + 6, ry, 138, 13, 3, PixelScreen.alpha(th.accent(), 0x50));
            p.drawText(x + 10, ry + 2, f.domain, f.banned ? th.bad() : th.text());
            p.drawTextRight(x + 142, ry + 2, f.daysLeft < 0 ? "срок!" : f.daysLeft + " сут.", f.daysLeft < 0 ? th.bad() : th.sub(), 1, false);
        }
        if (mine.isEmpty()) p.drawText(x + 10, ly + 5, "Нет сайтов. Займите адрес.", th.sub());
        WinSoft.scrollbar(p, th, x + 141, ly + 2, lh - 4, mine.size(), rows, lscroll);
        fNew.x = x + 4;
        fNew.y = by + bh - 20;
        fNew.draw(p, th, focus == fNew, now);
        place(bReg, x + 104, by + bh - 20, 84);
        bReg.label = "Занять (" + terms[0] + " К)";
        int rx = x + 152, rw = w - 156;
        SiteStore.Info f = selSite >= 0 && selSite < mine.size() ? mine.get(selSite) : null;
        if (f == null) {
            p.drawText(rx, by + 16, "Выберите сайт в списке", th.sub());
            drawBtn(p, th, bReg);
            return;
        }
        p.drawText(rx, by + 16, f.domain, th.text(), 1, true);
        p.drawText(rx, by + 27, f.daysLeft < 0 ? "Срок вышел! Продлите." : "Осталось: " + f.daysLeft + " сут.", f.daysLeft < 0 ? th.bad() : th.sub());
        p.drawText(rx, by + 38, "Страниц: " + f.pages.size() + "/" + terms[4] + ", " + f.bytes + " Б", th.sub());
        p.drawText(rx, by + 49, f.banned ? "Заблокирован" + (f.banReason.isEmpty() ? "" : ": " + f.banReason) : "Период: " + terms[2] + " сут.", f.banned ? th.bad() : th.sub());
        place(bSel, rx, by + 62, rw);
        place(bRenew, rx, by + 80, rw);
        place(bRelease, rx, by + 98, rw);
        bSel.enabled = !f.banned;
        bRenew.label = "Продлить (" + terms[1] + " К)";
        bRelease.label = armed.equals("rel") ? "Точно освободить?" : "Освободить";
        for (WinUi.Button b : vis) drawBtn(p, th, b);
    }

    private void drawPages(PixelScreen p, WinTheme th, int x, int by, int w, int bh) {
        SiteStore.Info f = info(curSite);
        p.drawText(x + 6, by + 3, "Страницы: " + (curSite.isEmpty() ? "-" : curSite), th.text(), 1, true);
        int ly = by + 14, lh = bh - 14, rows = Math.max(1, lh / 14);
        p.roundRectBorder(x + 4, ly, 110, lh, 4, th.surface(), th.border());
        List<String> pg = f == null ? new ArrayList<String>() : f.pages;
        lscroll = Math.max(0, Math.min(lscroll, Math.max(0, pg.size() - rows)));
        for (int i = 0; i < rows && lscroll + i < pg.size(); i++) {
            String n = pg.get(lscroll + i);
            int ry = ly + 2 + i * 14;
            if (n.equals(selPage)) p.roundRect(x + 6, ry, 106, 13, 3, PixelScreen.alpha(th.accent(), 0x50));
            p.drawText(x + 10, ry + 2, PixelScreen.fit(n, 98, 1, false), th.text());
        }
        if (pg.isEmpty()) p.drawText(x + 10, ly + 5, "Пока пусто", th.sub());
        WinSoft.scrollbar(p, th, x + 109, ly + 2, lh - 4, pg.size(), rows, lscroll);
        int rx = x + 120, rw = w - 124;
        fTitle.x = rx; fTitle.y = by + 14; fTitle.w = rw;
        fTags.x = rx; fTags.y = by + 32; fTags.w = rw;
        fPage.x = rx; fPage.y = by + 74; fPage.w = rw - 56;
        fTitle.draw(p, th, focus == fTitle, now);
        fTags.draw(p, th, focus == fTags, now);
        fPage.draw(p, th, focus == fPage, now);
        place(bMeta, rx, by + 50, rw);
        place(bNewPage, rx + rw - 52, by + 74, 52);
        place(bOpen, rx, by + 94, 58);
        place(bSrv, rx + 61, by + 94, 64);
        place(bDel, rx + 128, by + 94, 50);
        bDel.label = armed.equals("del") ? "Точно?" : "Удалить";
        boolean has = !selPage.isEmpty();
        bOpen.enabled = bSrv.enabled = bDel.enabled = has;
        for (WinUi.Button b : vis) {
            drawBtn(p, th, b);
        }
    }

    // ------------------------------------------------------------------ действия
    private void act(WinUi.Button b) {
        String a = armed;
        armed = "";
        msg = "";
        if (b == bSites) {
            mode = M_SITES;
            refresh();
            focus = null;
        } else if (b == bPages) {
            if (curSite.isEmpty()) {
                say("Сначала выберите сайт", false);
                return;
            }
            mode = M_PAGES;
            refresh();
            SiteStore.Info f = info(curSite);
            fTitle.sb.setLength(0);
            fTags.sb.setLength(0);
            if (f != null) {
                fTitle.sb.append(f.title);
                fTags.sb.append(f.tags);
            }
            selPage = f != null && f.pages.contains(curPage) ? curPage : "";
            focus = null;
        } else if (b == bBack) {
            mode = M_EDIT;
            focus = null;
        } else if (b == bDraft) saveDraft();
        else if (b == bTpl) {
            if (a.equals("tpl") || np.text().trim().isEmpty()) {
                np.replace(TEMPLATE);
                say("Вставлен шаблон", true);
            } else {
                armed = "tpl";
                say("Шаблон заменит текст. Нажмите ещё раз", false);
            }
        } else if (b == bPub) publish();
        else if (b == bSel) {
            if (selSite >= 0 && selSite < mine.size()) {
                curSite = mine.get(selSite).domain;
                openPage("index", false);
            }
        } else if (b == bRenew) {
            if (selSite >= 0 && selSite < mine.size()) result(svc.siteRenew(mine.get(selSite).domain));
        } else if (b == bRelease) {
            if (selSite < 0 || selSite >= mine.size()) return;
            String d = mine.get(selSite).domain;
            if (a.equals("rel")) {
                result(svc.siteRelease(d));
                if (curSite.equals(d)) curSite = "";
                selSite = -1;
            } else {
                armed = "rel";
                say("Сайт и все страницы будут удалены. Нажмите ещё раз", false);
            }
        } else if (b == bReg) doRegister();
        else if (b == bOpen) {
            if (!selPage.isEmpty()) openPage(selPage, false);
        } else if (b == bSrv) {
            if (!selPage.isEmpty()) openPage(selPage, true);
        } else if (b == bDel) {
            if (selPage.isEmpty()) return;
            if (a.equals("del")) {
                result(svc.siteDeletePage(curSite, selPage));
                selPage = "";
            } else {
                armed = "del";
                say("Страница будет удалена с сервера. Нажмите ещё раз", false);
            }
        } else if (b == bMeta) result(svc.siteMeta(curSite, fTitle.sb.toString(), fTags.sb.toString()));
        else if (b == bNewPage) {
            String n = SiteConfig.pageName(fPage.sb.toString().isEmpty() ? "index" : fPage.sb.toString());
            if (n == null) say("Имя страницы: a-z, 0-9, _, - (до 24 знаков)", false);
            else {
                fPage.sb.setLength(0);
                openPage(n, false);
            }
        }
    }

    private void doRegister() {
        String d = SiteConfig.normalize(fNew.sb.toString());
        if (d == null) {
            say("Адрес: a-z, 0-9, дефис, 3-16 знаков", false);
            return;
        }
        WinSvc.Res r = svc.siteRegister(d);
        result(r);
        if (r.ok) {
            fNew.sb.setLength(0);
            for (int i = 0; i < mine.size(); i++) if (mine.get(i).domain.equals(d)) selSite = i;
        }
    }

    // ------------------------------------------------------------------ ввод
    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int ax = rx + ox, ay = ry + oy;
        boolean busy = mode == M_EDIT && np.busy();
        if (mode == M_EDIT && (busy || npDrag || (ry >= BAR && rx < ew))) {
            if (kind == PixelScreen.MOUSE_PRESS) npDrag = true;
            if (kind == PixelScreen.MOUSE_RELEASE) npDrag = false;
            focus = null;
            return np.mouse(rx, ry - BAR, btn, kind);
        }
        if (mode == M_EDIT && (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN)) {
            pscroll = Math.max(0, pscroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -12 : 12));
            return true;
        }
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            lscroll = Math.max(0, lscroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -1 : 1));
            return true;
        }
        boolean d = false;
        for (WinUi.Button b : new ArrayList<WinUi.Button>(vis)) {
            boolean hv = b.hit(ax, ay);
            if (hv != b.hover) {
                b.hover = hv;
                d = true;
            }
        }
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return d;
        for (WinUi.Button b : new ArrayList<WinUi.Button>(vis)) {
            if (b.hit(ax, ay)) {
                act(b);
                return true;
            }
        }
        if (mode == M_SITES) {
            focus = fNew.hit(ax, ay) ? fNew : null;
            int by = oy + BAR, ly = by + 14, lh = ah - BAR - STAT - 14 - 24;
            if (ax >= ox + 4 && ax < ox + 146 && ay >= ly && ay < ly + lh) {
                int i = lscroll + (ay - ly - 2) / 14;
                if (i >= 0 && i < mine.size()) {
                    selSite = i;
                    armed = "";
                    msg = "";
                }
            }
        } else if (mode == M_PAGES) {
            focus = fTitle.hit(ax, ay) ? fTitle : fTags.hit(ax, ay) ? fTags : fPage.hit(ax, ay) ? fPage : null;
            SiteStore.Info f = info(curSite);
            int ly = oy + BAR + 14;
            if (f != null && ax >= ox + 4 && ax < ox + 114 && ay >= ly && ay < ly + ah - BAR - STAT - 14) {
                int i = lscroll + (ay - ly - 2) / 14;
                if (i >= 0 && i < f.pages.size()) {
                    selPage = f.pages.get(i);
                    armed = "";
                }
            }
        }
        return true;
    }

    @Override
    public boolean key(char c, int key) {
        if (mode == M_EDIT) return np.key(c, key);
        if (focus != null) {
            boolean enter = focus.key(c, key);
            msg = "";
            if (enter) {
                if (focus == fNew) doRegister();
                else if (focus == fPage) act(bNewPage);
                else if (focus == fTitle || focus == fTags) act(bMeta);
            }
            return true;
        }
        if (key == WinSoft.K_ESC) {
            mode = M_EDIT;
            return true;
        }
        return false;
    }

    @Override
    public boolean tick(long t) {
        now = t;
        boolean d = np.tick(t);
        if (mode != M_EDIT && t % 100 == 0) {
            refresh();
            d = true;
        }
        return d || mode != M_EDIT && focus != null && t % 10 == 0;
    }
}
