package ru.pcmod.common;

/** Страница «Персонализация»: тема, акцентный цвет, обои, прозрачность и анимации. Изменения применяются сразу. */
final class WinPersonal extends WinFormPage {
    private static final int TW = 52, TH = 29, GX = 6, GY = 4, SW = 14;

    private final WinTheme th;
    private final WinLook look;
    private final WinSpec.Perf perf;
    private final int[][] thumbs = new int[WinWalls.COUNT][];
    private boolean thumbDark;
    private int hoverAcc = -1, hoverWall = -1, accW = 200;

    WinPersonal(WinHost host, WinTheme th, WinLook look, WinSpec.Perf perf) {
        super(host);
        this.th = th;
        this.look = look;
        this.perf = perf;
    }

    @Override
    void build(WinForm f) {
        f.section("Тема");
        f.card("Режим").choice(WinLook.MODES, look.mode, look::setMode);
        f.section("Акцентный цвет: " + WinLook.ACCENT_NAMES[look.accent]);
        f.custom(26, this::paintAccent, this::touchAccent);
        f.section("Обои: " + WinWalls.NAMES[look.wall]);
        f.custom(2 * TH + 3 * GY + 2, this::paintWalls, this::touchWalls);
        f.section("Эффекты");
        boolean g = look.glassSupported(), a = look.animSupported();
        f.card("Эффекты прозрачности").sub(g ? "Mica и тени окон" : "Недоступно: слабое железо")
                .toggle(look.trans && g, g, () -> look.setTrans(!look.trans));
        f.card("Анимация окон").sub(a ? "Открытие, закрытие, сворачивание" : "Недоступно: слабое железо")
                .toggle(look.anim && a, a, () -> look.setAnim(!look.anim));
        if (!g || !a) f.note("Уровень производительности ПК: " + perf.label + ". Эффекты зависят от процессора, памяти и видеокарты.", false);
    }

    // ------------------------------------------------------------------ акцентный цвет
    private int pitch() {
        return Math.max(SW + 2, (accW - 20) / WinLook.ACCENTS.length);
    }

    private void paintAccent(PixelScreen p, int x, int y, int w) {
        accW = w;
        for (int i = 0; i < WinLook.ACCENTS.length; i++) {
            int sx = x + 10 + i * pitch(), c = WinLook.ACCENTS[i];
            if (th.dark) c = PixelScreen.lerp(c, 0xFFFFFFFF, 0.2f) | 0xFF000000;
            p.roundRect(sx, y + 6, SW, SW, 4, c);
            if (look.accent == i) p.roundRectOutline(sx - 2, y + 4, SW + 4, SW + 4, 6, 1, th.text());
            else if (hoverAcc == i) p.roundRectOutline(sx - 1, y + 5, SW + 2, SW + 2, 5, 1, th.sub());
        }
    }

    private boolean touchAccent(int rx, int ry, boolean press) {
        int i = -1;
        if (rx >= 10 && ry >= 4 && ry < 4 + SW + 4) {
            int k = (rx - 10) / pitch();
            if (k < WinLook.ACCENTS.length && (rx - 10) % pitch() < SW) i = k;
        }
        boolean ch = i != hoverAcc;
        hoverAcc = i;
        if (press && i >= 0) look.setAccent(i);
        return ch || press;
    }

    // ------------------------------------------------------------------ обои
    private int[] thumb(int i) {
        if (thumbDark != th.dark) {
            for (int k = 0; k < thumbs.length; k++) thumbs[k] = null;
            thumbDark = th.dark;
        }
        if (thumbs[i] == null) {
            int[] src = WinGfx.wall(i, th.dark), t = new int[TW * TH];
            int sw = PixelScreen.W, sh = PixelScreen.H;
            for (int j = 0; j < TH; j++) {
                for (int k = 0; k < TW; k++) {
                    int x0 = k * sw / TW, x1 = Math.max(x0 + 1, (k + 1) * sw / TW), y0 = j * sh / TH, y1 = Math.max(y0 + 1, (j + 1) * sh / TH);
                    int r = 0, g = 0, b = 0, n = 0;
                    for (int y = y0; y < y1; y++) {
                        for (int x = x0; x < x1; x++) {
                            int c = src[y * sw + x];
                            r += c >> 16 & 255;
                            g += c >> 8 & 255;
                            b += c & 255;
                            n++;
                        }
                    }
                    t[j * TW + k] = 0xFF000000 | (r / n) << 16 | (g / n) << 8 | b / n;
                }
            }
            thumbs[i] = t;
        }
        return thumbs[i];
    }

    private void paintWalls(PixelScreen p, int x, int y, int w) {
        for (int i = 0; i < WinWalls.COUNT; i++) {
            int sx = x + 10 + (i % 3) * (TW + GX), sy = y + 3 + (i / 3) * (TH + GY);
            p.blit(thumb(i), TW, TH, sx, sy);
            if (look.wall == i) p.roundRectOutline(sx - 2, sy - 2, TW + 4, TH + 4, 3, 2, th.accent());
            else if (hoverWall == i) p.roundRectOutline(sx - 1, sy - 1, TW + 2, TH + 2, 2, 1, th.sub());
        }
    }

    private boolean touchWalls(int rx, int ry, boolean press) {
        int i = -1, col = (rx - 10) / (TW + GX), row = (ry - 3) / (TH + GY);
        if (rx >= 10 && ry >= 3 && col < 3 && row < 2 && (rx - 10) % (TW + GX) < TW && (ry - 3) % (TH + GY) < TH) {
            int k = row * 3 + col;
            if (k < WinWalls.COUNT) i = k;
        }
        boolean ch = i != hoverWall;
        hoverWall = i;
        if (press && i >= 0) look.setWall(i);
        return ch || press;
    }
}
