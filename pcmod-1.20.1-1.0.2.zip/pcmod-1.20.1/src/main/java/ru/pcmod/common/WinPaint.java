package ru.pcmod.common;

import java.util.ArrayDeque;

/** Paint: холст 144x80, 16 цветов, карандаш, кисть, ластик, заливка, линия, прямоугольник, эллипс, пипетка, отмена, файлы .pnt. */
public final class WinPaint implements WinApp {
    private static final int CW = 144, CH = 80, BAR = 15, PAL = 14, TOOLX = 2, CX = 27, CY = BAR + 2;
    private static final int[] COLORS = {0xFF000000, 0xFF7F7F7F, 0xFFC3C3C3, 0xFFFFFFFF, 0xFFED1C24, 0xFF880015, 0xFFFF7F27, 0xFFFFF200,
            0xFFB5E61D, 0xFF22B14C, 0xFF00A2E8, 0xFF3F48CC, 0xFFA349A4, 0xFFFFAEC9, 0xFFB97A57, 0xFF99D9EA};
    private static final String[] TOOLS = {"Карандаш", "Кисть", "Ластик", "Заливка", "Линия", "Прямоугольник", "Эллипс", "Пипетка"};
    private static final int[] SIZES = {1, 2, 3, 5};
    private static final String ALPHA = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private final WinSoft s;
    private final byte[] cv = new byte[CW * CH];
    private final int[] img = new int[CW * CH];
    private final ArrayDeque<byte[]> undo = new ArrayDeque<byte[]>();
    private byte[] tmp;
    private String path = "", note = "";
    private boolean mod, filled, down;
    private int tool, size = 1, fg = 0, bg = 3, btn, lx, ly, sx, sy, scx, scy, hover = -1, cmx = -1, cmy = -1, aw = 260, ah = 133;
    private long now;
    private WinPopup menu;
    private WinFileDialog dlg;

    public WinPaint(WinSoft s, String arg) {
        this.s = s;
        java.util.Arrays.fill(cv, (byte) 3);
        if (!arg.isEmpty()) load(arg);
    }

    @Override public String title() { return (mod ? "*" : "") + (path.isEmpty() ? "Без имени" : WinFs.name(path)) + " - Paint"; }

    @Override public String id() { return "paint"; }

    @Override public int minW() { return 170; }

    @Override public int minH() { return 100; }

    // ------------------------------------------------------------------ рисование на холсте
    private void snap() {
        undo.addLast(cv.clone());
        if (undo.size() > 8) undo.removeFirst();
        mod = true;
        note = "";
    }

    private static void plot(byte[] t, int x, int y, int c) {
        if (x >= 0 && y >= 0 && x < CW && y < CH) t[y * CW + x] = (byte) c;
    }

    private static void dab(byte[] t, int x, int y, int d, boolean round, int c) {
        int a = d / 2;
        for (int j = 0; j < d; j++) {
            for (int i = 0; i < d; i++) {
                if (round && d > 2 && (i - (d - 1) / 2.0) * (i - (d - 1) / 2.0) + (j - (d - 1) / 2.0) * (j - (d - 1) / 2.0) > d * d / 4.0) continue;
                plot(t, x - a + i, y - a + j, c);
            }
        }
    }

    private static void line(byte[] t, int x0, int y0, int x1, int y1, int d, boolean round, int c) {
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, e = dx + dy;
        while (true) {
            dab(t, x0, y0, d, round, c);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * e;
            if (e2 >= dy) {
                e += dy;
                x0 += sx;
            }
            if (e2 <= dx) {
                e += dx;
                y0 += sy;
            }
        }
    }

    private static void flood(byte[] t, int x, int y, int c) {
        if (x < 0 || y < 0 || x >= CW || y >= CH) return;
        int from = t[y * CW + x];
        if (from == c) return;
        int[] st = new int[CW * CH];
        int n = 0;
        st[n++] = y * CW + x;
        while (n > 0) {
            int q = st[--n], qx = q % CW, qy = q / CW;
            if (t[q] != from) continue;
            int l = qx, r = qx;
            while (l > 0 && t[qy * CW + l - 1] == from) l--;
            while (r < CW - 1 && t[qy * CW + r + 1] == from) r++;
            for (int i = l; i <= r; i++) {
                t[qy * CW + i] = (byte) c;
                if (qy > 0 && t[(qy - 1) * CW + i] == from && (i == l || t[(qy - 1) * CW + i - 1] != from)) st[n++] = (qy - 1) * CW + i;
                if (qy < CH - 1 && t[(qy + 1) * CW + i] == from && (i == l || t[(qy + 1) * CW + i - 1] != from)) st[n++] = (qy + 1) * CW + i;
            }
        }
    }

    private void shape(byte[] t, int x0, int y0, int x1, int y1, int c) {
        int d = size;
        if (tool == 4) {
            line(t, x0, y0, x1, y1, d, false, c);
            return;
        }
        int l = Math.min(x0, x1), r = Math.max(x0, x1), u = Math.min(y0, y1), b = Math.max(y0, y1);
        if (tool == 5) {
            for (int j = u; j <= b; j++) {
                for (int i = l; i <= r; i++) {
                    boolean edge = i - l < d || r - i < d || j - u < d || b - j < d;
                    if (filled || edge) plot(t, i, j, c);
                }
            }
            return;
        }
        double a = (r - l) / 2.0, bb = (b - u) / 2.0, cx = (l + r) / 2.0, cy = (u + b) / 2.0;
        for (int j = u; j <= b; j++) {
            for (int i = l; i <= r; i++) {
                double ox = a < 0.5 ? 0 : (i - cx) / (a + 0.5), oy = bb < 0.5 ? 0 : (j - cy) / (bb + 0.5);
                if (ox * ox + oy * oy > 1) continue;
                double ix = a - d < 0.5 ? 2 : (i - cx) / (a + 0.5 - d), iy = bb - d < 0.5 ? 2 : (j - cy) / (bb + 0.5 - d);
                if (filled || ix * ix + iy * iy >= 1) plot(t, i, j, c);
            }
        }
    }

    private int px(int rx) { return Math.max(0, Math.min(CW - 1, rx - CX + scx)); }

    private int py(int ry) { return Math.max(0, Math.min(CH - 1, ry - CY + scy)); }

    private int col() { return btn == 1 ? bg : fg; }

    // ------------------------------------------------------------------ файлы
    private String encode() {
        StringBuilder b = new StringBuilder("PNT1 " + CW + " " + CH + "\n");
        int i = 0;
        while (i < cv.length) {
            int c = cv[i], n = 1;
            while (i + n < cv.length && cv[i + n] == c && n < 62) n++;
            b.append(Integer.toHexString(c & 15).toUpperCase()).append(ALPHA.charAt(n - 1));
            i += n;
        }
        return b.toString();
    }

    private void load(String p) {
        String t = s.fs.read(p);
        if (t == null || s.fs.size(p) != t.length()) {
            note = "Не удалось открыть файл";
            return;
        }
        byte[] n = new byte[CW * CH];
        java.util.Arrays.fill(n, (byte) 3);
        if (!t.isEmpty()) {
            try {
                int nl = t.indexOf('\n');
                String[] h = t.substring(0, nl).split(" ");
                if (!h[0].equals("PNT1")) throw new IllegalArgumentException();
                int w = Integer.parseInt(h[1]), hh = Integer.parseInt(h[2]), pos = 0, total = w * hh;
                for (int i = nl + 1; i + 1 < t.length() && pos < total; i += 2) {
                    int c = Character.digit(t.charAt(i), 16), cnt = ALPHA.indexOf(t.charAt(i + 1)) + 1;
                    if (c < 0 || cnt <= 0) throw new IllegalArgumentException();
                    for (int k = 0; k < cnt && pos < total; k++, pos++) {
                        if (pos % w < CW && pos / w < CH) n[pos / w * CW + pos % w] = (byte) c;
                    }
                }
            } catch (RuntimeException e) {
                note = "Файл повреждён";
                return;
            }
        }
        snap();
        System.arraycopy(n, 0, cv, 0, n.length);
        path = p;
        mod = false;
        scx = 0;
        scy = 0;
    }

    private void save() {
        if (path.isEmpty()) {
            saveAs();
            return;
        }
        if (s.fs.write(path, encode())) {
            mod = false;
            note = "Сохранено";
        } else {
            note = "Не удалось сохранить: нет места";
        }
    }

    private void saveAs() {
        String dir = path.isEmpty() ? s.fs.home() + "/Pictures" : WinFs.parent(path);
        dlg = new WinFileDialog(s.fs, true, "Сохранить как", dir, path.isEmpty() ? "Рисунок.pnt" : WinFs.name(path), "pnt", new String[] {"pnt"}, p -> {
            path = p;
            save();
        });
    }

    private void act(int id) {
        if (id == 1) {
            snap();
            java.util.Arrays.fill(cv, (byte) bg);
            path = "";
            mod = false;
        } else if (id == 2) {
            dlg = new WinFileDialog(s.fs, false, "Открыть", path.isEmpty() ? s.fs.home() + "/Pictures" : WinFs.parent(path), "", "pnt", new String[] {"pnt"}, this::load);
        } else if (id == 3) {
            save();
        } else if (id == 4) {
            saveAs();
        }
    }

    // ------------------------------------------------------------------ интерфейс
    private int toolBox(int i) { return TOOLX + (i % 2) * 11; }

    private int toolY(int i) { return BAR + 3 + (i / 2) * 11; }

    private int palY() { return ah - PAL; }

    private static void toolIcon(PixelScreen p, int i, int x, int y, int c) {
        switch (i) {
            case 0: WinGfx.line(p, x + 1, y + 8, x + 7, y + 2, c); p.fillRect(x + 6, y + 1, 3, 2, c); break;
            case 1: p.fillRect(x + 4, y + 1, 5, 4, c); WinGfx.line(p, x + 1, y + 8, x + 4, y + 5, c); break;
            case 2: p.roundRect(x + 1, y + 3, 8, 5, 1, c); break;
            case 3: p.roundRectOutline(x + 1, y + 2, 7, 6, 1, 1, c); p.fillRect(x + 3, y + 5, 3, 3, c); p.pixel(x + 8, y + 6, c); break;
            case 4: WinGfx.line(p, x + 1, y + 8, x + 8, y + 1, c); break;
            case 5: p.rect(x + 1, y + 2, 8, 6, 1, c); break;
            case 6: p.roundRectOutline(x + 1, y + 2, 8, 6, 3, 1, c); break;
            default: WinGfx.line(p, x + 2, y + 7, x + 7, y + 2, c); p.fillRect(x + 6, y + 1, 3, 3, c); break;
        }
    }

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        WinSoft.flat(p, th, x + 3, y + 1, 30, BAR - 2, "Файл", hover == 1, menu != null && menu.open());
        WinSoft.flat(p, th, x + 35, y + 1, 40, BAR - 2, "Отмена", hover == 2 && !undo.isEmpty(), false);
        for (int i = 0; i < 4; i++) {
            int bx = x + 82 + i * 15;
            if (size == SIZES[i]) p.roundRect(bx, y + 1, 14, BAR - 2, 3, PixelScreen.alpha(th.accent(), 0x40));
            else if (hover == 10 + i) p.roundRect(bx, y + 1, 14, BAR - 2, 3, th.hover());
            int d = Math.min(SIZES[i], 5);
            p.fillRect(bx + 7 - d / 2, y + 7 - d / 2, d, d, th.text());
        }
        WinSoft.flat(p, th, x + 146, y + 1, 54, BAR - 2, filled ? "Залитая" : "Контур", hover == 3, false);
        String st = note.isEmpty() ? (cmx >= 0 ? cmx + ", " + cmy : "") : note;
        p.drawTextRight(x + w - 6, y + 3, st, note.isEmpty() ? th.sub() : th.warn(), 1, false);
        p.hline(x, y + BAR, w, th.border());
        for (int i = 0; i < 8; i++) {
            int bx = x + toolBox(i), by = y + toolY(i);
            if (tool == i) p.roundRect(bx, by, 10, 10, 2, PixelScreen.alpha(th.accent(), 0x50));
            else if (hover == 20 + i) p.roundRect(bx, by, 10, 10, 2, th.hover());
            toolIcon(p, i, bx, by, th.text());
        }
        int fy = y + BAR + 3 + 4 * 11 + 3;
        p.rect(x + 8, fy + 6, 11, 11, 1, th.border());
        p.fillRect(x + 9, fy + 7, 9, 9, COLORS[bg]);
        p.rect(x + 3, fy, 11, 11, 1, th.border());
        p.fillRect(x + 4, fy + 1, 9, 9, COLORS[fg]);
        // холст
        int ax = x + CX, ay = y + CY, aw2 = w - CX - 3, ah2 = h - CY - PAL - 3;
        p.fillRect(x + CX - 1, y + CY - 1, aw2 + 2, ah2 + 2, th.dark ? 0xFF161616 : 0xFFD6D6D6);
        byte[] v = tmp != null ? tmp : cv;
        for (int i = 0; i < v.length; i++) img[i] = COLORS[v[i] & 15];
        p.pushClip(ax, ay, aw2, ah2);
        p.blit(img, CW, CH, ax - scx, ay - scy);
        p.popClip();
        // палитра
        int pyy = y + palY();
        p.hline(x, pyy - 2, w, th.border());
        for (int i = 0; i < 16; i++) {
            int bx = x + CX + i * 11;
            p.fillRect(bx, pyy, 10, 10, COLORS[i]);
            p.rect(bx - 1, pyy - 1, 12, 12, 1, hover == 40 + i ? th.accent() : PixelScreen.alpha(th.border(), 0x90));
        }
        p.drawText(x + CX + 16 * 11 + 4, pyy + 1, TOOLS[tool], th.sub());
        if (menu != null) menu.draw(p, th, x, y, s.perf.effects);
        if (dlg != null) dlg.draw(p, th, x, y, w, h, now);
    }

    @Override
    public boolean tick(long t) {
        now = t;
        return false;
    }

    @Override
    public boolean key(char c, int key) {
        if (dlg != null) {
            boolean r = dlg.key(c, key);
            if (dlg.closed) dlg = null;
            return r;
        }
        if (menu != null && menu.open() && key == WinSoft.K_ESC) {
            menu.close();
            return true;
        }
        return false;
    }

    private int hit(int rx, int ry) {
        if (rx < 0 || ry < 0) return -1;
        if (ry < BAR) {
            if (WinSoft.in(rx, ry, 3, 1, 30, BAR - 2)) return 1;
            if (WinSoft.in(rx, ry, 35, 1, 40, BAR - 2)) return 2;
            if (WinSoft.in(rx, ry, 146, 1, 54, BAR - 2)) return 3;
            for (int i = 0; i < 4; i++) if (WinSoft.in(rx, ry, 82 + i * 15, 1, 14, BAR - 2)) return 10 + i;
            return -1;
        }
        for (int i = 0; i < 8; i++) if (WinSoft.in(rx, ry, toolBox(i), toolY(i), 10, 10)) return 20 + i;
        if (ry >= palY()) {
            for (int i = 0; i < 16; i++) if (WinSoft.in(rx, ry, CX + i * 11, palY(), 10, 10)) return 40 + i;
            return -1;
        }
        return WinSoft.in(rx, ry, CX, CY, aw - CX - 3, ah - CY - PAL - 3) ? 100 : -1;
    }

    @Override
    public boolean mouse(int rx, int ry, int btnIn, int kind) {
        if (dlg != null) {
            boolean r = dlg.mouse(rx, ry, btnIn, kind, now);
            if (dlg.closed) dlg = null;
            return r;
        }
        if (menu != null && menu.open()) {
            if (kind == PixelScreen.MOUSE_PRESS) {
                int id = menu.press(rx, ry);
                if (id >= 0) act(id);
                return true;
            }
            return menu.move(rx, ry);
        }
        int hv = hit(rx, ry);
        boolean dirty = hv != hover;
        hover = hv;
        if (hv == 100) {
            int nx = px(rx), ny = py(ry);
            if (nx != cmx || ny != cmy) {
                cmx = nx;
                cmy = ny;
                dirty = true;
            }
        } else if (cmx >= 0 && !down) {
            cmx = -1;
            dirty = true;
        }
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            int max = Math.max(0, CH - (ah - CY - PAL - 3)), ns = Math.max(0, Math.min(max, scy + (kind == PixelScreen.MOUSE_SCROLL_UP ? -8 : 8)));
            if (ns == scy) return dirty;
            scy = ns;
            return true;
        }
        if (kind == PixelScreen.MOUSE_PRESS) {
            if (hv == 100) return begin(rx, ry, btnIn);
            if (btnIn != 0) return dirty;
            if (hv == 1) {
                menu = new WinPopup(new String[] {"Создать", "Открыть...", "Сохранить", "Сохранить как..."}, new int[] {1, 2, 3, 4});
                menu.openAt(3, BAR, aw, ah);
            } else if (hv == 2) {
                if (!undo.isEmpty()) {
                    byte[] u = undo.removeLast();
                    System.arraycopy(u, 0, cv, 0, u.length);
                    mod = true;
                }
            } else if (hv == 3) {
                filled = !filled;
            } else if (hv >= 10 && hv < 14) {
                size = SIZES[hv - 10];
            } else if (hv >= 20 && hv < 28) {
                tool = hv - 20;
            } else if (hv >= 40 && hv < 56) {
                fg = hv - 40;
            }
            return true;
        }
        if (kind == PixelScreen.MOUSE_DRAG && down) return move(rx, ry);
        if (kind == PixelScreen.MOUSE_RELEASE && down) return end(rx, ry);
        return dirty;
    }

    private boolean begin(int rx, int ry, int b) {
        btn = b == 1 ? 1 : 0;
        int x = px(rx), y = py(ry);
        if (tool == 7) {
            int c = cv[y * CW + x] & 15;
            if (btn == 1) bg = c;
            else fg = c;
            return true;
        }
        snap();
        down = true;
        lx = sx = x;
        ly = sy = y;
        if (tool == 3) {
            flood(cv, x, y, col());
            down = false;
        } else if (tool == 0 || tool == 1 || tool == 2) {
            stroke(x, y);
        } else {
            tmp = cv.clone();
        }
        return true;
    }

    private void stroke(int x, int y) {
        int c = tool == 2 ? bg : col(), d = tool == 2 ? size * 2 + 2 : tool == 1 ? size + 2 : size;
        line(cv, lx, ly, x, y, d, tool == 1, c);
        lx = x;
        ly = y;
    }

    private boolean move(int rx, int ry) {
        int x = px(rx), y = py(ry);
        cmx = x;
        cmy = y;
        if (tool <= 2) {
            stroke(x, y);
        } else if (tmp != null) {
            System.arraycopy(cv, 0, tmp, 0, cv.length);
            shape(tmp, sx, sy, x, y, col());
        }
        return true;
    }

    private boolean end(int rx, int ry) {
        if (tmp != null) {
            move(rx, ry);
            System.arraycopy(tmp, 0, cv, 0, cv.length);
            tmp = null;
        }
        down = false;
        return true;
    }
}
