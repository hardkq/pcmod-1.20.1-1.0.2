package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Программа «Мобильный оператор» (товар soft.pc, id mobileop): логика на стороне сервера мира поверх TileServer, OperatorStore и Bank.
 * Окно - WinMobileOp. Управлять оператором (вышки, тарифы, абоненты, выручка) может только владелец; выпуск SIM доступен всем клиентам.
 */
public final class SoftMobileOperator {
    public static final int LICENSE_PRICE = 2500000;

    private SoftMobileOperator() { }

    /** Снимок состояния для окна. */
    public static final class View {
        public boolean ready, licensed, owner;
        public String name = "", myNumber = "", myTariff = "";
        public long balance, bank;
        public int myMb = -1, price = LICENSE_PRICE;
        /** Вышки: {координаты, высота, радиус, статус}. */
        public final List<String[]> towers = new ArrayList<String[]>();
        /** Абоненты: {игрок, номер, тариф, остаток МБ, статус}. */
        public final List<String[]> subs = new ArrayList<String[]>();
        public final List<OperatorStore.Tariff> tariffs = new ArrayList<OperatorStore.Tariff>();
    }

    private static WinSvc.Res no(String m) { return new WinSvc.Res(false, m); }

    private static OperatorStore.Operator op(TileServer s, OperatorStore st) { return st.get(s.operatorId); }

    private static long day(TileServer s) {
        return s.getLevel() == null ? 0 : s.getLevel().getServer().overworld().getDayTime() / OperatorStore.DAY;
    }

    public static View view(TileServer s, String actorId) {
        View v = new View();
        OperatorStore st = OperatorStore.get();
        Bank bank = Bank.get();
        if (s == null || st == null || bank == null || s.getLevel() == null) return v;
        v.ready = true;
        v.bank = bank.balance(actorId);
        OperatorStore.Operator o = op(s, st);
        if (o == null) return v;
        v.licensed = true;
        v.owner = o.owner.equals(actorId);
        v.name = o.name;
        v.tariffs.addAll(o.tariffs);
        UUID me = uuid(actorId);
        OperatorStore.SimRecord mine = me == null ? null : o.subscribers.get(me);
        if (mine != null) {
            OperatorStore.Tariff t = o.tariff(mine.tariffId);
            v.myNumber = ItemSimCard.formatNumber(mine.phoneNumber);
            v.myTariff = t == null ? "?" : t.name;
            v.myMb = mine.dataBalance;
        }
        if (!v.owner) return v;
        v.balance = o.balance;
        Level lv = s.getLevel();
        for (BlockPos p : o.towers) {
            String st2 = !lv.isLoaded(p) ? "не загружена" : lv.getBlockEntity(p) instanceof TileTower t ? (t.isActive ? "активна" : "не активна") : "нет вышки";
            v.towers.add(new String[] {p.getX() + " " + p.getY() + " " + p.getZ(), String.valueOf(p.getY()), String.valueOf(TileTower.radiusAt(p.getY())), st2});
        }
        for (Map.Entry<UUID, OperatorStore.SimRecord> e : o.subscribers.entrySet()) {
            OperatorStore.SimRecord r = e.getValue();
            OperatorStore.Tariff t = o.tariff(r.tariffId);
            v.subs.add(new String[] {bank.nameOf(e.getKey().toString()), ItemSimCard.formatNumber(r.phoneNumber), t == null ? "?" : t.name,
                String.valueOf(r.dataBalance), r.blocked ? "заблокирована" : "активна"});
        }
        return v;
    }

    private static UUID uuid(String id) {
        try { return UUID.fromString(id); } catch (RuntimeException e) { return null; }
    }

    /** Покупка лицензии оператора: 2 500 000 К со счёта Bank, создание оператора и привязка к серверу. */
    public static WinSvc.Res buyLicense(TileServer s, Player p, String name) {
        OperatorStore st = OperatorStore.get();
        Bank b = Bank.get();
        if (s == null || st == null || b == null) return no("Нет связи с сервером");
        if (op(s, st) != null) return no("У сервера уже есть оператор");
        name = name == null ? "" : name.trim();
        if (name.length() < 3 || name.length() > OperatorStore.MAX_NAME) return no("Название оператора: от 3 до " + OperatorStore.MAX_NAME + " знаков");
        String id = p.getUUID().toString();
        long have = b.balance(id);
        if (have < LICENSE_PRICE) return no("Недостаточно средств: нужно " + WinSoft.kons(LICENSE_PRICE) + " К");
        b.rename(id, p.getGameProfile().getName());
        b.setBalance(id, have - LICENSE_PRICE);
        b.log(id, "-" + Bank.fmt(LICENSE_PRICE) + " operator license");
        OperatorStore.Operator o = st.createOperator(name, id, name.hashCode());
        s.operatorId = o.id.toString();
        s.setChanged();
        return new WinSvc.Res(true, "Лицензия куплена: оператор «" + o.name + "»");
    }

    private static OperatorStore.Operator owned(TileServer s, String actorId, OperatorStore st) {
        OperatorStore.Operator o = s == null || st == null ? null : op(s, st);
        return o != null && o.owner.equals(actorId) ? o : null;
    }

    public static WinSvc.Res addTariff(TileServer s, String actorId, String name, int act, int mb, int daily) {
        OperatorStore st = OperatorStore.get();
        OperatorStore.Operator o = owned(s, actorId, st);
        if (o == null) return no("Только владелец оператора");
        if (name == null || name.trim().isEmpty()) return no("Введите название тарифа");
        if (act < 0 || mb < 0 || daily < 0 || act > 1000000 || mb > 100000 || daily > 100000) return no("Неверные цены");
        if (o.tariffs.size() >= OperatorStore.MAX_TARIFFS) return no("Достигнут предел тарифов");
        return st.addTariff(o.id, name, act, mb, daily) == null ? no("Тариф не создан") : new WinSvc.Res(true, "Тариф создан");
    }

    public static WinSvc.Res delTariff(TileServer s, String actorId, String tariffId) {
        OperatorStore st = OperatorStore.get();
        OperatorStore.Operator o = owned(s, actorId, st);
        if (o == null) return no("Только владелец оператора");
        return st.removeTariff(o.id, tariffId) ? new WinSvc.Res(true, "Тариф удалён") : no("Тариф занят абонентами или не найден");
    }

    /** Оформить абонента (activationCost с его счёта) и выдать SIM-карту в инвентарь. */
    public static WinSvc.Res issueSim(TileServer s, Player p, String tariffId) {
        OperatorStore st = OperatorStore.get();
        OperatorStore.Operator o = s == null || st == null ? null : op(s, st);
        if (o == null) return no("У сервера нет оператора");
        String e = st.addSubscriber(o.id, p.getUUID(), tariffId, day(s));
        if (e != null) return no(e);
        ItemStack sim = st.issueSimCard(o.id, p.getUUID());
        if (sim.isEmpty()) return no("SIM не выпущена");
        Bank b = Bank.get();
        if (b != null) b.rename(p.getUUID().toString(), p.getGameProfile().getName());
        Bank.give(p, sim);
        return new WinSvc.Res(true, "SIM-карта выдана: " + ItemSimCard.formatNumber(ItemSimCard.getPhoneNumber(sim)));
    }

    public static WinSvc.Res buyData(TileServer s, Player p, int mb) {
        OperatorStore st = OperatorStore.get();
        OperatorStore.Operator o = s == null || st == null ? null : op(s, st);
        if (o == null) return no("У сервера нет оператора");
        String e = st.buyData(o.id, p.getUUID(), mb);
        return e != null ? no(e) : new WinSvc.Res(true, "Куплено " + mb + " МБ (обновится при вставке SIM в телефон)");
    }

    public static WinSvc.Res payout(TileServer s, String actorId) {
        OperatorStore st = OperatorStore.get();
        OperatorStore.Operator o = owned(s, actorId, st);
        if (o == null) return no("Только владелец оператора");
        long n = st.payout(o.id, actorId);
        return n > 0 ? new WinSvc.Res(true, "На счёт переведено " + WinSoft.kons(n) + " К") : no("Выводить нечего");
    }
}
