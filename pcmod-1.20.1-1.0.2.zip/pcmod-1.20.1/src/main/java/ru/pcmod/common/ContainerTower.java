package ru.pcmod.common;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Меню вышки без слотов: данные идут клиенту пакетом блок-сущности (TileTower.getUpdatePacket). */
public class ContainerTower extends ContainerBlank {
    public final TileTower tower;

    public ContainerTower(int id, Inventory inv, BlockEntity te) {
        super(ModMenus.TOWER.get(), id, te);
        this.tower = (TileTower) te;
    }

    public ContainerTower(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, inv.player.level().getBlockEntity(buf.readBlockPos()));
    }
}
