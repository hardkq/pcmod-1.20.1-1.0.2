package ru.pcmod.common;

import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.network.NetworkEvent;
import ru.pcmod.PCMod;

/** Сервер -> клиент: сжатая дельта или ключевой кадр пиксельного экрана (PixelScreen). */
public class PacketPixels {
    public final int x, y, z;
    public final byte[] data;

    public PacketPixels(int x, int y, int z, byte[] data) {
        this.x = x; this.y = y; this.z = z; this.data = data;
    }

    public static void encode(PacketPixels m, FriendlyByteBuf b) {
        b.writeInt(m.x); b.writeInt(m.y); b.writeInt(m.z);
        b.writeByteArray(m.data);
    }

    public static PacketPixels decode(FriendlyByteBuf b) {
        int x = b.readInt(), y = b.readInt(), z = b.readInt();
        return new PacketPixels(x, y, z, b.readByteArray(600000));
    }

    public static void handle(PacketPixels m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> {
            Level w = PCMod.proxy.clientWorld();
            if (w == null) return;
            BlockPos pos = new BlockPos(m.x, m.y, m.z);
            if (!w.hasChunkAt(pos)) return;
            BlockEntity te = w.getBlockEntity(pos);
            if (te instanceof TileComputer) ((TileComputer) te).pixel().apply(m.data);
        });
        ctx.setPacketHandled(true);
    }
}
