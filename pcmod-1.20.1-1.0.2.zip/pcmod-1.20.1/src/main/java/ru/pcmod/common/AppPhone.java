package ru.pcmod.common;

import net.minecraft.nbt.ListTag;
import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Телефон»: набор номера, недавние, контакты, экран вызова. Звонки идут между открытыми телефонами по номерам (нужна сеть 4G+). */
final class AppPhone implements AndroOs.App {
    private static final class St {
        int tab;
        final StringBuilder num = new StringBuilder();
        final AppUi.Scroll sc = new AppUi.Scroll();
        String msg = "";
        long until;
    }

    private static final int GREEN = rgb(52, 168, 83), RED = rgb(220, 64, 56), ROW = 28, LIST_Y = 96, LIST_H = 200;

    private static St st(AndroOs os) { return os.state("phone", St::new); }

    private static void say(AndroOs os, St s, String ru, String en) { s.msg = os.t(ru, en); s.until = os.now() + 80; }

    private static void dial(AndroOs os, St s, String n) {
        if (n.isEmpty()) return;
        String[] e = PhoneBook.dial(os.ses, n);
        if (e != null) say(os, s, e[0], e[1]);
        else s.msg = "";
    }

    /** Полноэкранный вход для входящего вызова поверх любого экрана. */
    static void incoming(AndroOs os, PixelScreen s) {
        PhoneBook.Call c = os.call;
        s.fillRect(0, 0, AndroOs.W, AndroOs.H, rgb(10, 14, 26));
        String num = c.na;
        s.drawTextCentered(0, AndroOs.W, 70, os.t("Входящий вызов", "Incoming call"), rgb(150, 165, 190), 1, false);
        s.roundRect(65, 100, 50, 50, 25, rgb(52, 168, 83));
        s.drawTextCentered(65, 50, 116, "#", rgb(255, 255, 255), 3, true);
        s.drawTextCentered(0, AndroOs.W, 168, PixelScreen.fit(PhoneData.label(os.stack(), num), 170, 2, true), rgb(240, 245, 255), 2, true);
        s.drawTextCentered(0, AndroOs.W, 192, PhoneData.fmt(num), rgb(150, 165, 190), 1, false);
        s.roundRect(20, 250, 60, 30, 15, RED);
        s.drawTextCentered(20, 60, 261, os.t("Откл.", "Decline"), rgb(255, 255, 255), 1, true);
        s.roundRect(100, 250, 60, 30, 15, GREEN);
        s.drawTextCentered(100, 60, 261, os.t("Ответ", "Answer"), rgb(255, 255, 255), 1, true);
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "phone", os.t("Телефон", "Phone"));
        s.drawTextRight(170, AndroOs.STATUS + 11, PhoneData.fmt(os.number()), rgb(255, 255, 255), 1, false);
        if (os.call != null) { drawCall(os, s); return; }
        AppUi.tabs(os, s, new String[] {os.t("Набор", "Keypad"), os.t("Недавние", "Recent"), os.t("Контакты", "Contacts")}, st.tab);
        if (st.tab == 0) drawPad(os, s, st);
        else if (st.tab == 1) drawRecent(os, s, st);
        else drawContacts(os, s, st);
        if (st.until > os.now()) s.drawTextCentered(0, AndroOs.W, 284, st.msg, rgb(240, 120, 100), 1, true);
    }

    private void drawCall(AndroOs os, PixelScreen s) {
        PhoneBook.Call c = os.call;
        String num = os.callOut ? c.nb : c.na;
        s.roundRect(65, 90, 50, 50, 25, GREEN);
        s.drawTextCentered(65, 50, 106, "#", rgb(255, 255, 255), 3, true);
        s.drawTextCentered(0, AndroOs.W, 156, PixelScreen.fit(PhoneData.label(os.stack(), num), 170, 2, true), os.text(), 2, true);
        s.drawTextCentered(0, AndroOs.W, 180, PhoneData.fmt(num), os.sub(), 1, false);
        long sec = (os.now() - c.since) / 20;
        String t = c.state == 0 ? os.t("Вызов...", "Calling...") : AppUi.two((int) (sec / 60)) + ":" + AppUi.two((int) (sec % 60));
        s.drawTextCentered(0, AndroOs.W, 200, t, c.state == 1 ? GREEN : os.sub(), 1, true);
        s.roundRect(50, 240, 80, 32, 16, RED);
        s.drawTextCentered(50, 80, 252, os.t("Завершить", "End call"), rgb(255, 255, 255), 1, true);
    }

    private void drawPad(AndroOs os, PixelScreen s, St st) {
        s.roundRect(8, 70, 164, 24, 8, os.panel());
        s.drawTextCentered(8, 164, 76, st.num.length() == 0 ? os.t("Введите номер", "Enter number") : PhoneData.fmt(st.num.toString()), st.num.length() == 0 ? os.sub() : os.text(), 1, true);
        String[] k = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "<"};
        for (int i = 0; i < 12; i++) {
            int x = 8 + (i % 3) * 56, y = 100 + (i / 3) * 36;
            s.roundRect(x, y, 52, 32, 10, os.panel());
            s.drawTextCentered(x, 52, y + 10, k[i], os.text(), 1, true);
        }
        s.roundRect(8, 248, 164, 30, 15, GREEN);
        s.drawTextCentered(8, 164, 259, os.t("Позвонить", "Call"), rgb(255, 255, 255), 1, true);
    }

    private ListTag calls(AndroOs os) { return PhoneData.list(os.stack(), "Calls"); }
    private ListTag contacts(AndroOs os) { return PhoneData.list(os.stack(), "Contacts"); }

    private void drawRecent(AndroOs os, PixelScreen s, St st) {
        ListTag l = calls(os);
        if (l.isEmpty()) { s.drawTextCentered(0, AndroOs.W, 150, os.t("Звонков нет", "No calls"), os.sub(), 1, false); return; }
        s.pushClip(0, LIST_Y - 4, AndroOs.W, LIST_H + 4);
        for (int i = 0; i < l.size(); i++) {
            var c = l.getCompound(l.size() - 1 - i);
            int y = LIST_Y - st.sc.off + i * ROW;
            if (y < LIST_Y - ROW || y > LIST_Y + LIST_H) continue;
            int t = c.getInt("t");
            String n = c.getString("n");
            s.roundRect(8, y, 164, ROW - 3, 8, os.panel());
            s.roundRect(14, y + 8, 8, 8, 4, t == 0 ? os.accent() : t == 1 ? GREEN : RED);
            s.drawText(28, y + 4, PixelScreen.fit(PhoneData.label(os.stack(), n), 96, 1, true), t == 2 ? rgb(240, 120, 100) : os.text(), 1, true);
            s.drawText(28, y + 14, AppUi.hhmm(c.getInt("m")) + (t == 0 ? " >" : t == 1 ? " <" : " x"), os.sub());
            if (PhoneData.contactName(os.stack(), n) == null) s.drawTextRight(166, y + 8, "+", os.accent(), 1, true);
        }
        s.popClip();
    }

    private void drawContacts(AndroOs os, PixelScreen s, St st) {
        AppUi.btn(os, s, 8, 68, 164, 22, os.t("Новый контакт", "New contact"), false);
        ListTag l = contacts(os);
        s.pushClip(0, LIST_Y - 4, AndroOs.W, LIST_H + 4);
        for (int i = 0; i < l.size(); i++) {
            var c = l.getCompound(i);
            int y = LIST_Y - st.sc.off + i * ROW;
            if (y < LIST_Y - ROW || y > LIST_Y + LIST_H) continue;
            s.roundRect(8, y, 164, ROW - 3, 8, os.panel());
            s.drawText(14, y + 4, PixelScreen.fit(c.getString("name"), 110, 1, true), os.text(), 1, true);
            s.drawText(14, y + 14, PhoneData.fmt(c.getString("n")), os.sub());
            s.drawTextRight(166, y + 8, "x", rgb(240, 120, 100), 1, true);
        }
        s.popClip();
        if (l.isEmpty()) s.drawTextCentered(0, AndroOs.W, 150, os.t("Контактов нет", "No contacts"), os.sub(), 1, false);
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St st = st(os);
        if (kind == 0) { st.sc.down(y); return true; }
        if (kind == 2) {
            int n = st.tab == 1 ? calls(os).size() : contacts(os).size();
            st.sc.drag(y, n * ROW, LIST_H);
            return true;
        }
        if (!os.tap(x, y) || st.sc.moved) return true;
        if (os.call != null) {
            if (AppUi.in(x, y, 50, 240, 80, 32)) PhoneBook.hangup(os);
            return true;
        }
        int tb = AppUi.tabAt(3, x, y);
        if (tb >= 0) { st.tab = tb; st.sc.off = 0; return true; }
        if (st.tab == 0) tapPad(os, st, x, y);
        else if (st.tab == 1) tapRecent(os, st, x, y);
        else tapContacts(os, st, x, y);
        return true;
    }

    private void tapPad(AndroOs os, St st, int x, int y) {
        if (y >= 100 && y < 244 && (x - 8) % 56 < 52 && (y - 100) % 36 < 32 && x >= 8 && x < 172) {
            int i = (y - 100) / 36 * 3 + (x - 8) / 56;
            if (i == 9) st.num.setLength(0);
            else if (i == 11) { if (st.num.length() > 0) st.num.setLength(st.num.length() - 1); }
            else if (st.num.length() < 7) st.num.append(i == 10 ? '0' : (char) ('1' + i));
        } else if (AppUi.in(x, y, 8, 248, 164, 30)) dial(os, st, st.num.toString());
    }

    private void tapRecent(AndroOs os, St st, int x, int y) {
        ListTag l = calls(os);
        if (y < LIST_Y || y >= LIST_Y + LIST_H) return;
        int i = (y - LIST_Y + st.sc.off) / ROW;
        if (i < 0 || i >= l.size()) return;
        String n = l.getCompound(l.size() - 1 - i).getString("n");
        if (x >= 150 && PhoneData.contactName(os.stack(), n) == null) addContact(os, n);
        else dial(os, st, n);
    }

    private void tapContacts(AndroOs os, St st, int x, int y) {
        if (AppUi.in(x, y, 8, 68, 164, 22)) { addContact(os, null); return; }
        ListTag l = contacts(os);
        if (y < LIST_Y || y >= LIST_Y + LIST_H) return;
        int i = (y - LIST_Y + st.sc.off) / ROW;
        if (i < 0 || i >= l.size()) return;
        if (x >= 152) { l.remove(i); PhoneData.put(os.stack(), "Contacts", l); }
        else dial(os, st, l.getCompound(i).getString("n"));
    }

    /** Добавить контакт: имя, затем номер (если не задан). */
    private void addContact(AndroOs os, String number) {
        os.input(os.t("Имя контакта", "Contact name"), "", 14, 0, name -> {
            if (name.isEmpty()) return;
            if (number != null) { PhoneData.addContact(os.stack(), name, number); return; }
            os.input(os.t("Номер (7 цифр)", "Number (7 digits)"), "", 7, 1, n -> { if (n.length() == 7) PhoneData.addContact(os.stack(), name, n); });
        });
    }

    @Override
    public boolean back(AndroOs os) { return false; }
}
