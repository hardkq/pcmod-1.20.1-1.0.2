package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Браузер: адресная строка, история, страницы PC-Net, ссылки и загрузки установщиков на накопитель. */
public final class WinBrowser implements WinApp {
    private static final int TB = 22, ST = 14;
    private final WinSoft s;
    private final WinSvc svc;
    private final WinUi.Field addr = new WinUi.Field(30, 3, 100);
    private final List<String> hist = new ArrayList<String>();
    private final WebView view = new WebView();
    private WebPage site;
    private String siteUrl = "";
    private String url = "home.pc", msg = "";
    private boolean msgOk, focusAddr;
    private int scroll, contentH, aw = 288, ah = 140, hover = -1, hoverLink = -1, tb = -1;
    private String dlId = "";
    private int dlTotal, lastPct = -1;
    private double dlDone;
    private boolean lastUp = true;
    /** Окно ввода для действий сайта (гостевая книга, форма, донат, оценка, жалоба, поиск). */
    private String pTg = "", pLabel = "";
    private final WinUi.Field pf = new WinUi.Field(0, 0, 180);
    private final WinUi.Button pOk = new WinUi.Button("OK", 0, 0, 60, true), pNo = new WinUi.Button("Отмена", 0, 0, 60, false);

    public WinBrowser(WinSoft s) {
        this.s = s;
        this.svc = s.svc;
        addr.max = 40;
        addr.hint = "Введите адрес";
        go("home.pc");
    }

    @Override public String title() { return "Браузер"; }

    @Override public String id() { return "browser"; }

    @Override public int minW() { return 190; }

    @Override public int minH() { return 90; }

    // ------------------------------------------------------------------ переходы
    private void go(String raw) {
        String u = WinWeb.norm(raw);
        url = u;
        site = null;
        addr.sb.setLength(0);
        addr.sb.append(u);
        scroll = 0;
        msg = "";
        if (hist.isEmpty() || !hist.get(hist.size() - 1).equals(u)) hist.add(u);
        if (hist.size() > 20) hist.remove(0);
    }

    private void back() {
        if (hist.size() < 2) return;
        hist.remove(hist.size() - 1);
        url = hist.get(hist.size() - 1);
        site = null;
        addr.sb.setLength(0);
        addr.sb.append(url);
        scroll = 0;
        msg = "";
    }

    private void link(String tg) {
        if (tg == null) return;
        if (tg.startsWith("dl:")) download(tg.substring(3));
        else if (tg.startsWith("buy:")) {
            WinSvc.Res r = svc.softBuy(tg.substring(4));
            msg = r.msg.isEmpty() ? (r.ok ? "Куплено" : "Не удалось") : r.msg;
            msgOk = r.ok;
        } else if (tg.startsWith("inst:")) {
            String path = svc.softSetupPath(tg.substring(5));
            msgOk = false;
            if (path.isEmpty()) msg = "Установщик не найден: скачайте его снова";
            else s.ctx.open("setup", path);
        } else if (SiteWidgets.isAction(tg)) action(tg);
        else go(tg);
        focusAddr = false;
    }

    private void action(String tg) {
        String pr = SiteWidgets.prompt(tg, true);
        if (pr == null) {
            runAct(tg, "");
            return;
        }
        pTg = tg;
        pLabel = pr;
        pf.sb.setLength(0);
        pf.max = SiteWidgets.maxLen(tg);
    }

    private void runAct(String tg, String in) {
        if (tg.startsWith("search:")) {
            go(SiteWidgets.searchUrl(in));
            return;
        }
        WinSvc.Res r = svc.siteAct(tg, in);
        String u = url;
        if (r.ok) go(u);
        msg = r.msg.isEmpty() ? (r.ok ? "Готово" : "Не удалось") : r.msg;
        msgOk = r.ok;
    }

    private void submit() {
        String tg = pTg;
        pTg = "";
        runAct(tg, pf.sb.toString());
    }

    private int[] pbox() { return new int[] {(aw - 204) / 2, (ah - 70) / 2, 204, 70}; }

    private void drawPrompt(PixelScreen p, WinTheme th, int x, int y) {
        int[] b = pbox();
        int bx = x + b[0], by = y + b[1];
        p.roundRectBorder(bx, by, b[2], b[3], 6, th.surface(), th.border());
        p.drawText(bx + 10, by + 8, PixelScreen.fit(pLabel, b[2] - 20, 1, true), th.text(), 1, true);
        pf.x = bx + 12;
        pf.y = by + 22;
        pf.w = b[2] - 24;
        pf.draw(p, th, true, s.host.time());
        pOk.x = bx + b[2] - 136;
        pOk.y = by + 46;
        pNo.x = bx + b[2] - 70;
        pNo.y = by + 46;
        pOk.draw(p, th);
        pNo.draw(p, th);
    }

    private void download(String id) {
        msgOk = false;
        SoftItem it = SoftRegistry.get(id);
        if (it == null || !it.isPc() || it.setupFile.isEmpty()) {
            msg = "Неизвестная программа";
            return;
        }
        if (dlTotal > 0) {
            msg = "Загрузка уже идёт";
            return;
        }
        String e = svc.softDlCheck(id);
        if (e != null) {
            msg = e;
            return;
        }
        dlId = id;
        dlTotal = it.setupSize;
        dlDone = 0;
        lastPct = 0;
        msg = "";
    }

    /** Встроенные страницы строятся при каждой отрисовке, страница сайта игрока запрашивается у сервера один раз (до F5 или смены адреса). */
    private WebPage doc() {
        if (!svc.netUp()) return WebPage.of(WinWeb.offline(s.host));
        if (WinWeb.isBuiltin(url)) return WinWeb.doc(url, svc);
        if (site == null || !siteUrl.equals(url)) {
            site = WinWeb.doc(url, svc);
            siteUrl = url;
        }
        return site;
    }

    private WebView.Skin skin(WinTheme th, int w) {
        WebView.Skin k = new WebView.Skin();
        k.wrapW = w - 16;
        k.text = th.text();
        k.sub = th.sub();
        k.accent = th.accent();
        k.accentHover = th.accentHover();
        k.onAccent = th.onAccent();
        k.ok = th.ok();
        k.bad = th.bad();
        return k;
    }

    // ------------------------------------------------------------------ рисование
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        // панель инструментов
        p.fillRect(x, y, w, TB, th.surface());
        p.hline(x, y + TB - 1, w, th.border());
        boolean canBack = hist.size() > 1;
        tool(p, th, x + 3, y + 3, "<", tb == 0, canBack);
        tool(p, th, x + w - 19, y + 3, "F5", tb == 1, true);
        addr.x = x + 24;
        addr.y = y + 3;
        addr.w = w - 24 - 24;
        addr.h = 16;
        addr.draw(p, th, focusAddr, s.host.time());
        // содержимое
        int cy = y + TB, ch = h - TB - ST;
        p.pushClip(x, cy, w, ch);
        contentH = view.draw(p, doc(), skin(th, w), x, y, x, cy, w - 6, scroll, cy, ch, hoverLink);
        p.popClip();
        WinSoft.scrollbar(p, th, x + w - 5, cy + 2, ch - 4, contentH, ch, scroll);
        // строка состояния
        int sy = y + h - ST;
        p.fillRect(x, sy, w, ST, th.surface());
        p.hline(x, sy, w, th.border());
        if (dlTotal > 0) {
            int pct = (int) (dlDone * 100 / dlTotal), bw = Math.min(90, w / 3);
            p.roundRect(x + 6, sy + 4, bw, 6, 3, PixelScreen.alpha(th.sub(), 0x40));
            p.roundRect(x + 6, sy + 4, Math.max(3, bw * pct / 100), 6, 3, th.accent());
            String info = svc.netUp() ? pct + "%  " + String.format("%.1f", svc.linkRate() / 1024).replace('.', ',') + " КБ/с" : "ожидание сети...";
            p.drawText(x + 12 + bw, sy + 3, PixelScreen.fit(info, w - bw - 18, 1, false), th.sub());
        } else if (!msg.isEmpty()) {
            p.drawText(x + 6, sy + 3, PixelScreen.fit(msg, w - 12, 1, false), msgOk ? th.ok() : th.bad());
        } else {
            p.drawText(x + 6, sy + 3, PixelScreen.fit(svc.netUp() ? "Подключено: " + (svc.server().isEmpty() ? "сервера нет" : svc.server()) : "Нет подключения", w - 12, 1, false), th.sub());
        }
        if (!pTg.isEmpty()) drawPrompt(p, th, x, y);
    }

    private static void tool(PixelScreen p, WinTheme th, int x, int y, String g, boolean hv, boolean en) {
        if (hv && en) p.roundRect(x, y, 18, 16, 4, th.hover());
        p.drawTextCentered(x, 18, y + 4, g, en ? th.text() : PixelScreen.alpha(th.sub(), 0x70), 1, false);
    }

    // ------------------------------------------------------------------ ввод
    private int maxScroll() {
        return Math.max(0, contentH - (ah - TB - ST));
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        if (!pTg.isEmpty()) {
            if (kind == PixelScreen.MOUSE_PRESS && btn == 0) {
                int[] b = pbox();
                int ax = rx + 0, ay = ry;
                if (WinSoft.in(ax, ay, b[0] + b[2] - 136, b[1] + 46, 60, 16)) submit();
                else if (WinSoft.in(ax, ay, b[0] + b[2] - 70, b[1] + 46, 60, 16)) pTg = "";
            }
            return true;
        }
        boolean d = false;
        int hv = ry < TB ? (rx >= 3 && rx < 21 ? 0 : rx >= aw - 19 && rx < aw - 1 ? 1 : -1) : -1;
        if (hv != tb) {
            tb = hv;
            d = true;
        }
        int hl = -1;
        for (int i = 0; i < view.hits.size(); i++) {
            WebView.Hit r = view.hits.get(i);
            if (WinSoft.in(rx, ry, r.x - 1, r.y, r.w + 2, r.h) && ry >= TB && ry < ah - ST) hl = i;
        }
        if (hl != hoverLink) {
            hoverLink = hl;
            d = true;
        }
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            int ns = Math.max(0, Math.min(maxScroll(), scroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -22 : 22)));
            if (ns == scroll) return d;
            scroll = ns;
            return true;
        }
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return d;
        if (ry < TB) {
            if (hv == 0) back();
            else if (hv == 1) go(url);
            else focusAddr = rx >= 24 && rx < aw - 24;
            return true;
        }
        if (hl >= 0) {
            link(view.hits.get(hl).target);
            return true;
        }
        if (focusAddr) {
            focusAddr = false;
            return true;
        }
        return d;
    }

    @Override
    public boolean key(char c, int key) {
        if (!pTg.isEmpty()) {
            if (key == WinSoft.K_ESC) pTg = "";
            else if (pf.key(c, key)) submit();
            return true;
        }
        if (focusAddr || (c >= 32 && c != 127 && key != WinUi.K_UP && key != WinUi.K_DOWN)) {
            if (!focusAddr) {
                focusAddr = true;
                addr.sb.setLength(0);
            }
            if (key == WinUi.K_TAB) {
                focusAddr = false;
                return true;
            }
            if (addr.key(c, key)) {
                go(addr.sb.toString());
                focusAddr = false;
            }
            return true;
        }
        int v = ah - TB - ST - 12, ns = scroll;
        if (key == WinUi.K_TAB) {
            focusAddr = true;
            return true;
        }
        if (key == WinUi.K_BACK) {
            back();
            return true;
        }
        if (key == WinSoft.K_F5) {
            go(url);
            return true;
        }
        if (key == WinSoft.K_UP) ns -= 11;
        else if (key == WinSoft.K_DOWN) ns += 11;
        else if (key == WinSoft.K_PGUP) ns -= v;
        else if (key == WinSoft.K_PGDN) ns += v;
        else if (key == WinSoft.K_HOME) ns = 0;
        else if (key == WinSoft.K_END) ns = maxScroll();
        else return false;
        ns = Math.max(0, Math.min(maxScroll(), ns));
        if (ns == scroll) return false;
        scroll = ns;
        return true;
    }

    @Override
    public boolean tick(long now) {
        boolean d = focusAddr && now % 10 == 0;
        boolean up = svc.netUp();
        if (up != lastUp) {
            lastUp = up;
            site = null;
            d = true;
        }
        if (dlTotal > 0 && up) {
            dlDone += svc.linkRate() / 20.0;
            if (dlDone >= dlTotal) {
                boolean ok = svc.softDlFinish(dlId);
                SoftItem di = SoftRegistry.get(dlId);
                String f = di == null ? "" : di.setupFile;
                dlTotal = 0;
                dlDone = 0;
                msgOk = ok;
                msg = ok ? "Сохранено в «Загрузки»: " + f : "Диск заполнен: загрузка не удалась";
                return true;
            }
            int pct = (int) (dlDone * 100 / dlTotal);
            if (pct != lastPct) {
                lastPct = pct;
                d = true;
            }
        }
        return d;
    }
}
