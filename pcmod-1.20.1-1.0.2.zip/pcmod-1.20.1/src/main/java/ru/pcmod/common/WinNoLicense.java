package ru.pcmod.common;

/** Окно вместо программы, у которой нет лицензии (сервер отклонил запуск). */
final class WinNoLicense implements WinApp {
    private final String name;

    WinNoLicense(String name) { this.name = name; }

    @Override public String title() { return name; }

    @Override public String id() { return "nolicense"; }

    @Override public boolean resizable() { return false; }

    @Override public int minW() { return 250; }

    @Override public int minH() { return 100; }

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        p.drawText(x + 10, y + 12, "Нет лицензии", th.bad(), 1, true);
        int ty = y + 28;
        for (String ln : WinSoft.wrap("Программа не запущена: лицензия не найдена на сервере. Купите её на сайте soft.pc.", w - 20)) {
            p.drawText(x + 10, ty, ln, th.text());
            ty += 11;
        }
    }
}
