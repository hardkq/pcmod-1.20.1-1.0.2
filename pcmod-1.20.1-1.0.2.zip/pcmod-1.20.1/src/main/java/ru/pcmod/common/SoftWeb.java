package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Страницы магазина программ soft.pc для браузера ПК: каталог и страница товара (покупка, загрузка, установка). */
final class SoftWeb {
    private SoftWeb() { }

    private static void r(List<WebRow> o, char k, String t, String tg) { o.add(new WebRow(k, t, tg)); }

    static String priceText(int price) { return price <= 0 ? "Бесплатно" : price + " K"; }

    static String mem(int mb) { return mb >= 1024 ? (mb / 1024) + " ГБ" : mb + " МБ"; }

    static List<WebRow> pc(String url, WinSvc s) {
        List<WebRow> o = new ArrayList<WebRow>();
        int sl = url.indexOf('/');
        SoftItem it = sl < 0 ? null : SoftRegistry.get(url.substring(sl + 1));
        if (sl < 0) catalog(o, s);
        else if (it == null || !SoftRegistry.onSale(it) && !s.softInstalled(it.id)) {
            r(o, 'h', "404 - товар не найден", null);
            r(o, 'l', "Каталог программ", "soft.pc");
        } else product(o, s, it);
        return o;
    }

    private static void catalog(List<WebRow> o, WinSvc s) {
        r(o, 'h', "Магазин программ", null);
        r(o, 'd', "Программы и игры для ПК, приложения для телефонов.", null);
        if (s.bankReady()) r(o, 'd', "Ваш баланс: " + s.balance() + " K (счёт общий с банком и телефоном)", null);
        List<SoftItem> all = s.softCatalog();
        String[] titles = {"Программы", "Игры", "Приложения для телефона"};
        SoftItem.Type[] types = {SoftItem.Type.PC_PROGRAM, SoftItem.Type.PC_GAME, SoftItem.Type.PHONE_APP};
        for (int k = 0; k < 3; k++) {
            boolean head = false;
            for (SoftItem it : all) {
                if (it.type != types[k]) continue;
                if (!head) {
                    r(o, 't', "", null);
                    r(o, 'h', titles[k], null);
                    head = true;
                }
                String st = it.isPc() ? (s.softInstalled(it.id) ? ", установлено" : s.softPrice(it.id) > 0 && s.softLicensed(it.id) ? ", куплено" : "") : "";
                r(o, 'l', it.ru + " - " + priceText(s.softPrice(it.id)) + st, "soft.pc/" + it.id);
            }
        }
        r(o, 't', "", null);
        r(o, 'l', "На начальную страницу", "home.pc");
    }

    private static void product(List<WebRow> o, WinSvc s, SoftItem it) {
        int price = s.softPrice(it.id);
        r(o, 'h', it.ru, null);
        r(o, 'p', it.preview.isEmpty() ? it.id : it.preview, null);
        r(o, 't', it.dRu, null);
        r(o, 't', "", null);
        r(o, 'd', "Требования: ОС " + it.reqOs + (it.reqRamMB > 0 ? ", ОЗУ " + mem(it.reqRamMB) : "")
                + ", место " + (it.reqDiskKB > 0 ? it.reqDiskKB + " КБ" : "мало"), null);
        r(o, 'd', "Загрузка: " + it.sizeKB + " КБ. Цена: " + priceText(price), null);
        boolean lic = s.softLicensed(it.id);
        if (price <= 0) r(o, 'k', "Лицензия: не требуется", null);
        else if (lic) r(o, 'k', "Лицензия: куплена (привязана к вашему аккаунту)", null);
        else r(o, 'e', "Лицензия: не куплена", null);
        r(o, 't', "", null);
        if (!it.isPc()) {
            r(o, 'd', "Это приложение для телефона: откройте soft.pc в браузере телефона или «Приложения».", null);
        } else {
            boolean inst = s.softInstalled(it.id);
            String setup = s.softSetupPath(it.id);
            if (price > 0 && !lic) {
                if (s.bankReady()) r(o, 'b', "Купить за " + price + " K", "buy:" + it.id);
                else r(o, 'e', "Для покупки нужен сервер банка.", null);
            }
            if (inst) {
                r(o, 'k', "Установлено" + (s.softRunnable(it.id) ? "" : ", но лицензии нет: запуск закрыт"), null);
            } else if (lic) {
                if (!setup.isEmpty()) r(o, 'b', "Установить", "inst:" + it.id);
                else {
                    String e = s.softDlCheck(it.id);
                    if (e == null) r(o, 'b', "Скачать установщик (" + it.sizeKB + " КБ)", "dl:" + it.id);
                    else r(o, 'e', e, null);
                }
            }
        }
        r(o, 't', "", null);
        r(o, 'l', "Каталог программ", "soft.pc");
        r(o, 'l', "На начальную страницу", "home.pc");
    }
}
