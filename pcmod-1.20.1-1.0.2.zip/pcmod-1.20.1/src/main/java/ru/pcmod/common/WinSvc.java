package ru.pcmod.common;

import java.util.List;

/** Сетевые службы мира для приложений WinCraft 11: чат-сервер, интернет-магазин, банк, загрузки. Реализует WinSvcImpl. */
public interface WinSvc {
    /** Сообщение чата (время - время суток мира на момент отправки). */
    final class Msg {
        public final String from, text;
        public final long time;
        public final boolean mine;

        public Msg(String from, String text, long time, boolean mine) {
            this.from = from;
            this.text = text;
            this.time = time;
            this.mine = mine;
        }
    }

    /** Товар магазина; left* == Integer.MAX_VALUE - без ограничения. */
    final class Offer {
        public final String key, name;
        public final int price, limit, stock, playerLeft, stockLeft;

        public Offer(String key, String name, int price, int limit, int stock, int playerLeft, int stockLeft) {
            this.key = key;
            this.name = name;
            this.price = price;
            this.limit = limit;
            this.stock = stock;
            this.playerLeft = playerLeft;
            this.stockLeft = stockLeft;
        }
    }

    /** Итог операции с текстом для экрана. */
    final class Res {
        public final boolean ok;
        public final String msg;

        public Res(boolean ok, String msg) {
            this.ok = ok;
            this.msg = msg;
        }
    }

    int DL_DOOM = 1, DL_AV = 2;

    // ------------------------------------------------------------------ сеть
    boolean netUp();

    /** Домен выбранного сервера сети ("" - сервера нет). */
    String server();

    /** Домены всех серверов сети. */
    List<String> servers();

    /** Скорость канала, байт/с (0 - нет сети). */
    double linkRate();

    // ------------------------------------------------------------------ чат
    String chatSavedNick();

    /** Ник выполненного входа или "". */
    String chatNick();

    boolean chatOnline();

    /** Растёт при любом изменении, видимом в окне чата. */
    int chatRev();

    /** null - успех, иначе причина. */
    String chatLogin(String nick, String pass);

    String chatRegister(String nick, String pass);

    void chatLogout();

    /** Выбрать следующий сервер (если их несколько). */
    void chatNextServer();

    List<String> chatUsers();

    boolean chatUserOnline(String nick);

    /** Сообщения диалога: "#general" - общий чат, иначе ник собеседника. */
    List<Msg> chatThread(String peer);

    int chatUnread(String peer);

    /** Диалог открыт на экране (его сообщения не считаются непрочитанными); null - ни один. */
    void chatView(String peer);

    String chatSend(String to, String text);

    /** Забрать новые сообщения; true - что-то изменилось. */
    boolean chatPoll();

    // ------------------------------------------------------------------ банк и магазин
    /** Банк и сервер доступны (сеть есть, сервер найден). */
    boolean bankReady();

    /** Имя игрока за ПК ("" - ещё не известно). */
    String account();

    long balance();

    /** Консов наличными в инвентаре игрока (-1 - неизвестно). */
    long cash();

    /** Последние операции, новые в конце. */
    List<String> history();

    /** amount < 0 - внести всё. */
    Res deposit(long amount);

    Res withdraw(long amount);

    long shopStamp();

    int shopSeconds();

    List<Offer> catalog();

    /** qty <= 0 - максимум; stamp - отпечаток каталога, который видел игрок. */
    Res buy(int index, int qty, long stamp);

    // ------------------------------------------------------------------ загрузки
    boolean installed(int kind);

    String dlName(int kind);

    int dlSize(int kind);

    /** null - можно качать, иначе причина отказа. */
    String dlCheck(int kind);

    /** Записать скачанный файл в «Загрузки». */
    boolean dlFinish(int kind);

    // ------------------------------------------------------------------ реестр товаров и лицензии (проверки на сервере)
    /** Товары в продаже (ПК и телефон). */
    List<SoftItem> softCatalog();

    /** Цена товара в консах с учётом конфига (0 - бесплатно). */
    int softPrice(String id);

    /** У игрока есть право пользоваться товаром (бесплатный или лицензия на аккаунте). */
    boolean softLicensed(String id);

    /** Купить лицензию с общего банковского счёта. */
    Res softBuy(String id);

    /** Программа ПК установлена на этом накопителе. */
    boolean softInstalled(String id);

    /** Можно ли запускать: бесплатный, есть лицензия или установка из старых сохранений. */
    boolean softRunnable(String id);

    /** null - можно качать, иначе причина отказа. */
    String softDlCheck(String id);

    /** Записать установщик в «Загрузки» (повторно проверяет лицензию на сервере). */
    boolean softDlFinish(String id);

    /** Товар, чей установщик лежит по пути (\"\" - не установщик). */
    String softSetupId(String path);

    /** Путь установщика в «Загрузки» ("" - не скачан). */
    String softSetupPath(String id);

    String softSetupCheck(String id, String path);

    Res softSetupRun(String id, String path);

    // ------------------------------------------------------------------ антивирус
    /** 0 - не установлен, 1 - защита включена, 2 - есть угрозы. */
    int avState();

    /** Найденные угрозы: {имя, описание}. */
    List<String[]> avThreats();

    /** Угрозы, ожидающие решения (без выбравших «Ждать»). */
    int avWaiting();

    /** Удалить угрозы: ПК перезапускается. */
    void avRemove();

    /** Ждать: угрозы остаются, окно не повторяется. */
    void avWait();

    // ------------------------------------------------------------------ установщик программ
    /** Что за установщик лежит по пути: 0 - не установщик, DL_DOOM или DL_AV. */
    int setupKind(String path);

    String setupName(int kind);

    /** Папка установки (системный путь). */
    String setupFolder(int kind);

    /** Сколько места нужно, байт. */
    int setupBytes(int kind);

    /** null - можно ставить, иначе причина отказа. */
    String setupCheck(int kind, String path);

    /** Установить: установщик стирается, программа записывается на накопитель. */
    Res setupRun(int kind, String path);

    // ------------------------------------------------------------------ сайты игроков (хостинг на сервере)
    /** Запрос страницы сайта: сеть, TileServer и все проверки - на сервере; code 0/503/404/403/200. */
    SiteHost.Resp siteFetch(String domain, String page);

    /** Сайты игрока (включая льготный период после срока). */
    List<SiteStore.Info> siteMine();

    /** Условия хостинга: {цена регистрации, цена продления, период (сутки), лимит сайтов, лимит страниц, байт на страницу, байт на сайт}. */
    int[] siteTerms();

    Res siteRegister(String domain);

    Res siteRenew(String domain);

    Res siteRelease(String domain);

    /** Сохранить страницу сайта владельца (page "" - главная). */
    Res sitePut(String domain, String page, String markup);

    Res siteDeletePage(String domain, String page);

    // ------------------------------------------------------------------ мобильный оператор (программа mobileop; проверки на сервере)
    /** Снимок состояния оператора сервера сети (ready=false - нет сети, сервера или банка). */
    SoftMobileOperator.View mobState();

    Res mobBuyLicense(String name);

    Res mobAddTariff(String name, int activationCost, int mbPrice, int dailyFee);

    Res mobDelTariff(String tariffId);

    /** Оформить абонента и выдать SIM-карту в инвентарь. */
    Res mobIssueSim(String tariffId);

    Res mobBuyData(int mb);

    Res mobPayout();

    /** Каталог search.pc: section 0 - все, 1 - новые, 2 - популярные; q - запрос (пусто - без фильтра). */
    List<SiteStore.Listing> siteSearch(String q, int section, int max);

    /** Действие посетителя со страницы сайта (гостевая книга, форма, донат, платный доступ, оценка, жалоба): все проверки на сервере. */
    Res siteAct(String target, String input);

    /** Название и теги сайта. */
    Res siteMeta(String domain, String title, String tags);
}
