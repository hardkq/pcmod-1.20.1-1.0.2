package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Переключатель окон Alt+Tab (или Ctrl+Tab): карточки окон текущего рабочего стола в порядке последнего использования.
 * Tab - дальше, Shift+Tab - назад, стрелки - выбор, отпускание Alt/Ctrl - переключиться.
 */
final class WinSwitcher {
    private static final int W = PixelScreen.W, CW = 58, CH = 54, PAD = 6, GAP = 4, MAXCOLS = 5, TW = 52, TH = 30;

    private final WinWm wm;
    private final WinTheme th;
    private final boolean effects;
    private List<WinWm.Win> list = new ArrayList<WinWm.Win>();
    private WinThumb[] thumbs = new WinThumb[0];
    private boolean open;
    private int sel, hold, cols, px, py, pw, ph;

    WinSwitcher(WinWm wm, WinTheme th, boolean effects) {
        this.wm = wm;
        this.th = th;
        this.effects = effects;
    }

    boolean isOpen() { return open; }

    /** Клавиши-модификаторы (Alt/Ctrl), с которыми открыт переключатель: их отпускание подтверждает выбор. */
    int hold() { return hold; }

    private int[] box() {
        return new int[] {px - 10, py - 8, pw + 20, ph + 22};
    }

    int[] open(List<WinWm.Win> l, boolean back, int holdMask) {
        list = new ArrayList<WinWm.Win>(l);
        int n = list.size();
        sel = n == 1 ? 0 : back ? n - 1 : 1;
        hold = holdMask;
        thumbs = new WinThumb[n];
        for (int i = 0; i < n; i++) thumbs[i] = wm.thumb(list.get(i), TW, TH);
        cols = Math.min(n, MAXCOLS);
        int rows = (n + cols - 1) / cols;
        pw = cols * CW + (cols - 1) * GAP + 2 * PAD;
        ph = rows * CH + (rows - 1) * GAP + 2 * PAD;
        px = (W - pw) / 2;
        py = (WinWm.workH() - ph) / 2;
        open = true;
        return box();
    }

    void cancel() {
        open = false;
        list.clear();
    }

    /** Подтвердить выбор: окно выходит на передний план. */
    int[] commit() {
        if (!open) return null;
        int[] d = box();
        WinWm.Win w = sel >= 0 && sel < list.size() ? list.get(sel) : null;
        cancel();
        return WinWm.union(d, w == null ? null : wm.bring(w));
    }

    private int[] step(int dir) {
        int n = list.size();
        if (n == 0) return null;
        sel = ((sel + dir) % n + n) % n;
        return box();
    }

    int[] key(char c, int key, boolean shift) {
        if (key == WinUi.K_TAB) return step(shift ? -1 : 1);
        if (key == WinUi.K_RIGHT) return step(1);
        if (key == WinUi.K_LEFT) return step(-1);
        if (key == WinUi.K_DOWN) return sel + cols < list.size() ? step(cols) : null;
        if (key == WinUi.K_UP) return sel - cols >= 0 ? step(-cols) : null;
        if (WinUi.isEnter(c, key)) return commit();
        return null;
    }

    private int cardAt(int mx, int my) {
        for (int i = 0; i < list.size(); i++) {
            int cx = px + PAD + (i % cols) * (CW + GAP), cy = py + PAD + (i / cols) * (CH + GAP);
            if (mx >= cx && my >= cy && mx < cx + CW && my < cy + CH) return i;
        }
        return -1;
    }

    int[] mouse(int mx, int my, int btn, int kind) {
        int i = cardAt(mx, my);
        if (i < 0) return null;
        if (kind == PixelScreen.MOUSE_PRESS && btn == 0) {
            sel = i;
            return commit();
        }
        if (i != sel) {
            sel = i;
            return box();
        }
        return null;
    }

    void paint(PixelScreen p) {
        if (!open) return;
        if (effects) p.shadow(px, py, pw, ph, 9, 10, 0, 3, 0x78000000);
        p.roundRectBorder(px, py, pw, ph, 9, effects ? (th.surface() & 0xFFFFFF) | 0xEA000000 : th.surface(), th.border());
        for (int i = 0; i < list.size(); i++) {
            WinWm.Win w = list.get(i);
            int cx = px + PAD + (i % cols) * (CW + GAP), cy = py + PAD + (i / cols) * (CH + GAP);
            if (i == sel) {
                p.roundRect(cx, cy, CW, CH, 5, th.hover());
                p.roundRectOutline(cx, cy, CW, CH, 5, 2, th.accent());
            }
            WinIcons.draw(p, th, w.app.id(), cx + 9, cy + 8);
            p.drawText(cx + 18, cy + 4, PixelScreen.fit(w.app.title(), CW - 21, 1, false), th.text());
            int by = cy + 16;
            p.roundRect(cx + 3, by, CW - 6, TH, 3, th.bg());
            WinThumb t = thumbs[i];
            if (t == null) {
                WinIcons.drawSized(p, th, w.app.id(), cx + CW / 2 - 12, by + 3, 24);
            } else {
                t.draw(p, cx + (CW - t.w) / 2, by + (TH - t.h) / 2);
                p.rect(cx + (CW - t.w) / 2 - 1, by + (TH - t.h) / 2 - 1, t.w + 2, t.h + 2, 1, th.border());
            }
            if (w.min) p.fillRect(cx + CW - 9, cy + 4, 5, 1, th.sub());
        }
    }
}
