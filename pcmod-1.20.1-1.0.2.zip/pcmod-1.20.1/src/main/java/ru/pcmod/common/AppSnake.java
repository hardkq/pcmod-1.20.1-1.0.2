package ru.pcmod.common;

import java.util.ArrayDeque;
import java.util.Random;
import net.minecraft.nbt.CompoundTag;
import static ru.pcmod.common.PixelScreen.rgb;

/** Игра «Змейка» (магазин приложений): поле 20x22, управление кнопками или свайпом, рекорд хранится в NBT телефона. */
final class AppSnake implements AndroOs.App {
    private static final int GW = 20, GH = 22, C = 8, OX = 10, OY = 70;
    private static final int[] DX = {0, 1, 0, -1}, DY = {-1, 0, 1, 0};

    private static final class St {
        final ArrayDeque<int[]> body = new ArrayDeque<int[]>();
        int dir = 1, next = 1, fx, fy, score, best, sx, sy;
        boolean over = true, fresh = true;
        long last;
        final Random rnd = new Random();
    }

    private static St st(AndroOs os) { return os.state("snake", St::new); }

    private static void start(AndroOs os, St s) {
        s.body.clear();
        for (int i = 0; i < 4; i++) s.body.addFirst(new int[] {5 + i, 11});
        s.dir = s.next = 1;
        s.score = 0;
        s.over = false;
        s.fresh = false;
        s.last = os.now();
        food(s);
    }

    private static void food(St s) {
        for (int n = 0; n < 200; n++) {
            int x = s.rnd.nextInt(GW), y = s.rnd.nextInt(GH);
            boolean hit = false;
            for (int[] b : s.body) if (b[0] == x && b[1] == y) { hit = true; break; }
            if (!hit) { s.fx = x; s.fy = y; return; }
        }
    }

    private static void turn(St s, int d) { if ((d + 2) % 4 != s.dir) s.next = d; }

    @Override
    public boolean tick(AndroOs os, long now) {
        St s = st(os);
        if (s.over || now - s.last < Math.max(2, 5 - s.score / 8)) return false;
        s.last = now;
        s.dir = s.next;
        int[] h = s.body.peekFirst();
        int nx = h[0] + DX[s.dir], ny = h[1] + DY[s.dir];
        boolean eat = nx == s.fx && ny == s.fy;
        if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) { die(os, s); return true; }
        if (!eat) s.body.removeLast();
        for (int[] b : s.body) if (b[0] == nx && b[1] == ny) { die(os, s); return true; }
        s.body.addFirst(new int[] {nx, ny});
        if (eat) { s.score++; food(s); }
        return true;
    }

    private static void die(AndroOs os, St s) {
        s.over = true;
        if (s.score > s.best && !os.stack().isEmpty()) { s.best = s.score; PhoneData.d(os.stack()).putInt("SnakeBest", s.best); }
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        if (st.fresh && !os.stack().isEmpty()) st.best = PhoneData.d(os.stack()).getInt("SnakeBest");
        AppUi.header(os, s, "snake", os.t("Змейка", "Snake"));
        s.drawText(10, 50, os.t("Счёт: ", "Score: ") + st.score, os.text(), 1, true);
        s.drawTextRight(170, 50, os.t("Рекорд: ", "Best: ") + st.best, os.sub(), 1, false);
        s.fillRect(OX - 1, OY - 1, GW * C + 2, GH * C + 2, rgb(20, 30, 24));
        s.fillRect(OX, OY, GW * C, GH * C, rgb(30, 44, 34));
        s.roundRect(OX + st.fx * C, OY + st.fy * C, C, C, 4, rgb(235, 70, 60));
        boolean head = true;
        for (int[] b : st.body) {
            s.fillRect(OX + b[0] * C, OY + b[1] * C, C - 1, C - 1, head ? rgb(150, 240, 120) : rgb(80, 190, 90));
            head = false;
        }
        if (st.over) {
            s.fillRect(OX, OY + 70, GW * C, 36, rgb(10, 16, 12));
            s.drawTextCentered(OX, GW * C, OY + 76, st.fresh ? os.t("Нажмите для старта", "Tap to start") : os.t("Игра окончена", "Game over"), rgb(255, 255, 255), 1, true);
            s.drawTextCentered(OX, GW * C, OY + 90, os.t("Коснитесь поля", "Touch the field"), os.sub(), 1, false);
        }
        pad(os, s, 66, 252, 48, 18, "^");
        pad(os, s, 16, 274, 48, 22, "<");
        pad(os, s, 66, 274, 48, 22, "v");
        pad(os, s, 116, 274, 48, 22, ">");
    }

    private static void pad(AndroOs os, PixelScreen s, int x, int y, int w, int h, String l) {
        s.roundRect(x, y, w, h, 8, os.panel());
        s.drawTextCentered(x, w, y + h / 2 - 4, l, os.text(), 1, true);
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St s = st(os);
        if (kind == 0) { s.sx = x; s.sy = y; return true; }
        if (kind != 1) return true;
        int dx = x - s.sx, dy = y - s.sy;
        int d = -1;
        if (AppUi.in(x, y, 66, 252, 48, 18)) d = 0;
        else if (AppUi.in(x, y, 16, 274, 48, 22)) d = 3;
        else if (AppUi.in(x, y, 66, 274, 48, 22)) d = 2;
        else if (AppUi.in(x, y, 116, 274, 48, 22)) d = 1;
        else if (Math.abs(dx) >= 14 || Math.abs(dy) >= 14) d = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
        else if (s.over && AppUi.in(x, y, OX, OY, GW * C, GH * C)) { start(os, s); return true; }
        if (d >= 0) turn(s, d);
        return true;
    }
}
