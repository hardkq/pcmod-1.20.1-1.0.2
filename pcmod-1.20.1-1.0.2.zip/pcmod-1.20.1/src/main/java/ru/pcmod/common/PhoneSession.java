package ru.pcmod.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.network.PacketDistributor;
import ru.pcmod.PCMod;

/**
 * Серверная сессия открытого экрана телефона: портретный PixelScreen 180x320, ОС AndroCraft (AndroOs), расход батареи
 * при включённом экране, отправка кадров игроку и приём касаний.
 */
public final class PhoneSession {
    private static final Map<UUID, PhoneSession> MAP = new HashMap<UUID, PhoneSession>();

    public final ServerPlayer player;
    public final InteractionHand hand;
    public final PixelScreen scr = new PixelScreen(true);
    public final AndroOs os;

    private PhoneSession(ServerPlayer p, InteractionHand h) {
        player = p;
        hand = h;
        ItemStack st = p.getItemInHand(h);
        os = new AndroOs(st);
        os.ses = this;
        scr.setActive(true);
    }

    public static PhoneSession open(ServerPlayer p, InteractionHand h) {
        PhoneSession s = new PhoneSession(p, h);
        MAP.put(p.getUUID(), s);
        return s;
    }

    public static PhoneSession get(Player p) { return MAP.get(p.getUUID()); }

    public static void close(Player p) {
        PhoneSession s = MAP.remove(p.getUUID());
        if (s != null && s.os.call != null) PhoneBook.hangup(s.os);
    }

    /** Открытый телефон с этим номером (или null). */
    public static PhoneSession byNumber(String n) {
        for (PhoneSession s : MAP.values()) if (s.os.num().equals(n) && !s.player.hasDisconnected()) return s;
        return null;
    }

    /** Раз в секунду: Wi-Fi подключение, номер, SMS и пропущенные звонки, состояние вызова. */
    /** Полоски сигнала оператора 0..3 (считаются раз в секунду). */
    private int bars;

    private void secondly(long gt, ItemStack st) {
        PhoneSim.Info si = PhoneSim.info(player, st);
        bars = si.bars;
        os.simNumber = si.number;
        if (!si.number.isEmpty()) PhoneBook.get(player.server).claim(si.number);
        os.link = Net.resolveAt(player.level(), player.getX(), player.getY(), player.getZ(), os.wifi && !os.air ? os.wifiSsid : "", os.wifiPass);
        if (!os.installed) return;
        String num = os.number();
        PhoneBook pb = PhoneBook.get(player.server);
        PhoneData.uid(st);
        PhoneBook.tickCall(this, gt);
        if (!os.cellular() || !pb.has(num)) return;
        java.util.List<PhoneBook.Msg> in = pb.take(num);
        if (in == null) return;
        for (PhoneBook.Msg m : in) {
            String who = PhoneData.label(st, m.from);
            if (m.missed) {
                PhoneData.addCall(st, m.from, 2, os.minute);
                os.notify(os.t("Пропущенный вызов", "Missed call"), who);
            } else {
                PhoneData.addSms(st, m.from, false, m.text, os.minute);
                os.notify(who, m.text);
            }
        }
    }

    public ItemStack stack() { return player.getItemInHand(hand); }

    /** Касание с клиента: kind 0/1/2 - экран, 3 - кнопка питания. */
    public void touch(int kind, int x, int y) {
        if (kind == 3) os.power();
        else os.touch(kind, Math.max(0, Math.min(PixelScreen.PW - 1, x)), Math.max(0, Math.min(PixelScreen.PH - 1, y)));
    }

    private void tick(long gt) {
        ItemStack st = stack();
        if (!(st.getItem() instanceof ItemPhone) || !(player.containerMenu instanceof ContainerPhone) || !player.isAlive()) {
            close(player);
            return;
        }
        if (gt % 20 == 0 && os.awake()) ItemPhone.drain(st, Math.max(1, ItemPhone.screenDrainPerSec(st) * os.drainFactorPct() / 100));
        if (gt % 200 == 0 && os.aodOn()) ItemPhone.drain(st, 1);
        if (ItemPhone.charge(st) <= 0) {
            os.dead();
            player.displayClientMessage(Component.translatable("gui.pcmod.phone.dead"), true);
            os.tick(gt, st, 0, 0, 0, 0);
            player.closeContainer();
            return;
        }
        PartSpec modem = ItemPhone.part(st, PartSpec.Cat.PH_MODEM);
        long dt = player.level().getDayTime();
        int minute = (int) (((dt % 24000L + 6000L) % 24000L) * 1440L / 24000L);
        if (gt % 20 == 0) secondly(gt, st);
        if (os.tick(gt, st, minute, dt / 24000L, ItemPhone.percent(st), modem != null && modem.net >= 2 ? bars : 0)) os.draw(scr);
        if (gt % 2 == 1) {
            byte[] d = scr.poll(gt);
            if (d != null) PCMod.NET.send(PacketDistributor.PLAYER.with(() -> player), new PacketPhonePixels(d));
        }
    }

    /** Подписчик событий Forge: тик всех сессий и очистка при выходе игрока. */
    public static final class Events {
        @SubscribeEvent
        public void onServerTick(TickEvent.ServerTickEvent e) {
            if (e.phase != TickEvent.Phase.END || MAP.isEmpty()) return;
            long gt = e.getServer().getTickCount();
            for (PhoneSession s : new ArrayList<PhoneSession>(MAP.values())) {
                try {
                    s.tick(gt);
                } catch (RuntimeException ex) {
                    PCMod.LOG.error("Phone session failed", ex);
                    close(s.player);
                    s.player.closeContainer();
                }
            }
        }

        @SubscribeEvent
        public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { MAP.remove(e.getEntity().getUUID()); }
    }
}
