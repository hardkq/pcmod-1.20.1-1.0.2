package ru.pcmod.common;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Команды операторов магазина программ:
 * /pcsoft list [игрок] | give &lt;игрок&gt; &lt;товар&gt; | revoke &lt;игрок&gt; &lt;товар&gt; | reload
 */
public final class CommandSoft {
    private CommandSoft() { }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("pcsoft").requires(s -> s.hasPermission(2))
                .executes(c -> list(c, null))
                .then(Commands.literal("list").executes(c -> list(c, null))
                        .then(Commands.argument("player", EntityArgument.player()).executes(c -> list(c, EntityArgument.getPlayer(c, "player")))))
                .then(op("give")).then(op("revoke"))
                .then(Commands.literal("reload").executes(CommandSoft::reload)));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> op(String name) {
        return Commands.literal(name).then(Commands.argument("player", EntityArgument.player())
                .then(Commands.argument("id", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(ids(), b))
                        .executes(c -> change(c, name.equals("give")))));
    }

    private static List<String> ids() {
        List<String> r = new ArrayList<String>();
        for (SoftItem i : SoftRegistry.allIncludingOff()) r.add(i.id);
        return r;
    }

    private static void tr(CommandContext<CommandSourceStack> c, String key, Object... args) {
        c.getSource().sendSuccess(() -> Component.translatable("pcmod.cmd.soft." + key, args), false);
    }

    private static void say(CommandContext<CommandSourceStack> c, String t) {
        c.getSource().sendSuccess(() -> Component.literal(t), false);
    }

    private static int list(CommandContext<CommandSourceStack> c, ServerPlayer p) {
        SoftLicenses s = SoftLicenses.get();
        for (SoftItem i : SoftRegistry.allIncludingOff()) {
            int price = SoftRegistry.price(i);
            String own = p == null || s == null ? "" : price <= 0 ? " [free]" : s.has(p.getUUID().toString(), i.id) ? " [owned]" : " [not owned]";
            say(c, i.id + " - " + i.en + ", " + i.type + ", " + (price <= 0 ? "free" : Bank.fmt(price))
                    + (SoftRegistry.onSale(i) ? "" : ", off sale") + own);
        }
        return 1;
    }

    private static int change(CommandContext<CommandSourceStack> c, boolean give) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(c, "player");
        String id = StringArgumentType.getString(c, "id");
        SoftLicenses s = SoftLicenses.get();
        String name = p.getGameProfile().getName();
        if (s == null || SoftRegistry.get(id) == null) {
            tr(c, "unknown", id);
            return 0;
        }
        String by = c.getSource().getTextName();
        boolean ch = give ? s.grant(p.getUUID().toString(), id, "op " + by) : s.revoke(p.getUUID().toString(), id, "op " + by);
        tr(c, give ? (ch ? "granted" : "already") : (ch ? "revoked" : "nolicense"), name, id);
        return ch ? 1 : 0;
    }

    private static int reload(CommandContext<CommandSourceStack> c) {
        int n = SoftRegistry.load();
        tr(c, "reload", n, SoftRegistry.allIncludingOff().size());
        return 1;
    }
}
