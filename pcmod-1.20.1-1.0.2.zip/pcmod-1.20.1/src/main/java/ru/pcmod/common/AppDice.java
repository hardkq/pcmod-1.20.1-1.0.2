package ru.pcmod.common;

import java.util.Random;
import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Кубики» (магазин приложений): от 1 до 3 кубиков и подбрасывание монетки. */
final class AppDice implements AndroOs.App {
    private static final class St {
        int count = 2, coin = -1;
        int[] v = {1, 1, 1};
        final Random rnd = new Random();
    }

    private static St st(AndroOs os) { return os.state("dice", St::new); }

    private static final int[][] DOTS = {{}, {4}, {0, 8}, {0, 4, 8}, {0, 2, 6, 8}, {0, 2, 4, 6, 8}, {0, 2, 3, 5, 6, 8}};

    private static void die(PixelScreen s, int x, int y, int v) {
        s.roundRect(x, y, 44, 44, 9, rgb(250, 250, 252));
        for (int d : DOTS[v]) s.roundRect(x + 8 + (d % 3) * 12, y + 8 + (d / 3) * 12, 8, 8, 4, rgb(40, 40, 60));
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "dice", os.t("Кубики", "Dice"));
        s.drawText(10, 52, os.t("Кубиков: ", "Dice: "), os.text(), 1, true);
        for (int i = 1; i <= 3; i++) AppUi.btn(os, s, 70 + (i - 1) * 34, 48, 30, 20, String.valueOf(i), i == st.count);
        int total = 0;
        for (int i = 0; i < st.count; i++) {
            die(s, 90 - st.count * 25 + i * 50, 90, st.v[i]);
            total += st.v[i];
        }
        s.drawTextCentered(0, AndroOs.W, 146, os.t("Сумма: ", "Sum: ") + total, os.text(), 2, true);
        AppUi.btn(os, s, 20, 176, 140, 28, os.t("Бросить", "Roll"), true);
        s.drawTextCentered(0, AndroOs.W, 224, st.coin < 0 ? os.t("Монетка", "Coin") : st.coin == 0 ? os.t("Орёл", "Heads") : os.t("Решка", "Tails"), st.coin < 0 ? os.sub() : os.text(), 2, true);
        AppUi.btn(os, s, 20, 252, 140, 28, os.t("Подбросить монетку", "Flip the coin"), false);
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        if (kind != 1 || !os.tap(x, y)) return true;
        St st = st(os);
        for (int i = 1; i <= 3; i++) if (AppUi.in(x, y, 70 + (i - 1) * 34, 48, 30, 20)) st.count = i;
        if (AppUi.in(x, y, 20, 176, 140, 28)) for (int i = 0; i < 3; i++) st.v[i] = 1 + st.rnd.nextInt(6);
        if (AppUi.in(x, y, 20, 252, 140, 28)) st.coin = st.rnd.nextInt(2);
        return true;
    }
}
