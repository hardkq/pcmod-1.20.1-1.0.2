package ru.pcmod.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import static ru.pcmod.common.PixelScreen.rgb;

/**
 * Приложение «Сообщения»: вкладка SMS (между телефонами по номерам, нужна сеть 4G+) и вкладка «Чат» - тот же чат-сервер сети,
 * что и мессенджер на ПК (общие аккаунты и история), через Wi-Fi телефона.
 */
final class AppMessages implements AndroOs.App {
    private static final int LIST_Y = 96, LIST_H = 170, ROW = 28;

    private static final class St {
        int tab;
        String peer;                       // открытый SMS-диалог
        String conv;                       // открытый диалог чата
        final AppUi.Scroll sc = new AppUi.Scroll();
        String msg = "";
        long until;
        // чат
        String nick = "", hash = "";
        boolean loaded;
        int lastId;
        TileServer bound;
        final List<ChatStore.Msg> cache = new ArrayList<ChatStore.Msg>();
        final Map<String, Integer> unread = new HashMap<String, Integer>();
        List<String> users = new ArrayList<String>();
        final Set<String> online = new HashSet<String>();
        boolean up;
    }

    private static St st(AndroOs os) { return os.state("messages", St::new); }

    private static void say(AndroOs os, St s, String ru, String en) { s.msg = os.t(ru, en); s.until = os.now() + 80; }

    // ---------------- чат-сервер
    static TileServer server(AndroOs os) {
        TileServer best = null;
        if (os.link == null || !os.link.up()) return null;
        for (TileServer t : os.link.servers) if (!t.isRemoved() && (best == null || t.domain.compareTo(best.domain) < 0)) best = t;
        return best;
    }

    private static void load(AndroOs os, St s) {
        if (s.loaded || os.ses == null) return;
        s.loaded = true;
        CompoundTag d = PhoneData.d(os.stack());
        s.nick = d.getString("ChatNick");
        s.hash = d.getString("ChatHash");
    }

    private static void logout(AndroOs os, St s) {
        s.nick = ""; s.hash = ""; s.conv = null; s.lastId = 0; s.bound = null; s.up = false;
        s.cache.clear(); s.unread.clear(); s.users = new ArrayList<String>(); s.online.clear();
        CompoundTag d = PhoneData.d(os.stack());
        d.remove("ChatNick"); d.remove("ChatHash");
    }

    private static String conv(St s, ChatStore.Msg m) {
        if (m.to.equals(ChatStore.GENERAL)) return ChatStore.GENERAL;
        return m.from.equals(s.nick) ? m.to : m.from;
    }

    /** Забрать новые сообщения чата (раз в секунду). */
    private static void poll(AndroOs os, St s) {
        if (s.nick.isEmpty()) return;
        TileServer t = server(os);
        if (t == null || !t.isUp()) { s.up = false; return; }
        if (t != s.bound) { s.bound = t; s.lastId = 0; s.cache.clear(); s.unread.clear(); }
        ChatStore store = t.store();
        long now = t.getLevel().getGameTime();
        List<ChatStore.Msg> fresh = store.fetch(s.nick, s.hash, s.lastId, now);
        if (fresh == null) { logout(os, s); say(os, s, "Сессия истекла", "Session expired"); return; }
        boolean first = s.lastId == 0 && s.cache.isEmpty();
        s.up = true;
        for (ChatStore.Msg m : fresh) {
            s.cache.add(m);
            if (m.id > s.lastId) s.lastId = m.id;
            if (!first && !m.from.equals(s.nick)) {
                String c = conv(s, m);
                boolean seeing = os.phase == AndroOs.Phase.APP && os.app.equals("messages") && c.equals(s.conv) && os.awake();
                if (!seeing) {
                    s.unread.merge(c, 1, Integer::sum);
                    os.notify((c.equals(ChatStore.GENERAL) ? "#general: " : "") + m.from, m.text);
                }
            }
        }
        while (s.cache.size() > 200) s.cache.remove(0);
        List<String> names = new ArrayList<String>();
        s.online.clear();
        for (ChatStore.Account a : store.accounts) {
            if (a.nick.equals(s.nick)) continue;
            names.add(a.nick);
            if (store.online(a, now)) s.online.add(a.nick);
        }
        Collections.sort(names);
        s.users = names;
        if (!fresh.isEmpty()) os.dirty();
    }

    @Override
    public void bg(AndroOs os) {
        St s = st(os);
        load(os, s);
        poll(os, s);
    }

    // ---------------- рисование
    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        load(os, st);
        AppUi.header(os, s, "messages", os.t("Сообщения", "Messages"));
        if (st.peer != null) { drawSmsThread(os, s, st); return; }
        if (st.conv != null) { drawChatThread(os, s, st); return; }
        AppUi.tabs(os, s, new String[] {"SMS", os.t("Чат", "Chat")}, st.tab);
        if (st.tab == 0) drawSmsList(os, s, st);
        else drawChat(os, s, st);
        if (st.until > os.now()) s.drawTextCentered(0, AndroOs.W, 284, st.msg, rgb(240, 120, 100), 1, true);
    }

    private List<String> peers(AndroOs os) {
        ListTag l = PhoneData.list(os.stack(), "Sms");
        List<String> out = new ArrayList<String>();
        for (int i = l.size() - 1; i >= 0; i--) { String p = l.getCompound(i).getString("p"); if (!out.contains(p)) out.add(p); }
        return out;
    }

    private void drawSmsList(AndroOs os, PixelScreen s, St st) {
        AppUi.btn(os, s, 8, 68, 164, 22, os.t("Новое сообщение", "New message"), false);
        List<String> ps = peers(os);
        if (ps.isEmpty()) { s.drawTextCentered(0, AndroOs.W, 150, os.t("Сообщений нет", "No messages"), os.sub(), 1, false); return; }
        s.pushClip(0, LIST_Y - 4, AndroOs.W, LIST_H + 4);
        ListTag l = PhoneData.list(os.stack(), "Sms");
        for (int i = 0; i < ps.size(); i++) {
            int y = LIST_Y - st.sc.off + i * ROW;
            if (y < LIST_Y - ROW || y > LIST_Y + LIST_H) continue;
            String last = "";
            for (int k = l.size() - 1; k >= 0; k--) if (l.getCompound(k).getString("p").equals(ps.get(i))) { last = l.getCompound(k).getString("x"); break; }
            s.roundRect(8, y, 164, ROW - 3, 8, os.panel());
            s.drawText(14, y + 4, PixelScreen.fit(PhoneData.label(os.stack(), ps.get(i)), 150, 1, true), os.text(), 1, true);
            s.drawText(14, y + 14, PixelScreen.fit(last, 150, 1, false), os.sub());
        }
        s.popClip();
    }

    private void bubbles(AndroOs os, PixelScreen s, St st, List<String[]> msgs) {
        // msgs: {от кого (пусто = я), текст, время}
        int w = 118, total = 0;
        List<List<String>> wr = new ArrayList<List<String>>();
        for (String[] m : msgs) {
            List<String> ln = AppUi.wrap(m[1], w - 10);
            wr.add(ln);
            total += ln.size() * 10 + 22 + (m[0].isEmpty() ? 0 : 10);
        }
        int view = 190;
        st.sc.off = Math.max(0, Math.min(st.sc.off, Math.max(0, total - view)));
        s.pushClip(0, 70, AndroOs.W, view);
        int y = 70 - st.sc.off;
        for (int i = 0; i < msgs.size(); i++) {
            String[] m = msgs.get(i);
            List<String> ln = wr.get(i);
            boolean me = m[0].isEmpty();
            int h = ln.size() * 10 + 8, x = me ? 172 - w : 8;
            if (!me) { s.drawText(x + 4, y, PixelScreen.fit(m[0], w, 1, true), os.sub(), 1, true); y += 10; }
            s.roundRect(x, y, w, h, 8, me ? os.accent() : os.panel());
            for (int k = 0; k < ln.size(); k++) s.drawText(x + 5, y + 4 + k * 10, ln.get(k), me ? rgb(255, 255, 255) : os.text());
            s.drawText(x + (me ? 4 : 6), y + h + 1, m[2], os.sub());
            y += h + 12;
        }
        s.popClip();
        if (st.until > os.now()) s.drawTextCentered(0, AndroOs.W, 262, st.msg, rgb(240, 120, 100), 1, true);
    }

    private void composeBar(AndroOs os, PixelScreen s) {
        s.roundRect(8, 268, 128, 26, 13, os.panel());
        s.drawText(18, 277, os.t("Написать...", "Type..."), os.sub());
        AppUi.btn(os, s, 140, 268, 32, 26, ">", true);
    }

    private void drawSmsThread(AndroOs os, PixelScreen s, St st) {
        s.drawText(10, 52, "< " + PixelScreen.fit(PhoneData.label(os.stack(), st.peer), 150, 1, true), os.text(), 1, true);
        ListTag l = PhoneData.list(os.stack(), "Sms");
        List<String[]> msgs = new ArrayList<String[]>();
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            if (c.getString("p").equals(st.peer))
                msgs.add(new String[] {c.getBoolean("o") ? "" : PhoneData.label(os.stack(), st.peer), c.getString("x"), AppUi.hhmm(c.getInt("m"))});
        }
        bubbles(os, s, st, msgs);
        composeBar(os, s);
    }

    private void drawChat(AndroOs os, PixelScreen s, St st) {
        TileServer srv = server(os);
        if (srv == null) {
            s.drawTextCentered(0, AndroOs.W, 130, os.t("Нет подключения к серверу", "No server connection"), os.text(), 1, true);
            s.drawTextCentered(0, AndroOs.W, 146, os.t("Подключитесь к Wi-Fi сети", "Connect to a Wi-Fi network"), os.sub(), 1, false);
            s.drawTextCentered(0, AndroOs.W, 158, os.t("с чат-сервером в Настройках", "with a chat server in Settings"), os.sub(), 1, false);
            return;
        }
        if (st.nick.isEmpty()) {
            s.drawTextCentered(0, AndroOs.W, 90, srv.domain, os.accent(), 1, true);
            s.drawTextCentered(0, AndroOs.W, 106, os.t("Войдите в аккаунт чата", "Sign in to chat"), os.sub(), 1, false);
            AppUi.btn(os, s, 20, 130, 140, 30, os.t("Войти", "Log in"), true);
            AppUi.btn(os, s, 20, 170, 140, 30, os.t("Регистрация", "Register"), false);
            return;
        }
        s.drawText(10, 70, st.nick + " @ " + srv.domain, os.sub());
        s.drawTextRight(170, 70, os.t("Выйти", "Out"), os.accent(), 1, true);
        List<String> list = new ArrayList<String>();
        list.add(ChatStore.GENERAL);
        list.addAll(st.users);
        s.pushClip(0, 84, AndroOs.W, 200);
        for (int i = 0; i < list.size(); i++) {
            int y = 86 - st.sc.off + i * ROW;
            if (y < 58 || y > 290) continue;
            String c = list.get(i);
            s.roundRect(8, y, 164, ROW - 3, 8, os.panel());
            s.roundRect(14, y + 9, 7, 7, 3, c.equals(ChatStore.GENERAL) || st.online.contains(c) ? rgb(80, 220, 120) : os.sub());
            s.drawText(28, y + 9, PixelScreen.fit(c, 100, 1, true), os.text(), 1, true);
            int u = st.unread.getOrDefault(c, 0);
            if (u > 0) { s.roundRect(150, y + 5, 16, 14, 7, os.accent()); s.drawTextCentered(150, 16, y + 8, String.valueOf(Math.min(99, u)), rgb(255, 255, 255), 1, true); }
        }
        s.popClip();
        if (!st.up) s.drawTextCentered(0, AndroOs.W, 290, os.t("Сервер недоступен", "Server unavailable"), rgb(240, 120, 100), 1, false);
    }

    private void drawChatThread(AndroOs os, PixelScreen s, St st) {
        s.drawText(10, 52, "< " + PixelScreen.fit(st.conv, 150, 1, true), os.text(), 1, true);
        List<String[]> msgs = new ArrayList<String[]>();
        for (ChatStore.Msg m : st.cache) {
            if (!conv(st, m).equals(st.conv)) continue;
            msgs.add(new String[] {m.from.equals(st.nick) ? "" : m.from, m.text, ChatClient.hhmm(m.time)});
        }
        bubbles(os, s, st, msgs);
        composeBar(os, s);
    }

    // ---------------- ввод
    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St st = st(os);
        if (kind == 0) { st.sc.down(y); return true; }
        if (kind == 2) {
            int n = st.tab == 0 ? peers(os).size() : 1 + st.users.size();
            st.sc.drag(y, st.peer != null || st.conv != null ? 100000 : n * ROW, st.peer != null || st.conv != null ? 190 : LIST_H);
            return true;
        }
        if (!os.tap(x, y) || st.sc.moved) return true;
        if (st.peer != null) { if (AppUi.in(x, y, 8, 268, 164, 26)) writeSms(os, st, st.peer); return true; }
        if (st.conv != null) { if (AppUi.in(x, y, 8, 268, 164, 26)) writeChat(os, st); return true; }
        int tb = AppUi.tabAt(2, x, y);
        if (tb >= 0) { st.tab = tb; st.sc.off = 0; return true; }
        if (st.tab == 0) tapSms(os, st, x, y); else tapChat(os, st, x, y);
        return true;
    }

    private void tapSms(AndroOs os, St st, int x, int y) {
        if (AppUi.in(x, y, 8, 68, 164, 22)) {
            os.input(os.t("Номер (7 цифр)", "Number (7 digits)"), "", 7, 1, n -> { if (n.length() == 7) writeSms(os, st, n); else say(os, st, "Неверный номер", "Bad number"); });
            return;
        }
        List<String> ps = peers(os);
        if (y < LIST_Y || y >= LIST_Y + LIST_H) return;
        int i = (y - LIST_Y + st.sc.off) / ROW;
        if (i >= 0 && i < ps.size()) { st.peer = ps.get(i); st.sc.off = Integer.MAX_VALUE / 2; }
    }

    private void writeSms(AndroOs os, St st, String to) {
        os.input(os.t("SMS: ", "SMS: ") + PhoneData.label(os.stack(), to), "", 100, 0, text -> {
            if (text.isEmpty()) return;
            String err = sendSms(os, to, text);
            if (err != null) say(os, st, err, err);
            else { st.peer = to; st.sc.off = Integer.MAX_VALUE / 2; }
        });
    }

    /** Отправить SMS; null - успех, иначе текст ошибки (на языке телефона). */
    static String sendSms(AndroOs os, String to, String text) {
        if (!os.cellular()) return os.t("Нет сети оператора", "No cellular network");
        PhoneBook pb = PhoneBook.get(os.ses.player.server);
        if (!pb.exists(to)) return os.t("Номер не существует", "Number does not exist");
        if (to.equals(os.number())) return os.t("Нельзя написать себе", "Cannot message yourself");
        pb.post(to, os.number(), text, false);
        PhoneData.addSms(os.stack(), to, true, text, os.minute);
        return null;
    }

    private void tapChat(AndroOs os, St st, int x, int y) {
        TileServer srv = server(os);
        if (srv == null) return;
        if (st.nick.isEmpty()) {
            if (AppUi.in(x, y, 20, 130, 140, 30)) auth(os, st, false);
            else if (AppUi.in(x, y, 20, 170, 140, 30)) auth(os, st, true);
            return;
        }
        if (y < 84 && x >= 120) { logout(os, st); return; }
        List<String> list = new ArrayList<String>();
        list.add(ChatStore.GENERAL);
        list.addAll(st.users);
        if (y < 86) return;
        int i = (y - 86 + st.sc.off) / ROW;
        if (i >= 0 && i < list.size()) { st.conv = list.get(i); st.unread.remove(st.conv); st.sc.off = Integer.MAX_VALUE / 2; }
    }

    private void auth(AndroOs os, St st, boolean reg) {
        os.input(os.t("Ник (a-z, 0-9, _)", "Nick (a-z, 0-9, _)"), "", 16, 0, nick -> {
            if (nick.isEmpty()) return;
            os.input(os.t("Пароль", "Password"), "", 20, 2, pass -> {
                TileServer srv = server(os);
                if (srv == null) { say(os, st, "Нет сервера", "No server"); return; }
                String h = VFS.hash(pass);
                String e = reg ? (pass.isEmpty() ? "Password must not be empty" : srv.register(nick, h)) : srv.login(nick, h);
                if (e != null) { say(os, st, e, e); return; }
                st.nick = nick; st.hash = h; st.lastId = 0; st.cache.clear(); st.bound = null;
                CompoundTag d = PhoneData.d(os.stack());
                d.putString("ChatNick", nick); d.putString("ChatHash", h);
                poll(os, st);
            });
        });
    }

    private void writeChat(AndroOs os, St st) {
        String to = st.conv;
        os.input(to, "", ChatStore.MAX_TEXT, 0, text -> {
            if (text.isEmpty()) return;
            TileServer srv = server(os);
            if (srv == null) { say(os, st, "Нет сервера", "No server"); return; }
            String e = srv.send(st.nick, st.hash, to, text);
            if (e != null) say(os, st, e, e);
            else { poll(os, st); st.sc.off = Integer.MAX_VALUE / 2; }
        });
    }

    @Override
    public boolean back(AndroOs os) {
        St st = st(os);
        if (st.peer != null || st.conv != null) { st.peer = null; st.conv = null; st.sc.off = 0; return true; }
        return false;
    }
}
