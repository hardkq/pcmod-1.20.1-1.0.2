package ru.pcmod.common;

import net.minecraft.nbt.ListTag;

/** Приложение «Заметки»: список (до 20), создание/правка через экранную клавиатуру, удаление. */
final class AppNotes implements AndroOs.App {
    private static final int LIST_Y = 76, LIST_H = 220, ROW = 30, MAX_LEN = 150;

    private static final class St { int open = -1; final AppUi.Scroll sc = new AppUi.Scroll(); }

    private static St st(AndroOs os) { return os.state("notes", St::new); }

    private static ListTag notes(AndroOs os) { return PhoneData.strings(os.stack(), "Notes"); }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        ListTag l = notes(os);
        if (st.open >= l.size()) st.open = -1;
        AppUi.header(os, s, "notes", os.t("Заметки", "Notes"));
        if (st.open >= 0) {
            var lines = AppUi.wrap(l.getString(st.open), 150);
            s.roundRect(8, 48, 164, 200, 10, os.panel());
            for (int i = 0; i < lines.size() && i < 18; i++) s.drawText(14, 54 + i * 11, lines.get(i), os.text());
            AppUi.btn(os, s, 8, 256, 52, 28, os.t("Назад", "Back"), false);
            AppUi.btn(os, s, 64, 256, 52, 28, os.t("Править", "Edit"), true);
            AppUi.btn(os, s, 120, 256, 52, 28, os.t("Удалить", "Delete"), false);
            return;
        }
        AppUi.btn(os, s, 8, 48, 164, 24, os.t("+ Новая заметка", "+ New note"), true);
        if (l.isEmpty()) s.drawTextCentered(0, AndroOs.W, 150, os.t("Заметок нет", "No notes"), os.sub(), 1, false);
        s.pushClip(0, LIST_Y - 2, AndroOs.W, LIST_H + 2);
        for (int i = 0; i < l.size(); i++) {
            int y = LIST_Y - st.sc.off + i * ROW;
            if (y < LIST_Y - ROW || y > LIST_Y + LIST_H) continue;
            s.roundRect(8, y, 164, ROW - 3, 8, os.panel());
            s.roundRect(8, y, 4, ROW - 3, 2, AndroIcons.colorOf("notes"));
            s.drawText(18, y + 4, PixelScreen.fit(l.getString(i), 148, 1, true), os.text(), 1, true);
            s.drawText(18, y + 15, PixelScreen.fit(l.getString(i).length() + " " + os.t("симв.", "chars"), 148, 1, false), os.sub());
        }
        s.popClip();
    }

    private void edit(AndroOs os, int idx) {
        ListTag l = notes(os);
        String init = idx >= 0 && idx < l.size() ? l.getString(idx) : "";
        os.input(os.t("Заметка", "Note"), init, MAX_LEN, 0, t -> {
            if (t.isEmpty()) return;
            ListTag n = notes(os);
            if (idx >= 0 && idx < n.size()) n.set(idx, net.minecraft.nbt.StringTag.valueOf(t));
            else if (n.size() < PhoneData.MAX_NOTES) n.add(net.minecraft.nbt.StringTag.valueOf(t));
            PhoneData.d(os.stack()).put("Notes", n);
        });
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St st = st(os);
        if (kind == 0) { st.sc.down(y); return true; }
        if (kind == 2) { st.sc.drag(y, notes(os).size() * ROW, LIST_H); return true; }
        if (!os.tap(x, y) || st.sc.moved) return true;
        ListTag l = notes(os);
        if (st.open >= 0) {
            if (AppUi.in(x, y, 8, 256, 52, 28)) st.open = -1;
            else if (AppUi.in(x, y, 64, 256, 52, 28)) edit(os, st.open);
            else if (AppUi.in(x, y, 120, 256, 52, 28)) { l.remove(st.open); PhoneData.d(os.stack()).put("Notes", l); st.open = -1; }
            return true;
        }
        if (AppUi.in(x, y, 8, 48, 164, 24)) {
            if (l.size() >= PhoneData.MAX_NOTES) return true;
            edit(os, -1);
        } else if (y >= LIST_Y) {
            int i = (y - LIST_Y + st.sc.off) / ROW;
            if (i >= 0 && i < l.size()) st.open = i;
        }
        return true;
    }

    @Override
    public boolean back(AndroOs os) {
        St st = st(os);
        if (st.open >= 0) { st.open = -1; return true; }
        return false;
    }
}
