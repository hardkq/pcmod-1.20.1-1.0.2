package ru.pcmod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Зарядная станция телефонов (3D-модель charger / charger_full). ПКМ с телефоном в руке - поставить, ПКМ без телефона - забрать. */
public class BlockCharger extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    public static final BooleanProperty HAS_PHONE = BooleanProperty.create("has_phone");
    private static final VoxelShape SHAPE = Block.box(2, 0, 2, 14, 15, 14);

    public BlockCharger() {
        super(Properties.of().strength(1.5F, 6.0F).sound(SoundType.METAL).noOcclusion());
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH).setValue(HAS_PHONE, false));
    }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(FACING, HAS_PHONE); }
    @Override public BlockState getStateForPlacement(BlockPlaceContext c) {
        return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite());
    }
    @Override public RenderShape getRenderShape(BlockState s) { return RenderShape.MODEL; }
    @Override public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) { return SHAPE; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState st) { return new TileCharger(pos, st); }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level l, BlockState s, BlockEntityType<T> t) {
        return l.isClientSide ? null : createTickerHelper(t, ModBlockEntities.CHARGER.get(), (lv, p, st, te) -> te.tick());
    }

    @Override public InteractionResult use(BlockState st, Level level, BlockPos pos, Player pl, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(level.getBlockEntity(pos) instanceof TileCharger t)) return InteractionResult.PASS;
        ItemStack held = pl.getItemInHand(hand);
        if (t.phone().isEmpty()) {
            if (!(held.getItem() instanceof ItemPhone)) return InteractionResult.PASS;
            t.setPhone(held.split(1));
            return InteractionResult.CONSUME;
        }
        ItemStack out = t.takePhone();
        pl.displayClientMessage(Component.translatable("tooltip.pcmod.phone.battery", ItemPhone.percent(out)), true);
        if (held.isEmpty()) pl.setItemInHand(hand, out);
        else pl.getInventory().placeItemBackInInventory(out);
        return InteractionResult.CONSUME;
    }

    @Override public void onRemove(BlockState st, Level level, BlockPos pos, BlockState ns, boolean moving) {
        if (!st.is(ns.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof TileCharger t && !t.phone().isEmpty()) {
            level.addFreshEntity(new ItemEntity(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, t.phone()));
        }
        super.onRemove(st, level, pos, ns, moving);
    }
}
