package ru.pcmod.common;

import java.util.List;
import ru.pcmod.common.WinUi.Button;

/** Установщик WinCraft 11 в стиле Windows 11 Setup: проверка ПК, выбор накопителя, учётная запись, установка. */
public final class WinSetup extends WinScene {
    private static final int W = PixelScreen.W, H = PixelScreen.H;
    private static final int CX = 30, CY = 8, CW = 260, CH = 164;
    private static final int WELCOME = 0, CHECK = 1, DRIVE = 2, CONFIRM = 3, ACCOUNT = 4, INSTALL = 5, DONE = 6;
    private static final String[] TITLE = {"Добро пожаловать", "Проверка компьютера", "Выбор накопителя", "Подтверждение",
            "Учётная запись", "Установка", "Готово"};

    private final WinSpec.Hw hw;
    private final WinSpec.Perf perf;
    private final List<WinSpec.Req> reqs;
    private final boolean blocked, slow;
    private final Button back = new Button("Назад", 0, 0, 62, false), next = new Button("Далее", 0, 0, 80, true);
    private final WinUi.Field[] f = new WinUi.Field[3];
    private int page, focus, timer, total, lastPct = -1;
    private boolean showBack, showNext;
    private String err = "", host = "", user = "", pw = "";
    private long doneAt;

    public WinSetup(WinHost h) {
        super(h);
        hw = h.hw();
        perf = WinSpec.perf(hw);
        reqs = WinSpec.checks(hw, true);
        boolean b = false, s = false;
        for (WinSpec.Req r : reqs) {
            if (r.state == 0) b = true;
            if (r.state == 1) s = true;
        }
        blocked = b;
        slow = s;
        for (int i = 0; i < 3; i++) {
            f[i] = new WinUi.Field(CX + 112, CY + 56 + i * 24, 132);
            f[i].max = 16;
        }
        f[0].hint = "wincraft";
        f[1].hint = "user";
        f[2].hint = "Пароль";
        f[2].mask = true;
        f[2].max = 24;
        layout();
    }

    public void begin() {
        activate();
        go(WELCOME);
    }

    // ================================================================== страницы
    private void go(int pg) {
        page = pg;
        err = "";
        layout();
        redraw(this::drawAll);
    }

    private void layout() {
        int y = CY + CH - 24;
        next.y = back.y = y;
        next.w = page == DONE ? 112 : 80;
        next.x = CX + CW - 12 - next.w;
        back.x = next.x - 8 - back.w;
        showBack = page == CHECK && !blocked || page == DRIVE || page == CONFIRM || page == ACCOUNT;
        showNext = page != INSTALL;
        next.primary = !(page == CHECK && blocked);
        next.enabled = !(page == DRIVE && hw.driveKB <= 0);
        switch (page) {
            case CHECK: next.label = blocked ? "Выход" : "Далее"; break;
            case CONFIRM: next.label = "Продолжить"; break;
            case ACCOUNT: next.label = "Установить"; break;
            case DONE: next.label = "Перезагрузить"; break;
            default: next.label = "Далее"; break;
        }
    }

    private void onNext() {
        switch (page) {
            case WELCOME: go(CHECK); break;
            case CHECK:
                if (blocked) {
                    dead = true;
                    h.restart();
                } else {
                    go(DRIVE);
                }
                break;
            case DRIVE: if (next.enabled) go(CONFIRM); break;
            case CONFIRM: go(ACCOUNT); break;
            case ACCOUNT: tryInstall(); break;
            case DONE:
                dead = true;
                h.restart();
                break;
            default: break;
        }
    }

    private void onBack() {
        if (showBack && page > WELCOME && page < INSTALL) go(page - 1);
    }

    private void tryInstall() {
        err = "";
        String hn = f[0].sb.toString().trim().toLowerCase();
        String un = f[1].sb.toString().trim().toLowerCase();
        String pwd = f[2].sb.toString();
        if (hn.isEmpty()) hn = "wincraft";
        if (!hn.matches("[a-z0-9-]{1,16}")) err = "Имя компьютера: a-z, 0-9, -, до 16 символов.";
        else if (!un.matches("[a-z][a-z0-9_]{0,15}")) err = "Имя пользователя: a-z, 0-9, _, начинается с буквы.";
        else if (pwd.isEmpty()) err = "Введите пароль.";
        if (!err.isEmpty()) {
            redraw(this::drawBody);
            return;
        }
        host = hn;
        user = un;
        pw = pwd;
        for (WinUi.Field x : f) x.sb.setLength(0);
        total = WinSpec.installTicks(hw);
        timer = 0;
        lastPct = -1;
        go(INSTALL);
    }

    // ================================================================== тик и ввод
    public void tick() {
        if (dead) return;
        long now = h.time();
        if (page == INSTALL) {
            timer++;
            int pct = Math.min(100, timer * 100 / Math.max(1, total));
            if (timer >= total) {
                h.install(host, user, pw);
                pw = "";
                doneAt = now + 200;
                go(DONE);
                return;
            }
            boolean spin = timer % perf.animDiv == 0, prog = pct != lastPct;
            lastPct = pct;
            if (spin || prog) {
                redraw(() -> {
                    if (spin) drawSpinner();
                    if (prog) drawProgress(pct);
                });
            }
        } else if (page == DONE) {
            if (now >= doneAt) {
                dead = true;
                h.restart();
            } else if (now % 20 == 0) {
                redraw(this::drawDoneText);
            }
        } else if (page == ACCOUNT && now % 10 == 0) {
            redraw(this::drawFields);
        }
    }

    public void key(char c, int key) {
        if (dead) return;
        if (page == ACCOUNT) {
            if (key == WinUi.K_TAB || c == '\t') {
                focus = (focus + 1) % 3;
                redraw(this::drawFields);
            } else if (key == WinUi.K_DOWN) {
                focus = Math.min(2, focus + 1);
                redraw(this::drawFields);
            } else if (key == WinUi.K_UP) {
                focus = Math.max(0, focus - 1);
                redraw(this::drawFields);
            } else if (f[focus].key(c, key)) {
                if (focus < 2) focus++;
                else onNext();
                redraw(this::drawBody);
            } else {
                redraw(this::drawFields);
            }
            return;
        }
        if (WinUi.isEnter(c, key) && page != INSTALL) onNext();
    }

    @Override
    void onMouse(int btn, int kind) {
        boolean press = kind == PixelScreen.MOUSE_PRESS && btn == 0;
        boolean hb = showBack && back.hit(mx, my), hn = showNext && next.hit(mx, my);
        if (press) {
            if (hn) {
                onNext();
                return;
            }
            if (hb) {
                onBack();
                return;
            }
            if (page == ACCOUNT) {
                for (int i = 0; i < 3; i++) {
                    if (f[i].hit(mx, my) && focus != i) {
                        focus = i;
                        redraw(this::drawFields);
                        return;
                    }
                }
            }
        }
        if (hb != back.hover || hn != next.hover) {
            back.hover = hb;
            next.hover = hn;
            redraw(this::drawButtons);
        }
    }

    // ================================================================== рисование
    private void drawAll() {
        p.gradientV(0, 0, W, H, 0xFF1E5AA6, 0xFF0C2A5C);
        p.shadow(CX, CY, CW, CH, 6, 10, 0, 3, 0x88000000);
        p.roundRect(CX, CY, CW, CH, 6, th.surface());
        WinGfx.logo(p, CX + 12, CY + 7, 12, 0xFF0078D4);
        p.drawText(CX + 30, CY + 9, "Установка WinCraft 11", th.text(), 1, true);
        p.hline(CX + 1, CY + 25, CW - 2, th.border());
        drawBody();
        drawButtons();
    }

    private void drawButtons() {
        p.fillRect(CX + 2, CY + CH - 32, CW - 4, 24, th.surface());
        if (showBack) back.draw(p, th);
        if (showNext) next.draw(p, th);
    }

    private void drawBody() {
        p.fillRect(CX + 2, CY + 26, CW - 4, CH - 58, th.surface());
        p.drawText(CX + 14, CY + 33, TITLE[page], th.text(), 2, false);
        int x = CX + 14, y = CY + 60;
        switch (page) {
            case WELCOME:
                WinGfx.logo(p, x, y + 2, 32, 0xFF0078D4);
                p.drawText(x + 46, y, "Этот мастер установит", th.text());
                p.drawText(x + 46, y + 12, "WinCraft 11 на накопитель", th.text());
                p.drawText(x + 46, y + 24, "этого компьютера.", th.text());
                p.drawText(x, y + 52, "Язык: Русский (Россия)", th.sub());
                p.drawText(x, y + 64, "Формат времени: Россия", th.sub());
                break;
            case CHECK:
                drawCheck(x, y);
                break;
            case DRIVE:
                drawDrive(x, y);
                break;
            case CONFIRM:
                WinGfx.state(p, x + 8, y + 8, 1, th);
                p.drawText(x + 24, y + 2, "Все данные на накопителе", th.text());
                p.drawText(x + 24, y + 14, PixelScreen.fit(hw.drive, CW - 60, 1, true) + " будут удалены.", th.text(), 1, false);
                p.drawText(x + 24, y + 32, "Продолжить установку?", th.sub());
                break;
            case ACCOUNT:
                drawAccount();
                break;
            case INSTALL:
                drawSpinner();
                drawProgress(Math.max(0, lastPct));
                p.drawTextCentered(CX, CW, CY + CH - 24, "Не выключайте компьютер", th.sub(), 1, false);
                break;
            case DONE:
                p.roundRect(CX + CW / 2 - 14, CY + 58, 28, 28, 14, 0xFF2E9E3E);
                WinGfx.line(p, CX + CW / 2 - 7, CY + 72, CX + CW / 2 - 2, CY + 77, 0xFFFFFFFF);
                WinGfx.line(p, CX + CW / 2 - 7, CY + 73, CX + CW / 2 - 2, CY + 78, 0xFFFFFFFF);
                WinGfx.line(p, CX + CW / 2 - 2, CY + 77, CX + CW / 2 + 8, CY + 66, 0xFFFFFFFF);
                WinGfx.line(p, CX + CW / 2 - 2, CY + 78, CX + CW / 2 + 8, CY + 67, 0xFFFFFFFF);
                p.drawTextCentered(CX, CW, CY + 94, "Установка WinCraft 11 завершена", th.text(), 1, true);
                drawDoneText();
                break;
            default:
                break;
        }
    }

    private void drawCheck(int x, int y0) {
        int y = y0 - 6;
        p.drawText(x, y, "Компонент", th.sub());
        p.drawText(x + 76, y, "Требуется", th.sub());
        p.drawText(x + 160, y, "У вас", th.sub());
        int ry = y + 11;
        for (WinSpec.Req r : reqs) {
            p.drawText(x, ry + 1, r.name, th.text());
            p.drawText(x + 76, ry + 1, PixelScreen.fit(r.need, 80, 1, false), th.sub());
            p.drawText(x + 160, ry + 1, r.have, th.text());
            WinGfx.state(p, CX + CW - 22, ry + 4, r.state, th);
            ry += 13;
        }
        int my = ry + 4;
        if (blocked) {
            p.drawText(x, my, "Не хватает ресурсов: замените железо.", th.bad());
        } else if (slow) {
            p.drawText(x, my, "Будет медленнее: эффекты отключатся.", th.warn());
        } else {
            p.drawText(x, my, "Компьютер полностью подходит.", th.ok());
        }
    }

    private void drawDrive(int x, int y) {
        p.roundRectBorder(x, y, CW - 28, 38, 5, th.dark ? 0xFF333333 : 0xFFF7F9FC, th.accent());
        p.roundRect(x + 8, y + 9, 22, 20, 3, th.accent());
        p.fillRect(x + 12, y + 22, 14, 2, 0xFFFFFFFF);
        p.fillRect(x + 12, y + 25, 8, 2, 0xFFFFFFFF);
        if (hw.driveKB <= 0) {
            p.drawText(x + 40, y + 8, "Накопитель не найден", th.bad(), 1, true);
            p.drawText(x + 40, y + 21, "Установите накопитель и повторите.", th.sub());
        } else {
            p.drawText(x + 40, y + 8, PixelScreen.fit(hw.drive, CW - 90, 1, true), th.text(), 1, true);
            p.drawText(x + 40, y + 21, "Объём: " + hw.driveKB + " КБ", th.sub());
        }
        boolean ok = hw.driveKB >= WinSpec.MIN_DISK_KB;
        p.drawText(x, y + 48, "Нужно " + WinSpec.MIN_DISK_KB + " КБ, система займёт "
                + WinSpec.OS_SIZE / 1024 + " КБ.", ok ? th.sub() : th.bad());
        p.drawText(x, y + 60, "Выбран единственный накопитель.", th.sub());
    }

    private void drawAccount() {
        String[] lab = {"Имя компьютера", "Имя пользователя", "Пароль"};
        for (int i = 0; i < 3; i++) p.drawText(CX + 14, f[i].y + 4, lab[i], th.text());
        drawFields();
        if (!err.isEmpty()) p.drawText(CX + 14, CY + CH - 42, PixelScreen.fit(err, CW - 28, 1, false), th.bad());
    }

    private void drawFields() {
        for (int i = 0; i < 3; i++) {
            p.fillRect(f[i].x - 2, f[i].y - 2, f[i].w + 4, f[i].h + 4, th.surface());
            f[i].draw(p, th, i == focus, h.time());
        }
    }

    private void drawSpinner() {
        int[] b = WinGfx.spinnerBox(CX + CW / 2, CY + 70, 10);
        p.fillRect(b[0], b[1], b[2], b[3], th.surface());
        WinGfx.spinner(p, CX + CW / 2, CY + 70, 10, h.time(), th.accent());
    }

    private static String caption(int pct) {
        return pct < 12 ? "Подготовка накопителя..." : pct < 60 ? "Копирование файлов WinCraft..."
                : pct < 90 ? "Установка компонентов..." : "Настройка параметров...";
    }

    private void drawProgress(int pct) {
        int bx = CX + 40, bw = CW - 80;
        p.fillRect(CX + 4, CY + 84, CW - 8, 56, th.surface());
        p.drawTextCentered(CX, CW, CY + 84, pct + " %", th.text(), 2, false);
        p.roundRect(bx, CY + 112, bw, 6, 3, th.dark ? 0xFF4A4A4A : 0xFFD9D9D9);
        if (pct > 0) p.roundRect(bx, CY + 112, Math.max(6, bw * pct / 100), 6, 3, th.accent());
        p.drawTextCentered(CX, CW, CY + 124, caption(pct), th.sub(), 1, false);
    }

    private void drawDoneText() {
        p.fillRect(CX + 4, CY + 108, CW - 8, 14, th.surface());
        long left = Math.max(1, (doneAt - h.time() + 19) / 20);
        p.drawTextCentered(CX, CW, CY + 110, "Перезагрузка через " + left + " с", th.sub(), 1, false);
    }
}
