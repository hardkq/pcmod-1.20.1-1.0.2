package ru.pcmod.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Данные мира для телефонов (SavedData): реестр номеров, непрочитанные SMS и пропущенные звонки (доставляются при открытии
 * телефона), фото из камеры по идентификатору телефона. Звонки между открытыми телефонами живут в памяти ({@link Call}).
 */
public final class PhoneBook extends SavedData {
    /** Входящее для номера: SMS (missed = false) или пропущенный звонок. */
    public static final class Msg {
        public String from = "", text = "";
        public boolean missed;
    }

    /** Фото камеры: w*h байт - цвет карты (MapColor packed id), 0 - небо. */
    public static final class Photo {
        public int w, h, min;
        public long day;
        public byte[] d = new byte[0];
    }

    /** Звонок: state 0 - вызов, 1 - разговор, 2 - завершён. */
    public static final class Call {
        public final PhoneSession a, b;
        public final String na, nb;
        public int state;
        public long since;
        Call(PhoneSession a, PhoneSession b, String na, String nb, long now) { this.a = a; this.b = b; this.na = na; this.nb = nb; since = now; }
    }

    private static final Random RND = new Random();
    private final Set<String> numbers = new HashSet<String>();
    private final Map<String, List<Msg>> inbox = new HashMap<String, List<Msg>>();
    private final Map<String, List<Photo>> photos = new HashMap<String, List<Photo>>();

    public static PhoneBook get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(PhoneBook::load, PhoneBook::new, "pcmod_phonebook");
    }

    // ---- номера
    public String allocate() {
        String n;
        do n = String.valueOf(5000000 + RND.nextInt(4000000)); while (numbers.contains(n));
        numbers.add(n);
        setDirty();
        return n;
    }

    public void claim(String n) { if (numbers.add(n)) setDirty(); }
    public boolean exists(String n) { return numbers.contains(n); }

    // ---- входящие
    public void post(String to, String from, String text, boolean missed) {
        Msg m = new Msg();
        m.from = from; m.text = text; m.missed = missed;
        List<Msg> l = inbox.computeIfAbsent(to, k -> new ArrayList<Msg>());
        l.add(m);
        while (l.size() > 100) l.remove(0);
        setDirty();
    }

    public List<Msg> take(String to) {
        List<Msg> l = inbox.remove(to);
        if (l != null) setDirty();
        return l;
    }

    public boolean has(String to) { return inbox.containsKey(to); }

    // ---- фото
    public List<Photo> photos(String uid) { return photos.computeIfAbsent(uid, k -> new ArrayList<Photo>()); }

    public void changed() { setDirty(); }

    // ---- сохранение
    public static PhoneBook load(CompoundTag t) {
        PhoneBook b = new PhoneBook();
        ListTag n = t.getList("Numbers", Tag.TAG_STRING);
        for (int i = 0; i < n.size(); i++) b.numbers.add(n.getString(i));
        CompoundTag in = t.getCompound("Inbox");
        for (String k : in.getAllKeys()) {
            ListTag l = in.getList(k, Tag.TAG_COMPOUND);
            List<Msg> out = new ArrayList<Msg>();
            for (int i = 0; i < l.size(); i++) {
                Msg m = new Msg();
                m.from = l.getCompound(i).getString("f"); m.text = l.getCompound(i).getString("x"); m.missed = l.getCompound(i).getBoolean("c");
                out.add(m);
            }
            b.inbox.put(k, out);
        }
        CompoundTag ph = t.getCompound("Photos");
        for (String k : ph.getAllKeys()) {
            ListTag l = ph.getList(k, Tag.TAG_COMPOUND);
            List<Photo> out = new ArrayList<Photo>();
            for (int i = 0; i < l.size(); i++) {
                CompoundTag c = l.getCompound(i);
                Photo p = new Photo();
                p.w = c.getInt("w"); p.h = c.getInt("h"); p.min = c.getInt("m"); p.day = c.getLong("d"); p.d = c.getByteArray("b");
                if (p.w > 0 && p.h > 0 && p.d.length == p.w * p.h) out.add(p);
            }
            b.photos.put(k, out);
        }
        return b;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        ListTag n = new ListTag();
        for (String s : numbers) n.add(net.minecraft.nbt.StringTag.valueOf(s));
        t.put("Numbers", n);
        CompoundTag in = new CompoundTag();
        for (Map.Entry<String, List<Msg>> e : inbox.entrySet()) {
            ListTag l = new ListTag();
            for (Msg m : e.getValue()) {
                CompoundTag c = new CompoundTag();
                c.putString("f", m.from); c.putString("x", m.text); c.putBoolean("c", m.missed);
                l.add(c);
            }
            in.put(e.getKey(), l);
        }
        t.put("Inbox", in);
        CompoundTag ph = new CompoundTag();
        for (Map.Entry<String, List<Photo>> e : photos.entrySet()) {
            if (e.getValue().isEmpty()) continue;
            ListTag l = new ListTag();
            for (Photo p : e.getValue()) {
                CompoundTag c = new CompoundTag();
                c.putInt("w", p.w); c.putInt("h", p.h); c.putInt("m", p.min); c.putLong("d", p.day); c.putByteArray("b", p.d);
                l.add(c);
            }
            ph.put(e.getKey(), l);
        }
        t.put("Photos", ph);
        return t;
    }

    // ===================== звонки (в памяти) =====================
    public static final int RING_TICKS = 600;

    /** Набор номера. null - вызов пошёл, иначе причина отказа (ru, en). */
    public static String[] dial(PhoneSession from, String num) {
        AndroOs os = from.os;
        String mine = os.number();
        if (mine.isEmpty()) return new String[] {"Нет SIM", "No SIM"};
        if (os.call != null) return new String[] {"Уже идёт вызов", "Already in a call"};
        if (!os.cellular()) return new String[] {"Нет сети оператора", "No cellular network"};
        PhoneBook pb = get(from.player.server);
        if (num.equals(mine)) return new String[] {"Нельзя позвонить себе", "Cannot call yourself"};
        if (!pb.exists(num)) return new String[] {"Номер не существует", "Number does not exist"};
        PhoneSession to = PhoneSession.byNumber(num);
        long now = from.player.server.getTickCount();
        if (to == null || !to.os.awake() || to.os.dnd || to.os.call != null || !to.os.cellular()) {
            pb.post(num, mine, "", true);
            PhoneData.addCall(from.stack(), num, 0, os.minute);
            return new String[] {"Абонент недоступен", "Subscriber unavailable"};
        }
        Call c = new Call(from, to, mine, num, now);
        os.call = c; os.callOut = true;
        to.os.call = c; to.os.callOut = false;
        to.os.alert(to.os.t("Входящий вызов", "Incoming call"), PhoneData.label(to.stack(), mine));
        return null;
    }

    public static void answer(AndroOs os) {
        Call c = os.call;
        if (c == null || c.state != 0 || os.callOut) return;
        c.state = 1;
        c.since = c.a.player.server.getTickCount();
        PhoneSession o = c.a;
        o.os.dirty();
        os.dirty();
        if (os.phase == AndroOs.Phase.HOME || os.phase == AndroOs.Phase.APP) os.open("phone");
    }

    /** Завершить вызов (любая сторона). */
    public static void hangup(AndroOs os) {
        Call c = os.call;
        if (c == null) return;
        boolean talked = c.state == 1;
        boolean callerSide = c.a.os == os;
        c.state = 2;
        PhoneSession me = callerSide ? c.a : c.b, other = callerSide ? c.b : c.a;
        String meNum = callerSide ? c.nb : c.na, otherNum = callerSide ? c.na : c.nb;
        PhoneData.addCall(me.stack(), meNum, callerSide ? 0 : talked ? 1 : 2, me.os.minute);
        PhoneData.addCall(other.stack(), otherNum, callerSide ? (talked ? 1 : 2) : 0, other.os.minute);
        if (!talked && callerSide) other.os.notify(other.os.t("Пропущенный вызов", "Missed call"), PhoneData.label(other.stack(), otherNum));
        me.os.call = null; other.os.call = null;
        me.os.dirty(); other.os.dirty();
    }

    /** Раз в секунду для каждой сессии: таймаут вызова, обрыв связи. */
    public static void tickCall(PhoneSession s, long gt) {
        Call c = s.os.call;
        if (c == null || c.a != s) return;
        if (!c.a.os.cellular() || !c.b.os.cellular() || !c.b.os.awake() && c.state == 0) { hangup(s.os); return; }
        if (c.state == 0 && gt - c.since > RING_TICKS) hangup(s.os);
    }
}
