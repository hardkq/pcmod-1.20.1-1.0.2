package ru.pcmod.common;

import java.util.List;
import net.minecraft.nbt.ListTag;
import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Файлы»: занятое место во встроенной памяти (ОС, фото, заметки, SMS), просмотр и удаление фото и заметок. */
final class AppFiles implements AndroOs.App {
    private static final class St { int page; final AppUi.Scroll sc = new AppUi.Scroll(); }

    private static St st(AndroOs os) { return os.state("files", St::new); }

    private static int camMB(AndroOs os) {
        PartSpec cam = ItemPhone.part(os.stack(), PartSpec.Cat.PH_CAM);
        return AppCamera.photoMB(cam == null ? 0 : cam.mp);
    }

    private static List<PhoneBook.Photo> photos(AndroOs os) {
        return os.ses == null ? List.of() : PhoneBook.get(os.ses.player.server).photos(PhoneData.uid(os.stack()));
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "files", os.t("Файлы", "Files") + (st.page == 1 ? " / " + os.t("Фото", "Photos") : st.page == 2 ? " / " + os.t("Заметки", "Notes") : ""));
        int sys = os.sysMB() + AppStore.installedMB(os), ph = photos(os).size() * camMB(os), nt = PhoneData.strings(os.stack(), "Notes").size() * 2, sm = PhoneData.list(os.stack(), "Sms").size();
        int total = os.romGB * 1000, used = sys + ph + nt + sm;
        if (st.page == 0) {
            s.roundRect(8, 50, 164, 56, 10, os.panel());
            s.drawText(16, 56, os.t("Память", "Storage") + " " + os.romLabel, os.text(), 1, true);
            s.drawText(16, 68, String.format(java.util.Locale.ROOT, "%.1f / %.1f GB", used / 1000.0, total / 1000.0), os.sub());
            int bw = 148;
            s.roundRect(16, 84, bw, 8, 4, os.panel());
            int x = 16;
            int[] parts = {sys, ph, nt + sm};
            int[] col = {rgb(120, 130, 150), rgb(233, 84, 140), rgb(251, 192, 45)};
            for (int i = 0; i < 3; i++) {
                int w = (int) Math.min(16 + bw - x, (long) parts[i] * bw / Math.max(1, total));
                if (w > 0) { s.fillRect(x, 84, w, 8, col[i]); x += w; }
            }
            String[][] rows = {{"Система и ПО", "System & apps", String.format(java.util.Locale.ROOT, "%.1f GB", sys / 1000.0)}, {"Фото", "Photos", photos(os).size() + " (" + ph + " MB)"}, {"Заметки", "Notes", String.valueOf(PhoneData.strings(os.stack(), "Notes").size())}};
            for (int i = 0; i < 3; i++) {
                int y = 116 + i * 32;
                s.roundRect(8, y, 164, 28, 8, os.panel());
                s.roundRect(14, y + 10, 8, 8, 4, col[i]);
                s.drawText(28, y + 10, os.t(rows[i][0], rows[i][1]), os.text(), 1, true);
                s.drawTextRight(166, y + 10, rows[i][2], os.sub(), 1, false);
                if (i > 0) s.drawTextRight(166, y + 10, ">", os.accent(), 1, true);
            }
            s.drawText(14, 220, os.t("Свободно: ", "Free: ") + (total - used) / 1000 + " GB", os.sub());
            return;
        }
        s.pushClip(0, 48, AndroOs.W, 250);
        if (st.page == 1) {
            List<PhoneBook.Photo> l = photos(os);
            for (int i = 0; i < l.size(); i++) {
                int y = 50 - st.sc.off + i * 28;
                s.roundRect(8, y, 164, 25, 8, os.panel());
                s.drawText(14, y + 4, "IMG_" + AppUi.two(i + 1) + ".map", os.text(), 1, true);
                s.drawText(14, y + 14, l.get(i).w + "x" + l.get(i).h + "  " + camMB(os) + " MB", os.sub());
                s.drawTextRight(166, y + 8, "x", rgb(240, 120, 100), 1, true);
            }
            if (l.isEmpty()) s.drawTextCentered(0, AndroOs.W, 150, os.t("Пусто", "Empty"), os.sub(), 1, false);
        } else {
            ListTag l = PhoneData.strings(os.stack(), "Notes");
            for (int i = 0; i < l.size(); i++) {
                int y = 50 - st.sc.off + i * 28;
                s.roundRect(8, y, 164, 25, 8, os.panel());
                s.drawText(14, y + 4, PixelScreen.fit("note_" + AppUi.two(i + 1) + ".txt", 120, 1, true), os.text(), 1, true);
                s.drawText(14, y + 14, l.getString(i).length() + " B", os.sub());
                s.drawTextRight(166, y + 8, "x", rgb(240, 120, 100), 1, true);
            }
            if (l.isEmpty()) s.drawTextCentered(0, AndroOs.W, 150, os.t("Пусто", "Empty"), os.sub(), 1, false);
        }
        s.popClip();
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St st = st(os);
        if (kind == 0) { st.sc.down(y); return true; }
        if (kind == 2) { st.sc.drag(y, (st.page == 1 ? photos(os).size() : PhoneData.strings(os.stack(), "Notes").size()) * 28 + 6, 250); return true; }
        if (!os.tap(x, y) || st.sc.moved) return true;
        if (st.page == 0) {
            int i = (y - 116) / 32;
            if (y >= 116 && (y - 116) % 32 < 28 && i >= 1 && i <= 2) { st.page = i; st.sc.off = 0; }
            return true;
        }
        int i = (y - 50 + st.sc.off) / 28;
        if (y < 48 || x < 140 || i < 0) return true;
        if (st.page == 1) {
            List<PhoneBook.Photo> l = photos(os);
            if (i < l.size()) { l.remove(i); PhoneBook.get(os.ses.player.server).changed(); }
        } else {
            ListTag l = PhoneData.strings(os.stack(), "Notes");
            if (i < l.size()) { l.remove(i); PhoneData.d(os.stack()).put("Notes", l); }
        }
        return true;
    }

    @Override
    public boolean back(AndroOs os) {
        St st = st(os);
        if (st.page != 0) { st.page = 0; st.sc.off = 0; return true; }
        return false;
    }
}
