package ru.pcmod.common;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import static ru.pcmod.common.PixelScreen.rgb;

/**
 * Приложение «Камера»: видоискатель и снимок строятся на сервере трассировкой лучей из глаз игрока (цвета карты блоков).
 * Разрешение снимка зависит от камеры телефона (мегапиксели), число фото ограничено памятью. Фото хранятся в {@link PhoneBook}.
 */
final class AppCamera implements AndroOs.App {
    private static final int VX = 0, VY = AndroOs.STATUS, VW = 180, VH = 240, RANGE = 64;

    private static final class St {
        byte[] prev;
        int pw, ph;
        long last;
        String msg = "";
        long until;
        boolean flash;
    }

    private static St st(AndroOs os) { return os.state("camera", St::new); }

    static int[] gridFor(int mp) { return mp <= 0 ? new int[] {0, 0} : mp <= 8 ? new int[] {36, 48} : mp <= 20 ? new int[] {45, 60} : new int[] {60, 80}; }

    static int photoMB(int mp) { return 2 + mp / 4; }

    static int maxPhotos(AndroOs os) {
        PartSpec cam = ItemPhone.part(os.stack(), PartSpec.Cat.PH_CAM);
        int free = os.romGB * 1000 - os.sysMB() - AppStore.installedMB(os) - 150;
        return Math.max(0, Math.min(40, free / Math.max(1, photoMB(cam == null ? 0 : cam.mp)) / 4));
    }

    /** Снимок сцены перед игроком: gw x gh байт цвета карты (0 - небо). */
    static byte[] render(ServerPlayer p, int gw, int gh) {
        byte[] out = new byte[gw * gh];
        Level lv = p.level();
        Vec3 eye = p.getEyePosition(), f = p.getLookAngle();
        Vec3 right = f.cross(new Vec3(0, 1, 0));
        if (right.lengthSqr() < 1e-4) right = new Vec3(1, 0, 0);
        right = right.normalize();
        Vec3 up = right.cross(f).normalize();
        double th = Math.tan(Math.toRadians(32)), tv = th * gh / gw;
        for (int j = 0; j < gh; j++) {
            for (int i = 0; i < gw; i++) {
                double u = ((i + 0.5) / gw * 2 - 1) * th, v = (1 - (j + 0.5) / gh * 2) * tv;
                Vec3 dir = f.add(right.scale(u)).add(up.scale(v)).normalize();
                BlockHitResult h = lv.clip(new ClipContext(eye, eye.add(dir.scale(RANGE)), ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, p));
                if (h.getType() != HitResult.Type.BLOCK) continue;
                BlockPos bp = h.getBlockPos();
                BlockState bs = lv.getBlockState(bp);
                MapColor mc = bs.getMapColor(lv, bp);
                if (mc == MapColor.NONE) continue;
                double dist = eye.distanceTo(h.getLocation());
                int br = h.getDirection().getAxis().isVertical() ? (h.getDirection().getStepY() > 0 ? 2 : 3) : (h.getDirection().getAxis() == net.minecraft.core.Direction.Axis.X ? 1 : 0);
                if (dist > 36 && br > 0) br--;
                out[j * gw + i] = mc.getPackedId(MapColor.Brightness.byId(br));
            }
        }
        return out;
    }

    /** Нарисовать фото (gw x gh) в прямоугольнике width x (width*gh/gw) в точке (x, y). */
    static void paint(PixelScreen s, byte[] d, int gw, int gh, int x, int y, int width, int dayMinute) {
        int cell = Math.max(1, width / gw);
        int sky1 = dayMinute >= 360 && dayMinute < 1200 ? rgb(110, 175, 235) : rgb(12, 18, 40), sky2 = dayMinute >= 360 && dayMinute < 1200 ? rgb(200, 225, 250) : rgb(30, 40, 70);
        for (int j = 0; j < gh; j++)
            for (int i = 0; i < gw; i++) {
                int b = d[j * gw + i] & 255;
                int c;
                if (b == 0) c = PixelScreen.lerp(sky1, sky2, j / (float) gh);
                else {
                    int a = MapColor.getColorFromPackedId(b);
                    c = rgb(a & 255, a >> 8 & 255, a >> 16 & 255);
                }
                s.fillRect(x + i * cell, y + j * cell, cell, cell, c);
            }
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        PartSpec cam = ItemPhone.part(os.stack(), PartSpec.Cat.PH_CAM);
        s.fillRect(0, 0, AndroOs.W, AndroOs.H, rgb(0, 0, 0));
        if (cam == null) {
            AndroIcons.draw(s, "camera", 75, 110, 30);
            s.drawTextCentered(0, AndroOs.W, 160, os.t("Камера не установлена", "No camera installed"), rgb(240, 245, 255), 1, true);
            s.drawTextCentered(0, AndroOs.W, 176, os.t("Установите её на столе сборки", "Install it at the assembly table"), rgb(150, 165, 190), 1, false);
            return;
        }
        int[] g = gridFor(cam.mp);
        int lag = os.lag();
        if (st.prev == null || st.pw != g[0] || os.now() - st.last >= 4 + lag * 3) {
            if (os.ses != null) st.prev = render(os.ses.player, g[0], g[1]);
            st.pw = g[0]; st.ph = g[1]; st.last = os.now();
            os.dirty();
        }
        if (st.prev != null) paint(s, st.prev, st.pw, st.ph, VX, VY, VW, os.minute);
        s.drawText(6, VY + 4, cam.mp + " MP", rgb(255, 255, 255), 1, true);
        s.hline(90 - 8, VY + VH / 2, 17, argb(120));
        s.vline(90, VY + VH / 2 - 8, 17, argb(120));
        List<PhoneBook.Photo> ph = os.ses == null ? List.of() : PhoneBook.get(os.ses.player.server).photos(PhoneData.uid(os.stack()));
        s.fillRect(0, VY + VH, AndroOs.W, AndroOs.NAV - VY - VH, rgb(10, 12, 18));
        s.roundRect(76, 262, 28, 28, 14, rgb(255, 255, 255));
        s.roundRect(80, 266, 20, 20, 10, rgb(230, 70, 60));
        s.drawText(10, 270, ph.size() + "/" + maxPhotos(os), rgb(200, 210, 225), 1, true);
        s.roundRect(140, 266, 32, 20, 8, rgb(40, 46, 60));
        s.drawTextCentered(140, 32, 272, os.t("Фото", "Pics"), rgb(240, 245, 255), 1, false);
        if (st.until > os.now()) s.drawTextCentered(0, AndroOs.W, VY + 100, st.msg, rgb(255, 120, 100), 1, true);
    }

    private static int argb(int a) { return PixelScreen.argb(a, 255, 255, 255); }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        if (kind != 1 || !os.tap(x, y)) return true;
        St st = st(os);
        PartSpec cam = ItemPhone.part(os.stack(), PartSpec.Cat.PH_CAM);
        if (cam == null || os.ses == null) return true;
        if (AppUi.in(x, y, 140, 266, 32, 20)) { os.open("gallery"); return true; }
        if (y >= 258 && x >= 70 && x < 110) {
            PhoneBook pb = PhoneBook.get(os.ses.player.server);
            List<PhoneBook.Photo> ph = pb.photos(PhoneData.uid(os.stack()));
            if (ph.size() >= maxPhotos(os)) { st.msg = os.t("Память заполнена", "Storage full"); st.until = os.now() + 60; return true; }
            int[] g = gridFor(cam.mp);
            PhoneBook.Photo p = new PhoneBook.Photo();
            p.w = g[0]; p.h = g[1]; p.d = render(os.ses.player, g[0], g[1]); p.min = os.minute; p.day = os.day;
            ph.add(p);
            pb.changed();
            st.msg = os.t("Фото сохранено", "Photo saved"); st.until = os.now() + 40;
        }
        return true;
    }
}
