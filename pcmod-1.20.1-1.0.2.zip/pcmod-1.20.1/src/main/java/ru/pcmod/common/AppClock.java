package ru.pcmod.common;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import static ru.pcmod.common.PixelScreen.rgb;

/** Приложение «Часы»: время мира, будильники (до 4, звонят даже при закрытом приложении), секундомер, таймер. */
final class AppClock implements AndroOs.App {
    private static final int[] PRESETS = {1, 5, 10, 30};

    private static final class St {
        int tab;
        long lastFire = -1;
        boolean swRun;
        long swStart, swAcc, timerEnd;
        int timerSet;
    }

    private static St st(AndroOs os) { return os.state("clock", St::new); }

    private static ListTag alarms(AndroOs os) { return PhoneData.list(os.stack(), "Alarms"); }

    @Override
    public void bg(AndroOs os) {
        St st = st(os);
        long key = os.day * 1440L + os.minute;
        if (st.lastFire != key && os.ses != null) {
            ListTag l = alarms(os);
            for (int i = 0; i < l.size(); i++) {
                CompoundTag c = l.getCompound(i);
                if (c.getBoolean("on") && c.getInt("m") == os.minute) { st.lastFire = key; os.alert(os.t("Будильник", "Alarm"), AppUi.hhmm(os.minute)); break; }
            }
        }
        if (st.timerEnd > 0 && os.now() >= st.timerEnd) { st.timerEnd = 0; os.alert(os.t("Таймер", "Timer"), os.t("Время вышло", "Time is up")); }
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "clock", os.t("Часы", "Clock"));
        AppUi.tabs(os, s, new String[] {os.t("Часы", "Clock"), os.t("Будильник", "Alarm"), os.t("Секундомер", "Stopwatch"), os.t("Таймер", "Timer")}, st.tab);
        switch (st.tab) {
            case 0 -> {
                s.drawTextCentered(0, AndroOs.W, 120, AppUi.hhmm(os.minute), os.text(), 5, false);
                s.drawTextCentered(0, AndroOs.W, 172, os.t("День ", "Day ") + (os.day + 1), os.sub(), 1, false);
                boolean dayt = os.minute >= 360 && os.minute < 1200;
                s.drawTextCentered(0, AndroOs.W, 190, dayt ? os.t("День", "Daytime") : os.t("Ночь", "Night"), dayt ? rgb(250, 200, 60) : rgb(130, 150, 220), 1, true);
            }
            case 1 -> drawAlarms(os, s);
            case 2 -> {
                long ms = (st.swRun ? st.swAcc + os.now() - st.swStart : st.swAcc) * 50;
                s.drawTextCentered(0, AndroOs.W, 110, AppUi.two((int) (ms / 60000)) + ":" + AppUi.two((int) (ms / 1000 % 60)) + "." + AppUi.two((int) (ms / 10 % 100)), os.text(), 3, false);
                AppUi.btn(os, s, 14, 180, 74, 32, os.t("Сброс", "Reset"), false);
                AppUi.btn(os, s, 92, 180, 74, 32, st.swRun ? os.t("Стоп", "Stop") : os.t("Старт", "Start"), true);
                if (st.swRun) os.dirty();
            }
            default -> {
                long left = Math.max(0, st.timerEnd - os.now()) / 20;
                s.drawTextCentered(0, AndroOs.W, 110, st.timerEnd > 0 ? AppUi.two((int) (left / 60)) + ":" + AppUi.two((int) (left % 60)) : AppUi.two(PRESETS[st.timerSet]) + ":00", os.text(), 4, false);
                for (int i = 0; i < PRESETS.length; i++) AppUi.btn(os, s, 8 + i * 42, 160, 38, 26, PRESETS[i] + " " + os.t("мин", "min"), i == st.timerSet);
                AppUi.btn(os, s, 30, 200, 120, 32, st.timerEnd > 0 ? os.t("Отмена", "Cancel") : os.t("Старт", "Start"), true);
                if (st.timerEnd > 0) os.dirty();
            }
        }
    }

    private void drawAlarms(AndroOs os, PixelScreen s) {
        ListTag l = alarms(os);
        if (l.size() < PhoneData.MAX_ALARMS) AppUi.btn(os, s, 8, 72, 164, 24, os.t("+ Новый будильник", "+ New alarm"), true);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            int y = 102 + i * 40;
            boolean on = c.getBoolean("on");
            s.roundRect(8, y, 164, 36, 10, os.panel());
            s.drawText(16, y + 10, AppUi.hhmm(c.getInt("m")), on ? os.text() : os.sub(), 2, false);
            s.roundRect(110, y + 10, 26, 16, 8, on ? os.accent() : os.sub());
            s.roundRect(on ? 122 : 112, y + 12, 12, 12, 6, rgb(255, 255, 255));
            s.drawTextRight(166, y + 14, "x", rgb(240, 120, 100), 1, true);
        }
        if (l.isEmpty()) s.drawTextCentered(0, AndroOs.W, 160, os.t("Будильников нет", "No alarms"), os.sub(), 1, false);
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        if (kind != 1 || !os.tap(x, y)) return true;
        St st = st(os);
        int tb = AppUi.tabAt(4, x, y);
        if (tb >= 0) { st.tab = tb; return true; }
        if (st.tab == 1) {
            ListTag l = alarms(os);
            if (AppUi.in(x, y, 8, 72, 164, 24) && l.size() < PhoneData.MAX_ALARMS) {
                os.input(os.t("Время ЧЧММ", "Time HHMM"), "", 4, 1, t -> {
                    if (t.length() != 4) return;
                    int h = Integer.parseInt(t.substring(0, 2)), m = Integer.parseInt(t.substring(2));
                    if (h > 23 || m > 59) return;
                    ListTag n = alarms(os);
                    CompoundTag c = new CompoundTag();
                    c.putInt("m", h * 60 + m); c.putBoolean("on", true);
                    n.add(c);
                    PhoneData.put(os.stack(), "Alarms", n);
                });
                return true;
            }
            int i = (y - 102) / 40;
            if (y >= 102 && i < l.size()) {
                if (x >= 150) { l.remove(i); PhoneData.put(os.stack(), "Alarms", l); }
                else if (x >= 106) { CompoundTag c = l.getCompound(i); c.putBoolean("on", !c.getBoolean("on")); PhoneData.put(os.stack(), "Alarms", l); }
            }
        } else if (st.tab == 2) {
            if (AppUi.in(x, y, 14, 180, 74, 32)) { st.swRun = false; st.swAcc = 0; }
            else if (AppUi.in(x, y, 92, 180, 74, 32)) {
                if (st.swRun) { st.swAcc += os.now() - st.swStart; st.swRun = false; }
                else { st.swStart = os.now(); st.swRun = true; }
            }
        } else if (st.tab == 3) {
            for (int i = 0; i < PRESETS.length; i++) if (AppUi.in(x, y, 8 + i * 42, 160, 38, 26) && st.timerEnd == 0) st.timerSet = i;
            if (AppUi.in(x, y, 30, 200, 120, 32)) st.timerEnd = st.timerEnd > 0 ? 0 : os.now() + PRESETS[st.timerSet] * 1200L;
        }
        return true;
    }
}
