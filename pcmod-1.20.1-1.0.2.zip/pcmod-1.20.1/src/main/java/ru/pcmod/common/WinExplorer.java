package ru.pcmod.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Проводник: папки и файлы накопителя, переход по пути, создание, копирование, перемещение, переименование, удаление. */
public final class WinExplorer implements WinApp {
    private static final int TOOL = 17, ADDR = 18, NAV = 78, HEAD = 11, IH = 12, STAT = 13, TOP = TOOL + ADDR;
    private static final String[] TB = {"Создать", "Копир.", "Вырез.", "Встав.", "Переим.", "Удалить"};
    private static final int[] TB_ID = {10, 2, 3, 6, 4, 5};
    private final WinSoft s;
    private final WinFs fs;
    private final List<String> names = new ArrayList<String>();
    private final List<String> back = new ArrayList<String>();
    private final WinUi.Field rf = new WinUi.Field(0, 0, 10), pf = new WinUi.Field(0, 0, 10);
    private String dir, note = "";
    private int sel = -1, scroll, ren = -1, hover = -2, aw = 260, ah = 137, prompt;
    private boolean editPath, renFresh;
    private long now, lastAt;
    private int lastIdx = -1;
    private WinPopup menu;

    public WinExplorer(WinSoft s, String arg) {
        this.s = s;
        this.fs = s.fs;
        rf.h = IH;
        rf.max = 40;
        pf.h = 14;
        pf.max = 80;
        String start = arg.isEmpty() ? fs.home() : arg;
        dir = fs.isDir(start) ? start : fs.isFile(start) ? WinFs.parent(start) : "/";
        reload();
    }

    @Override public String title() { return (dir.equals("/") ? "Диск (C:)" : WinFs.name(dir)) + " - Проводник"; }

    @Override public String id() { return "explorer"; }

    @Override public int minW() { return 200; }

    @Override public int minH() { return 100; }

    // ------------------------------------------------------------------ состояние
    private void reload() {
        names.clear();
        List<String> d = new ArrayList<String>(), f = new ArrayList<String>();
        for (String n : fs.list(dir)) (n.endsWith("/") ? d : f).add(n);
        Collections.sort(d, String.CASE_INSENSITIVE_ORDER);
        Collections.sort(f, String.CASE_INSENSITIVE_ORDER);
        names.addAll(d);
        names.addAll(f);
        sel = Math.min(sel, names.size() - 1);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, names.size() - rows())));
        ren = -1;
    }

    private int rows() { return Math.max(1, (ah - TOP - HEAD - STAT) / IH); }

    private static String bare(String n) { return n.endsWith("/") ? n.substring(0, n.length() - 1) : n; }

    private String pathOf(int i) { return WinFs.join(dir, bare(names.get(i))); }

    private void go(String p) {
        if (!fs.isDir(p) || p.equals(dir)) return;
        back.add(dir);
        if (back.size() > 20) back.remove(0);
        dir = p;
        sel = -1;
        scroll = 0;
        note = "";
        editPath = false;
        reload();
    }

    private void goBack() {
        if (back.isEmpty()) return;
        dir = back.remove(back.size() - 1);
        sel = -1;
        scroll = 0;
        note = "";
        reload();
    }

    private void showSel() {
        if (sel < scroll) scroll = sel;
        else if (sel >= scroll + rows()) scroll = sel - rows() + 1;
        scroll = Math.max(0, scroll);
    }

    private void open(int i) {
        if (i < 0 || i >= names.size()) return;
        if (names.get(i).endsWith("/")) {
            go(pathOf(i));
        } else {
            String path = pathOf(i);
            String t = fs.read(path);
            if (t == null) note = "Этот файл нельзя открыть";
            else if (WinFs.ext(WinFs.name(path)).equals("exe")) s.openFile(path); // установщик: размер на диске больше длины текста
            else if (fs.size(path) != t.length()) note = "Этот файл нельзя открыть";
            else s.openFile(path);
        }
    }

    private void create(int kind) {
        String n;
        boolean ok;
        if (kind == 10) {
            n = fs.unique(dir, "Новая папка", "");
            ok = fs.mkdir(WinFs.join(dir, n));
        } else if (kind == 11) {
            n = fs.unique(dir, "Новый текстовый документ", "txt");
            ok = fs.write(WinFs.join(dir, n), "");
        } else {
            n = fs.unique(dir, "Новый рисунок", "pnt");
            ok = fs.write(WinFs.join(dir, n), "");
        }
        if (!ok) {
            note = "Не удалось создать: нет места";
            return;
        }
        reload();
        for (int i = 0; i < names.size(); i++) if (bare(names.get(i)).equals(n)) sel = i;
        showSel();
        startRename();
    }

    private void startRename() {
        if (sel < 0) return;
        if (fs.locked(pathOf(sel))) {
            note = "Системную папку нельзя переименовать";
            return;
        }
        ren = sel;
        rf.sb.setLength(0);
        rf.sb.append(bare(names.get(sel)));
        renFresh = true;
    }

    private void commitRename() {
        if (ren < 0) return;
        String old = bare(names.get(ren)), nn = rf.sb.toString().trim();
        int i = ren;
        ren = -1;
        if (nn.isEmpty() || nn.equals(old)) return;
        if (nn.indexOf('/') >= 0 || nn.indexOf('\\') >= 0 || fs.isFile(WinFs.join(dir, nn)) || fs.isDir(WinFs.join(dir, nn))) {
            note = "Такое имя уже есть или недопустимо";
            return;
        }
        if (!fs.move(WinFs.join(dir, old), WinFs.join(dir, nn))) note = "Не удалось переименовать";
        reload();
        for (int k = 0; k < names.size(); k++) if (bare(names.get(k)).equals(nn)) sel = k;
        if (i < 0) sel = -1;
    }

    private void copySel(boolean cut) {
        if (sel < 0) return;
        if (cut && fs.locked(pathOf(sel))) {
            note = "Системную папку нельзя переместить";
            return;
        }
        s.clipFiles.clear();
        s.clipFiles.add(pathOf(sel));
        s.clipCut = cut;
        note = cut ? "Вырезано" : "Скопировано";
    }

    private void paste() {
        if (s.clipFiles.isEmpty()) return;
        boolean ok = true;
        for (String src : new ArrayList<String>(s.clipFiles)) {
            String nm = WinFs.name(src), base = nm, ext = "";
            boolean dirSrc = fs.isDir(src);
            if (!dirSrc && WinFs.ext(nm).length() > 0) {
                ext = WinFs.ext(nm);
                base = nm.substring(0, nm.length() - ext.length() - 1);
            }
            if (!fs.isFile(src) && !dirSrc) {
                ok = false;
                continue;
            }
            String dst = WinFs.join(dir, nm);
            if (s.clipCut && WinFs.parent(src).equals(dir)) continue;
            if (fs.isFile(dst) || fs.isDir(dst)) dst = WinFs.join(dir, fs.unique(dir, base + " - копия", ext));
            ok &= s.clipCut ? fs.move(src, dst) : fs.copy(src, dst);
        }
        if (s.clipCut) s.clipFiles.clear();
        note = ok ? "" : "Не всё удалось вставить (нет места или файл нельзя скопировать)";
        reload();
    }

    private void delete() {
        if (sel < 0) return;
        String p = pathOf(sel);
        if (fs.locked(p)) note = "Системную папку нельзя удалить";
        else if (!fs.removeAll(p)) note = "Не удалось удалить";
        else note = "";
        reload();
    }

    private void act(int id, int target) {
        if (target >= 0) sel = target;
        switch (id) {
            case 1: open(sel); break;
            case 2: copySel(false); break;
            case 3: copySel(true); break;
            case 4: startRename(); break;
            case 5: if (sel >= 0) prompt = 1; break;
            case 6: paste(); break;
            case 7: reload(); break;
            case 10: case 11: case 12: create(id); break;
            default: break;
        }
    }

    private boolean enabled(int id) {
        if (id == 6) return !s.clipFiles.isEmpty();
        return id == 10 || sel >= 0;
    }

    private int[] tbBox(int i) {
        int x = 3;
        for (int k = 0; k < i; k++) x += PixelScreen.textWidth(TB[k]) + 9;
        return new int[] {x, 1, PixelScreen.textWidth(TB[i]) + 8, TOOL - 3};
    }

    private String[][] nav() {
        String h = fs.home();
        return new String[][] {{"Раб. стол", h + "/Desktop"}, {"Документы", h + "/Documents"}, {"Загрузки", h + "/Downloads"},
                {"Рисунки", h + "/Pictures"}, {"Диск (C:)", "/"}};
    }

    // ------------------------------------------------------------------ рисование
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        for (int i = 0; i < TB.length; i++) {
            int[] b = tbBox(i);
            boolean en = enabled(TB_ID[i]);
            if (en && hover == i) p.roundRect(x + b[0], y + b[1], b[2], b[3], 3, th.hover());
            p.drawTextCentered(x + b[0], b[2], y + b[1] + (b[3] - PixelFont.H) / 2, TB[i], en ? th.text() : PixelScreen.alpha(th.sub(), 0x80), 1, false);
        }
        p.hline(x, y + TOOL - 1, w, th.border());
        WinSoft.flat(p, th, x + 3, y + TOOL + 2, 14, 14, "<", hover == 20 && !back.isEmpty(), false);
        WinSoft.flat(p, th, x + 19, y + TOOL + 2, 14, 14, "^", hover == 21 && !dir.equals("/"), false);
        int bx = x + 36, bw = w - 40;
        if (editPath) {
            pf.x = bx;
            pf.y = y + TOOL + 2;
            pf.w = bw;
            pf.draw(p, th, true, now);
        } else {
            p.roundRectBorder(bx, y + TOOL + 2, bw, 14, 4, th.surface(), th.border());
            p.drawText(bx + 6, y + TOOL + 5, PixelScreen.fit(WinFs.show(dir), bw - 12, 1, false), th.text());
        }
        // навигация
        String[][] nv = nav();
        for (int i = 0; i < nv.length; i++) {
            int ny = y + TOP + 4 + i * 15;
            boolean cur = nv[i][1].equals(dir);
            if (cur) {
                p.roundRect(x + 3, ny, NAV - 6, 13, 3, th.dark ? 0xFF383838 : 0xFFE6E6E6);
                p.roundRect(x + 3, ny + 3, 2, 7, 1, th.accent());
            } else if (hover == 30 + i) {
                p.roundRect(x + 3, ny, NAV - 6, 13, 3, th.hover());
            }
            WinSoft.fileIcon(p, "", true, x + 7, ny + 1);
            p.drawText(x + 21, ny + 2, PixelScreen.fit(nv[i][0], NAV - 25, 1, false), th.text());
        }
        // список
        int lx = x + NAV, lw = w - NAV, ly = y + TOP;
        p.vline(lx, ly, h - TOP - STAT, th.border());
        p.fillRect(lx + 1, ly, lw - 1, h - TOP - STAT, th.surface());
        p.drawText(lx + 21, ly + 2, "Имя", th.sub());
        p.drawTextRight(x + w - 10, ly + 2, "Размер", th.sub(), 1, false);
        p.hline(lx + 1, ly + HEAD - 1, lw - 1, th.border());
        p.pushClip(lx + 1, ly + HEAD, lw - 1, h - TOP - STAT - HEAD);
        for (int i = 0; i < rows() && scroll + i < names.size(); i++) {
            int idx = scroll + i, ry = ly + HEAD + i * IH;
            String n = names.get(idx);
            boolean d = n.endsWith("/");
            if (idx == sel) p.roundRect(lx + 3, ry, lw - 9, IH - 1, 2, PixelScreen.alpha(th.accent(), 0x48));
            else if (hover == 100 + idx) p.roundRect(lx + 3, ry, lw - 9, IH - 1, 2, th.hover());
            WinSoft.fileIcon(p, n, d, lx + 6, ry - 1);
            if (idx == ren) {
                rf.x = lx + 19;
                rf.y = ry - 1;
                rf.w = lw - 80;
                rf.draw(p, th, true, now);
            } else {
                p.drawText(lx + 21, ry + 1, PixelScreen.fit(bare(n), lw - 78, 1, false), th.text());
            }
            if (!d) p.drawTextRight(x + w - 10, ry + 1, WinSoft.sizeText(fs.size(WinFs.join(dir, n))), th.sub(), 1, false);
        }
        p.popClip();
        if (names.isEmpty()) p.drawTextCentered(lx, lw, ly + 40, "Эта папка пуста", th.sub(), 1, false);
        WinSoft.scrollbar(p, th, x + w - 5, ly + HEAD + 1, h - TOP - STAT - HEAD - 2, names.size(), rows(), scroll);
        // строка состояния
        int sy = y + h - STAT;
        p.fillRect(x, sy, w, STAT, th.bg());
        p.hline(x, sy, w, th.border());
        if (prompt == 1 && sel >= 0) {
            p.drawText(x + 6, sy + 3, PixelScreen.fit("Удалить «" + bare(names.get(sel)) + "»?", w - 90, 1, false), th.text());
            WinUi.Button yes = new WinUi.Button("Да", x + w - 78, sy + 1, 36, true);
            yes.h = 11;
            yes.hover = hover == 40;
            yes.draw(p, th);
            WinUi.Button no = new WinUi.Button("Нет", x + w - 39, sy + 1, 36, false);
            no.h = 11;
            no.hover = hover == 41;
            no.draw(p, th);
        } else {
            String st = !note.isEmpty() ? note : names.size() + " эл." + (sel >= 0 ? "  |  " + bare(names.get(sel)) : "");
            p.drawText(x + 6, sy + 3, PixelScreen.fit(st, w - 100, 1, false), note.isEmpty() ? th.sub() : th.warn());
            p.drawTextRight(x + w - 6, sy + 3, "Свободно: " + WinSoft.bytesText(fs.free()), th.sub(), 1, false);
        }
        if (menu != null) menu.draw(p, th, x, y, s.perf.effects);
    }

    // ------------------------------------------------------------------ ввод
    @Override
    public boolean tick(long t) {
        boolean b = (editPath || ren >= 0) && (now / 10) % 2 != (t / 10) % 2;
        now = t;
        return b;
    }

    @Override
    public boolean key(char c, int key) {
        if (menu != null && menu.open()) {
            if (key == WinSoft.K_ESC) menu.close();
            return true;
        }
        if (prompt == 1) {
            if (key == WinSoft.K_ESC) prompt = 0;
            else if (WinUi.isEnter(c, key)) {
                prompt = 0;
                delete();
            }
            return true;
        }
        if (ren >= 0) {
            if (key == WinSoft.K_ESC) {
                ren = -1;
                return true;
            }
            boolean bs = key == WinUi.K_BACK || c == '\b';
            if (renFresh && (bs || c >= 32)) rf.sb.setLength(0);
            renFresh = false;
            if (bs && rf.sb.length() == 0) return true;
            if (rf.key(c, key)) commitRename();
            return true;
        }
        if (editPath) {
            if (key == WinSoft.K_ESC) editPath = false;
            else if (pf.key(c, key)) {
                editPath = false;
                String p = WinFs.parse(dir, pf.sb.toString());
                if (fs.isDir(p)) go(p);
                else note = "Путь не найден";
            }
            return true;
        }
        note = "";
        if (key == WinSoft.K_UP) sel = Math.max(0, sel < 0 ? names.size() - 1 : sel - 1);
        else if (key == WinSoft.K_DOWN) sel = Math.min(names.size() - 1, sel + 1);
        else if (key == WinSoft.K_HOME) sel = names.isEmpty() ? -1 : 0;
        else if (key == WinSoft.K_END) sel = names.size() - 1;
        else if (key == WinSoft.K_PGUP) sel = Math.max(0, sel - rows());
        else if (key == WinSoft.K_PGDN) sel = Math.min(names.size() - 1, sel + rows());
        else if (WinUi.isEnter(c, key)) {
            open(sel);
            return true;
        } else if (key == WinUi.K_BACK || c == '\b') {
            if (!dir.equals("/")) go(WinFs.parent(dir));
            return true;
        } else if (key == WinSoft.K_DEL) {
            act(5, -1);
            return true;
        } else if (key == WinSoft.K_F2) {
            startRename();
            return true;
        } else if (key == WinSoft.K_F5) {
            reload();
            return true;
        } else {
            return false;
        }
        showSel();
        return true;
    }

    private int hit(int rx, int ry) {
        if (ry < 0 || rx < 0) return -2;
        if (ry < TOOL) {
            for (int i = 0; i < TB.length; i++) {
                int[] b = tbBox(i);
                if (WinSoft.in(rx, ry, b[0], b[1], b[2], b[3])) return i;
            }
            return -1;
        }
        if (ry < TOP) {
            if (WinSoft.in(rx, ry, 3, TOOL + 2, 14, 14)) return 20;
            if (WinSoft.in(rx, ry, 19, TOOL + 2, 14, 14)) return 21;
            if (WinSoft.in(rx, ry, 36, TOOL + 2, aw - 40, 14)) return 22;
            return -1;
        }
        if (ry >= ah - STAT) {
            if (prompt == 1 && WinSoft.in(rx, ry, aw - 78, ah - STAT + 1, 36, 11)) return 40;
            if (prompt == 1 && WinSoft.in(rx, ry, aw - 39, ah - STAT + 1, 36, 11)) return 41;
            return -1;
        }
        if (rx < NAV) {
            for (int i = 0; i < 5; i++) if (WinSoft.in(rx, ry, 3, TOP + 4 + i * 15, NAV - 6, 13)) return 30 + i;
            return -1;
        }
        int i = scroll + (ry - TOP - HEAD) / IH;
        if (ry >= TOP + HEAD && i < names.size()) return 100 + i;
        return 99;
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        boolean dirty = false;
        int hv = hit(rx, ry);
        if (menu != null && menu.open()) {
            if (kind == PixelScreen.MOUSE_PRESS) {
                int id = menu.press(rx, ry);
                if (id >= 0) act(id, menuTarget);
                return true;
            }
            return menu.move(rx, ry);
        }
        if (hv != hover) {
            hover = hv;
            dirty = true;
        }
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            int ns = Math.max(0, Math.min(Math.max(0, names.size() - rows()), scroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -3 : 3)));
            if (ns == scroll) return dirty;
            scroll = ns;
            return true;
        }
        if (kind != PixelScreen.MOUSE_PRESS) return dirty;
        if (ren >= 0) commitRename();
        if (editPath && hv != 22) editPath = false;
        if (prompt == 1) {
            if (btn == 0 && hv == 40) delete();
            if (btn == 0 && (hv == 40 || hv == 41)) prompt = 0;
            return true;
        }
        note = "";
        if (btn == 1 && hv >= 99) {
            menuTarget = hv >= 100 ? hv - 100 : -1;
            if (menuTarget >= 0) sel = menuTarget;
            else sel = -1;
            menu = menuTarget >= 0
                    ? new WinPopup(new String[] {"Открыть", "Копировать", "Вырезать", "Переименовать", "Удалить"}, new int[] {1, 2, 3, 4, 5})
                    : new WinPopup(new String[] {"Создать папку", "Создать текст. файл", "Создать рисунок", "Вставить", "Обновить"}, new int[] {10, 11, 12, 6, 7});
            menu.openAt(rx, ry, aw, ah);
            return true;
        }
        if (btn != 0) return dirty;
        if (hv >= 0 && hv < TB.length) {
            int id = TB_ID[hv];
            if (!enabled(id)) return true;
            if (id == 10) {
                int[] b = tbBox(hv);
                menuTarget = -1;
                menu = new WinPopup(new String[] {"Папку", "Текстовый документ", "Рисунок Paint"}, new int[] {10, 11, 12});
                menu.openAt(b[0], TOOL, aw, ah);
            } else {
                act(id, -1);
            }
        } else if (hv == 20) {
            goBack();
        } else if (hv == 21) {
            go(WinFs.parent(dir));
        } else if (hv == 22) {
            editPath = true;
            pf.sb.setLength(0);
            pf.sb.append(WinFs.show(dir));
        } else if (hv >= 30 && hv < 35) {
            go(nav()[hv - 30][1]);
        } else if (hv >= 100) {
            int i = hv - 100;
            boolean dbl = i == lastIdx && now - lastAt <= 9;
            sel = i;
            lastIdx = i;
            lastAt = now;
            if (dbl) {
                lastIdx = -1;
                open(i);
            }
        } else if (hv == 99) {
            sel = -1;
            lastIdx = -1;
        }
        return true;
    }

    private int menuTarget = -1;
}
