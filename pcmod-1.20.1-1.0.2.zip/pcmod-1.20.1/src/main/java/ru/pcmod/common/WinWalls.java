package ru.pcmod.common;

/** Обои WinCraft 11: шесть картинок, каждая в светлом и тёмном варианте. Считаются один раз (кэш в WinGfx). */
final class WinWalls {
    private WinWalls() {}

    static final String[] NAMES = {"Bloom", "Волны", "Закат", "Горы", "Звёзды", "Графит"};
    static final int COUNT = NAMES.length;
    private static final int W = PixelScreen.W, H = PixelScreen.H;

    static int[] gen(int idx, boolean dark) {
        switch (idx) {
            case 1: return waves(dark);
            case 2: return sunset(dark);
            case 3: return mountains(dark);
            case 4: return stars(dark);
            case 5: return graphite(dark);
            default: return WinGfx.genWall(dark);
        }
    }

    private static int mix(int a, int b, float t) {
        return PixelScreen.lerp(a, b, Math.max(0f, Math.min(1f, t))) | 0xFF000000;
    }

    private static float hash(int x, int y, int s) {
        int h = x * 374761393 + y * 668265263 + s * 1274126177;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535f;
    }

    /** Гладкий одномерный шум 0..1. */
    private static float noise(float x, int s) {
        int i = (int) Math.floor(x);
        float f = x - i;
        f = f * f * (3 - 2 * f);
        return hash(i, 0, s) * (1 - f) + hash(i + 1, 0, s) * f;
    }

    private static float fbm(float x, int s) {
        float v = 0, a = 0.5f, sum = 0;
        for (int o = 0; o < 4; o++) {
            v += noise(x, s + o) * a;
            sum += a;
            x *= 2.1f;
            a *= 0.5f;
        }
        return v / sum;
    }

    // ------------------------------------------------------------------ Волны
    private static int[] waves(boolean dark) {
        int[] o = new int[W * H];
        int c1 = dark ? 0xFF0A0A28 : 0xFFDDE9FB, c2 = dark ? 0xFF3A1B6E : 0xFFA9C8F5;
        int[] cols = dark ? new int[] {0xFF5B2BD6, 0xFF2D7BE8, 0xFF22C3E6, 0xFF7AE8D4}
                : new int[] {0xFF7C5CF0, 0xFF3C8DF2, 0xFF35B7E0, 0xFF8FE3CF};
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int c = mix(c1, c2, x / (float) W * 0.5f + y / (float) H * 0.5f);
                for (int k = 0; k < 4; k++) {
                    double yy = H * (0.30 + 0.17 * k) + Math.sin(x * 0.020 + k * 1.7) * 11 + Math.sin(x * 0.047 + k * 0.9) * 5;
                    double d = y - yy;
                    if (d < 0) continue;
                    c = mix(c, cols[k], (float) (Math.min(1.0, d / 3.0) * (0.22 + 0.12 * k)));
                    if (d < 1.5) c = mix(c, 0xFFFFFFFF, 0.22f);
                }
                o[y * W + x] = c;
            }
        }
        return o;
    }

    // ------------------------------------------------------------------ Закат
    private static int[] sunset(boolean dark) {
        int[] o = new int[W * H];
        int hz = (int) (H * 0.62);
        int[] stops = {0xFF1B2A6B, 0xFF7B3F98, 0xFFF0707A, 0xFFFFC067};
        double sx = W * 0.68, sy = hz - 4;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int c;
                if (y < hz) {
                    float t = y / (float) hz * 3f;
                    int k = Math.min(2, (int) t);
                    c = mix(stops[k], stops[k + 1], t - k);
                } else {
                    float t = (y - hz) / (float) (H - hz);
                    c = mix(0xFFB04E7A, 0xFF14204A, Math.min(1f, t * 1.4f));
                    double sp = 10 + 22 * t;
                    double a = Math.exp(-(x - sx) * (x - sx) / (2 * sp * sp)) * (0.5 + 0.5 * Math.sin(y * 1.6 + x * 0.05)) * (0.65 - 0.3 * t);
                    c = mix(c, 0xFFFFD27A, (float) a);
                }
                double dx = x - sx, dy = y - sy, d2 = dx * dx + dy * dy;
                if (y < hz + 1) {
                    c = mix(c, 0xFFFFD27A, (float) (Math.exp(-d2 / (2 * 38.0 * 38.0)) * 0.6));
                    if (d2 < 17 * 17) c = 0xFFFFE9A8;
                }
                c = dark ? mix(c, 0xFF05060F, 0.38f) : mix(c, 0xFFFFFFFF, 0.10f);
                o[y * W + x] = c;
            }
        }
        return o;
    }

    // ------------------------------------------------------------------ Горы
    private static int[] mountains(boolean dark) {
        int[] o = new int[W * H];
        int top = dark ? 0xFF0B1230 : 0xFF4D7CC9, low = dark ? 0xFF2B3E7A : 0xFFCFE3F7;
        int[] lay = dark ? new int[] {0xFF1E2B57, 0xFF141E40, 0xFF0B1230} : new int[] {0xFF9FB6D8, 0xFF6F8DB8, 0xFF3D5A87};
        double[] base = {H * 0.55, H * 0.68, H * 0.80}, amp = {34, 28, 22}, sc = {0.012, 0.02, 0.035};
        double mx = W * 0.25, my = H * 0.28;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int c = mix(top, low, y / (H * 0.7f));
                double dx = x - mx, dy = y - my, d2 = dx * dx + dy * dy;
                c = mix(c, dark ? 0xFFDDE6FF : 0xFFFFF2C4, (float) (Math.exp(-d2 / (2 * 20.0 * 20.0)) * 0.45));
                if (d2 < 9 * 9) c = dark ? 0xFFF4F7FF : 0xFFFFF6D6;
                for (int k = 0; k < 3; k++) {
                    double ridge = base[k] - amp[k] * fbm((float) (x * sc[k] * 10 + k * 37), 11 + k);
                    if (y >= ridge) {
                        float haze = (float) Math.max(0, 0.28 * (1 - (y - ridge) / 40.0));
                        c = mix(lay[k], low, haze);
                    }
                }
                o[y * W + x] = c;
            }
        }
        return o;
    }

    // ------------------------------------------------------------------ Звёзды
    private static int[] stars(boolean dark) {
        int[] o = new int[W * H];
        int top = dark ? 0xFF02030D : 0xFF9DB7E8, bot = dark ? 0xFF0E1B4D : 0xFFE6EEFB;
        float dens = dark ? 0.0035f : 0.0006f;
        double mx = W * 0.78, my = H * 0.25;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int c = mix(top, bot, y / (float) H);
                double gx = x - W * 0.5, gy = y - H * 1.1;
                c = mix(c, dark ? 0xFF2B4FB0 : 0xFFFFFFFF, (float) (Math.exp(-(gx * gx + gy * gy) / (2 * 90.0 * 90.0)) * (dark ? 0.45 : 0.3)));
                o[y * W + x] = c;
            }
        }
        for (int y = 1; y < H - 1; y++) {
            for (int x = 1; x < W - 1; x++) {
                float h = hash(x, y, 1);
                if (h >= dens) continue;
                float b = hash(x, y, 2);
                b = b * b * b;
                int sc = mix(o[y * W + x], 0xFFFFFFFF, 0.4f + 0.6f * b);
                o[y * W + x] = sc;
                if (h < dens * 0.1f) {
                    o[y * W + x - 1] = mix(o[y * W + x - 1], 0xFFFFFFFF, 0.5f);
                    o[y * W + x + 1] = mix(o[y * W + x + 1], 0xFFFFFFFF, 0.5f);
                    o[(y - 1) * W + x] = mix(o[(y - 1) * W + x], 0xFFFFFFFF, 0.5f);
                    o[(y + 1) * W + x] = mix(o[(y + 1) * W + x], 0xFFFFFFFF, 0.5f);
                }
            }
        }
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                double dx = x - mx, dy = y - my, d2 = dx * dx + dy * dy;
                int c = mix(o[y * W + x], dark ? 0xFFBFD4FF : 0xFFFFFFFF, (float) (Math.exp(-d2 / (2 * 26.0 * 26.0)) * 0.35));
                double ex = x - (mx + 5), ey = y - (my - 3);
                if (d2 < 12 * 12 && ex * ex + ey * ey >= 11 * 11) c = dark ? 0xFFF4F7FF : 0xFFFFFBEA;
                o[y * W + x] = c;
            }
        }
        return o;
    }

    // ------------------------------------------------------------------ Графит
    private static int[] graphite(boolean dark) {
        int[] o = new int[W * H];
        int a = dark ? 0xFF111418 : 0xFFEDEFF3, b = dark ? 0xFF2A3038 : 0xFFCDD3DC;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int c = mix(a, b, (x / (float) W + y / (float) H) * 0.5f);
                double dx = x - W * 0.5, dy = y - H * 0.5;
                c = mix(c, dark ? 0xFF3A424D : 0xFFFFFFFF, (float) (Math.exp(-(dx * dx + dy * dy) / (2 * 80.0 * 80.0)) * 0.35));
                double band = Math.abs(x - y * 1.2 - 40);
                if (band < 30) c = mix(c, 0xFFFFFFFF, (float) ((1 - band / 30) * 0.06));
                o[y * W + x] = c;
            }
        }
        return o;
    }
}
