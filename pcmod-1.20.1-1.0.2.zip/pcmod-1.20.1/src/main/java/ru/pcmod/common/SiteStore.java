package ru.pcmod.common;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Сайты игроков: домены, владельцы (UUID), страницы разметки. Живут в сохранении мира, отдаются через SiteHost
 * только когда есть сеть и исправный TileServer. Регистрация и продление - за консы с общего банковского счёта.
 * Все проверки (владелец, лимиты, чёрный список) выполняются здесь, на сервере.
 */
public class SiteStore extends SavedData {
    public static final String ID = "pcmod_sites";
    private static final Logger LOG = LogManager.getLogger("pcmod");
    static final int AUDIT_MAX = 300;
    static final long DAY = 24000L;

    /** Сайт в хранилище. */
    public static final class Site {
        public String domain = "", owner = "", ownerName = "", title = "", tags = "", banReason = "";
        public boolean banned;
        /** Игровые сутки: создан, действует по (включительно). */
        public long created, expires;
        public final Map<String, String> pages = new LinkedHashMap<String, String>();
        /** Счётчик посетителей: число засчитанных визитов и последние сутки визита по UUID (антинакрутка: один визит в сутки). */
        public int visits;
        public final Map<String, Long> visitDay = new LinkedHashMap<String, Long>();
        /** Оценки 1-5 по UUID (один голос на игрока) и жалобы (UUID -> причина). */
        public final Map<String, Integer> votes = new LinkedHashMap<String, Integer>();
        public final Map<String, String> reports = new LinkedHashMap<String, String>();
        /** Купившие доступ к платным страницам: "uuid|страница". */
        public final Set<String> paid = new LinkedHashSet<String>();
        public final List<Guest> guests = new ArrayList<Guest>();
        public int nextGuest = 1;

        public int bytes() {
            int n = 0;
            for (String s : pages.values()) n += s.getBytes(StandardCharsets.UTF_8).length;
            return n;
        }
    }

    /** Запись гостевой книги; пока approved == false видна только владельцу и автору. */
    public static final class Guest {
        public int id;
        public String uuid = "", name = "", text = "";
        public boolean approved;
        public long day;
    }

    /** Данные для показа страницы посетителю (счётчик, рейтинг, гостевая книга, права). */
    public static final class Extra {
        public int visits, votes, rating10, price;
        public boolean owner, suspicious, paid;
        public long created;
        public String ownerName = "";
        /** Записи книги: {id, имя, текст, "ok" или "wait"}. */
        public final List<String[]> guests = new ArrayList<String[]>();
    }

    /** Строка каталога search.pc. */
    public static final class Listing {
        public final String domain, title, tags, ownerName;
        public final int rating10, votes, visits;
        public final long created;
        public final boolean suspicious;

        Listing(Site x) {
            domain = x.domain;
            title = x.title;
            tags = x.tags;
            ownerName = x.ownerName;
            votes = x.votes.size();
            int sum = 0;
            for (int v : x.votes.values()) sum += v;
            rating10 = votes == 0 ? 0 : Math.round(sum * 10f / votes);
            visits = x.visits;
            created = x.created;
            suspicious = x.reports.size() >= SiteConfig.flagReports();
        }
    }

    /** Неизменяемый снимок сайта для экранов. daysLeft < 0 - срок вышел, идёт льготный период. */
    public static final class Info {
        public final String domain, ownerName, title, tags, banReason;
        public final boolean banned;
        public final long daysLeft;
        public final int bytes;
        public final List<String> pages;

        Info(Site s, long today) {
            domain = s.domain;
            ownerName = s.ownerName;
            title = s.title;
            tags = s.tags;
            banReason = s.banReason;
            banned = s.banned;
            daysLeft = s.expires - today;
            bytes = s.bytes();
            pages = new ArrayList<String>(s.pages.keySet());
        }
    }

    private final Map<String, Site> sites = new LinkedHashMap<String, Site>();
    private final List<String> audit = new ArrayList<String>();
    private long lastPurge = Long.MIN_VALUE;

    public SiteStore() { }

    public static SiteStore load(CompoundTag tag) {
        SiteStore s = new SiteStore();
        ListTag l = tag.getList("sites", 10);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            Site x = new Site();
            x.domain = c.getString("d");
            if (SiteConfig.normalize(x.domain) == null || !SiteConfig.normalize(x.domain).equals(x.domain)) continue;
            x.owner = c.getString("o");
            x.ownerName = c.getString("on");
            x.title = c.getString("t");
            x.tags = c.getString("g");
            x.banned = c.getBoolean("ban");
            x.banReason = c.getString("br");
            x.created = c.getLong("c");
            x.expires = c.getLong("e");
            x.visits = c.getInt("v");
            x.nextGuest = Math.max(1, c.getInt("ng"));
            ListTag vl = c.getList("vd", 10);
            for (int j = 0; j < vl.size(); j++) x.visitDay.put(vl.getCompound(j).getString("u"), vl.getCompound(j).getLong("d"));
            ListTag rl = c.getList("vt", 10);
            for (int j = 0; j < rl.size(); j++) x.votes.put(rl.getCompound(j).getString("u"), Math.max(1, Math.min(5, rl.getCompound(j).getInt("n"))));
            ListTag rp = c.getList("rp", 10);
            for (int j = 0; j < rp.size(); j++) x.reports.put(rp.getCompound(j).getString("u"), rp.getCompound(j).getString("r"));
            ListTag pd = c.getList("pd", 8);
            for (int j = 0; j < pd.size(); j++) x.paid.add(pd.getString(j));
            ListTag gl = c.getList("gb", 10);
            for (int j = 0; j < gl.size(); j++) {
                CompoundTag gc = gl.getCompound(j);
                Guest g = new Guest();
                g.id = gc.getInt("i");
                g.uuid = gc.getString("u");
                g.name = gc.getString("n");
                g.text = gc.getString("t");
                g.approved = gc.getBoolean("a");
                g.day = gc.getLong("d");
                x.guests.add(g);
                x.nextGuest = Math.max(x.nextGuest, g.id + 1);
            }
            ListTag pl = c.getList("p", 10);
            for (int j = 0; j < pl.size(); j++) {
                CompoundTag pc = pl.getCompound(j);
                String n = SiteConfig.pageName(pc.getString("n"));
                if (n != null) x.pages.put(n, pc.getString("x"));
            }
            s.sites.put(x.domain, x);
        }
        ListTag a = tag.getList("audit", 8);
        for (int i = 0; i < a.size(); i++) s.audit.add(a.getString(i));
        return s;
    }

    /** Хранилище основного мира или null, если сервер ещё не запущен. */
    public static SiteStore get() {
        MinecraftServer srv = ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return null;
        ServerLevel w = srv.overworld();
        if (w == null) return null;
        return w.getDataStorage().computeIfAbsent(SiteStore::load, SiteStore::new, ID);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (Site x : sites.values()) {
            CompoundTag c = new CompoundTag();
            c.putString("d", x.domain);
            c.putString("o", x.owner);
            c.putString("on", x.ownerName);
            c.putString("t", x.title);
            c.putString("g", x.tags);
            c.putBoolean("ban", x.banned);
            c.putString("br", x.banReason);
            c.putLong("c", x.created);
            c.putLong("e", x.expires);
            c.putInt("v", x.visits);
            c.putInt("ng", x.nextGuest);
            ListTag vl = new ListTag();
            for (Map.Entry<String, Long> e : x.visitDay.entrySet()) {
                CompoundTag t = new CompoundTag();
                t.putString("u", e.getKey());
                t.putLong("d", e.getValue());
                vl.add(t);
            }
            c.put("vd", vl);
            ListTag rl = new ListTag();
            for (Map.Entry<String, Integer> e : x.votes.entrySet()) {
                CompoundTag t = new CompoundTag();
                t.putString("u", e.getKey());
                t.putInt("n", e.getValue());
                rl.add(t);
            }
            c.put("vt", rl);
            ListTag rp = new ListTag();
            for (Map.Entry<String, String> e : x.reports.entrySet()) {
                CompoundTag t = new CompoundTag();
                t.putString("u", e.getKey());
                t.putString("r", e.getValue());
                rp.add(t);
            }
            c.put("rp", rp);
            ListTag pd = new ListTag();
            for (String q : x.paid) pd.add(StringTag.valueOf(q));
            c.put("pd", pd);
            ListTag gl = new ListTag();
            for (Guest g : x.guests) {
                CompoundTag t = new CompoundTag();
                t.putInt("i", g.id);
                t.putString("u", g.uuid);
                t.putString("n", g.name);
                t.putString("t", g.text);
                t.putBoolean("a", g.approved);
                t.putLong("d", g.day);
                gl.add(t);
            }
            c.put("gb", gl);
            ListTag pl = new ListTag();
            for (Map.Entry<String, String> e : x.pages.entrySet()) {
                CompoundTag pc = new CompoundTag();
                pc.putString("n", e.getKey());
                pc.putString("x", e.getValue());
                pl.add(pc);
            }
            c.put("p", pl);
            l.add(c);
        }
        tag.put("sites", l);
        ListTag a = new ListTag();
        for (String s : audit) a.add(StringTag.valueOf(s));
        tag.put("audit", a);
        return tag;
    }

    // ===================== время, аудит, обслуживание =====================
    /** Текущие игровые сутки. */
    public static long today() {
        MinecraftServer srv = ServerLifecycleHooks.getCurrentServer();
        return srv == null || srv.overworld() == null ? 0 : srv.overworld().getGameTime() / DAY;
    }

    public void audit(String text) {
        audit.add(text);
        while (audit.size() > AUDIT_MAX) audit.remove(0);
        LOG.info("[pcsite] " + text);
        setDirty();
    }

    public List<String> auditLog() { return new ArrayList<String>(audit); }

    /** Освободить домены, у которых вышел срок и льготный период (не чаще раза в сутки). */
    public void purge() {
        long t = today();
        if (t == lastPurge) return;
        lastPurge = t;
        long g = SiteConfig.grace();
        List<String> gone = new ArrayList<String>();
        for (Site x : sites.values()) if (t > x.expires + g) gone.add(x.domain);
        for (String d : gone) {
            sites.remove(d);
            audit("expired " + d);
        }
    }

    // ===================== чтение =====================
    /** Сайт или null. Просроченный (льготный период) отдаётся только если withGrace. */
    public Site site(String domain, boolean withGrace) {
        purge();
        Site x = sites.get(domain);
        if (x == null) return null;
        if (!withGrace && today() > x.expires) return null;
        return x;
    }

    public List<Site> all() {
        purge();
        return new ArrayList<Site>(sites.values());
    }

    public int countOf(String uuid) {
        int n = 0;
        for (Site x : sites.values()) if (x.owner.equals(uuid)) n++;
        return n;
    }

    /** Сайты игрока (включая льготный период). */
    public static List<Info> mine(String uuid) {
        List<Info> r = new ArrayList<Info>();
        SiteStore s = get();
        if (s == null) return r;
        long t = today();
        for (Site x : s.all()) if (x.owner.equals(uuid)) r.add(new Info(x, t));
        return r;
    }

    // ===================== проверки =====================
    /** Товары, на которые разрешены ссылки phone: и soft: в разметке. */
    private static final Markup.Env ENV = new Markup.Env() {
        @Override public boolean phoneApp(String id) {
            SoftItem i = SoftRegistry.get(id);
            return i != null && i.type == SoftItem.Type.PHONE_APP;
        }

        @Override public boolean soft(String id) { return SoftRegistry.get(id) != null; }
    };

    /** Проверка текста страницы: размер, служебные символы, чёрный список, строгий разбор разметки (лимиты элементов, ссылки, картинки). */
    static String checkMarkup(String text, String domain) {
        if (text == null) return "Empty page";
        if (text.getBytes(StandardCharsets.UTF_8).length > SiteConfig.maxPageBytes()) return "Page is too large (max " + SiteConfig.maxPageBytes() + " bytes)";
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c < 32 && c != '\n' && c != '\t' || c == 127 || c == '￿') return "Page contains forbidden characters";
        }
        if (SiteConfig.hasBadWord(text)) return "Text contains forbidden words";
        return Markup.parse(text, domain, true, ENV, false).error;
    }

    private static String ownerCheck(Site x, String uuid) {
        if (x == null) return "No such site";
        if (!x.owner.equals(uuid)) return "This is not your site";
        return null;
    }

    private static String editCheck(Site x, String uuid) {
        String e = ownerCheck(x, uuid);
        if (e != null) return e;
        if (x.banned) return "Site is blocked";
        if (today() > x.expires) return "Domain has expired - renew it first";
        return null;
    }

    // ===================== операции игрока (Bank.Res: тексты английские, переводит WinSvcImpl.ru) =====================
    public static Bank.Res register(Player p, String raw) {
        SiteStore s = get();
        Bank b = Bank.get();
        if (s == null || b == null) return new Bank.Res(false, "Bank is unavailable");
        s.purge();
        String d = SiteConfig.normalize(raw);
        if (d == null) return new Bank.Res(false, "Bad domain (a-z, 0-9, hyphen; 3-16 chars)");
        String e = SiteConfig.checkDomain(d);
        if (e != null) return new Bank.Res(false, e);
        if (s.sites.containsKey(d)) return new Bank.Res(false, "Domain is already taken");
        String u = p.getUUID().toString();
        if (s.countOf(u) >= SiteConfig.maxSites()) return new Bank.Res(false, "Site limit reached (" + SiteConfig.maxSites() + ")");
        int price = SiteConfig.price();
        b.rename(u, p.getGameProfile().getName());
        if (b.balance(u) < price) return new Bank.Res(false, "Not enough kons (need " + Bank.fmt(price) + ")");
        if (price > 0) {
            b.setBalance(u, b.balance(u) - price);
            b.log(u, "-" + Bank.fmt(price) + " domain " + d);
        }
        Site x = new Site();
        x.domain = d;
        x.owner = u;
        x.ownerName = p.getGameProfile().getName();
        x.created = today();
        x.expires = x.created + SiteConfig.days();
        s.sites.put(d, x);
        s.audit("register " + d + " by " + x.ownerName + " " + u + " for " + price);
        return new Bank.Res(true, "Registered " + d + " for " + Bank.fmt(price));
    }

    public static Bank.Res renew(Player p, String raw) {
        SiteStore s = get();
        Bank b = Bank.get();
        if (s == null || b == null) return new Bank.Res(false, "Bank is unavailable");
        String d = SiteConfig.normalize(raw);
        String u = p.getUUID().toString();
        Site x = d == null ? null : s.site(d, true);
        String e = ownerCheck(x, u);
        if (e != null) return new Bank.Res(false, e);
        if (x.banned) return new Bank.Res(false, "Site is blocked");
        long t = today();
        long base = Math.max(x.expires, t);
        if (base + SiteConfig.days() - t > 3L * SiteConfig.days()) return new Bank.Res(false, "Cannot renew that far ahead");
        int price = SiteConfig.renewPrice();
        b.rename(u, p.getGameProfile().getName());
        if (b.balance(u) < price) return new Bank.Res(false, "Not enough kons (need " + Bank.fmt(price) + ")");
        if (price > 0) {
            b.setBalance(u, b.balance(u) - price);
            b.log(u, "-" + Bank.fmt(price) + " renew " + d);
        }
        x.expires = base + SiteConfig.days();
        s.audit("renew " + d + " by " + x.ownerName + " until day " + x.expires);
        return new Bank.Res(true, "Renewed " + d + " for " + Bank.fmt(price));
    }

    public static Bank.Res release(Player p, String raw) {
        SiteStore s = get();
        if (s == null) return new Bank.Res(false, "Bank is unavailable");
        String d = SiteConfig.normalize(raw);
        Site x = d == null ? null : s.site(d, true);
        String e = ownerCheck(x, p.getUUID().toString());
        if (e != null) return new Bank.Res(false, e);
        if (x.banned) return new Bank.Res(false, "Site is blocked");
        s.sites.remove(d);
        s.audit("release " + d + " by " + x.ownerName);
        return new Bank.Res(true, "Released " + d);
    }

    public static Bank.Res putPage(Player p, String raw, String pageRaw, String text) {
        SiteStore s = get();
        if (s == null) return new Bank.Res(false, "Bank is unavailable");
        String d = SiteConfig.normalize(raw);
        Site x = d == null ? null : s.site(d, true);
        String e = editCheck(x, p.getUUID().toString());
        if (e != null) return new Bank.Res(false, e);
        String pg = SiteConfig.pageName(pageRaw);
        if (pg == null) return new Bank.Res(false, "Bad page name (a-z, 0-9, _, -; max 24)");
        if (text == null) text = "";
        text = text.replace("\r", "");
        e = checkMarkup(text, d);
        if (e != null) return new Bank.Res(false, e);
        if (pg.equals("index") && Markup.parse(text, d, false, ENV, false).page.price > 0) return new Bank.Res(false, "The home page cannot be paid");
        String old = x.pages.get(pg);
        if (old == null && x.pages.size() >= SiteConfig.maxPages()) return new Bank.Res(false, "Too many pages (max " + SiteConfig.maxPages() + ")");
        int total = x.bytes() - (old == null ? 0 : old.getBytes(StandardCharsets.UTF_8).length) + text.getBytes(StandardCharsets.UTF_8).length;
        if (total > SiteConfig.maxTotalBytes()) return new Bank.Res(false, "Site is too large (max " + SiteConfig.maxTotalBytes() + " bytes)");
        x.pages.put(pg, text);
        s.setDirty();
        return new Bank.Res(true, "Page saved");
    }

    public static Bank.Res deletePage(Player p, String raw, String pageRaw) {
        SiteStore s = get();
        if (s == null) return new Bank.Res(false, "Bank is unavailable");
        String d = SiteConfig.normalize(raw);
        Site x = d == null ? null : s.site(d, true);
        String e = editCheck(x, p.getUUID().toString());
        if (e != null) return new Bank.Res(false, e);
        String pg = SiteConfig.pageName(pageRaw);
        if (pg == null || x.pages.remove(pg) == null) return new Bank.Res(false, "Page not found");
        s.setDirty();
        return new Bank.Res(true, "Page deleted");
    }

    /** Название и теги сайта (для каталога search.pc). */
    public static Bank.Res setMeta(Player p, String raw, String title, String tags) {
        SiteStore s = get();
        if (s == null) return new Bank.Res(false, "Bank is unavailable");
        String d = SiteConfig.normalize(raw);
        Site x = d == null ? null : s.site(d, true);
        String e = editCheck(x, p.getUUID().toString());
        if (e != null) return new Bank.Res(false, e);
        title = title == null ? "" : title.trim();
        if (title.length() > SiteConfig.MAX_TITLE) return new Bank.Res(false, "Title is too long (max " + SiteConfig.MAX_TITLE + ")");
        for (int i = 0; i < title.length(); i++) if (title.charAt(i) < 32) return new Bank.Res(false, "Page contains forbidden characters");
        List<String> tl = new ArrayList<String>();
        if (tags != null) {
            for (String t : tags.toLowerCase(Locale.ROOT).split("[\\s,;]+")) {
                if (t.isEmpty() || tl.contains(t)) continue;
                if (t.length() > SiteConfig.MAX_TAG || tl.size() >= SiteConfig.MAX_TAGS) return new Bank.Res(false, "Too many tags (max " + SiteConfig.MAX_TAGS + ", " + SiteConfig.MAX_TAG + " chars each)");
                for (int i = 0; i < t.length(); i++) {
                    char c = t.charAt(i);
                    if (!(c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '-' || c >= 'а' && c <= 'я' || c == 'ё')) return new Bank.Res(false, "Bad tag (letters, digits, hyphen)");
                }
                tl.add(t);
            }
        }
        String joined = String.join(" ", tl);
        if (SiteConfig.hasBadWord(title) || SiteConfig.hasBadWord(joined)) return new Bank.Res(false, "Text contains forbidden words");
        x.title = title;
        x.tags = joined;
        s.setDirty();
        return new Bank.Res(true, "Saved");
    }

    // ===================== операции оператора =====================
    public boolean adminDelete(String domain, String by) {
        if (sites.remove(domain) == null) return false;
        audit("delete " + domain + " by " + by);
        return true;
    }

    public boolean adminBan(String domain, boolean ban, String reason, String by) {
        Site x = sites.get(domain);
        if (x == null) return false;
        x.banned = ban;
        x.banReason = ban ? (reason == null ? "" : reason) : "";
        audit((ban ? "ban " : "unban ") + domain + " by " + by + (ban && !x.banReason.isEmpty() ? " (" + x.banReason + ")" : ""));
        return true;
    }

    // ===================== интерактив: счётчик, оценки, гостевая книга, формы, донаты, платные страницы, жалобы =====================
    static final int CAP_VISITS = 100, CAP_VOTES = 300, CAP_REPORTS = 50, CAP_PAID = 300, GB_TEXT = 80, GB_PENDING = 3;
    private static final Map<String, Long> COOL = new HashMap<String, Long>();

    /** Текущее игровое время в тиках. */
    static long ticks() {
        MinecraftServer srv = ServerLifecycleHooks.getCurrentServer();
        return srv == null || srv.overworld() == null ? 0 : srv.overworld().getGameTime();
    }

    /** Антиспам: true - действие kind игрока uuid разрешено (прошло gap тиков с прошлого такого же). */
    static boolean cool(String uuid, String kind, long gap) {
        long now = ticks();
        String k = uuid + ":" + kind;
        Long last = COOL.get(k);
        if (last != null && now - last < gap && now >= last) return false;
        if (COOL.size() > 2000) {
            long keep = now - 1200;
            COOL.values().removeIf(v -> v < keep || v > now);
            if (COOL.size() > 2000) return false;
        }
        COOL.put(k, now);
        return true;
    }

    static String clean(String t, int max) {
        if (t == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c >= 32 && c != 127 && c != '￿') b.append(c);
        }
        String r = b.toString().trim();
        return r.length() > max ? r.substring(0, max) : r;
    }

    private static boolean paidFor(Site x, String viewer, String page) { return !viewer.isEmpty() && x.paid.contains(viewer + "|" + page); }

    /** Открытие страницы посетителем: считает визит (раз в сутки на игрока, не владельца) и собирает данные для показа. */
    public Extra open(Site x, String page, String viewer) {
        String v = viewer == null ? "" : viewer;
        Extra e = new Extra();
        long t = today();
        e.owner = !v.isEmpty() && x.owner.equals(v);
        if (!e.owner && !v.isEmpty() && page.equals("index")) {
            Long d = x.visitDay.get(v);
            if (d == null || d != t) {
                x.visits++;
                x.visitDay.remove(v);
                x.visitDay.put(v, t);
                while (x.visitDay.size() > CAP_VISITS) x.visitDay.remove(x.visitDay.keySet().iterator().next());
                setDirty();
            }
        }
        e.visits = x.visits;
        e.votes = x.votes.size();
        int sum = 0;
        for (int n : x.votes.values()) sum += n;
        e.rating10 = e.votes == 0 ? 0 : Math.round(sum * 10f / e.votes);
        e.suspicious = x.reports.size() >= SiteConfig.flagReports();
        e.created = x.created;
        e.ownerName = x.ownerName;
        e.paid = paidFor(x, v, page);
        for (Guest g : x.guests) {
            if (g.approved) e.guests.add(new String[] {String.valueOf(g.id), g.name, g.text, "ok"});
            else if (e.owner || g.uuid.equals(v)) e.guests.add(new String[] {String.valueOf(g.id), g.name, g.text, "wait"});
        }
        return e;
    }

    public boolean paidAccess(Site x, String viewer, String page) { return paidFor(x, viewer == null ? "" : viewer, page); }

    private static Bank.Res fail(String m) { return new Bank.Res(false, m); }

    /**
     * Действие посетителя со страницы сайта. Цели: gb:add:домен, gb:ok:домен:id, gb:del:домен:id, form:домен:имя,
     * donate:домен, pay:домен:страница, rate:домен, report:домен. Все проверки (сайт, владелец, лимиты, антиспам, банк) - здесь.
     */
    public static Bank.Res act(Player p, TileServer srv, String target, String input) {
        try {
            return act0(p, srv, target, input);
        } catch (RuntimeException e) {
            LOG.warn("[pcsite] action failed: " + e);
            return fail("Internal error");
        }
    }

    private static Bank.Res act0(Player p, TileServer srv, String target, String input) {
        SiteStore s = get();
        Bank b = Bank.get();
        if (s == null || b == null || p == null) return fail("Bank is unavailable");
        String[] a = target == null ? new String[0] : target.split(":");
        if (a.length < 2) return fail("Bad action");
        String d = SiteConfig.normalize(a[1]);
        Site x = d == null ? null : s.site(d, false);
        if (x == null) return fail("No such site");
        if (x.banned) return fail("Site is blocked");
        String u = p.getUUID().toString(), name = p.getGameProfile().getName();
        boolean owner = x.owner.equals(u);
        String in = clean(input, 120);
        switch (a[0]) {
            case "gbadd": {
                String t = clean(in, GB_TEXT);
                if (t.isEmpty()) return fail("Empty message");
                if (SiteConfig.hasBadWord(t)) return fail("Text contains forbidden words");
                if (x.guests.size() >= SiteConfig.maxGuests()) return fail("Guestbook is full");
                int mine = 0;
                for (Guest g : x.guests) if (g.uuid.equals(u) && !g.approved) mine++;
                if (!owner && mine >= GB_PENDING) return fail("Too many entries waiting for approval");
                if (!cool(u, "gb", 600)) return fail("Too fast - wait a little");
                Guest g = new Guest();
                g.id = x.nextGuest++;
                g.uuid = u;
                g.name = name;
                g.text = t;
                g.approved = owner;
                g.day = today();
                x.guests.add(g);
                s.setDirty();
                return new Bank.Res(true, owner ? "Entry added" : "Entry sent: it will appear after the owner approves it");
            }
            case "gbok":
            case "gbdel": {
                if (!owner) return fail("This is not your site");
                int id;
                try { id = Integer.parseInt(a.length > 2 ? a[2] : ""); } catch (NumberFormatException e) { return fail("Bad action"); }
                for (Guest g : x.guests) {
                    if (g.id != id) continue;
                    if (a[0].equals("gbok")) g.approved = true;
                    else x.guests.remove(g);
                    s.setDirty();
                    return new Bank.Res(true, a[0].equals("gbok") ? "Entry approved" : "Entry deleted");
                }
                return fail("Entry not found");
            }
            case "form": {
                if (a.length < 3 || !a[2].matches("[a-z0-9_-]{1,12}")) return fail("Bad action");
                if (in.isEmpty()) return fail("Empty message");
                if (SiteConfig.hasBadWord(in)) return fail("Text contains forbidden words");
                if (!cool(u, "form", 600)) return fail("Too fast - wait a little");
                String text = "[" + a[2] + "] " + name + ": " + in;
                if (text.length() > ChatStore.MAX_TEXT) text = text.substring(0, ChatStore.MAX_TEXT);
                if (srv == null || !srv.post("@" + d.substring(0, d.length() - 3), x.ownerName.toLowerCase(Locale.ROOT), text)) return fail("Owner has no chat account");
                s.audit("form " + d + " by " + name);
                return new Bank.Res(true, "Message sent to the owner");
            }
            case "donate": {
                if (owner) return fail("You cannot pay yourself");
                long n;
                try { n = Long.parseLong(in.trim()); } catch (NumberFormatException e) { return fail("Enter an amount"); }
                if (n < 1 || n > 1000) return fail("Donation: 1-1000 kons");
                if (!cool(u, "donate", 100)) return fail("Too fast - wait a little");
                return transfer(s, b, u, name, x, n, n, "donate " + d);
            }
            case "pay": {
                if (a.length < 3) return fail("Bad action");
                String pg = SiteConfig.pageName(a[2]);
                String body = pg == null ? null : x.pages.get(pg);
                if (body == null) return fail("Page not found");
                int price = pg.equals("index") ? 0 : Markup.parse(body, d, false, ENV, false).page.price;
                if (price <= 0) return fail("This page is free");
                if (owner || paidFor(x, u, pg)) return fail("You already have access");
                if (x.paid.size() >= CAP_PAID) return fail("Page sales are closed");
                Bank.Res r = transfer(s, b, u, name, x, price, price - price * SiteConfig.fee() / 100, "page " + d + "/" + pg);
                if (r.ok) {
                    x.paid.add(u + "|" + pg);
                    s.setDirty();
                    return new Bank.Res(true, "Access bought for " + Bank.fmt(price));
                }
                return r;
            }
            case "rate": {
                if (owner) return fail("You cannot rate your own site");
                int n;
                try { n = Integer.parseInt(in.trim()); } catch (NumberFormatException e) { return fail("Rate 1-5"); }
                if (n < 1 || n > 5) return fail("Rate 1-5");
                if (!x.votes.containsKey(u) && x.votes.size() >= CAP_VOTES) return fail("Rating is closed");
                x.votes.put(u, n);
                s.setDirty();
                return new Bank.Res(true, "Thanks for your rating");
            }
            case "report": {
                if (owner) return fail("You cannot report your own site");
                String why = clean(in, 30);
                if (why.length() < 3) return fail("Describe the problem (3+ chars)");
                if (x.reports.containsKey(u)) return fail("You have already reported this site");
                if (x.reports.size() >= CAP_REPORTS) return fail("Reports saved");
                if (!cool(u, "report", 1200)) return fail("Too fast - wait a little");
                x.reports.put(u, why);
                s.audit("report " + d + " by " + name + ": " + why);
                return new Bank.Res(true, "Report sent");
            }
            default:
                return fail("Bad action");
        }
    }

    /** Перевод консов игрока владельцу сайта: списать total, зачислить toOwner (разница сгорает как комиссия). */
    private static Bank.Res transfer(SiteStore s, Bank b, String u, String name, Site x, long total, long toOwner, String why) {
        b.rename(u, name);
        if (b.balance(u) < total) return fail("Not enough kons (need " + Bank.fmt(total) + ")");
        if (b.balance(x.owner) + toOwner > Bank.MAX_BALANCE) return fail("Owner's account is full");
        b.setBalance(u, b.balance(u) - total);
        b.setBalance(x.owner, b.balance(x.owner) + toOwner);
        b.log(u, "-" + Bank.fmt(total) + " " + why);
        b.log(x.owner, "+" + Bank.fmt(toOwner) + " " + why + " from " + name);
        s.audit(why + " " + total + " (" + toOwner + " to owner) by " + name);
        return new Bank.Res(true, "Donated " + Bank.fmt(total) + " to " + x.ownerName);
    }

    // ===================== каталог search.pc =====================
    /** Сайты каталога: без заблокированных и просроченных. section: 0 - все, 1 - новые, 2 - популярные; q - поиск по адресу, названию и тегам. */
    public static List<Listing> search(String q, int section, int max) {
        List<Listing> r = new ArrayList<Listing>();
        SiteStore s = get();
        if (s == null) return r;
        String n = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        long t = today();
        for (Site x : s.all()) {
            if (x.banned || t > x.expires) continue;
            if (!n.isEmpty() && !(x.domain.contains(n) || x.title.toLowerCase(Locale.ROOT).contains(n) || (" " + x.tags + " ").contains(" " + n)
                    || x.tags.contains(n))) continue;
            r.add(new Listing(x));
        }
        if (section == 1) r.sort((p1, p2) -> Long.compare(p2.created, p1.created));
        else r.sort((p1, p2) -> Integer.compare(score(p2), score(p1)));
        return r.size() > max ? new ArrayList<Listing>(r.subList(0, max)) : r;
    }

    /** Популярность: визиты и оценки (оценка весит больше), жалобы вычитаются. */
    private static int score(Listing l) { return l.visits + l.rating10 * l.votes - (l.suspicious ? 1000 : 0); }

    // ===================== жалобы (оператор) =====================
    public int reportCount(String domain) {
        Site x = sites.get(domain);
        return x == null ? 0 : x.reports.size();
    }

    public boolean adminClearReports(String domain, String by) {
        Site x = sites.get(domain);
        if (x == null) return false;
        x.reports.clear();
        audit("clear reports " + domain + " by " + by);
        return true;
    }
}
