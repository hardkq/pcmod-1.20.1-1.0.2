package ru.pcmod.common;

import net.minecraft.world.item.Item;

/**
 * Антенна — простой предмет для башен сотовой связи.
 * Крафт: золотой слиток + 2x палочка (3x3 shaped) — см. antenna.json.
 */
public class ItemAntenna extends Item {

    public ItemAntenna(Item.Properties props) {
        super(props);
    }
}
