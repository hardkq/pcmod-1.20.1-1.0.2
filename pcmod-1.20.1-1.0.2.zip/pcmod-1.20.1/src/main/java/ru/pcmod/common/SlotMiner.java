package ru.pcmod.common;

import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Слот блока-контейнера (ферма, стол сборки телефонов): принимает только то, что разрешает Container.canPlaceItem. */
public class SlotMiner extends Slot {
    private final Container tile;

    public SlotMiner(Container t, int index, int x, int y) {
        super(t, index, x, y);
        this.tile = t;
    }

    @Override
    public boolean mayPlace(ItemStack s) {
        return tile.canPlaceItem(getSlotIndex(), s);
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }
}
