package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Блокнот: текст с выделением мышью, перенос строк, буфер обмена, открытие и сохранение файлов накопителя. */
public final class WinNotepad implements WinApp {
    private static final int BAR = 14, STAT = 12, LH = 10, PAD = 4;
    private static final int M_FILE = 0, M_EDIT = 1, M_VIEW = 2;
    private static final int[] BX = {4, 36, 80}, BW = {30, 42, 28};
    private final WinSoft s;
    private final StringBuilder sb = new StringBuilder();
    private final List<int[]> vl = new ArrayList<int[]>();
    private String path = "", note = "";
    private boolean mod, wrap, drag;
    private int cur, anc = -1, scroll, scrollX, wantX = -1, lw = -1, ver, lver = -1, aw = 218, ah = 129, hover = -1, prompt;
    private long now;
    private WinPopup menu;
    private WinFileDialog dlg;
    private Runnable after;
    /** Папка по умолчанию для «Открыть» и «Сохранить как» (пусто - Документы). Нужна встроенному использованию. */
    private String startDir = "";

    public WinNotepad(WinSoft s, String arg) {
        this.s = s;
        wrap = !"0".equals(s.host.pref("np_wrap"));
        if (!arg.isEmpty()) load(arg);
    }

    @Override public String title() { return (mod ? "*" : "") + (path.isEmpty() ? "Без имени" : WinFs.name(path)) + " - Блокнот"; }

    @Override public String id() { return "notepad"; }

    @Override public int minW() { return 150; }

    @Override public int minH() { return 80; }

    // ------------------------------------------------------------------ встроенное использование (Конструктор сайтов)
    String text() { return sb.toString(); }

    /** Растёт при любом изменении текста. */
    int rev() { return ver; }

    String path() { return path; }

    /** Открыт диалог файла или запрос о сохранении: окну нужна вся область. */
    boolean busy() { return dlg != null || prompt != 0; }

    boolean modified() { return mod; }

    void startDir(String dir) { startDir = dir == null ? "" : dir; }

    /** Заменить текст (файл не привязан, считается изменённым). */
    void replace(String t) {
        sb.setLength(0);
        sb.append(clean(t));
        path = "";
        cur = 0;
        anc = -1;
        scroll = 0;
        scrollX = 0;
        changed();
        mod = false;
    }

    /** Открыть файл накопителя. */
    void openPath(String p) { load(p); }

    private String dir() { return startDir.isEmpty() ? s.fs.home() + "/Documents" : startDir; }

    // ------------------------------------------------------------------ текст
    private static int adv(char c) { return PixelFont.advance(PixelFont.index(c)); }

    private int tw() { return aw - 2 * PAD - 4; }

    private int rows() { return Math.max(1, (ah - BAR - STAT - 4) / LH); }

    private void layout() {
        int w = tw();
        if (lw == w && lver == ver) return;
        lw = w;
        lver = ver;
        vl.clear();
        int n = sb.length(), i = 0;
        while (true) {
            int j = sb.indexOf("\n", i), e = j < 0 ? n : j;
            if (!wrap) {
                vl.add(new int[] {i, e});
            } else {
                int st = i;
                while (true) {
                    int x = 0, k = st, brk = -1;
                    while (k < e) {
                        int a = adv(sb.charAt(k));
                        if (x + a > w && k > st) break;
                        x += a;
                        k++;
                        if (sb.charAt(k - 1) == ' ') brk = k;
                    }
                    if (k >= e) {
                        vl.add(new int[] {st, e});
                        break;
                    }
                    int cut = brk > st ? brk : k;
                    vl.add(new int[] {st, cut});
                    st = cut;
                }
            }
            if (j < 0) break;
            i = j + 1;
        }
    }

    private int lineOf(int idx) {
        layout();
        int r = 0;
        for (int i = 0; i < vl.size(); i++) {
            if (vl.get(i)[0] <= idx) r = i;
            else break;
        }
        return r;
    }

    private int xOf(int line, int idx) {
        int x = 0;
        for (int i = vl.get(line)[0]; i < idx; i++) x += adv(sb.charAt(i));
        return x;
    }

    private int indexAt(int line, int px) {
        int[] l = vl.get(line);
        int x = 0, i = l[0];
        while (i < l[1]) {
            int a = adv(sb.charAt(i));
            if (x + a / 2 >= px) break;
            x += a;
            i++;
        }
        return i;
    }

    private void showCursor() {
        int ln = lineOf(cur), r = rows();
        if (ln < scroll) scroll = ln;
        else if (ln >= scroll + r) scroll = ln - r + 1;
        scroll = Math.max(0, Math.min(Math.max(0, vl.size() - r), scroll));
        if (!wrap) {
            int cx = xOf(ln, cur), vw = tw() - 6;
            if (cx < scrollX) scrollX = Math.max(0, cx - 20);
            else if (cx > scrollX + vw) scrollX = cx - vw + 20;
        } else {
            scrollX = 0;
        }
    }

    private void changed() {
        mod = true;
        ver++;
        wantX = -1;
        note = "";
    }

    private boolean delSel() {
        if (anc < 0 || anc == cur) {
            anc = -1;
            return false;
        }
        int a = Math.min(cur, anc), b = Math.max(cur, anc);
        sb.delete(a, b);
        cur = a;
        anc = -1;
        changed();
        return true;
    }

    private void insert(String t) {
        delSel();
        int room = WinFs.MAX_TEXT - sb.length();
        if (room <= 0) {
            note = "Достигнут предел размера файла";
            return;
        }
        if (t.length() > room) t = t.substring(0, room);
        sb.insert(cur, t);
        cur += t.length();
        changed();
    }

    private String selected() {
        return anc < 0 || anc == cur ? "" : sb.substring(Math.min(cur, anc), Math.max(cur, anc));
    }

    private static String clean(String t) {
        return t.replace("\r", "").replace("\t", "    ");
    }

    // ------------------------------------------------------------------ файлы
    private void load(String p) {
        String t = s.fs.read(p);
        if (t == null || s.fs.size(p) != t.length()) {
            note = "Не удалось открыть файл";
            return;
        }
        sb.setLength(0);
        sb.append(clean(t));
        path = p;
        mod = false;
        cur = 0;
        anc = -1;
        scroll = 0;
        scrollX = 0;
        ver++;
    }

    private void save() {
        if (path.isEmpty()) {
            saveAs();
            return;
        }
        if (s.fs.write(path, sb.toString())) {
            mod = false;
            note = "Сохранено";
        } else {
            note = "Не удалось сохранить: нет места";
        }
    }

    private void saveAs() {
        String dir = path.isEmpty() ? dir() : WinFs.parent(path);
        dlg = new WinFileDialog(s.fs, true, "Сохранить как", dir, path.isEmpty() ? "Без имени.txt" : WinFs.name(path), "txt", null, p -> {
            path = p;
            save();
            Runnable r = after;
            after = null;
            if (r != null && !mod) r.run();
        });
    }

    private void open() {
        dlg = new WinFileDialog(s.fs, false, "Открыть", path.isEmpty() ? dir() : WinFs.parent(path), "", "txt", null, this::load);
    }

    private void fresh() {
        sb.setLength(0);
        path = "";
        mod = false;
        cur = 0;
        anc = -1;
        scroll = 0;
        ver++;
    }

    /** Выполнить действие, спросив о несохранённых изменениях. */
    private void guard(Runnable r) {
        if (!mod) {
            r.run();
            return;
        }
        after = r;
        prompt = 1;
    }

    // ------------------------------------------------------------------ меню
    private void openMenu(int m) {
        String[] l;
        int[] id;
        if (m == M_FILE) {
            l = new String[] {"Создать", "Открыть...", "Сохранить", "Сохранить как..."};
            id = new int[] {1, 2, 3, 4};
        } else if (m == M_EDIT) {
            l = new String[] {"Вырезать", "Копировать", "Вставить", "Выделить всё", "Время и дата"};
            id = new int[] {10, 11, 12, 13, 14};
        } else {
            l = new String[] {wrap ? "Перенос строк: вкл" : "Перенос строк: выкл"};
            id = new int[] {20};
        }
        menu = new WinPopup(l, id);
        menu.openAt(BX[m], BAR, aw, ah);
    }

    private void act(int id) {
        switch (id) {
            case 1: guard(this::fresh); break;
            case 2: guard(this::open); break;
            case 3: save(); break;
            case 4: saveAs(); break;
            case 10:
                if (!selected().isEmpty()) {
                    s.clipText = selected();
                    delSel();
                }
                break;
            case 11:
                if (!selected().isEmpty()) s.clipText = selected();
                break;
            case 12: insert(clean(s.clipText)); break;
            case 13:
                anc = 0;
                cur = sb.length();
                break;
            case 14: {
                long dt = s.host.dayTime();
                insert(WinClock.time(dt, s.th.h12) + " " + WinClock.dateShort(dt, s.th.dateFmt));
                break;
            }
            case 20:
                wrap = !wrap;
                s.host.setPref("np_wrap", wrap ? "1" : "0");
                ver++;
                break;
            default: break;
        }
        showCursor();
    }

    // ------------------------------------------------------------------ рисование
    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        aw = w;
        ah = h;
        layout();
        String[] nm = {"Файл", "Правка", "Вид"};
        for (int i = 0; i < 3; i++) WinSoft.flat(p, th, x + BX[i], y + 1, BW[i], BAR - 2, nm[i], hover == i, menu != null && menu.open() && hover == i);
        int ty = y + BAR, th2 = h - BAR - STAT;
        p.fillRect(x, ty, w, th2, th.surface());
        p.hline(x, ty, w, th.border());
        p.pushClip(x + 1, ty + 1, w - 2, th2 - 1);
        int tx = x + PAD, r = rows(), a = Math.min(cur, anc), b = Math.max(cur, anc);
        boolean hasSel = anc >= 0 && anc != cur;
        for (int i = 0; i < r && scroll + i < vl.size(); i++) {
            int[] l = vl.get(scroll + i);
            int ly = ty + 3 + i * LH;
            if (hasSel && b > l[0] && a <= l[1]) {
                int xa = xOf(scroll + i, Math.max(a, l[0])), xb = xOf(scroll + i, Math.min(b, l[1])) + (b > l[1] && !(scroll + i + 1 < vl.size() && vl.get(scroll + i + 1)[0] == l[1]) ? 3 : 0);
                p.fillRect(tx + xa - scrollX, ly - 1, Math.max(1, xb - xa), LH, PixelScreen.alpha(th.accent(), 0x70));
            }
            if (l[1] > l[0]) p.drawText(tx - scrollX, ly, sb.substring(l[0], l[1]), th.text());
        }
        if ((now / 10) % 2 == 0 || drag) {
            int ln = lineOf(cur);
            if (ln >= scroll && ln < scroll + r) p.fillRect(tx + xOf(ln, cur) - scrollX, ty + 2 + (ln - scroll) * LH, 1, LH, th.text());
        }
        p.popClip();
        WinSoft.scrollbar(p, th, x + w - 5, ty + 2, th2 - 4, vl.size(), r, scroll);
        int sy = y + h - STAT;
        p.fillRect(x, sy, w, STAT, th.bg());
        int row = 1, col = 1;
        for (int i = 0; i < cur; i++) {
            if (sb.charAt(i) == '\n') {
                row++;
                col = 1;
            } else {
                col++;
            }
        }
        String st = note.isEmpty() ? "Стр. " + row + ", стлб. " + col : note;
        p.drawText(x + 6, sy + 2, st, note.isEmpty() ? th.sub() : th.warn());
        p.drawTextRight(x + w - 6, sy + 2, sb.length() + " симв.  UTF-8", th.sub(), 1, false);
        if (menu != null) menu.draw(p, th, x, y, s.perf.effects);
        if (prompt != 0) drawPrompt(p, th, x, y, w, h);
        if (dlg != null) dlg.draw(p, th, x, y, w, h, now);
    }

    private int[] pbox() {
        int pw = Math.min(aw - 10, 190);
        return new int[] {(aw - pw) / 2, (ah - 52) / 2, pw, 52};
    }

    private void drawPrompt(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        p.fillRect(x, y, w, h, 0x50000000);
        int[] b = pbox();
        p.shadow(x + b[0], y + b[1], b[2], b[3], 6, 8, 0, 3, 0x70000000);
        p.roundRectBorder(x + b[0], y + b[1], b[2], b[3], 6, th.surface(), th.border());
        p.drawText(x + b[0] + 8, y + b[1] + 7, PixelScreen.fit("Сохранить изменения в файле?", b[2] - 16, 1, false), th.text());
        String[] l = {"Сохранить", "Не сохранять", "Отмена"};
        int bw = (b[2] - 20) / 3;
        for (int i = 0; i < 3; i++) {
            WinUi.Button bt = new WinUi.Button(l[i], x + b[0] + 6 + i * (bw + 4), y + b[1] + b[3] - 20, bw, i == 0);
            bt.h = 14;
            bt.draw(p, th);
        }
    }

    // ------------------------------------------------------------------ ввод
    @Override
    public boolean tick(long t) {
        boolean b = (now / 10) % 2 != (t / 10) % 2;
        now = t;
        return b;
    }

    @Override
    public boolean key(char c, int key) {
        if (dlg != null) {
            boolean r = dlg.key(c, key);
            if (dlg.closed) dlg = null;
            return r;
        }
        if (prompt != 0) {
            if (key == WinSoft.K_ESC) prompt = 0;
            return true;
        }
        if (menu != null && menu.open()) {
            if (key == WinSoft.K_ESC) menu.close();
            return true;
        }
        layout();
        int ln = lineOf(cur), r = rows();
        boolean nav = true;
        if (key == WinSoft.K_LEFT) cur = Math.max(0, cur - 1);
        else if (key == WinSoft.K_RIGHT) cur = Math.min(sb.length(), cur + 1);
        else if (key == WinSoft.K_UP || key == WinSoft.K_DOWN || key == WinSoft.K_PGUP || key == WinSoft.K_PGDN) {
            if (wantX < 0) wantX = xOf(ln, cur);
            int d = key == WinSoft.K_UP ? -1 : key == WinSoft.K_DOWN ? 1 : key == WinSoft.K_PGUP ? -r : r;
            int to = Math.max(0, Math.min(vl.size() - 1, ln + d));
            cur = indexAt(to, wantX);
            showCursor();
            anc = -1;
            return true;
        } else if (key == WinSoft.K_HOME) cur = vl.get(ln)[0];
        else if (key == WinSoft.K_END) cur = vl.get(ln)[1];
        else nav = false;
        if (nav) {
            anc = -1;
            wantX = -1;
            showCursor();
            return true;
        }
        if (key == WinUi.K_BACK || c == '\b') {
            if (!delSel() && cur > 0) {
                sb.deleteCharAt(--cur);
                changed();
            }
        } else if (key == WinSoft.K_DEL) {
            if (!delSel() && cur < sb.length()) {
                sb.deleteCharAt(cur);
                changed();
            }
        } else if (WinUi.isEnter(c, key)) {
            insert("\n");
        } else if (key == WinUi.K_TAB || c == '\t') {
            insert("    ");
        } else if (c >= 32 && c != 127) {
            insert(String.valueOf(c));
        } else {
            return false;
        }
        showCursor();
        return true;
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        if (dlg != null) {
            boolean r = dlg.mouse(rx, ry, btn, kind, now);
            if (dlg.closed) dlg = null;
            return r;
        }
        if (prompt != 0) return promptMouse(rx, ry, kind, btn);
        boolean dirty = false;
        int hv = -1;
        if (ry >= 0 && ry < BAR) for (int i = 0; i < 3; i++) if (rx >= BX[i] && rx < BX[i] + BW[i]) hv = i;
        if (hv != hover) {
            hover = hv;
            dirty = true;
        }
        if (menu != null && menu.open()) {
            if (kind == PixelScreen.MOUSE_PRESS) {
                int id = menu.press(rx, ry);
                if (id < 0 && hv >= 0 && btn == 0) openMenu(hv);
                else if (id >= 0) act(id);
                return true;
            }
            return menu.move(rx, ry) | dirty;
        }
        layout();
        int ty = BAR, r = rows();
        if (kind == PixelScreen.MOUSE_SCROLL_UP || kind == PixelScreen.MOUSE_SCROLL_DOWN) {
            int ns = Math.max(0, Math.min(Math.max(0, vl.size() - r), scroll + (kind == PixelScreen.MOUSE_SCROLL_UP ? -3 : 3)));
            if (ns == scroll) return dirty;
            scroll = ns;
            return true;
        }
        if (kind == PixelScreen.MOUSE_PRESS && btn == 0) {
            if (hv >= 0) {
                openMenu(hv);
                return true;
            }
            if (ry >= ty && ry < ah - STAT) {
                cur = posAt(rx, ry);
                anc = cur;
                drag = true;
                wantX = -1;
                return true;
            }
        } else if (kind == PixelScreen.MOUSE_DRAG && drag) {
            if (ry < ty && scroll > 0) scroll--;
            else if (ry >= ah - STAT && scroll < vl.size() - r) scroll++;
            cur = posAt(rx, ry);
            return true;
        } else if (kind == PixelScreen.MOUSE_RELEASE && drag) {
            drag = false;
            if (anc == cur) anc = -1;
            return true;
        }
        return dirty;
    }

    private int posAt(int rx, int ry) {
        int ln = Math.max(0, Math.min(vl.size() - 1, scroll + (ry - BAR - 3) / LH));
        if (ry < BAR + 3) ln = Math.max(0, Math.min(vl.size() - 1, scroll));
        return indexAt(ln, Math.max(0, rx - PAD + scrollX));
    }

    private boolean promptMouse(int rx, int ry, int kind, int btn) {
        if (kind != PixelScreen.MOUSE_PRESS || btn != 0) return false;
        int[] b = pbox();
        int bw = (b[2] - 20) / 3;
        for (int i = 0; i < 3; i++) {
            if (!WinSoft.in(rx, ry, b[0] + 6 + i * (bw + 4), b[1] + b[3] - 20, bw, 14)) continue;
            prompt = 0;
            Runnable r = after;
            if (i == 0) {
                if (path.isEmpty()) {
                    saveAs();
                    return true;
                }
                save();
                after = null;
                if (!mod && r != null) r.run();
            } else if (i == 1) {
                after = null;
                if (r != null) r.run();
            } else {
                after = null;
            }
            showCursor();
            return true;
        }
        return false;
    }
}
