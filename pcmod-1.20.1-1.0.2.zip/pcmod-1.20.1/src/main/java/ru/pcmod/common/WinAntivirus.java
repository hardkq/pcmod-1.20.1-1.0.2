package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;

/** Антивирус SafeGuard: состояние защиты, список угроз, проверка, удаление (перезапуск ПК) и «Ждать». Режим alert - окно при обнаружении угрозы. */
public final class WinAntivirus implements WinApp {
    private static final String[] SCAN_DIRS = {"C:\\Windows", "C:\\Users", "C:\\programs", "C:\\games", "C:\\Users\\Downloads"};
    private static final int SCAN_STEPS = 40, BH = 36;

    private final WinSoft s;
    private final WinSvc svc;
    private final boolean alert;
    private List<String[]> threats = new ArrayList<String[]>();
    private int waiting;
    private boolean scanning, gone;
    private int scanStep, ox, oy;
    private long lastRefresh;
    private String scanMsg = "";
    private final WinUi.Button bScan = new WinUi.Button("Проверка", 0, 0, 70, false);
    private final WinUi.Button bRemove = new WinUi.Button("Удалить угрозы", 0, 0, 100, true);
    private final WinUi.Button bWait = new WinUi.Button("Ждать", 0, 0, 60, false);

    public WinAntivirus(WinSoft s, String arg) {
        this.s = s;
        this.svc = s.svc;
        this.alert = "alert".equals(arg);
        refresh();
    }

    @Override public String title() { return "Антивирус SafeGuard"; }

    @Override public String id() { return "av"; }

    @Override public boolean resizable() { return false; }

    @Override public int minW() { return 262; }

    @Override public int minH() { return 150; }

    private boolean refresh() {
        List<String[]> t = svc.avThreats();
        int wt = svc.avWaiting();
        boolean ch = t.size() != threats.size() || wt != waiting;
        threats = t;
        waiting = wt;
        return ch;
    }

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        ox = x;
        oy = y;
        int n = threats.size();
        boolean bad = n > 0;
        int col = bad ? th.bad() : th.ok();
        p.fillRect(x, y, w, BH, PixelScreen.alpha(col, 0x30));
        p.hline(x, y + BH, w, th.border());
        WinIcons.drawSized(p, th, "av", x + 8, y + 6, 24);
        if (alert && bad) {
            p.drawText(x + 40, y + 5, "Найдена угроза!", col, 1, true);
            int ty = y + 16;
            for (String ln : WinSoft.wrap("Неизвестная программа была найдена у вас в компьютере.", w - 48)) {
                p.drawText(x + 40, ty, ln, th.text());
                ty += 10;
            }
        } else if (bad) {
            p.drawText(x + 40, y + 7, "Обнаружены угрозы: " + n, col, 1, true);
            p.drawText(x + 40, y + 20, waiting > 0 ? "Нужно ваше решение" : "Вы выбрали «Ждать»: угрозы остаются", th.sub());
        } else {
            p.drawText(x + 40, y + 7, "Вы защищены", col, 1, true);
            p.drawText(x + 40, y + 20, "Защита в реальном времени включена", th.sub());
        }
        int ly = y + BH + 6;
        p.drawText(x + 8, ly, "Угрозы на этом ПК", th.sub());
        ly += 12;
        if (!bad) {
            p.drawText(x + 8, ly, "Угроз не найдено", th.text());
        } else {
            int shown = Math.min(n, 3);
            for (int i = 0; i < shown; i++) {
                String t;
                if (i == 2 && n > 3) t = "... и ещё " + (n - 2);
                else t = threats.get(i)[0] + " - " + threats.get(i)[1];
                p.drawText(x + 8, ly + i * 12, PixelScreen.fit(t, w - 16, 1, false), th.text());
            }
        }
        int sy = y + 89;
        if (scanning) {
            int pct = scanStep * 100 / SCAN_STEPS;
            p.drawText(x + 8, sy, PixelScreen.fit("Проверка: " + SCAN_DIRS[(scanStep / 6) % SCAN_DIRS.length] + "  " + pct + "%", w - 16, 1, false), th.text());
            p.roundRect(x + 8, sy + 11, w - 16, 4, 2, th.border());
            if (pct > 0) p.roundRect(x + 8, sy + 11, Math.max(4, (w - 16) * pct / 100), 4, 2, th.accent());
        } else {
            if (!scanMsg.isEmpty()) p.drawText(x + 8, sy, PixelScreen.fit(scanMsg, w - 16, 1, false), th.sub());
            if (bad) p.drawText(x + 8, sy + 11, "Удаление перезапустит ПК (до 11 секунд).", th.sub());
        }
        int by = y + h - 22;
        bScan.x = x + 8;
        bRemove.x = bScan.x + bScan.w + 6;
        bWait.x = bRemove.x + bRemove.w + 6;
        bScan.y = bRemove.y = bWait.y = by;
        bScan.enabled = !scanning;
        bRemove.enabled = bad && !scanning;
        bWait.enabled = waiting > 0 && !scanning;
        bScan.draw(p, th);
        bRemove.draw(p, th);
        bWait.draw(p, th);
    }

    private void remove() {
        gone = true;
        svc.avRemove();
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        if (gone) return false;
        int ax = rx + ox, ay = ry + oy;
        boolean ch = false;
        for (WinUi.Button b : new WinUi.Button[] {bScan, bRemove, bWait}) {
            boolean hv = b.hit(ax, ay);
            if (hv != b.hover) {
                b.hover = hv;
                ch = true;
            }
        }
        if (kind == PixelScreen.MOUSE_PRESS && btn == 0) {
            if (bScan.hit(ax, ay)) {
                scanning = true;
                scanStep = 0;
                scanMsg = "";
                return true;
            }
            if (bRemove.hit(ax, ay)) {
                remove();
                return true;
            }
            if (bWait.hit(ax, ay)) {
                svc.avWait();
                refresh();
                if (alert) s.ctx.kill(this);
                return true;
            }
        }
        return ch;
    }

    @Override
    public boolean key(char c, int key) {
        if (alert && key == WinSoft.K_ESC) {
            s.ctx.kill(this);
            return false;
        }
        return false;
    }

    @Override
    public boolean tick(long now) {
        if (gone) return false;
        boolean ch = false;
        if (scanning && now % 2 == 0) {
            if (++scanStep >= SCAN_STEPS) {
                scanning = false;
                refresh();
                scanMsg = threats.isEmpty() ? "Проверка завершена: угроз не найдено" : "Проверка завершена: найдено угроз: " + threats.size();
            }
            ch = true;
        }
        if (now - lastRefresh >= 10) {
            lastRefresh = now;
            ch |= refresh();
        }
        return ch;
    }
}
