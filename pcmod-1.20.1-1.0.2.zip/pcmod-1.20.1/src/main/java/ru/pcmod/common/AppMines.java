package ru.pcmod.common;

import java.util.Random;
import static ru.pcmod.common.PixelScreen.rgb;

/** Игра «Сапёр» (магазин приложений): поле 8x8, 10 мин, первый ход безопасен, режим флажка, открытие пустых областей. */
final class AppMines implements AndroOs.App {
    private static final int N = 8, MINES = 10, C = 20, OX = 10, OY = 70;
    private static final int[] NUM = {0, rgb(80, 150, 255), rgb(80, 200, 100), rgb(240, 90, 80), rgb(150, 100, 255), rgb(220, 140, 60), rgb(60, 200, 200), rgb(230, 230, 230), rgb(150, 150, 150)};

    private static final class St {
        boolean[] mine = new boolean[N * N], open = new boolean[N * N], flag = new boolean[N * N];
        boolean placed, over, win, flagMode;
        final Random rnd = new Random();
    }

    private static St st(AndroOs os) { return os.state("mines", St::new); }

    private static int around(St s, int x, int y) {
        int n = 0;
        for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
            int a = x + i, b = y + j;
            if ((i != 0 || j != 0) && a >= 0 && b >= 0 && a < N && b < N && s.mine[b * N + a]) n++;
        }
        return n;
    }

    private static void reveal(St s, int x, int y) {
        if (x < 0 || y < 0 || x >= N || y >= N || s.open[y * N + x] || s.flag[y * N + x]) return;
        s.open[y * N + x] = true;
        if (around(s, x, y) == 0) for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) reveal(s, x + i, y + j);
    }

    private static void place(St s, int sx, int sy) {
        int left = MINES;
        while (left > 0) {
            int x = s.rnd.nextInt(N), y = s.rnd.nextInt(N);
            if (s.mine[y * N + x] || Math.abs(x - sx) <= 1 && Math.abs(y - sy) <= 1) continue;
            s.mine[y * N + x] = true;
            left--;
        }
        s.placed = true;
    }

    private static void reset(St s) {
        s.mine = new boolean[N * N]; s.open = new boolean[N * N]; s.flag = new boolean[N * N];
        s.placed = false; s.over = false; s.win = false;
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        AppUi.header(os, s, "mines", os.t("Сапёр", "Minesweeper"));
        int flags = 0;
        for (boolean f : st.flag) if (f) flags++;
        s.drawText(10, 50, os.t("Мины: ", "Mines: ") + (MINES - flags), os.text(), 1, true);
        s.drawTextRight(170, 50, st.over ? (st.win ? os.t("Победа!", "You win!") : os.t("Взрыв!", "Boom!")) : "", st.win ? rgb(80, 220, 120) : rgb(240, 110, 100), 1, true);
        for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) {
            int i = y * N + x, px = OX + x * C, py = OY + y * C;
            boolean o = st.open[i];
            s.fillRect(px, py, C - 1, C - 1, o ? (st.mine[i] ? rgb(200, 60, 50) : os.panel()) : rgb(110, 130, 160));
            if (!o) s.hline(px, py, C - 1, rgb(160, 180, 210));
            if (o && st.mine[i]) s.roundRect(px + 5, py + 5, 9, 9, 4, rgb(20, 20, 20));
            else if (o) { int n = around(st, x, y); if (n > 0) s.drawTextCentered(px, C - 1, py + 6, String.valueOf(n), NUM[n], 1, true); }
            else if (st.flag[i]) { s.vline(px + 8, py + 4, 11, rgb(240, 240, 240)); s.fillRect(px + 8, py + 4, 7, 5, rgb(240, 80, 70)); }
            else if (st.over && st.mine[i]) s.roundRect(px + 6, py + 6, 7, 7, 3, rgb(30, 30, 30));
        }
        AppUi.btn(os, s, 10, 240, 76, 24, st.flagMode ? os.t("Флажок: вкл", "Flag: on") : os.t("Флажок", "Flag"), st.flagMode);
        AppUi.btn(os, s, 94, 240, 76, 24, os.t("Заново", "New game"), false);
        s.drawTextCentered(0, AndroOs.W, 274, os.t("Коснитесь клетки. Флажок - режим пометки мин.", "Tap a cell. Flag mode marks mines."), os.sub(), 1, false);
    }

    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        if (kind != 1 || !os.tap(x, y)) return true;
        St st = st(os);
        if (AppUi.in(x, y, 10, 240, 76, 24)) { st.flagMode = !st.flagMode; return true; }
        if (AppUi.in(x, y, 94, 240, 76, 24)) { reset(st); return true; }
        if (st.over || !AppUi.in(x, y, OX, OY, N * C, N * C)) return true;
        int cx = (x - OX) / C, cy = (y - OY) / C, i = cy * N + cx;
        if (st.flagMode) { if (!st.open[i]) st.flag[i] = !st.flag[i]; return true; }
        if (st.flag[i] || st.open[i]) return true;
        if (!st.placed) place(st, cx, cy);
        if (st.mine[i]) {
            st.over = true;
            for (int k = 0; k < N * N; k++) if (st.mine[k]) st.open[k] = true;
            return true;
        }
        reveal(st, cx, cy);
        int closed = 0;
        for (int k = 0; k < N * N; k++) if (!st.open[k]) closed++;
        if (closed == MINES) { st.over = true; st.win = true; }
        return true;
    }
}
