package ru.pcmod.common;

/** Страница окна «Параметры»: рисуется справа от списка разделов. Координаты мыши - внутри области страницы. */
interface WinPage {
    void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h);

    /** Мышь; rx < 0 - указатель ушёл со страницы. true - страницу нужно перерисовать. */
    boolean mouse(int rx, int ry, int btn, int kind);

    default boolean key(char c, int key) { return false; }

    /** Раз в тик; true - перерисовать. */
    default boolean tick(long now) { return false; }

    /** Страница открыта (или обновилась): перечитать состояние. */
    default void enter() {}
}
