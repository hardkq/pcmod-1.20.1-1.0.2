package ru.pcmod.common;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * Пиксельный экран 320x180 (RGB, 24 бита) для графических ОС.
 * Цвета в примитивах: ARGB 0xAARRGGBB (альфа 255 = непрозрачный; альфа 0 = ничего не рисуется). Удобно: {@link #rgb}, {@link #argb}.
 * Все примитивы учитывают прямоугольник отсечения (clip).
 * Сеть: экран разбит на плитки 16x12; сервер шлёт сжатые (Deflate) дельты изменённых плиток и периодический ключевой кадр.
 */
public class PixelScreen {
    public static final int W = 320, H = 180, TW = 16, TH = 12, TX = W / TW, TY = H / TH, TILES = TX * TY;
    /** Период ключевых кадров, тики. */
    private static final int KEY_PERIOD = 100;
    /** Если изменено больше плиток, шлётся ключевой кадр. */
    private static final int DELTA_MAX = 120;
    private static final int KIND_KEY = 0, KIND_DELTA = 1, KIND_OFF = 2;

    /** Портретный экран телефона: 180x320, плитки 12x16 (то же число пикселей, что и у 320x180). */
    public static final int PW = 180, PH = 320;
    /** Размеры этого экрана и плиток (у ПК - W x H, у телефона - PW x PH). */
    public final int fw, fh, ptw, pth, ptx, pty, ptiles;

    /** Пиксели 0xRRGGBB. */
    public final int[] px;
    /** Растёт при любом изменении (клиент по нему перезаливает текстуру). */
    public int version;
    private boolean active;
    private int seq;
    private boolean hasFrame;

    private final boolean[] dirty;
    private int dirtyCount;
    private boolean needKey = true;

    private int cx0 = 0, cy0 = 0, cx1, cy1;
    private final ArrayDeque<int[]> clipStack = new ArrayDeque<>();

    /** События мыши в пиксельных координатах (клиент -> сервер, PacketAction тип 7). */
    public static final int MOUSE_MOVE = 0, MOUSE_PRESS = 1, MOUSE_RELEASE = 2, MOUSE_DRAG = 3, MOUSE_SCROLL_UP = 4, MOUSE_SCROLL_DOWN = 5;
    /** x == LEAVE: курсор вне экрана. */
    public static final int LEAVE = 0xFFFF;

    /** Слушатель мыши для графической ОС (ставится в ComputerLogic.pixelMouse). Вызывается в серверном потоке. */
    public interface MouseListener {
        /** x, y - пиксель 0..319 x 0..179 (x == LEAVE - вне экрана); btn: 0 левая, 1 правая, 2 средняя; kind - MOUSE_*. */
        void mouse(int x, int y, int btn, int kind);
    }

    /** Упаковка y (8 бит), кнопки (4 бита) и вида события (3 бита) в одно число для PacketAction.key. */
    public static int packMouse(int y, int btn, int kind) {
        return (y & 0xFF) | (btn & 15) << 8 | (kind & 7) << 12;
    }

    public PixelScreen() { this(false); }

    /** portrait = true - вертикальный экран телефона 180x320. */
    public PixelScreen(boolean portrait) {
        fw = portrait ? PW : W;
        fh = portrait ? PH : H;
        ptw = portrait ? 12 : TW;
        pth = portrait ? 16 : TH;
        ptx = fw / ptw;
        pty = fh / pth;
        ptiles = ptx * pty;
        px = new int[fw * fh];
        dirty = new boolean[ptiles];
        cx1 = fw;
        cy1 = fh;
        markAll();
    }

    public boolean portrait() { return fw == PW; }

    // ------------------------------------------------------------------ цвета

    public static int rgb(int r, int g, int b) {
        return 0xFF000000 | (r & 255) << 16 | (g & 255) << 8 | (b & 255);
    }

    public static int argb(int a, int r, int g, int b) {
        return (a & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (b & 255);
    }

    /** Тот же цвет с другой прозрачностью (0..255). */
    public static int alpha(int c, int a) {
        return (a & 255) << 24 | (c & 0xFFFFFF);
    }

    /** Линейная смесь двух ARGB-цветов, t = 0..1. */
    public static int lerp(int c1, int c2, float t) {
        if (t <= 0) return c1;
        if (t >= 1) return c2;
        int a = (int) ((c1 >>> 24) + ((c2 >>> 24) - (c1 >>> 24)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return argb(a, r, g, b);
    }

    private static int mix(int d, int s, int a) {
        if (a >= 255) return s & 0xFFFFFF;
        if (a <= 0) return d;
        int ia = 255 - a;
        int r = ((((s >> 16) & 255) * a + ((d >> 16) & 255) * ia) + 127) / 255;
        int g = ((((s >> 8) & 255) * a + ((d >> 8) & 255) * ia) + 127) / 255;
        int b = (((s & 255) * a + (d & 255) * ia) + 127) / 255;
        return r << 16 | g << 8 | b;
    }

    // ------------------------------------------------------------------ состояние

    public boolean isActive() { return active; }

    /** Включить/выключить пиксельный режим (текстовые ОС держат false и работают через Screen). */
    public void setActive(boolean a) {
        if (a != active) {
            active = a;
            needKey = true;
            version++;
        }
    }

    public void clear(int c) {
        Arrays.fill(px, c & 0xFFFFFF);
        markAll();
    }

    public int pixelAt(int x, int y) {
        return x < 0 || y < 0 || x >= fw || y >= fh ? 0 : px[y * fw + x];
    }

    // ------------------------------------------------------------------ clip

    /** Задать отсечение (пересекается с экраном, стек не трогает). */
    public void setClip(int x, int y, int w, int h) {
        cx0 = Math.max(0, x);
        cy0 = Math.max(0, y);
        cx1 = Math.min(fw, x + w);
        cy1 = Math.min(fh, y + h);
        if (cx1 < cx0) cx1 = cx0;
        if (cy1 < cy0) cy1 = cy0;
    }

    public void resetClip() {
        cx0 = 0; cy0 = 0; cx1 = fw; cy1 = fh;
        clipStack.clear();
    }

    /** Новое отсечение = пересечение с текущим; старое сохраняется до popClip. */
    public void pushClip(int x, int y, int w, int h) {
        clipStack.push(new int[] {cx0, cy0, cx1, cy1});
        int nx0 = Math.max(cx0, x), ny0 = Math.max(cy0, y);
        int nx1 = Math.min(cx1, x + w), ny1 = Math.min(cy1, y + h);
        cx0 = nx0; cy0 = ny0;
        cx1 = Math.max(nx0, nx1);
        cy1 = Math.max(ny0, ny1);
    }

    public void popClip() {
        int[] c = clipStack.poll();
        if (c == null) {
            cx0 = 0; cy0 = 0; cx1 = fw; cy1 = fh;
        } else {
            cx0 = c[0]; cy0 = c[1]; cx1 = c[2]; cy1 = c[3];
        }
    }

    public boolean inClip(int x, int y) {
        return x >= cx0 && y >= cy0 && x < cx1 && y < cy1;
    }

    // ------------------------------------------------------------------ dirty

    private void markAll() {
        Arrays.fill(dirty, true);
        dirtyCount = ptiles;
        version++;
    }

    private void mark(int x0, int y0, int x1, int y1) {
        if (x1 <= x0 || y1 <= y0) return;
        version++;
        int tx0 = x0 / ptw, tx1 = (x1 - 1) / ptw, ty0 = y0 / pth, ty1 = (y1 - 1) / pth;
        for (int ty = ty0; ty <= ty1; ty++)
            for (int tx = tx0; tx <= tx1; tx++) {
                int i = ty * ptx + tx;
                if (!dirty[i]) {
                    dirty[i] = true;
                    dirtyCount++;
                }
            }
    }

    private void clearDirty() {
        Arrays.fill(dirty, false);
        dirtyCount = 0;
    }

    // ------------------------------------------------------------------ примитивы

    /** Закраска без отметки изменений. Границы уже ограничены clip внутри. */
    private void span(int x0, int y0, int x1, int y1, int rgb, int a) {
        x0 = Math.max(x0, cx0); y0 = Math.max(y0, cy0);
        x1 = Math.min(x1, cx1); y1 = Math.min(y1, cy1);
        if (x1 <= x0 || y1 <= y0 || a <= 0) return;
        for (int y = y0; y < y1; y++) {
            int o = y * fw;
            if (a >= 255) Arrays.fill(px, o + x0, o + x1, rgb);
            else for (int x = x0; x < x1; x++) px[o + x] = mix(px[o + x], rgb, a);
        }
    }

    private void dot(int x, int y, int rgb, int a) {
        if (x < cx0 || y < cy0 || x >= cx1 || y >= cy1 || a <= 0) return;
        int i = y * fw + x;
        px[i] = a >= 255 ? rgb : mix(px[i], rgb, a);
    }

    private void markClipped(int x0, int y0, int x1, int y1) {
        mark(Math.max(x0, cx0), Math.max(y0, cy0), Math.min(x1, cx1), Math.min(y1, cy1));
    }

    public void pixel(int x, int y, int c) {
        dot(x, y, c & 0xFFFFFF, c >>> 24);
        markClipped(x, y, x + 1, y + 1);
    }

    public void fillRect(int x, int y, int w, int h, int c) {
        span(x, y, x + w, y + h, c & 0xFFFFFF, c >>> 24);
        if ((c >>> 24) != 0) markClipped(x, y, x + w, y + h);
    }

    /** Рамка толщиной t внутри прямоугольника. */
    public void rect(int x, int y, int w, int h, int t, int c) {
        if (w <= 0 || h <= 0 || t <= 0) return;
        t = Math.min(t, Math.min(w, h) / 2 + 1);
        fillRect(x, y, w, t, c);
        fillRect(x, y + h - t, w, t, c);
        fillRect(x, y + t, t, h - 2 * t, c);
        fillRect(x + w - t, y + t, t, h - 2 * t, c);
    }

    public void hline(int x, int y, int w, int c) { fillRect(x, y, w, 1, c); }

    public void vline(int x, int y, int h, int c) { fillRect(x, y, 1, h, c); }

    /** Вертикальный градиент (c1 сверху, c2 снизу). */
    public void gradientV(int x, int y, int w, int h, int c1, int c2) {
        if (h <= 0) return;
        for (int j = 0; j < h; j++) {
            int c = lerp(c1, c2, h == 1 ? 0 : j / (float) (h - 1));
            span(x, y + j, x + w, y + j + 1, c & 0xFFFFFF, c >>> 24);
        }
        markClipped(x, y, x + w, y + h);
    }

    /** Горизонтальный градиент (c1 слева, c2 справа). */
    public void gradientH(int x, int y, int w, int h, int c1, int c2) {
        if (w <= 0) return;
        for (int i = 0; i < w; i++) {
            int c = lerp(c1, c2, w == 1 ? 0 : i / (float) (w - 1));
            span(x + i, y, x + i + 1, y + h, c & 0xFFFFFF, c >>> 24);
        }
        markClipped(x, y, x + w, y + h);
    }

    /** Закруглённый прямоугольник со сглаженными углами. */
    public void roundRect(int x, int y, int w, int h, int r, int c) {
        int a = c >>> 24;
        if (a == 0 || w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            fillRect(x, y, w, h, c);
            return;
        }
        int rgb = c & 0xFFFFFF;
        span(x, y + r, x + w, y + h - r, rgb, a);
        span(x + r, y, x + w - r, y + r, rgb, a);
        span(x + r, y + h - r, x + w - r, y + h, rgb, a);
        corner(x, y, r, x + r, y + r, rgb, a);
        corner(x + w - r, y, r, x + w - r, y + r, rgb, a);
        corner(x, y + h - r, r, x + r, y + h - r, rgb, a);
        corner(x + w - r, y + h - r, r, x + w - r, y + h - r, rgb, a);
        markClipped(x, y, x + w, y + h);
    }

    private void corner(int px0, int py0, int r, int ccx, int ccy, int rgb, int a) {
        for (int j = 0; j < r; j++) {
            int yy = py0 + j;
            if (yy < cy0 || yy >= cy1) continue;
            for (int i = 0; i < r; i++) {
                int xx = px0 + i;
                if (xx < cx0 || xx >= cx1) continue;
                double dx = xx + 0.5 - ccx, dy = yy + 0.5 - ccy;
                double cov = r - Math.sqrt(dx * dx + dy * dy) + 0.5;
                if (cov <= 0) continue;
                dot(xx, yy, rgb, cov >= 1 ? a : (int) (a * cov));
            }
        }
    }

    private static double sdf(double px, double py, int x, int y, int w, int h, int r) {
        double qx = Math.abs(px - (x + w / 2.0)) - (w / 2.0 - r);
        double qy = Math.abs(py - (y + h / 2.0)) - (h / 2.0 - r);
        double ox = Math.max(qx, 0), oy = Math.max(qy, 0);
        return Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0) - r;
    }

    /** Контур закруглённого прямоугольника толщиной t (внутрь). */
    public void roundRectOutline(int x, int y, int w, int h, int r, int t, int c) {
        int a = c >>> 24;
        if (a == 0 || w <= 0 || h <= 0 || t <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        int rgb = c & 0xFFFFFF;
        int band = t + 1;
        int y0 = Math.max(y, cy0), y1 = Math.min(y + h, cy1);
        for (int yy = y0; yy < y1; yy++) {
            boolean edgeRow = yy - y < band || y + h - 1 - yy < band;
            int xs = Math.max(x, cx0), xe = Math.min(x + w, cx1);
            for (int xx = xs; xx < xe; xx++) {
                if (!edgeRow && xx - x >= band && x + w - 1 - xx >= band) {
                    xx = Math.max(xx, x + w - band) - 1;
                    continue;
                }
                double s = sdf(xx + 0.5, yy + 0.5, x, y, w, h, r);
                double cov = Math.min(1, Math.max(0, 0.5 - s)) - Math.min(1, Math.max(0, 0.5 - (s + t)));
                if (cov > 0) dot(xx, yy, rgb, cov >= 1 ? a : (int) (a * cov));
            }
        }
        markClipped(x, y, x + w, y + h);
    }

    /** Заливка + контур толщиной 1 (карточка Win11). */
    public void roundRectBorder(int x, int y, int w, int h, int r, int fill, int border) {
        roundRect(x, y, w, h, r, fill);
        roundRectOutline(x, y, w, h, r, 1, border);
    }

    /**
     * Мягкая тень окна. Рисуется только вне самого окна (x,y,w,h,r), поэтому дёшево.
     * dx, dy - смещение, blur - ширина размытия, c - цвет (альфа = максимальная плотность).
     */
    public void shadow(int x, int y, int w, int h, int r, int blur, int dx, int dy, int c) {
        int a = c >>> 24;
        if (a == 0 || blur <= 0 || w <= 0 || h <= 0) return;
        int rgb = c & 0xFFFFFF;
        r = Math.min(r, Math.min(w, h) / 2);
        int sx = x + dx, sy = y + dy;
        int bx0 = Math.max(Math.min(x, sx) - blur, cx0), by0 = Math.max(Math.min(y, sy) - blur, cy0);
        int bx1 = Math.min(Math.max(x + w, sx + w) + blur, cx1), by1 = Math.min(Math.max(y + h, sy + h) + blur, cy1);
        for (int yy = by0; yy < by1; yy++) {
            boolean mid = yy >= y + r && yy < y + h - r;
            for (int xx = bx0; xx < bx1; xx++) {
                if (mid && xx >= x && xx < x + w) {
                    xx = x + w - 1;
                    continue;
                }
                if (!mid && xx >= x + r && xx < x + w - r && yy >= y && yy < y + h) {
                    xx = x + w - r - 1;
                    continue;
                }
                double px0 = xx + 0.5, py0 = yy + 0.5;
                if (yy >= y && yy < y + h && xx >= x && xx < x + w && sdf(px0, py0, x, y, w, h, r) < -0.5) continue;
                double s = sdf(px0, py0, sx, sy, w, h, r);
                if (s >= blur) continue;
                double k = s <= 0 ? 1 : 1 - s / blur;
                int al = (int) (a * k * k);
                if (al > 0) dot(xx, yy, rgb, al);
            }
        }
        markClipped(bx0, by0, bx1, by1);
    }

    // ------------------------------------------------------------------ blit

    /** ARGB-картинка src (ширина sw, высота sh) в точку (dx, dy). */
    public void blit(int[] src, int sw, int sh, int dx, int dy) {
        blit(src, sw, 0, 0, sw, sh, dx, dy, 255);
    }

    /** Фрагмент (sx, sy, w, h) ARGB-картинки шириной sw с общей прозрачностью alpha 0..255. */
    public void blit(int[] src, int sw, int sx, int sy, int w, int h, int dx, int dy, int alpha) {
        if (alpha <= 0) return;
        int x0 = Math.max(dx, cx0), y0 = Math.max(dy, cy0), x1 = Math.min(dx + w, cx1), y1 = Math.min(dy + h, cy1);
        if (x1 <= x0 || y1 <= y0) return;
        for (int y = y0; y < y1; y++) {
            int so = (sy + y - dy) * sw + sx - dx;
            int o = y * fw;
            for (int x = x0; x < x1; x++) {
                int s = src[so + x];
                int a = s >>> 24;
                if (alpha < 255) a = a * alpha / 255;
                if (a <= 0) continue;
                px[o + x] = a >= 255 ? s & 0xFFFFFF : mix(px[o + x], s, a);
            }
        }
        mark(x0, y0, x1, y1);
    }

    /** Увеличенный (целый масштаб) ARGB-спрайт. */
    public void blitScaled(int[] src, int sw, int sh, int dx, int dy, int scale) {
        int sc = Math.max(1, scale);
        for (int j = 0; j < sh; j++)
            for (int i = 0; i < sw; i++) {
                int s = src[j * sw + i];
                span(dx + i * sc, dy + j * sc, dx + (i + 1) * sc, dy + (j + 1) * sc, s & 0xFFFFFF, s >>> 24);
            }
        markClipped(dx, dy, dx + sw * sc, dy + sh * sc);
    }

    /** Копия области другого PixelScreen (непрозрачно, либо с общей прозрачностью alpha). */
    public void blit(PixelScreen s, int sx, int sy, int w, int h, int dx, int dy, int alpha) {
        if (alpha <= 0) return;
        if (sx < 0) { dx -= sx; w += sx; sx = 0; }
        if (sy < 0) { dy -= sy; h += sy; sy = 0; }
        w = Math.min(w, fw - sx);
        h = Math.min(h, fh - sy);
        int x0 = Math.max(dx, cx0), y0 = Math.max(dy, cy0), x1 = Math.min(dx + w, cx1), y1 = Math.min(dy + h, cy1);
        if (x1 <= x0 || y1 <= y0) return;
        for (int y = y0; y < y1; y++) {
            int so = (sy + y - dy) * fw + sx - dx;
            int o = y * fw;
            if (alpha >= 255) System.arraycopy(s.px, so + x0, px, o + x0, x1 - x0);
            else for (int x = x0; x < x1; x++) px[o + x] = mix(px[o + x], s.px[so + x], alpha);
        }
        mark(x0, y0, x1, y1);
    }

    /** Сдвиг/копирование области внутри экрана (прокрутка). Области могут пересекаться. */
    public void copyRect(int sx, int sy, int w, int h, int dx, int dy) {
        int x0 = Math.max(dx, cx0), y0 = Math.max(dy, cy0), x1 = Math.min(dx + w, cx1), y1 = Math.min(dy + h, cy1);
        if (x1 <= x0 || y1 <= y0) return;
        int ox = sx - dx, oy = sy - dy;
        x0 = Math.max(x0, -ox); y0 = Math.max(y0, -oy);
        x1 = Math.min(x1, fw - ox); y1 = Math.min(y1, fh - oy);
        if (x1 <= x0 || y1 <= y0) return;
        if (oy >= 0) for (int y = y0; y < y1; y++) System.arraycopy(px, (y + oy) * fw + x0 + ox, px, y * fw + x0, x1 - x0);
        else for (int y = y1 - 1; y >= y0; y--) System.arraycopy(px, (y + oy) * fw + x0 + ox, px, y * fw + x0, x1 - x0);
        mark(x0, y0, x1, y1);
    }

    // ------------------------------------------------------------------ текст

    /** Ширина текста в пикселях (видимая, без хвостового промежутка). */
    public static int textWidth(String s, int scale, boolean bold) {
        if (s == null || s.isEmpty()) return 0;
        int sc = Math.max(1, scale), w = 0;
        for (int i = 0; i < s.length(); i++) w += PixelFont.advance(PixelFont.index(s.charAt(i))) * sc + (bold ? sc : 0);
        return w - sc;
    }

    public static int textWidth(String s) { return textWidth(s, 1, false); }

    public static int textHeight(int scale) { return PixelFont.H * Math.max(1, scale); }

    /** Обрезать строку с «...» так, чтобы она влезла в maxW. */
    public static String fit(String s, int maxW, int scale, boolean bold) {
        if (s == null) return "";
        if (textWidth(s, scale, bold) <= maxW) return s;
        for (int n = s.length() - 1; n > 0; n--) {
            String t = s.substring(0, n) + "...";
            if (textWidth(t, scale, bold) <= maxW) return t;
        }
        return "";
    }

    /** Текст 6x9 (y - верх строки). Возвращает x конца текста. */
    public int drawText(int x, int y, String s, int c) {
        return drawText(x, y, s, c, 1, false);
    }

    public int drawText(int x, int y, String s, int c, int scale, boolean bold) {
        if (s == null || s.isEmpty()) return x;
        int a = c >>> 24, rgb = c & 0xFFFFFF, sc = Math.max(1, scale);
        int tw = textWidth(s, sc, bold);
        if (a == 0 || y >= cy1 || y + PixelFont.H * sc <= cy0 || x >= cx1 || x + tw <= cx0) return x + tw;
        int px0 = x;
        for (int i = 0; i < s.length(); i++) {
            int idx = PixelFont.index(s.charAt(i));
            int adv = PixelFont.advance(idx), left = PixelFont.left(idx);
            long bits = PixelFont.bits(idx);
            if (bits != 0 && px0 < cx1) {
                for (int row = 0; row < PixelFont.H; row++)
                    for (int col = 0; col < adv - 1; col++)
                        if ((bits >> (row * PixelFont.CELL + col + left) & 1L) != 0) {
                            int gx = px0 + col * sc, gy = y + row * sc;
                            span(gx, gy, gx + sc, gy + sc, rgb, a);
                            if (bold) span(gx + sc, gy, gx + 2 * sc, gy + sc, rgb, a);
                        }
            }
            px0 += adv * sc + (bold ? sc : 0);
        }
        markClipped(x, y, x + tw, y + PixelFont.H * sc);
        return x + tw;
    }

    /** Текст по центру отрезка [x, x + w). */
    public void drawTextCentered(int x, int w, int y, String s, int c, int scale, boolean bold) {
        drawText(x + (w - textWidth(s, scale, bold)) / 2, y, s, c, scale, bold);
    }

    /** Текст, прижатый к правому краю xr. */
    public void drawTextRight(int xr, int y, String s, int c, int scale, boolean bold) {
        drawText(xr - textWidth(s, scale, bold), y, s, c, scale, bold);
    }

    // ------------------------------------------------------------------ сеть

    /**
     * Сервер: пакет для отправки или null. Ключевой кадр - при needKey и раз в 5 с, иначе дельта изменённых плиток.
     * Вызывать не чаще раза в 2 тика.
     */
    public byte[] poll(long tick) {
        boolean key = needKey || (active && tick % KEY_PERIOD == 1);
        if (!key) {
            if (!active || dirtyCount == 0) return null;
            if (dirtyCount > DELTA_MAX) key = true;
        }
        byte[] r = !active ? encode(KIND_OFF) : encode(key ? KIND_KEY : KIND_DELTA);
        clearDirty();
        needKey = false;
        return r;
    }

    /** Сервер: ключевой кадр для нового наблюдателя (последовательность не сдвигается, дельты других клиентов не ломаются). */
    public byte[] snapshot() {
        return encode(KIND_KEY, false);
    }

    private byte[] encode(int kind) {
        return encode(kind, true);
    }

    private byte[] encode(int kind, boolean advance) {
        byte[] raw;
        int rawLen;
        if (kind == KIND_OFF) {
            raw = new byte[0];
            rawLen = 0;
        } else if (kind == KIND_KEY) {
            raw = new byte[3 * fw * fh];
            rawLen = raw.length;
            for (int i = 0; i < fw * fh; i++) {
                int c = px[i];
                raw[i] = (byte) (c >> 16);
                raw[fw * fh + i] = (byte) (c >> 8);
                raw[2 * fw * fh + i] = (byte) c;
            }
        } else {
            int n = dirtyCount, ts = ptw * pth;
            rawLen = 2 + n * 2 + n * 3 * ts;
            raw = new byte[rawLen];
            ByteBuffer bb = ByteBuffer.wrap(raw);
            bb.putShort((short) n);
            for (int t = 0; t < ptiles; t++) if (dirty[t]) bb.putShort((short) t);
            for (int t = 0; t < ptiles; t++) {
                if (!dirty[t]) continue;
                int base = bb.position();
                int ox = (t % ptx) * ptw, oy = (t / ptx) * pth;
                for (int j = 0; j < pth; j++)
                    for (int i = 0; i < ptw; i++) {
                        int c = px[(oy + j) * fw + ox + i], k = j * ptw + i;
                        raw[base + k] = (byte) (c >> 16);
                        raw[base + ts + k] = (byte) (c >> 8);
                        raw[base + 2 * ts + k] = (byte) c;
                    }
                bb.position(base + 3 * ts);
            }
        }
        byte[] z = deflate(raw);
        int base = seq;
        if (advance) seq++;
        ByteBuffer out = ByteBuffer.allocate(14 + z.length);
        out.put((byte) kind).put((byte) (active ? 1 : 0)).putInt(seq).putInt(base).putInt(rawLen).put(z);
        return out.array();
    }

    /**
     * Клиент: применить пакет. false - дельта не подошла к текущему кадру (потерян кадр), ждём ключевой.
     */
    public boolean apply(byte[] d) {
        try {
            if (d == null || d.length < 14) return false;
            ByteBuffer in = ByteBuffer.wrap(d);
            int kind = in.get(), act = in.get(), nseq = in.getInt(), base = in.getInt(), rawLen = in.getInt();
            if (rawLen < 0 || rawLen > 3 * fw * fh + 2 + ptiles * (2 + 3 * ptw * pth)) return false;
            if (kind == KIND_OFF) {
                active = false;
                seq = nseq;
                hasFrame = false;
                version++;
                return true;
            }
            if (kind == KIND_DELTA && (!hasFrame || base != seq)) return false;
            byte[] raw = inflate(d, 14, d.length - 14, rawLen);
            if (raw == null) return false;
            if (kind == KIND_KEY) {
                if (rawLen != 3 * fw * fh) return false;
                for (int i = 0; i < fw * fh; i++)
                    px[i] = (raw[i] & 255) << 16 | (raw[fw * fh + i] & 255) << 8 | (raw[2 * fw * fh + i] & 255);
                hasFrame = true;
            } else if (kind == KIND_DELTA) {
                ByteBuffer bb = ByteBuffer.wrap(raw);
                int n = bb.getShort() & 0xFFFF, ts = ptw * pth;
                if (n > ptiles || rawLen != 2 + n * 2 + n * 3 * ts) return false;
                int[] idx = new int[n];
                for (int i = 0; i < n; i++) {
                    idx[i] = bb.getShort() & 0xFFFF;
                    if (idx[i] >= ptiles) return false;
                }
                for (int t = 0; t < n; t++) {
                    int b = bb.position(), ox = (idx[t] % ptx) * ptw, oy = (idx[t] / ptx) * pth;
                    for (int j = 0; j < pth; j++)
                        for (int i = 0; i < ptw; i++) {
                            int k = j * ptw + i;
                            px[(oy + j) * fw + ox + i] = (raw[b + k] & 255) << 16 | (raw[b + ts + k] & 255) << 8 | (raw[b + 2 * ts + k] & 255);
                        }
                    bb.position(b + 3 * ts);
                }
            } else return false;
            active = act != 0;
            seq = nseq;
            version++;
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static byte[] deflate(byte[] raw) {
        Deflater d = new Deflater(Deflater.BEST_SPEED);
        try {
            d.setInput(raw);
            d.finish();
            ByteArrayOutputStream o = new ByteArrayOutputStream(raw.length / 8 + 64);
            byte[] buf = new byte[8192];
            while (!d.finished()) o.write(buf, 0, d.deflate(buf));
            return o.toByteArray();
        } finally {
            d.end();
        }
    }

    private static byte[] inflate(byte[] src, int off, int len, int rawLen) {
        Inflater inf = new Inflater();
        try {
            inf.setInput(src, off, len);
            byte[] out = new byte[rawLen];
            int got = 0;
            while (got < rawLen) {
                int n = inf.inflate(out, got, rawLen - got);
                if (n == 0 && (inf.finished() || inf.needsInput() || inf.needsDictionary())) break;
                got += n;
            }
            return got == rawLen ? out : null;
        } catch (DataFormatException e) {
            return null;
        } finally {
            inf.end();
        }
    }
}
