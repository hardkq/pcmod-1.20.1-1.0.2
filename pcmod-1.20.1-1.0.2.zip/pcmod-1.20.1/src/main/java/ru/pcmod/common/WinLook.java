package ru.pcmod.common;

/**
 * Оформление WinCraft 11: тема (светлая, тёмная, по времени суток), акцентный цвет, обои, прозрачность (Mica) и
 * анимации окон. Настройки применяются сразу к WinTheme и сохраняются на накопителе (настройка "look").
 * Прозрачность и анимации работают только если железо ПК это тянет (WinSpec.Perf), иначе настройка ни на что не влияет.
 */
public final class WinLook {
    public static final String[] MODES = {"Светлая", "Тёмная", "Авто"};
    public static final String[] ACCENT_NAMES = {"Синий", "Голубой", "Бирюзовый", "Зелёный", "Золотой", "Оранжевый", "Красный", "Розовый", "Фиолетовый"};
    public static final int[] ACCENTS = {0xFF0067C0, 0xFF0099BC, 0xFF038387, 0xFF107C10, 0xFFB38600, 0xFFCA5010, 0xFFC42B1C, 0xFFE3008C, 0xFF744DA9};
    private static final String KEY = "look";

    private final WinTheme th;
    private final WinSpec.Perf perf;
    private final WinHost h;
    public int mode, accent, wall;
    public boolean trans = true, anim = true;
    /** Формат времени и даты (на накопителе - настройка "clock"). */
    public boolean h12;
    public int dateFmt;
    private boolean changed;

    public WinLook(WinTheme th, WinSpec.Perf perf, WinHost h) {
        this.th = th;
        this.perf = perf;
        this.h = h;
        load();
        loadClock();
        apply();
    }

    /** Железо тянет прозрачность и Mica. */
    public boolean glassSupported() { return perf.effects; }

    /** Железо тянет анимации окон. */
    public boolean animSupported() { return perf.anims; }

    private void load() {
        String s = h.pref(KEY);
        if (s == null || s.isEmpty()) return;
        String[] a = s.split(",");
        if (a.length != 5) return;
        try {
            int m = Integer.parseInt(a[0].trim()), c = Integer.parseInt(a[1].trim()), w = Integer.parseInt(a[2].trim());
            if (m < 0 || m >= MODES.length || c < 0 || c >= ACCENTS.length || w < 0 || w >= WinWalls.COUNT) return;
            mode = m;
            accent = c;
            wall = w;
            trans = !a[3].trim().equals("0");
            anim = !a[4].trim().equals("0");
        } catch (NumberFormatException e) {
            // повреждённая настройка: остаются значения по умолчанию
        }
    }

    private void loadClock() {
        String c = h.pref("clock");
        if (c == null) return;
        String[] a = c.split(",");
        if (a.length != 2) return;
        try {
            int f = Integer.parseInt(a[1].trim());
            if (f < 0 || f >= WinClock.DATE_FMT.length) return;
            h12 = a[0].trim().equals("1");
            dateFmt = f;
        } catch (NumberFormatException e) {
            // повреждённая настройка: остаются значения по умолчанию
        }
    }

    private boolean wantDark() {
        if (mode == 1) return true;
        if (mode == 0) return false;
        int hr = WinClock.hour(h.dayTime());
        return hr >= 20 || hr < 7;
    }

    /** Перенести настройки в тему. */
    private void apply() {
        th.dark = wantDark();
        int base = ACCENTS[accent];
        th.accent = th.dark ? PixelScreen.lerp(base, 0xFFFFFFFF, 0.2f) | 0xFF000000 : base;
        th.wall = wall;
        th.glass = perf.effects && trans;
        th.anim = perf.anims && anim;
        th.h12 = h12;
        th.dateFmt = dateFmt;
    }

    private void commit() {
        h.setPref(KEY, mode + "," + accent + "," + wall + "," + (trans ? 1 : 0) + "," + (anim ? 1 : 0));
        apply();
        changed = true;
    }

    public void setMode(int m) {
        if (m < 0 || m >= MODES.length || m == mode) return;
        mode = m;
        commit();
    }

    public void setAccent(int i) {
        if (i < 0 || i >= ACCENTS.length || i == accent) return;
        accent = i;
        commit();
    }

    public void setWall(int i) {
        if (i < 0 || i >= WinWalls.COUNT || i == wall) return;
        wall = i;
        commit();
    }

    public void setTrans(boolean b) {
        if (b == trans) return;
        trans = b;
        commit();
    }

    public void setAnim(boolean b) {
        if (b == anim) return;
        anim = b;
        commit();
    }

    /** Формат часов и даты: применяется сразу и сохраняется. */
    public void setClock(boolean h12, int fmt) {
        if (fmt < 0 || fmt >= WinClock.DATE_FMT.length || (h12 == this.h12 && fmt == dateFmt)) return;
        this.h12 = h12;
        dateFmt = fmt;
        h.setPref("clock", (h12 ? 1 : 0) + "," + fmt);
        apply();
        changed = true;
    }

    /** Часовой пояс сменился: часы и тема «Авто» пересчитываются, экран перерисовывается. */
    public void clockChanged() {
        apply();
        changed = true;
    }

    /** Оформление изменилось: экран надо перерисовать целиком (флаг сбрасывается). */
    public boolean consume() {
        boolean c = changed;
        changed = false;
        return c;
    }

    /** Раз в тик: в режиме «Авто» тема меняется по времени суток. true - тема сменилась. */
    public boolean tick(long now) {
        if (mode != 2 || now % 100 != 0 || wantDark() == th.dark) return false;
        apply();
        return true;
    }
}
