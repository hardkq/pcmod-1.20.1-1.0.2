package ru.pcmod.common;

import java.time.LocalDate;

/** Время и дата WinCraft 11 по игровому времени мира (игровые сутки = календарные сутки). Часовой пояс уже учтён в dayTime. */
public final class WinClock {
    private WinClock() {}

    private static final String[] WEEKDAY = {"понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"};
    private static final String[] MONTH = {"января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа",
            "сентября", "октября", "ноября", "декабря"};
    private static final LocalDate START = LocalDate.of(2026, 9, 1);

    /** Форматы даты (настройка «Время»). */
    public static final String[] DATE_FMT = {"ДД.ММ.ГГГГ", "ГГГГ-ММ-ДД", "ДД/ММ/ГГГГ"};

    public static int hour(long dayTime) {
        return (int) ((Math.floorMod(dayTime, 24000L) / 1000L + 6L) % 24L);
    }

    public static int minute(long dayTime) {
        return (int) (Math.floorMod(dayTime, 1000L) * 60L / 1000L);
    }

    /** Номер минуты от начала мира: меняется раз в игровую минуту. */
    public static long stamp(long dayTime) {
        return Math.floorDiv(dayTime + 6000L, 24000L) * 1440L + hour(dayTime) * 60L + minute(dayTime);
    }

    public static LocalDate date(long dayTime) {
        return START.plusDays(Math.floorDiv(dayTime + 6000L, 24000L));
    }

    private static String two(int v) {
        return (v < 10 ? "0" : "") + v;
    }

    private static String hm(int h, int m, boolean h12) {
        if (!h12) return two(h) + ":" + two(m);
        return two(h % 12 == 0 ? 12 : h % 12) + ":" + two(m) + (h < 12 ? " AM" : " PM");
    }

    private static String ymd(LocalDate d, int fmt) {
        if (fmt == 1) return d.getYear() + "-" + two(d.getMonthValue()) + "-" + two(d.getDayOfMonth());
        char sep = fmt == 2 ? '/' : '.';
        return two(d.getDayOfMonth()) + sep + two(d.getMonthValue()) + sep + d.getYear();
    }

    public static String time(long dayTime) {
        return time(dayTime, false);
    }

    public static String time(long dayTime, boolean h12) {
        return hm(hour(dayTime), minute(dayTime), h12);
    }

    public static String dateShort(long dayTime) {
        return dateShort(dayTime, 0);
    }

    /** Короткая дата в формате DATE_FMT[fmt]. */
    public static String dateShort(long dayTime, int fmt) {
        return ymd(date(dayTime), fmt);
    }

    /** «воскресенье, 8 ноября». */
    public static String dateLong(long dayTime) {
        LocalDate d = date(dayTime);
        return WEEKDAY[d.getDayOfWeek().getValue() - 1] + ", " + d.getDayOfMonth() + " " + MONTH[d.getMonthValue() - 1];
    }

    /** Дата и время по номеру минуты (stamp), например «08.11.2026, 14:05». */
    public static String stampText(long stamp, boolean h12, int fmt) {
        LocalDate d = START.plusDays(Math.floorDiv(stamp, 1440L));
        int m = (int) Math.floorMod(stamp, 1440L);
        return ymd(d, fmt) + ", " + hm(m / 60, m % 60, h12);
    }
}
