package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

/** Связь WinCraft 11 с ComputerLogic: железо, учётная запись, питание, установка и BIOS. */
final class WinBridge implements WinHost {
    private final ComputerLogic l;

    WinBridge(ComputerLogic l) {
        this.l = l;
    }

    @Override public PixelScreen pix() { return l.t.pixel(); }

    @Override public void setMouse(PixelScreen.MouseListener m) { l.pixelMouse = m; }

    @Override public long time() { return l.t.getLevel().getGameTime(); }

    /** Время мира со сдвигом часового пояса (настройка «Время»). */
    @Override public long dayTime() { return l.t.getLevel().getDayTime() + tzHours() * 1000L; }

    private int tzHours() {
        try {
            return Math.max(-12, Math.min(14, Integer.parseInt(pref("tz").trim())));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override
    public WinSpec.Hw hw() {
        TileComputer t = l.t;
        WinSpec.Hw h = new WinSpec.Hw();
        PartSpec cpu = t.spec(TileComputer.CPU), gpu = t.spec(TileComputer.GPU), sto = t.spec(TileComputer.STORAGE),
                mb = t.spec(TileComputer.MB);
        h.cores = cpu == null ? 0 : cpu.cores;
        h.ghz = cpu == null ? 0 : cpu.ghz;
        h.cpu = ComputerLogic.lab(cpu);
        h.ramMB = t.totalRamMB();
        h.vramMB = gpu == null ? 0 : gpu.vram;
        h.gpuTier = gpu == null ? 0 : gpu.tier;
        h.gpu = ComputerLogic.lab(gpu);
        h.driveKB = sto == null ? 0 : sto.storageKB;
        h.driveSpeed = sto == null ? 1 : Math.max(1, sto.speed);
        h.drive = sto == null ? "" : sto.label;
        h.mb = ComputerLogic.lab(mb);
        h.fastBoot = t.fastBoot;
        return h;
    }

    @Override
    public String userName() {
        CompoundTag r = l.root();
        return r == null ? "" : r.getString("user");
    }

    @Override
    public boolean checkPass(String pass) {
        CompoundTag r = l.root();
        return r != null && VFS.hash(pass).equals(r.getString("pass"));
    }

    private WinSvc svc;

    @Override
    public WinSvc svc() {
        if (svc == null) svc = new WinSvcImpl(l);
        return svc;
    }

    @Override
    public WinFs fs() {
        return new WinFsImpl(l::root, () -> {
            PartSpec sto = l.t.spec(TileComputer.STORAGE);
            return sto == null ? 0 : sto.storageKB;
        }, () -> l.t.setChanged());
    }

    @Override public int temp() { return (int) l.t.temp; }

    @Override public void loginOk() { l.winLoginOk(); }

    @Override public void powerOff() { l.shutDown(null); }

    @Override public void restart() { l.startUp(); }

    @Override
    public void install(String host, String user, String pass) {
        ItemStack d = l.t.getItem(TileComputer.STORAGE);
        VFS.format(d);
        VFS.install(d, user, pass, host, WinSpec.ID);
        l.t.setChanged();
    }

    /** Режим «в самолёте» (настройка «Сеть»): сеть для системы отсутствует. */
    private boolean air() { return "1".equals(pref("air")); }

    @Override public int netType() { return air() ? NetLink.NONE : l.link().type; }

    @Override public int netSignal() { return air() ? 0 : l.link().signal; }

    @Override
    public long[] disk() {
        CompoundTag r = l.root();
        PartSpec sto = l.t.spec(TileComputer.STORAGE);
        return new long[] {sto == null ? 0 : sto.storageKB * 1024L, r == null ? 0 : VFS.osSize(r), r == null ? 0 : VFS.usedBytes(r)};
    }

    @Override
    public String hostName() {
        CompoundTag r = l.root();
        return r == null ? "" : r.getString("host");
    }

    @Override public long uptime() { return Math.max(0, l.t.getLevel().getGameTime() - l.bootTime); }

    @Override public boolean wifiModule() { return l.t.spec(TileComputer.NET) != null; }

    @Override
    public List<String[]> wifiScan() {
        List<String[]> r = new ArrayList<String[]>();
        for (Net.Ap a : Net.scan(l.t)) r.add(new String[] {a.ssid, String.valueOf(a.signal), a.secured ? "1" : "0"});
        return r;
    }

    @Override
    public String wifiSaved() {
        CompoundTag r = l.root();
        return r == null ? "" : r.getString("wifi_ssid");
    }

    @Override
    public String wifiConnect(String ssid, String pass) {
        CompoundTag r = l.root();
        if (r == null) return "Система не установлена";
        int res = Net.check(l.t, ssid, pass);
        if (res == Net.OK) {
            r.putString("wifi_ssid", ssid);
            r.putString("wifi_pass", pass);
            l.relink();
            return null;
        }
        if (res == Net.NO_MODULE) return "Нет модуля Wi-Fi";
        if (res == Net.BAD_PASS) return "Неверный пароль";
        return "Сеть вне зоны действия";
    }

    @Override
    public void wifiForget() {
        CompoundTag r = l.root();
        if (r == null) return;
        r.remove("wifi_ssid");
        r.remove("wifi_pass");
        l.relink();
    }

    /** Причины отсутствия сети из Net.resolve по-русски. */
    private static String ru(String s) {
        if (s.equals("Not connected")) return "Нет подключения";
        if (s.equals("Cable has no router")) return "Кабель есть, но нет роутера";
        if (s.equals("No cable, no Wi-Fi module")) return "Нет кабеля и модуля Wi-Fi";
        if (s.equals("Wi-Fi: not connected")) return "Wi-Fi не подключён";
        if (s.equals("Wi-Fi: wrong password")) return "Wi-Fi: неверный пароль";
        if (s.startsWith("Wi-Fi: ") && s.endsWith(" out of range")) return "Сеть " + s.substring(7, s.length() - 13) + " вне зоны действия";
        return s;
    }

    @Override public String netStatus() { return ru(l.link().status); }

    @Override
    public List<String[]> netInfo() {
        NetLink k = l.link();
        List<String[]> r = new ArrayList<String[]>();
        r.add(new String[] {"Подключение", k.type == NetLink.WIRED ? "Ethernet (кабель)" : k.type == NetLink.WIFI ? "Wi-Fi " + k.ssid : ru(k.status)});
        if (!k.up()) return r;
        r.add(new String[] {"Шлюз", k.router == null ? "-" : k.router.ssid});
        if (k.type == NetLink.WIFI) r.add(new String[] {"Сигнал", NetLink.bars(k.signal)});
        StringBuilder b = new StringBuilder();
        for (TileServer sv : k.servers) b.append(b.length() > 0 ? ", " : "").append(sv.domain);
        r.add(new String[] {"Серверы", k.servers.isEmpty() ? "нет" : b.toString()});
        return r;
    }

    @Override
    public String pref(String key) {
        CompoundTag r = l.root();
        return r == null ? "" : r.getString("wc_" + key);
    }

    @Override
    public void setPref(String key, String value) {
        CompoundTag r = l.root();
        if (r == null) return;
        r.putString("wc_" + key, value);
        l.t.setChanged();
    }

    @Override public int bootOrder() { return l.t.bootOrder; }

    @Override public boolean fastBoot() { return l.t.fastBoot; }

    @Override
    public void saveBios(int order, boolean fast) {
        l.t.bootOrder = order;
        l.t.fastBoot = fast;
        l.t.setChanged();
        l.startUp();
    }

    @Override
    public List<String[]> biosMain() {
        TileComputer t = l.t;
        PartSpec cpu = t.spec(TileComputer.CPU), mb = t.spec(TileComputer.MB), gpu = t.spec(TileComputer.GPU),
                sto = t.spec(TileComputer.STORAGE), med = t.spec(TileComputer.MEDIA), psu = t.spec(TileComputer.PSU);
        List<String[]> r = new ArrayList<String[]>();
        r.add(new String[] {"CPU", ComputerLogic.lab(cpu) + " (" + PartSpec.socketName(cpu.socket) + ")"});
        r.add(new String[] {"Cores/Clock", cpu.cores + " x " + cpu.ghz + " GHz"});
        r.add(new String[] {"Motherboard", ComputerLogic.lab(mb) + " (" + mb.ramSlots + " x " + PartSpec.ramName(mb.ramType) + ")"});
        r.add(new String[] {"Memory", t.totalRamMB() + " MB"});
        StringBuilder dimms = new StringBuilder();
        for (int i = TileComputer.RAM0; i <= TileComputer.RAM3; i++) {
            PartSpec m = t.spec(i);
            if (m != null) dimms.append(dimms.length() > 0 ? ", " : "").append(m.label);
        }
        r.add(new String[] {"DIMMs", dimms.length() > 0 ? dimms.toString() : "none"});
        r.add(new String[] {"Video", ComputerLogic.lab(gpu) + ", " + gpu.vram + " MB"});
        String os = !t.getItem(TileComputer.STORAGE).isEmpty() && VFS.hasOS(t.getItem(TileComputer.STORAGE))
                ? VFS.osName(l.root()) + " installed" : "no OS";
        r.add(new String[] {"Storage", ComputerLogic.lab(sto) + (sto != null ? " [" + os + "]" : "")});
        r.add(new String[] {"Boot media", ComputerLogic.lab(med)});
        r.add(new String[] {"PSU", ComputerLogic.lab(psu)});
        r.add(new String[] {"Network", t.spec(TileComputer.NET) == null ? "Ethernet only" : "Ethernet + " + ComputerLogic.lab(t.spec(TileComputer.NET))});
        r.add(new String[] {"Time", l.clock()});
        return r;
    }

    @Override
    public List<String[]> biosMonitor() {
        TileComputer t = l.t;
        PartSpec cool = t.spec(TileComputer.COOLER), psu = t.spec(TileComputer.PSU);
        int temp = (int) t.temp, mon = t.monitorType();
        List<String[]> r = new ArrayList<String[]>();
        r.add(new String[] {"Display", mon < 0 ? "none" : MonitorType.get(mon).describe()});
        r.add(new String[] {"CPU temperature", temp + " C", temp >= 85 ? "bad" : ""});
        r.add(new String[] {"CPU thermal limit", "100 C (auto shutdown)"});
        r.add(new String[] {"Cooler", ComputerLogic.lab(cool) + (cool != null ? " (rating " + cool.cooling + ")" : "")});
        r.add(new String[] {"PSU load", t.requiredWatts() + " W / " + psu.watts + " W"});
        for (String w : t.warnings()) r.add(new String[] {"!", w, "warn"});
        return r;
    }
}
