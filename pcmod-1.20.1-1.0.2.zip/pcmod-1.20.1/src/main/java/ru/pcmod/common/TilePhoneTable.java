package ru.pcmod.common;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Стол сборки телефонов: 10 входных слотов (PhoneParts) + выход. */
public class TilePhoneTable extends BlockEntity implements Container {
    public static final int SIZE = PhoneParts.IN + 1;
    private final NonNullList<ItemStack> inv = NonNullList.withSize(SIZE, ItemStack.EMPTY);

    public TilePhoneTable(BlockPos pos, BlockState st) { super(ModBlockEntities.PHONE_TABLE.get(), pos, st); }

    /** Сборка по кнопке (сервер). Возвращает сообщение игроку. */
    public Component assemble() {
        if (!inv.get(PhoneParts.OUT).isEmpty()) return Component.translatable("gui.pcmod.phone.busy");
        List<Component> errs = PhoneParts.check(this);
        if (!errs.isEmpty()) return errs.get(0);
        inv.set(PhoneParts.OUT, PhoneParts.build(this));
        for (int i = 0; i < PhoneParts.IN; i++) inv.set(i, ItemStack.EMPTY);
        setChanged();
        return Component.translatable("gui.pcmod.phone.done");
    }

    @Override public int getContainerSize() { return SIZE; }
    @Override public boolean isEmpty() { for (ItemStack s : inv) if (!s.isEmpty()) return false; return true; }
    @Override public ItemStack getItem(int i) { return i >= 0 && i < SIZE ? inv.get(i) : ItemStack.EMPTY; }
    @Override public ItemStack removeItem(int i, int n) {
        ItemStack r = ContainerHelper.removeItem(inv, i, n);
        if (!r.isEmpty()) setChanged();
        return r;
    }
    @Override public ItemStack removeItemNoUpdate(int i) { return ContainerHelper.takeItem(inv, i); }
    @Override public void setItem(int i, ItemStack s) {
        if (i < 0 || i >= SIZE) return;
        inv.set(i, s == null ? ItemStack.EMPTY : s);
        setChanged();
    }
    @Override public int getMaxStackSize() { return 1; }
    @Override public boolean stillValid(Player p) {
        BlockPos b = getBlockPos();
        return level != null && level.getBlockEntity(b) == this && p.distanceToSqr(b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5) <= 64.0;
    }
    @Override public boolean canPlaceItem(int i, ItemStack s) {
        PartSpec sp = PhoneParts.spec(s);
        return i >= 0 && i < PhoneParts.IN && sp != null && sp.cat == PhoneParts.CAT[i];
    }
    @Override public void clearContent() { inv.clear(); }

    @Override public void load(CompoundTag t) {
        super.load(t);
        inv.clear();
        ContainerHelper.loadAllItems(t, inv);
    }
    @Override protected void saveAdditional(CompoundTag t) {
        super.saveAdditional(t);
        ContainerHelper.saveAllItems(t, inv);
    }
}
