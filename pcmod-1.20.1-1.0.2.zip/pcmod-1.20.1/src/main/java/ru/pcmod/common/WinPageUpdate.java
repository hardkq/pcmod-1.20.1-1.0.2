package ru.pcmod.common;

/** Страница «Обновление»: проверка обновлений (время последней проверки хранится в настройке "upd"), версия и сборка. */
final class WinPageUpdate extends WinFormPage {
    private final WinTheme th;
    private final WinSpec.Perf perf;
    private final WinSettings.Ctx ctx;
    /** Когда закончится проверка (тики), -1 - не идёт. */
    private long until = -1;

    WinPageUpdate(WinHost host, WinTheme th, WinSpec.Perf perf, WinSettings.Ctx ctx) {
        super(host);
        this.th = th;
        this.perf = perf;
        this.ctx = ctx;
    }

    private String lastCheck() {
        try {
            return WinClock.stampText(Long.parseLong(host.pref("upd").trim()), th.h12, th.dateFmt);
        } catch (NumberFormatException e) {
            return "ещё не проводилась";
        }
    }

    private void check() {
        until = host.time() + 60;
    }

    @Override
    void build(WinForm f) {
        boolean busy = until >= 0;
        f.section("Центр обновления");
        WinForm.Row r = f.card(busy ? "Проверка обновлений..." : "Обновлений нет").sub(busy ? "Подождите" : "Проверка: " + lastCheck());
        if (busy) r.spin();
        else r.state(2);
        r.button("Проверить", !busy, this::check);
        f.section("Сведения");
        f.card("Выпуск").value(WinSpec.NAME);
        f.card("Версия").value(WinSpec.VERSION);
        f.card("Сборка").value(WinSpec.BUILD);
        f.section("Дополнительно");
        f.card("Перезагрузить сейчас").sub("Применить изменения").button("Выполнить", true, () -> ctx.power(1));
    }

    @Override
    public boolean tick(long now) {
        if (until < 0) return false;
        if (now >= until) {
            until = -1;
            host.setPref("upd", String.valueOf(WinClock.stamp(host.dayTime())));
            form.refresh();
            return true;
        }
        return now % perf.animDiv == 0;
    }
}
