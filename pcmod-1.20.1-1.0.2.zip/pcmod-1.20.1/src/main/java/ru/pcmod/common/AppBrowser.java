package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import ru.pcmod.common.BrowserCore.Tab;
import static ru.pcmod.common.PixelScreen.rgb;

/**
 * Приложение «Браузер»: сайты PC-Net (встроенные и игроков), до 4 вкладок, закладки, история, подсказки адреса, обновление,
 * загрузка по скорости канала (Wi-Fi или сотовая 4G), страницы ошибок и кэш. Логика - в {@link BrowserCore}, рендер - в {@link WebView}.
 */
final class AppBrowser implements AndroOs.App {
    private static final int TB = 46, TBH = 20, TOP = 71, VIEW = 227;
    private static final int PH_HEAD = 20, PH_ROW = 28;

    /** Строка панели (вкладки, закладки, история, адрес). */
    private static final class Item {
        final String label, sub, act, del;
        final boolean head;

        Item(boolean head, String label, String sub, String act, String del) {
            this.head = head;
            this.label = label;
            this.sub = sub;
            this.act = act;
            this.del = del;
        }
    }

    private static final class St {
        final BrowserCore core = new BrowserCore();
        boolean init, loaded;
        /** 0 страница, 1 вкладки и меню, 2 закладки, 3 история, 4 адрес и подсказки. */
        int mode;
        String typed = "", confirm = "", msg = "";
        boolean ok;
        long until;
        final AppUi.Scroll sc = new AppUi.Scroll(), psc = new AppUi.Scroll();
        final WebView view = new WebView();
        int contentH, panelH;
        List<Item> items = new ArrayList<Item>();
        List<Integer> itemY = new ArrayList<Integer>();
    }

    private static St st(AndroOs os) {
        St s = os.state("browser", St::new);
        ItemStack stack = os.stack();
        if (!s.loaded && !stack.isEmpty()) {
            s.loaded = true;
            CompoundTag d = PhoneData.d(stack);
            BrowserCore.split(d.getString("BrBm"), s.core.bookmarks, BrowserCore.MAX_BM);
            BrowserCore.split(d.getString("BrHist"), s.core.history, BrowserCore.MAX_HIST);
        }
        if (!s.init) {
            s.init = true;
            load(os, s, s.core.tab(), false);
        }
        return s;
    }

    private static void save(AndroOs os, St st) {
        ItemStack stack = os.stack();
        if (stack.isEmpty()) return;
        CompoundTag d = PhoneData.d(stack);
        d.putString("BrBm", BrowserCore.join(st.core.bookmarks));
        d.putString("BrHist", BrowserCore.join(st.core.history));
    }

    private static void r(List<WebRow> o, char k, String t, String tg) { o.add(new WebRow(k, t, tg)); }

    private static void say(AndroOs os, St st, String m, boolean ok) { st.msg = m; st.ok = ok; st.until = os.now() + 100; os.dirty(); }

    // ------------------------------------------------------------------ канал и загрузка
    /** Канал телефона: Wi-Fi сети мода, иначе сотовая сеть 4G, иначе нет связи. */
    private static int chan(AndroOs os) { return AppNet.wifi(os) ? BrowserCore.WIFI : os.cellular() ? BrowserCore.CELL : BrowserCore.NONE; }

    private static int signal(AndroOs os, int ch) { return ch == BrowserCore.WIFI ? os.link.signal : os.net; }

    private static String chanName(int ch) { return ch == BrowserCore.WIFI ? "Wi-Fi" : ch == BrowserCore.CELL ? "4G" : "-"; }

    private static String kbs(AndroOs os, double rate) {
        int t = (int) Math.round(rate / 102.4);
        return t / 10 + (os.lang == 0 ? "," : ".") + t % 10 + os.t(" КБ/с", " KB/s");
    }

    /** Начать загрузку вкладки: страница строится или запрашивается у сервера сразу, индикатор идёт по скорости канала. */
    private static void load(AndroOs os, St st, Tab t, boolean useCache) {
        t.page = null;
        t.stale = false;
        if (chan(os) == BrowserCore.NONE) { t.loading = false; return; }
        // мобильный интернет: каждый запрос стоит MB_PER_REQUEST Мб с SIM (страница из кэша бесплатна)
        if (chan(os) == BrowserCore.CELL && !(useCache && st.core.cacheGet(t.url) != null) && !PhoneSim.spend(os, PhoneSim.MB_PER_REQUEST)) {
            t.loading = false;
            String m = os.t("Недостаточно трафика", "Not enough data");
            say(os, st, m, false);
            os.notify(os.t("Мобильный интернет", "Mobile data"), m);
            return;
        }
        boolean cached = false;
        WebPage pg;
        if (WinWeb.isBuiltin(t.url)) pg = builtin(os, t.url);
        else {
            cached = fetch(os, st, t, useCache);
            pg = t.page;
        }
        st.core.startLoad(t, BrowserCore.weight(pg), cached);
    }

    /** Страница сайта игрока. true - взята из кэша без запроса. Недоступный сервер при наличии копии - показ копии. */
    private static boolean fetch(AndroOs os, St st, Tab t, boolean useCache) {
        WebPage c = st.core.cacheGet(t.url);
        t.pageUrl = t.url;
        if (useCache && c != null) {
            t.page = c;
            return true;
        }
        String[] a = WinWeb.split(t.url);
        SiteHost.Resp rs = SiteHost.fetch(chan(os) != BrowserCore.NONE, AppMessages.server(os), a[0], a[1], os.ses != null ? AppNet.id(os) : "");
        if (rs.code == SiteHost.OK) {
            t.page = WinWeb.site(rs, os.lang == 0);
            st.core.cachePut(t.url, t.page);
        } else if (c != null && (rs.code == SiteHost.UNAVAILABLE || rs.code == SiteHost.NO_NET)) {
            t.page = c;
            t.stale = true;
        } else t.page = WinWeb.site(rs, os.lang == 0);
        return false;
    }

    private static WebPage withBanner(AndroOs os, WebPage c) {
        List<WebRow> l = new ArrayList<WebRow>();
        l.add(new WebRow('e', os.t("Нет связи с сервером: показана сохранённая копия.", "No server connection: showing a saved copy."), null));
        l.addAll(c.rows);
        WebPage p = new WebPage(l);
        p.bg = c.bg;
        p.title = c.title;
        return p;
    }

    /** Страница, которую нужно показать сейчас. */
    private static WebPage current(AndroOs os, St st, Tab t) {
        boolean builtin = WinWeb.isBuiltin(t.url);
        if (chan(os) == BrowserCore.NONE) {
            WebPage c = builtin ? null : st.core.cacheGet(t.url);
            if (c != null) return withBanner(os, c);
            List<WebRow> o = new ArrayList<WebRow>();
            r(o, 'h', os.t("Нет подключения к сети", "No network connection"), null);
            r(o, 't', "", null);
            r(o, 't', os.t("Подключитесь к Wi-Fi или включите мобильную сеть в Настройках телефона.", "Connect to Wi-Fi or turn on mobile data in phone Settings."), null);
            return WebPage.of(o);
        }
        if (builtin) return builtin(os, t.url);
        if (t.page == null || !t.pageUrl.equals(t.url)) fetch(os, st, t, true);
        return t.stale ? withBanner(os, t.page) : t.page;
    }

    // ------------------------------------------------------------------ навигация
    private static void navigate(AndroOs os, St st, String raw) {
        Tab t = st.core.tab();
        st.core.go(t, raw);
        st.mode = 0;
        st.sc.off = 0;
        st.msg = "";
        load(os, st, t, false);
        save(os, st);
        os.dirty();
    }

    private static void refresh(AndroOs os, St st) {
        Tab t = st.core.tab();
        t.scroll = 0;
        st.sc.off = 0;
        load(os, st, t, false);
        os.dirty();
    }

    private static void switchTab(St st, int i) {
        st.core.tab().scroll = st.sc.off;
        st.core.cur = Math.max(0, Math.min(i, st.core.tabs.size() - 1));
        st.sc.off = st.core.tab().scroll;
        st.mode = 0;
    }

    private static String title(Tab t) { return t.page != null && !t.page.title.isEmpty() && t.pageUrl.equals(t.url) ? t.page.title : t.url; }

    private static void openAddress(AndroOs os, St st) {
        st.mode = 4;
        st.typed = "";
        st.psc.off = 0;
        os.input(os.t("Адрес сайта", "Site address"), st.core.tab().url, 40, 0, v -> {
            st.typed = v.trim();
            if (st.typed.isEmpty()) { os.dirty(); return; }
            if (st.typed.contains(".") || st.typed.contains("/") || st.core.suggest(st.typed, 1).isEmpty()) navigate(os, st, st.typed);
            else { st.mode = 4; st.psc.off = 0; os.dirty(); }
        });
    }

    /** Действие ссылки на странице. dl: и buy: сначала запрашивают подтверждение. */
    private static void link(AndroOs os, St st, String tg) {
        if (SiteWidgets.isAction(tg)) action(os, st, tg);
        else if (tg.startsWith("app:")) os.open(tg.substring(4));
        else if (tg.startsWith("buy:") || tg.startsWith("dl:")) { st.confirm = tg; os.dirty(); }
        else navigate(os, st, tg);
    }

    /** Действие сайта: гостевая книга, форма, донат, платный доступ, оценка, жалоба, поиск. Поле ввода - экранная клавиатура телефона. */
    private static void action(AndroOs os, St st, String tg) {
        boolean ru = os.lang == 0;
        String pr = SiteWidgets.prompt(tg, ru);
        if (pr == null) run(os, st, tg, "");
        else os.input(pr, "", SiteWidgets.maxLen(tg), 0, v -> run(os, st, tg, v));
    }

    private static void run(AndroOs os, St st, String tg, String in) {
        if (tg.startsWith("search:")) {
            navigate(os, st, SiteWidgets.searchUrl(in));
            return;
        }
        if (os.ses == null) {
            say(os, st, os.t("Нет связи", "No connection"), false);
            return;
        }
        TileServer srv = AppMessages.server(os);
        String e = SiteHost.reach(AppNet.wifi(os), srv);
        Bank.Res r = e != null ? new Bank.Res(false, e) : SiteStore.act(AppNet.player(os), srv, tg, in);
        say(os, st, AppNet.tr(os, r.msg), r.ok);
        if (r.ok) load(os, st, st.core.tab(), false);
    }

    private static void confirmed(AndroOs os, St st, String tg) {
        boolean[] ok = new boolean[1];
        String m = tg.startsWith("buy:") ? AppStore.buy(os, tg.substring(4), ok) : AppStore.begin(os, tg.substring(3), ok);
        say(os, st, m, ok[0]);
    }

    private static String confirmText(AndroOs os, String tg) {
        boolean buy = tg.startsWith("buy:");
        String id = tg.substring(buy ? 4 : 3);
        AppStore.Info i = AppStore.info(id);
        String n = i == null ? id : os.t(i.ru, i.en);
        if (buy) return os.t("Купить «", "Buy \"") + n + os.t("» за ", "\" for ") + (i == null ? 0 : i.price) + " K?";
        return os.t("Скачать «", "Download \"") + n + os.t("»?", "\"?");
    }

    // ------------------------------------------------------------------ встроенные сайты
    private static WebPage builtin(AndroOs os, String url) {
        if (url.equals("search.pc") || url.startsWith("search.pc/")) return WebPage.of(SiteWidgets.searchRows(url, os.lang == 0, SiteStore::search));
        List<WebRow> o = new ArrayList<WebRow>();
        switch (url) {
            case "home.pc" -> {
                r(o, 'h', "PC-Net", null);
                r(o, 't', os.t("Внутриигровой интернет. Те же сайты, что и на ПК, плюс мобильные сервисы.", "The in-game internet. Same sites as on PC, plus mobile services."), null);
                r(o, 't', "", null);
                r(o, 'l', os.t("AndroStore (apps.pc) - приложения", "AndroStore (apps.pc) - apps"), "apps.pc");
                r(o, 'l', os.t("Магазин программ (soft.pc)", "Software store (soft.pc)"), "soft.pc");
                r(o, 'l', os.t("Банк - открыть приложение", "Bank - open the app"), "app:bank");
                r(o, 'l', os.t("Магазин - открыть приложение", "Shop - open the app"), "app:shop");
                r(o, 'l', os.t("PC-News (news.pc) - новости", "PC-News (news.pc) - news"), "news.pc");
                r(o, 'l', os.t("Справка (help.pc)", "Help (help.pc)"), "help.pc");
                r(o, 'l', os.t("GameZone (games.pc), SafeGuard (av.pc)", "GameZone (games.pc), SafeGuard (av.pc)"), "games.pc");
                r(o, 't', "", null);
                r(o, 'd', os.t("Нажмите на адрес сверху, чтобы ввести другой.", "Tap the address bar to enter another."), null);
            }
            case "apps.pc" -> {
                r(o, 'h', "AndroStore", null);
                r(o, 'd', os.t("Приложения для AndroCraft. Установка на этот телефон.", "Apps for AndroCraft. Installs on this phone."), null);
                r(o, 't', "", null);
                for (AppStore.Info i : AppStore.cat()) {
                    r(o, 'h', os.t(i.ru, i.en), null);
                    r(o, 't', os.t(i.dRu, i.dEn), null);
                    r(o, 'd', i.mb + " MB, Android " + i.ver + "+, " + (i.price == 0 ? os.t("бесплатно", "free") : i.price + " K"), null);
                    if (AppStore.has(os.stack(), i.id)) r(o, 'd', os.t("Уже установлено", "Already installed"), null);
                    else r(o, 'b', os.t("Скачать", "Get") + " " + os.t(i.ru, i.en), "dl:" + i.id);
                    r(o, 't', "", null);
                }
                r(o, 'l', os.t("Открыть магазин приложений", "Open the app store"), "app:store");
                r(o, 'l', os.t("Магазин программ (soft.pc)", "Software store (soft.pc)"), "soft.pc");
                r(o, 'l', os.t("На главную", "Home"), "home.pc");
            }
            case "news.pc" -> {
                r(o, 'h', "PC-News", null);
                r(o, 't', "", null);
                r(o, 't', os.t("- AndroStore открыт: Змейка, Кубики и Сапёр уже в каталоге.", "- AndroStore is open: Snake, Dice and Minesweeper are in the catalog."), null);
                r(o, 't', os.t("- Слабые SoC и мало ОЗУ: приложения вылетают. Выбирайте железо с умом.", "- Weak SoCs and little RAM make apps crash. Choose hardware wisely."), null);
                r(o, 't', os.t("- Общий счёт: баланс одинаков на ПК и телефоне.", "- Shared account: the balance is the same on PC and phone."), null);
                r(o, 't', "", null);
                r(o, 'l', os.t("На главную", "Home"), "home.pc");
            }
            case "help.pc" -> {
                r(o, 'h', os.t("Справка", "Help"), null);
                r(o, 't', os.t("1. Подключитесь к Wi-Fi в Настройках.", "1. Connect to Wi-Fi in Settings."), null);
                r(o, 't', os.t("2. Откройте AndroStore (apps.pc или значок «Приложения»).", "2. Open AndroStore (apps.pc or the Apps icon)."), null);
                r(o, 't', os.t("3. Нажмите «Скачать»; платные приложения списываются с общего банковского счёта.", "3. Tap Get; paid apps are charged to your shared bank account."), null);
                r(o, 't', os.t("4. Значок появится на домашнем экране.", "4. The icon appears on the home screen."), null);
                r(o, 't', "", null);
                r(o, 'l', os.t("На главную", "Home"), "home.pc");
            }
            case "soft.pc" -> catalog(os, o);
            case "games.pc", "av.pc" -> {
                r(o, 'h', url.equals("games.pc") ? "GameZone" : "SafeGuard", null);
                r(o, 'e', os.t("Эти файлы только для ПК (WinCraft).", "These files are for PC (WinCraft) only."), null);
                r(o, 't', os.t("Откройте сайт в браузере компьютера.", "Open this site in the computer browser."), null);
                r(o, 't', "", null);
                r(o, 'l', os.t("На главную", "Home"), "home.pc");
            }
            default -> {
                if (url.startsWith("soft.pc/")) { product(os, o, url.substring(8)); return WebPage.of(o); }
                return WinWeb.site(SiteHost.Resp.err(SiteHost.NOT_FOUND, url, "", ""), os.lang == 0);
            }
        }
        return WebPage.of(o);
    }


    private static String price(AndroOs os, int p) { return p <= 0 ? os.t("Бесплатно", "Free") : p + " K"; }

    /** soft.pc на телефоне: только телефонные товары. */
    private static void catalog(AndroOs os, List<WebRow> o) {
        r(o, 'h', os.t("Магазин программ", "Software store"), null);
        r(o, 'd', os.t("Приложения для телефона. Программы и игры для ПК - в браузере компьютера.", "Phone apps. PC programs and games are in the computer browser."), null);
        r(o, 't', "", null);
        for (AppStore.Info i : AppStore.cat()) {
            String st = AppStore.has(os.stack(), i.id) ? os.t(", установлено", ", installed") : i.price > 0 && AppStore.owned(os, i.id) ? os.t(", куплено", ", owned") : "";
            r(o, 'l', os.t(i.ru, i.en) + " - " + price(os, i.price) + st, "soft.pc/" + i.id);
        }
        r(o, 't', "", null);
        r(o, 'l', os.t("На главную", "Home"), "home.pc");
    }

    private static void product(AndroOs os, List<WebRow> o, String id) {
        AppStore.Info i = AppStore.info(id);
        if (i == null) {
            r(o, 'h', os.t("404 - товар не найден", "404 - item not found"), null);
            r(o, 'l', os.t("Каталог", "Catalog"), "soft.pc");
            return;
        }
        boolean has = AppStore.has(os.stack(), id), owned = AppStore.owned(os, id);
        r(o, 'h', os.t(i.ru, i.en), null);
        r(o, 'p', id, null);
        r(o, 't', os.t(i.dRu, i.dEn), null);
        r(o, 't', "", null);
        r(o, 'd', os.t("Требования: Android ", "Requires: Android ") + i.ver + "+, " + os.t("ОЗУ ", "RAM ") + i.ram / 1024 + " GB, " + i.mb + " MB", null);
        r(o, 'd', os.t("Цена: ", "Price: ") + price(os, i.price), null);
        if (i.price <= 0) r(o, 'k', os.t("Лицензия: не требуется", "License: not required"), null);
        else if (owned) r(o, 'k', os.t("Лицензия: куплена (аккаунт)", "License: owned (account)"), null);
        else r(o, 'e', os.t("Лицензия: не куплена", "License: not owned"), null);
        r(o, 't', "", null);
        String why = has ? null : AppStore.blocked(os, i);
        if (i.price > 0 && !owned) r(o, 'b', os.t("Купить за ", "Buy for ") + i.price + " K", "buy:" + id);
        if (has) {
            r(o, 'k', os.t("Установлено", "Installed"), null);
            r(o, 'l', os.t("Открыть", "Open"), "app:" + id);
        } else if (why != null) r(o, 'e', why, null);
        else if (owned) r(o, 'b', os.t("Скачать и установить", "Download and install"), "dl:" + id);
        r(o, 't', "", null);
        r(o, 'l', os.t("Каталог", "Catalog"), "soft.pc");
        r(o, 'l', os.t("На главную", "Home"), "home.pc");
    }

    private static WebView.Skin skin(AndroOs os) {
        WebView.Skin k = new WebView.Skin();
        k.pad = 10; k.padTop = 2; k.wrapW = 160;
        k.hOff = 0; k.hLine = 12; k.hAfter = 2;
        k.btnH = 22; k.btnR = 8; k.btnStep = 28; k.btnW = 164; k.btnTextY = 7; k.btnX = 8;
        k.underlineAlways = true;
        k.text = os.text(); k.sub = os.sub(); k.accent = os.accent(); k.accentHover = os.accent(); k.onAccent = rgb(255, 255, 255);
        k.ok = rgb(80, 220, 120); k.bad = rgb(240, 110, 100);
        return k;
    }


    // ------------------------------------------------------------------ панели
    private static List<Item> items(AndroOs os, St st) {
        BrowserCore c = st.core;
        List<Item> l = new ArrayList<Item>();
        switch (st.mode) {
            case 1 -> {
                l.add(new Item(true, os.t("Вкладки ", "Tabs ") + c.tabs.size() + "/" + BrowserCore.MAX_TABS, "", "", null));
                for (int i = 0; i < c.tabs.size(); i++) {
                    Tab t = c.tabs.get(i);
                    l.add(new Item(false, (i == c.cur ? "> " : "") + (i + 1) + ". " + title(t), t.url, "tab:" + i, "close:" + i));
                }
                if (c.tabs.size() < BrowserCore.MAX_TABS) l.add(new Item(false, os.t("+ Новая вкладка", "+ New tab"), "", "newtab", null));
                l.add(new Item(true, os.t("Меню", "Menu"), "", "", null));
                l.add(new Item(false, os.t("Закладки", "Bookmarks"), c.bookmarks.size() + "/" + BrowserCore.MAX_BM, "mode:2", null));
                l.add(new Item(false, os.t("История", "History"), c.history.size() + "", "mode:3", null));
            }
            case 2 -> {
                l.add(new Item(true, os.t("Закладки", "Bookmarks"), "", "", null));
                if (c.bookmarks.isEmpty()) l.add(new Item(true, os.t("Пусто. Нажмите * на странице.", "Empty. Tap * on a page."), "", "", null));
                for (String b : c.bookmarks) l.add(new Item(false, b, "", "go:" + b, "bm:" + b));
            }
            case 3 -> {
                l.add(new Item(true, os.t("История", "History"), "", "", null));
                if (c.history.isEmpty()) l.add(new Item(true, os.t("Пусто", "Empty"), "", "", null));
                else l.add(new Item(false, os.t("Очистить историю", "Clear history"), "", "clrhist", null));
                for (int i = c.history.size() - 1; i >= 0; i--) l.add(new Item(false, c.history.get(i), "", "go:" + c.history.get(i), null));
            }
            default -> {
                l.add(new Item(false, st.typed.isEmpty() ? os.t("Нажмите, чтобы ввести адрес", "Tap to type an address") : st.typed, os.t("Изменить текст", "Edit text"), "edit", null));
                if (!st.typed.isEmpty()) l.add(new Item(false, os.t("Перейти: ", "Go: ") + WinWeb.norm(st.typed), "", "go:" + st.typed, null));
                l.add(new Item(true, st.typed.isEmpty() ? os.t("Недавние и закладки", "Recent and bookmarks") : os.t("Подсказки", "Suggestions"), "", "", null));
                for (String s : c.suggest(st.typed, 8)) l.add(new Item(false, s, c.isBookmarked(s) ? os.t("закладка", "bookmark") : "", "go:" + s, null));
            }
        }
        return l;
    }

    private static void panel(AndroOs os, PixelScreen s, St st) {
        st.view.hits.clear();
        st.items = items(os, st);
        st.itemY.clear();
        int y = 4;
        for (Item it : st.items) {
            st.itemY.add(y);
            int sy = TOP + y - st.psc.off;
            int h = it.head ? PH_HEAD : PH_ROW;
            if (sy + h > TOP && sy < TOP + VIEW) {
                if (it.head) s.drawText(10, sy + 6, PixelScreen.fit(it.label, 160, 1, true), os.accent(), 1, true);
                else {
                    s.roundRect(6, sy, 168, PH_ROW - 3, 6, os.panel());
                    s.drawText(12, sy + (it.sub.isEmpty() ? 8 : 4), PixelScreen.fit(it.label, it.del == null ? 154 : 126, 1, true), os.text(), 1, true);
                    if (!it.sub.isEmpty()) s.drawText(12, sy + 15, PixelScreen.fit(it.sub, it.del == null ? 154 : 126, 1, false), os.sub());
                    if (it.del != null) {
                        s.roundRect(148, sy + 3, 22, PH_ROW - 9, 6, rgb(150, 60, 60));
                        s.drawTextCentered(148, 22, sy + 8, "x", rgb(255, 255, 255), 1, true);
                    }
                }
            }
            y += h;
        }
        st.panelH = y + 4;
    }

    private static void panelAct(AndroOs os, St st, String a) {
        BrowserCore c = st.core;
        if (a.startsWith("go:")) navigate(os, st, a.substring(3));
        else if (a.startsWith("tab:")) { switchTab(st, Integer.parseInt(a.substring(4))); os.dirty(); }
        else if (a.equals("newtab")) {
            c.tab().scroll = st.sc.off;
            if (c.newTab("home.pc")) { st.mode = 0; st.sc.off = 0; load(os, st, c.tab(), false); save(os, st); }
            os.dirty();
        } else if (a.startsWith("mode:")) { st.mode = Integer.parseInt(a.substring(5)); st.psc.off = 0; os.dirty(); }
        else if (a.equals("clrhist")) { c.history.clear(); save(os, st); os.dirty(); }
        else if (a.equals("edit")) openAddress(os, st);
    }

    private static void panelDel(AndroOs os, St st, String d) {
        BrowserCore c = st.core;
        if (d.startsWith("close:")) {
            boolean last = c.tabs.size() == 1;
            c.closeTab(Integer.parseInt(d.substring(6)));
            st.sc.off = c.tab().scroll;
            if (last) load(os, st, c.tab(), false);
        } else if (d.startsWith("bm:")) { c.bookmarks.remove(d.substring(3)); save(os, st); }
        os.dirty();
    }

    // ------------------------------------------------------------------ рисование
    private static void loadScreen(AndroOs os, PixelScreen s, St st, Tab t, int ch) {
        st.view.hits.clear();
        int y = TOP + 80;
        s.drawTextCentered(0, AndroOs.W, y, os.t("Загрузка...", "Loading..."), os.text(), 1, true);
        s.drawTextCentered(0, AndroOs.W, y + 14, t.pct() + "%", os.sub(), 1, false);
        s.drawTextCentered(0, AndroOs.W, y + 26, chanName(ch) + ", " + kbs(os, BrowserCore.rate(ch, signal(os, ch))), os.sub(), 1, false);
    }

    private static void tool(PixelScreen s, AndroOs os, int x, int w, String g, boolean on, boolean en) {
        s.roundRect(x, TB, w, TBH, 8, on ? os.accent() : os.panel());
        s.drawTextCentered(x, w, TB + 6, g, on ? rgb(255, 255, 255) : en ? os.text() : os.sub(), 1, true);
    }

    @Override
    public void draw(AndroOs os, PixelScreen s) {
        St st = st(os);
        BrowserCore core = st.core;
        Tab t = core.tab();
        int ch = chan(os);
        AppUi.header(os, s, "browser", os.t("Браузер", "Browser"));
        tool(s, os, 4, 20, "<", st.mode != 0 || core.canBack(t), true);
        s.roundRect(26, TB, 86, TBH, 8, os.panel());
        s.drawText(33, TB + 6, PixelScreen.fit(st.mode == 4 ? os.t("Адрес...", "Address...") : t.url, 74, 1, false), os.text());
        tool(s, os, 114, 18, t.loading ? "x" : "F5", false, true);
        tool(s, os, 134, 18, "*", core.isBookmarked(t.url), true);
        tool(s, os, 154, 22, String.valueOf(core.tabs.size()), st.mode == 1, true);
        if (t.loading && ch != BrowserCore.NONE) {
            s.fillRect(4, TB + TBH + 1, 172, 3, os.panel());
            s.fillRect(4, TB + TBH + 1, Math.max(2, 172 * t.pct() / 100), 3, os.accent());
        }
        s.pushClip(0, TOP, AndroOs.W, VIEW);
        if (st.mode != 0) panel(os, s, st);
        else if (t.loading && ch != BrowserCore.NONE) loadScreen(os, s, st, t, ch);
        else st.contentH = st.view.draw(s, current(os, st, t), skin(os), 0, 0, 0, TOP, AndroOs.W, st.sc.off, TOP, VIEW, -1);
        s.popClip();
        if (st.until > os.now()) {
            s.roundRect(14, 270, 152, 20, 8, rgb(30, 36, 52));
            s.drawTextCentered(14, 152, 276, PixelScreen.fit(st.msg, 146, 1, true), st.ok ? rgb(80, 220, 120) : rgb(240, 110, 100), 1, true);
        }
        if (!st.confirm.isEmpty()) {
            s.roundRect(12, 112, 156, 92, 10, rgb(30, 36, 52));
            List<String> ls = AppUi.wrap(confirmText(os, st.confirm), 136);
            for (int i = 0; i < ls.size() && i < 4; i++) s.drawTextCentered(12, 156, 122 + i * 12, ls.get(i), rgb(240, 245, 255), 1, true);
            s.roundRect(22, 174, 66, 22, 8, os.accent());
            s.drawTextCentered(22, 66, 180, os.t("Да", "Yes"), rgb(255, 255, 255), 1, true);
            s.roundRect(96, 174, 66, 22, 8, rgb(70, 80, 100));
            s.drawTextCentered(96, 66, 180, os.t("Нет", "No"), rgb(255, 255, 255), 1, true);
        }
    }

    // ------------------------------------------------------------------ ввод
    @Override
    public boolean touch(AndroOs os, int kind, int x, int y) {
        St st = st(os);
        AppUi.Scroll cs = st.mode == 0 ? st.sc : st.psc;
        if (st.confirm.isEmpty()) {
            if (kind == 0) { cs.down(y); return true; }
            if (kind == 2) { cs.drag(y, st.mode == 0 ? st.contentH : st.panelH, VIEW); return true; }
        } else if (kind != 1) return true;
        if (!os.tap(x, y) || cs.moved) return true;
        BrowserCore core = st.core;
        Tab t = core.tab();
        if (!st.confirm.isEmpty()) {
            String tg = st.confirm;
            if (AppUi.in(x, y, 22, 174, 66, 22)) { st.confirm = ""; confirmed(os, st, tg); }
            else if (AppUi.in(x, y, 96, 174, 66, 22)) { st.confirm = ""; os.dirty(); }
            return true;
        }
        if (y >= TB && y < TB + TBH) {
            if (x < 26) navBack(os, st);
            else if (x < 114) openAddress(os, st);
            else if (x < 134) {
                if (t.loading) { t.loading = false; os.dirty(); }
                else refresh(os, st);
            } else if (x < 154) {
                boolean was = core.isBookmarked(t.url), added = core.toggleBookmark(t.url);
                save(os, st);
                say(os, st, was ? os.t("Закладка удалена", "Bookmark removed") : added ? os.t("Закладка добавлена", "Bookmark added")
                        : os.t("Закладок максимум: ", "Bookmark limit: ") + BrowserCore.MAX_BM, !was && added || was);
            } else {
                t.scroll = st.sc.off;
                st.mode = st.mode == 1 ? 0 : 1;
                st.psc.off = 0;
                os.dirty();
            }
            return true;
        }
        if (y < TOP || y >= TOP + VIEW) return true;
        if (st.mode != 0) {
            int cy = y - TOP + st.psc.off;
            for (int i = 0; i < st.items.size() && i < st.itemY.size(); i++) {
                Item it = st.items.get(i);
                int y0 = st.itemY.get(i);
                if (it.head || cy < y0 || cy >= y0 + PH_ROW - 3) continue;
                if (it.del != null && x >= 148) panelDel(os, st, it.del);
                else if (!it.act.isEmpty()) panelAct(os, st, it.act);
                return true;
            }
            return true;
        }
        if (t.loading) return true;
        for (WebView.Hit h : st.view.hits) {
            if (y < h.y - 2 || y >= h.y + h.h + 2) continue;
            link(os, st, h.target);
            return true;
        }
        return true;
    }

    /** Назад: закрыть подтверждение или панель, затем шаг по истории вкладки. */
    private static boolean navBack(AndroOs os, St st) {
        if (!st.confirm.isEmpty()) { st.confirm = ""; os.dirty(); return true; }
        if (st.mode != 0) { st.mode = 0; os.dirty(); return true; }
        Tab t = st.core.tab();
        if (!st.core.back(t)) return false;
        st.sc.off = 0;
        st.msg = "";
        load(os, st, t, true);
        os.dirty();
        return true;
    }

    @Override
    public boolean back(AndroOs os) { return navBack(os, st(os)); }

    @Override
    public boolean tick(AndroOs os, long now) {
        St st = st(os);
        boolean d = false;
        int ch = chan(os);
        for (Tab t : st.core.tabs) {
            if (!t.loading) continue;
            if (ch == BrowserCore.NONE) { t.loading = false; d = true; continue; }
            if (st.core.tickLoad(t, BrowserCore.rate(ch, signal(os, ch)) / (1 + os.lag()))) d = true;
        }
        if (st.until != 0 && now >= st.until) { st.until = 0; d = true; }
        return d;
    }
}
