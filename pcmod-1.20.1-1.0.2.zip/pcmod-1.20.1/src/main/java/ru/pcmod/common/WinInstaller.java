package ru.pcmod.common;

/** Установщик программ: открывается из Проводника или Терминала по файлу .exe (DOOM, антивирус). */
public final class WinInstaller implements WinApp {
    private static final int ST_ASK = 0, ST_RUN = 1, ST_DONE = 2, ST_ERR = 3;

    private final WinSoft s;
    private final WinSvc svc;
    private final String path;
    private final String id;
    private final SoftItem it;
    private final int ticks;
    private int stage = ST_ASK, ox, oy, lastPct = -1;
    private double prog;
    private String err = "";
    private final WinUi.Button b1 = new WinUi.Button("Установить", 0, 0, 80, true);
    private final WinUi.Button b2 = new WinUi.Button("Отмена", 0, 0, 70, false);

    public WinInstaller(WinSoft s, String path) {
        this.s = s;
        this.svc = s.svc;
        this.path = path == null ? "" : path;
        this.id = this.path.isEmpty() ? "" : svc.softSetupId(this.path);
        this.it = SoftRegistry.get(id);
        this.ticks = Math.max(40, 180 / Math.max(1, s.host.hw().driveSpeed));
        if (id.isEmpty()) {
            stage = ST_ERR;
            err = this.path.isEmpty() ? "Откройте файл установщика (.exe) в Проводнике." : "Этот файл не является установщиком программы.";
        } else {
            String e = svc.softSetupCheck(id, this.path);
            if (e != null) {
                stage = ST_ERR;
                err = e;
            }
        }
    }

    @Override public String title() { return "Установщик программ"; }

    @Override public String id() { return "setup"; }

    @Override public boolean resizable() { return false; }

    @Override public int minW() { return 250; }

    @Override public int minH() { return 132; }

    private boolean showB1() {
        return stage == ST_ASK || (stage == ST_DONE && launchable());
    }

    /** После установки можно сразу запустить (игры с приложением в системе). */
    private boolean launchable() {
        return it != null && it.type == SoftItem.Type.PC_GAME && !it.appId.isEmpty();
    }

    private static void row(PixelScreen p, WinTheme th, int x, int y, int w, String k, String v) {
        p.drawText(x + 10, y, k, th.sub());
        p.drawText(x + 84, y, PixelScreen.fit(v, w - 94, 1, false), th.text());
    }

    @Override
    public void draw(PixelScreen p, WinTheme th, int x, int y, int w, int h) {
        ox = x;
        oy = y;
        String icon = id.equals("av") ? "av" : id.equals("doom") ? "doom" : "setup";
        WinIcons.drawSized(p, th, icon, x + 10, y + 8, 24);
        p.drawText(x + 42, y + 9, it == null ? "Установщик" : it.ru, th.text(), 1, true);
        p.drawText(x + 42, y + 22, stage == ST_DONE ? "Установка завершена" : stage == ST_RUN ? "Установка..." : "Установка программы", th.sub());
        p.hline(x, y + 40, w, th.border());
        if (stage == ST_ASK) {
            row(p, th, x, y + 50, w, "Папка", WinFs.show(it.folder()));
            row(p, th, x, y + 62, w, "Нужно места", WinSoft.bytesText(it.needBytes));
            row(p, th, x, y + 74, w, "Свободно", WinSoft.bytesText(s.fs.free()));
        } else if (stage == ST_RUN) {
            int pct = (int) (prog * 100);
            p.drawText(x + 10, y + 52, "Копирование файлов...", th.text());
            p.roundRect(x + 10, y + 66, w - 20, 8, 4, th.border());
            if (pct > 0) p.roundRect(x + 10, y + 66, Math.max(6, (w - 20) * pct / 100), 8, 4, th.accent());
            p.drawTextCentered(x, w, y + 80, pct + "%", th.sub(), 1, false);
        } else if (stage == ST_DONE) {
            p.drawText(x + 10, y + 52, "Программа установлена на этот компьютер.", th.ok());
            if (id.equals("av")) p.drawText(x + 10, y + 64, "Защита включена.", th.text());
        } else {
            int ty = y + 50;
            for (String ln : WinSoft.wrap(err, w - 20)) {
                p.drawText(x + 10, ty, ln, th.bad());
                ty += 11;
            }
        }
        int by = y + h - 24;
        b2.label = stage == ST_ASK || stage == ST_RUN ? "Отмена" : stage == ST_DONE ? "Готово" : "Закрыть";
        b2.primary = stage == ST_ERR || (stage == ST_DONE && !launchable());
        b2.x = x + w - 10 - b2.w;
        b2.y = by;
        b1.label = stage == ST_ASK ? "Установить" : "Запустить";
        b1.x = b2.x - 6 - b1.w;
        b1.y = by;
        b2.draw(p, th);
        if (showB1()) b1.draw(p, th);
    }

    private void act1() {
        if (stage == ST_ASK) {
            stage = ST_RUN;
            prog = 0;
            lastPct = -1;
        } else if (stage == ST_DONE) {
            s.ctx.open(it.appId, "");
            s.ctx.kill(this);
        }
    }

    @Override
    public boolean mouse(int rx, int ry, int btn, int kind) {
        int ax = rx + ox, ay = ry + oy;
        boolean h1 = showB1() && b1.hit(ax, ay), h2 = b2.hit(ax, ay), ch = h1 != b1.hover || h2 != b2.hover;
        b1.hover = h1;
        b2.hover = h2;
        if (kind == PixelScreen.MOUSE_PRESS && btn == 0) {
            if (h1) {
                act1();
                return true;
            }
            if (h2) {
                s.ctx.kill(this);
                return false;
            }
        }
        return ch;
    }

    @Override
    public boolean key(char c, int key) {
        if (key == WinSoft.K_ESC) {
            s.ctx.kill(this);
            return false;
        }
        if (WinUi.isEnter(c, key)) {
            if (showB1()) {
                act1();
                return true;
            }
            if (stage == ST_DONE || stage == ST_ERR) s.ctx.kill(this);
        }
        return false;
    }

    @Override
    public boolean tick(long now) {
        if (stage != ST_RUN) return false;
        prog += 1.0 / ticks;
        if (prog >= 1) {
            prog = 1;
            WinSvc.Res r = svc.softSetupRun(id, path);
            if (r.ok) {
                stage = ST_DONE;
                s.apps.refresh();
            } else {
                stage = ST_ERR;
                err = r.msg;
            }
            return true;
        }
        int pct = (int) (prog * 100);
        if (pct == lastPct) return false;
        lastPct = pct;
        return true;
    }
}
