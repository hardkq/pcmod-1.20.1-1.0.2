package ru.pcmod.common;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;

/**
 * Команды операторов хостинга сайтов:
 * /pcsite list [владелец] | info &lt;домен&gt; | delete &lt;домен&gt; | ban &lt;домен&gt; [причина] | unban &lt;домен&gt; | reports | clear &lt;домен&gt; | audit | reload
 */
public final class CommandSite {
    private CommandSite() { }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("pcsite").requires(s -> s.hasPermission(2))
                .executes(c -> list(c, null))
                .then(Commands.literal("list").executes(c -> list(c, null))
                        .then(Commands.argument("owner", StringArgumentType.word()).executes(c -> list(c, StringArgumentType.getString(c, "owner")))))
                .then(dom("info", 0)).then(dom("delete", 1)).then(dom("unban", 3)).then(dom("clear", 4))
                .then(Commands.literal("reports").executes(CommandSite::reports))
                .then(Commands.literal("ban").then(Commands.argument("domain", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(domains(), b))
                        .executes(c -> ban(c, ""))
                        .then(Commands.argument("reason", StringArgumentType.greedyString()).executes(c -> ban(c, StringArgumentType.getString(c, "reason"))))))
                .then(Commands.literal("audit").executes(CommandSite::audit))
                .then(Commands.literal("reload").executes(CommandSite::reload)));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> dom(String name, int op) {
        return Commands.literal(name).then(Commands.argument("domain", StringArgumentType.word())
                .suggests((c, b) -> SharedSuggestionProvider.suggest(domains(), b))
                .executes(c -> run(c, op)));
    }

    private static List<String> domains() {
        List<String> r = new ArrayList<String>();
        SiteStore s = SiteStore.get();
        if (s != null) for (SiteStore.Site x : s.all()) r.add(x.domain);
        return r;
    }

    private static void tr(CommandContext<CommandSourceStack> c, String key, Object... args) {
        c.getSource().sendSuccess(() -> Component.translatable("pcmod.cmd.site." + key, args), false);
    }

    private static void say(CommandContext<CommandSourceStack> c, String t) {
        c.getSource().sendSuccess(() -> Component.literal(t), false);
    }

    private static String line(SiteStore.Site x, long today) {
        long left = x.expires - today;
        return x.domain + " - " + x.ownerName + ", " + x.pages.size() + " pages, " + x.bytes() + " B, " + x.visits + " visits, " + x.votes.size()
                + " votes, " + x.reports.size() + " reports, "
                + (left >= 0 ? left + " days left" : "expired " + (-left) + " days ago") + (x.banned ? ", BANNED" : "");
    }

    private static int list(CommandContext<CommandSourceStack> c, String owner) {
        SiteStore s = SiteStore.get();
        if (s == null) {
            tr(c, "unavailable");
            return 0;
        }
        long t = SiteStore.today();
        int n = 0;
        for (SiteStore.Site x : s.all()) {
            if (owner != null && !x.ownerName.equalsIgnoreCase(owner)) continue;
            say(c, line(x, t));
            n++;
        }
        tr(c, "count", n);
        return n;
    }

    private static int run(CommandContext<CommandSourceStack> c, int op) {
        SiteStore s = SiteStore.get();
        String d = SiteConfig.normalize(StringArgumentType.getString(c, "domain"));
        SiteStore.Site x = s == null || d == null ? null : s.site(d, true);
        if (x == null) {
            tr(c, "none");
            return 0;
        }
        String by = c.getSource().getTextName();
        if (op == 0) {
            say(c, line(x, SiteStore.today()));
            for (java.util.Map.Entry<String, String> e : x.reports.entrySet()) say(c, "report by " + e.getKey() + ": " + e.getValue());
            say(c, "owner " + x.owner + ", title \"" + x.title + "\", tags [" + x.tags + "], pages " + x.pages.keySet()
                    + (x.banned ? ", ban reason: " + x.banReason : ""));
        } else if (op == 4) {
            s.adminClearReports(d, by);
            tr(c, "cleared", d);
        } else if (op == 1) {
            s.adminDelete(d, by);
            tr(c, "deleted", d);
        } else {
            s.adminBan(d, false, "", by);
            tr(c, "unbanned", d);
        }
        return 1;
    }

    private static int ban(CommandContext<CommandSourceStack> c, String reason) {
        SiteStore s = SiteStore.get();
        String d = SiteConfig.normalize(StringArgumentType.getString(c, "domain"));
        if (s == null || d == null || !s.adminBan(d, true, reason, c.getSource().getTextName())) {
            tr(c, "none");
            return 0;
        }
        tr(c, "banned", d);
        return 1;
    }

    private static int reports(CommandContext<CommandSourceStack> c) {
        SiteStore s = SiteStore.get();
        if (s == null) return 0;
        long t = SiteStore.today();
        int n = 0;
        for (SiteStore.Site x : s.all()) {
            if (x.reports.isEmpty()) continue;
            say(c, line(x, t));
            n++;
        }
        tr(c, "reported", n);
        return n;
    }

    private static int audit(CommandContext<CommandSourceStack> c) {
        SiteStore s = SiteStore.get();
        if (s == null) return 0;
        List<String> a = s.auditLog();
        for (int i = Math.max(0, a.size() - 15); i < a.size(); i++) say(c, a.get(i));
        return a.size();
    }

    private static int reload(CommandContext<CommandSourceStack> c) {
        tr(c, "reload", SiteConfig.load());
        return 1;
    }
}
