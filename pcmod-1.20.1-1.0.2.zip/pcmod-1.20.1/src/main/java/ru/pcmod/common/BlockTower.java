package ru.pcmod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Вышка сотовой связи. ПКМ открывает GUI; с ItemTowerLinker в руке — передаёт клик предмету (привязка). */
public class BlockTower extends BaseEntityBlock {
    private static final VoxelShape SHAPE = Block.box(3, 0, 3, 13, 16, 13);

    public BlockTower() { super(Properties.of().strength(4.0F, 12.0F).sound(SoundType.METAL).noOcclusion()); }

    @Override public RenderShape getRenderShape(BlockState s) { return RenderShape.MODEL; }
    @Override public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) { return SHAPE; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState st) { return new TileTower(pos, st); }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level l, BlockState s, BlockEntityType<T> t) {
        return l.isClientSide ? null : createTickerHelper(t, ModBlockEntities.TOWER.get(), (lv, p, st, te) -> te.tick());
    }

    @Override public InteractionResult use(BlockState st, Level level, BlockPos pos, Player pl, InteractionHand hand, BlockHitResult hit) {
        if (pl.getItemInHand(hand).getItem() instanceof ItemTowerLinker) return InteractionResult.PASS;
        if (!level.isClientSide && pl instanceof ServerPlayer sp) GuiHandler.open(sp, 6, pos);
        return InteractionResult.SUCCESS;
    }

    @Override public void onRemove(BlockState st, Level level, BlockPos pos, BlockState ns, boolean moving) {
        if (!st.is(ns.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof TileTower t && t.linked) {
            OperatorStore os = OperatorStore.get();
            OperatorStore.Operator o = os == null ? null : os.get(t.operatorId);
            if (o != null) os.removeTower(o.id, pos);
        }
        super.onRemove(st, level, pos, ns, moving);
    }
}
