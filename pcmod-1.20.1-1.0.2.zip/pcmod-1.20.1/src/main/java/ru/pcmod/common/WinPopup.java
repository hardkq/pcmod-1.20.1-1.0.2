package ru.pcmod.common;

/** Всплывающее меню внутри окна приложения: координаты относительные (от левого верхнего угла содержимого). */
final class WinPopup {
    private final WinUi.Menu menu;
    private final int[] ids;
    private int rx, ry;

    WinPopup(String[] labels, int[] ids) {
        menu = new WinUi.Menu(labels);
        this.ids = ids;
    }

    boolean open() { return menu.open; }

    void close() { menu.open = false; }

    /** Открыть у точки (px, py); сдвигается так, чтобы влезть в область aw x ah. */
    void openAt(int px, int py, int aw, int ah) {
        rx = Math.max(0, Math.min(aw - menu.w, px));
        ry = Math.max(0, Math.min(ah - menu.h(), py));
        menu.hover = -1;
        menu.open = true;
    }

    private void place(int ox, int oy) {
        menu.x = rx + ox;
        menu.y = ry + oy;
    }

    void draw(PixelScreen p, WinTheme th, int ox, int oy, boolean shadow) {
        if (!menu.open) return;
        place(ox, oy);
        menu.draw(p, th, shadow);
    }

    /** Указатель двинулся; true - перерисовать. */
    boolean move(int mx, int my) {
        if (!menu.open) return false;
        place(0, 0);
        int h = menu.itemAt(mx, my);
        if (h == menu.hover) return false;
        menu.hover = h;
        return true;
    }

    /** Нажатие: номер пункта (из ids) или -1; меню закрывается. */
    int press(int mx, int my) {
        place(0, 0);
        int i = menu.itemAt(mx, my);
        menu.open = false;
        return i < 0 ? -1 : ids[i];
    }
}
