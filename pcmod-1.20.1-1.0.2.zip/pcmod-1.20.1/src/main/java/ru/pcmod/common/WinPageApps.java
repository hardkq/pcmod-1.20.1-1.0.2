package ru.pcmod.common;

import java.util.LinkedHashSet;
import java.util.Set;

/** Страница «Приложения»: список установленных приложений, запуск и автозапуск при входе (настройка "autorun"). */
final class WinPageApps extends WinFormPage {
    private final WinApps apps;
    private final WinSettings.Ctx ctx;

    WinPageApps(WinHost host, WinApps apps, WinSettings.Ctx ctx) {
        super(host);
        this.apps = apps;
        this.ctx = ctx;
    }

    private Set<String> autorun() {
        Set<String> s = new LinkedHashSet<String>();
        String v = host.pref("autorun");
        if (v != null && !v.isEmpty()) {
            for (String id : v.split(",")) if (apps.get(id.trim()) != null) s.add(id.trim());
        }
        return s;
    }

    private void toggle(String id) {
        Set<String> s = autorun();
        if (!s.remove(id)) s.add(id);
        host.setPref("autorun", String.join(",", s));
    }

    @Override
    void build(WinForm f) {
        Set<String> auto = autorun();
        f.section("Установленные приложения (" + apps.all().size() + ")");
        for (WinApps.Info a : apps.all()) {
            final String id = a.id;
            f.card(a.title).sub("Автозапуск").icon(a.icon).toggle(auto.contains(id), true, () -> toggle(id)).button("Запуск", true, () -> ctx.launch(id));
        }
        f.note("Приложения с включённым автозапуском открываются при каждом входе в систему.", false);
    }
}
