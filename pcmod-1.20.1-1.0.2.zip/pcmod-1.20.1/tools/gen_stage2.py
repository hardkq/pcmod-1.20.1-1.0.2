#!/usr/bin/env python3
"""Этап 2 (телефоны): комплектующие. Генерирует текстуры, модели, lang, рецепты и печатает Java-строки reg(...) для ModItems.
Запуск из корня проекта: python3 tools/gen_stage2.py [--java]"""
import json, os, sys, math
from PIL import Image
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'main', 'resources')
A = os.path.join(R, 'assets', 'pcmod'); D = os.path.join(R, 'data', 'pcmod')
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f: json.dump(obj, f, ensure_ascii=False, indent=2)

# id, ru, en, Cat, java-spec-chain, shapeless recipe {item: count}, icon-args
P = []
def add(id, ru, en, cat, label, chain, rec, icon): P.append((id, ru, en, cat, label, chain, rec, icon))

# --- SoC: socket=платформа, cores, ghz, watts(мощность в мВт*... условно), tier
for id, lab, ru, sock, cores, ghz, tier, rec in [
 ('l100', 'Andro L100', 'L100', 1, 4, 1.4, 1, {'microchip': 1, 'silicon_wafer': 1, 'gold_wire': 1}),
 ('m300', 'Andro M300', 'M300', 1, 6, 1.9, 2, {'microchip': 2, 'silicon_wafer': 1, 'gold_wire': 1}),
 ('m500', 'Andro M500', 'M500', 2, 8, 2.2, 3, {'microchip': 2, 'silicon_wafer': 2, 'gold_wire': 2}),
 ('p700', 'Andro P700', 'P700', 2, 8, 2.8, 4, {'microchip_adv': 1, 'microchip': 1, 'silicon_wafer': 2, 'gold_wire': 2}),
 ('x900', 'Andro X900', 'X900', 3, 8, 3.2, 5, {'microchip_adv': 2, 'silicon_wafer': 2, 'rare_earth': 2, 'gold_wire': 2}),
 ('x1200', 'Andro X1200', 'X1200', 3, 10, 3.6, 6, {'microchip_adv': 3, 'rare_earth': 4, 'gold_wire': 2})]:
    add('ph_soc_' + id, 'Процессор ' + lab, 'SoC ' + lab, 'PH_SOC', lab, 'socket(%d).cores(%d).ghz(%s).tier(%d).watts(%d)' % (sock, cores, ghz, tier, 2 + tier), rec, ('soc', tier))
# --- ОЗУ: ramType 1/2/3 = LPDDR3/4/5
for id, gb, t, rec in [
 ('lp3_2', 2, 1, {'memory_die': 1, 'plastic': 1, 'copper_wire': 1}),
 ('lp4_4', 4, 2, {'memory_die': 2, 'gold_wire': 1, 'plastic': 1}),
 ('lp4_6', 6, 2, {'memory_die': 3, 'gold_wire': 1, 'plastic': 1}),
 ('lp5_8', 8, 3, {'memory_die': 4, 'microchip': 1, 'gold_wire': 1}),
 ('lp5_12', 12, 3, {'memory_die': 5, 'microchip': 1, 'gold_wire': 2}),
 ('lp5_16', 16, 3, {'memory_die': 6, 'microchip_adv': 1, 'rare_earth': 1})]:
    add('ph_ram_' + id, 'ОЗУ LPDDR%d %d ГБ' % (t + 2, gb), 'RAM LPDDR%d %d GB' % (t + 2, gb), 'PH_RAM', 'LPDDR%d %d GB' % (t + 2, gb), 'ramType(%d).memMB(%d)' % (t, gb * 1024), rec, ('ram', gb))
# --- накопители, ГБ
for gb, kind, sp, rec in [
 (16, 'eMMC', 1, {'memory_die': 2, 'pcb_blank': 1}),
 (64, 'UFS 2.1', 2, {'memory_die': 3, 'pcb_blank': 1, 'gold_wire': 1}),
 (128, 'UFS 3.1', 3, {'memory_die': 4, 'pcb_blank': 1, 'microchip': 1}),
 (256, 'UFS 4.0', 4, {'memory_die': 6, 'pcb_blank': 1, 'microchip': 1, 'gold_wire': 1}),
 (512, 'UFS 4.0', 5, {'memory_die': 6, 'pcb_blank': 1, 'microchip_adv': 1, 'rare_earth': 1})]:
    add('ph_rom_%d' % gb, 'Накопитель %d ГБ (%s)' % (gb, kind), 'Storage %d GB (%s)' % (gb, kind), 'PH_ROM', '%s %d GB' % (kind, gb), 'gb(%d).speed(%d)' % (gb, sp), rec, ('rom', sp))
# --- аккумуляторы: size = габарит
for mah, size, rec in [
 (2500, 1, {'lithium_cell': 2, 'copper_wire': 1, 'plastic': 1}),
 (3500, 2, {'lithium_cell': 3, 'copper_wire': 2, 'plastic': 1}),
 (4500, 2, {'lithium_cell': 4, 'copper_wire': 2, 'plastic': 1, 'gold_wire': 1}),
 (6000, 3, {'lithium_cell': 5, 'gold_wire': 2, 'plastic': 1, 'rare_earth': 1})]:
    add('ph_batt_%d' % mah, 'Аккумулятор %d мА·ч' % mah, 'Battery %d mAh' % mah, 'PH_BATT', '%d mAh' % mah, 'mah(%d).size(%d)' % (mah, size), rec, ('batt', mah))
# --- экраны: size, дюймы, разрешение, Гц
for id, size, inch, rx, ry, hz, kind, rec in [
 ('5_hd', 1, 5.0, 720, 1280, 60, 'LCD', {'glass_matrix': 1, 'glass_panel': 1, 'flex_cable': 1, 'plastic': 1}),
 ('6_hd', 2, 6.1, 720, 1560, 60, 'LCD', {'glass_matrix': 1, 'glass_panel': 2, 'flex_cable': 1, 'plastic': 1}),
 ('6_fhd', 2, 6.4, 1080, 2340, 90, 'IPS', {'glass_matrix': 2, 'glass_panel': 1, 'flex_cable': 1, 'microchip': 1}),
 ('6_amoled', 2, 6.5, 1080, 2400, 120, 'AMOLED', {'glass_matrix': 2, 'flex_cable': 2, 'microchip': 1, 'gold_wire': 1}),
 ('7_qhd', 3, 6.8, 1440, 3120, 120, 'AMOLED', {'glass_matrix': 3, 'flex_cable': 2, 'microchip_adv': 1, 'rare_earth': 1})]:
    add('ph_screen_' + id, 'Экран %s\" %dx%d %s' % (inch, rx, ry, kind), 'Screen %s" %dx%d %s' % (inch, rx, ry, kind), 'PH_SCREEN', '%s" %dx%d' % (inch, rx, ry),
        'size(%d).inch(%s).res(%d, %d).hz(%d)' % (size, inch, rx, ry, hz), rec, ('screen', size, kind))
# --- камеры
for mp, rec in [(8, {'lens': 1, 'sensor': 1, 'flex_cable': 1}), (13, {'lens': 2, 'sensor': 1, 'flex_cable': 1}),
                (48, {'lens': 2, 'sensor': 2, 'flex_cable': 1, 'microchip': 1}), (108, {'lens': 3, 'sensor': 2, 'flex_cable': 1, 'microchip_adv': 1, 'rare_earth': 1})]:
    add('ph_cam_%d' % mp, 'Камера %d Мп' % mp, 'Camera %d MP' % mp, 'PH_CAM', '%d MP' % mp, 'mp(%d)' % mp, rec, ('cam', mp))
# --- платы: socket, ramType, ramSlots, size (макс. корпус), net (макс. модем)
for id, lab, sock, rt, slots, size, net, rec in [
 ('lite', 'PB-100', 1, 1, 1, 1, 1, {'pcb_blank': 1, 'microchip': 1, 'copper_wire': 2}),
 ('std', 'PB-200', 1, 2, 2, 2, 2, {'pcb_blank': 2, 'microchip': 2, 'gold_wire': 1, 'copper_wire': 1}),
 ('mid', 'PB-300', 2, 2, 2, 2, 3, {'pcb_blank': 2, 'microchip': 2, 'gold_wire': 2, 'flex_cable': 1}),
 ('pro', 'PB-500', 2, 3, 2, 3, 3, {'pcb_blank': 2, 'microchip_adv': 1, 'microchip': 1, 'gold_wire': 2, 'flex_cable': 1}),
 ('ultra', 'PB-900', 3, 3, 2, 3, 3, {'pcb_blank': 2, 'microchip_adv': 2, 'gold_wire': 2, 'rare_earth': 1})]:
    add('ph_board_' + id, 'Плата телефона ' + lab, 'Phone Board ' + lab, 'PH_BOARD', lab, 'socket(%d).ramType(%d).ramSlots(%d).size(%d).net(%d)' % (sock, rt, slots, size, net), rec, ('board', sock))
# --- корпуса: size, mah (макс. ёмкость батареи)
for id, lab, ru, size, cap, color, rec in [
 ('mini', 'Mini M1', 'Mini M1', 1, 3000, (110, 170, 230), {'case_blank': 1, 'plastic': 2}),
 ('classic', 'Classic C2', 'Classic C2', 2, 4500, (90, 90, 100), {'case_blank': 1, 'plastic': 2, 'glass_panel': 1}),
 ('slim', 'Slim S2', 'Slim S2', 2, 3500, (225, 225, 230), {'case_blank': 1, 'glass_panel': 2, 'copper_wire': 2}),
 ('max', 'Max X3', 'Max X3', 3, 6000, (60, 150, 100), {'case_blank_premium': 1, 'plastic': 2}),
 ('flagship', 'Flagship Z3', 'Flagship Z3', 3, 6000, (200, 160, 70), {'case_blank_premium': 1, 'glass_panel': 2, 'gold_wire': 2, 'rare_earth': 1})]:
    add('ph_case_' + id, 'Корпус телефона ' + lab, 'Phone Case ' + lab, 'PH_CASE', lab, 'size(%d).mah(%d)' % (size, cap), rec, ('case', color, size))
# --- модемы: net 1 Wi-Fi, 2 4G, 3 5G
for id, ru, en, net, col, rec in [
 ('wifi', 'Wi-Fi модуль', 'Wi-Fi Module', 1, (80, 170, 240), {'pcb_blank': 1, 'antenna_coil': 1, 'silicon_wafer': 1}),
 ('4g', 'Модем 4G', '4G Modem', 2, (90, 200, 110), {'pcb_blank': 1, 'antenna_coil': 2, 'microchip': 1, 'flex_cable': 1}),
 ('5g', 'Модем 5G', '5G Modem', 3, (230, 120, 220), {'pcb_blank': 1, 'antenna_coil': 2, 'microchip_adv': 1, 'flex_cable': 1, 'rare_earth': 1})]:
    add('ph_modem_' + id, ru + ' (телефон)', 'Phone ' + en, 'PH_MODEM', en, 'net(%d)' % net, rec, ('modem', net, col))

# ---------- иконки ----------
def new(): return Image.new('RGBA', (16, 16), (0, 0, 0, 0))
def px(im, pts, c):
    for x, y in pts:
        if 0 <= x < 16 and 0 <= y < 16: im.putpixel((x, y), tuple(c) + (255,))
def rect(im, x0, y0, x1, y1, c): px(im, [(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)], c)
def sh(c, k): return tuple(max(0, min(255, int(v * k))) for v in c)
def disc(im, cx, cy, r, c): px(im, [(x, y) for x in range(16) for y in range(16) if (x - cx) ** 2 + (y - cy) ** 2 <= r * r], c)
TIER = [(120, 125, 135), (80, 140, 220), (70, 180, 110), (235, 150, 50), (160, 80, 210), (235, 200, 70)]
def icon(a):
    im = new(); k = a[0]
    if k == 'soc':
        c = TIER[a[1] - 1]; rect(im, 3, 3, 12, 12, sh(c, .55)); rect(im, 4, 4, 11, 11, c)
        rect(im, 6, 6, 9, 9, sh(c, .4)); px(im, [(7, 7)], sh(c, 1.5))
        for i in range(4, 12, 2): px(im, [(i, 2), (i, 13), (2, i), (13, i)], (215, 215, 200))
    elif k == 'ram':
        n = 2 + min(4, a[1] // 4 + (1 if a[1] >= 4 else 0)); rect(im, 1, 4, 14, 11, (35, 120, 70)); rect(im, 1, 4, 14, 4, (50, 150, 90))
        for i in range(min(4, n)): rect(im, 2 + i * 3, 6, 4 + i * 3, 9, (30, 30, 36))
        px(im, [(x, 12) for x in range(2, 14, 2)] + [(x, 13) for x in range(2, 14, 2)], (225, 190, 60))
    elif k == 'rom':
        c = [(110, 120, 135), (80, 140, 210), (70, 190, 120), (240, 160, 60), (170, 90, 220)][a[1] - 1]
        rect(im, 3, 2, 12, 13, sh(c, .6)); rect(im, 4, 3, 11, 12, c); rect(im, 3, 2, 4, 3, (0, 0, 0, )); im.putpixel((3, 2), (0, 0, 0, 0)); im.putpixel((4, 2), (0, 0, 0, 0))
        rect(im, 5, 5, 10, 8, (30, 30, 36)); px(im, [(x, 13) for x in range(4, 12, 2)], (225, 190, 60))
    elif k == 'batt':
        t = a[1]; c = (70, 190, 90) if t >= 4500 else (230, 200, 70) if t >= 3500 else (235, 140, 60)
        rect(im, 6, 1, 9, 2, (200, 200, 205)); rect(im, 3, 3, 12, 14, (55, 58, 66)); rect(im, 4, 4, 11, 13, (35, 37, 44))
        h = {2500: 4, 3500: 6, 4500: 8, 6000: 9}[t]; rect(im, 4, 14 - h, 11, 13, c); px(im, [(7, 6), (8, 6)], (255, 255, 255))
    elif k == 'screen':
        sz, kind = a[1], a[2]; w = 3 + sz; x0, x1 = 8 - w // 2 - 1, 8 + w // 2 + (w % 2) - 1 + 1
        x0 = 8 - (2 + sz); x1 = 7 + (2 + sz); rect(im, x0, 0, x1, 15, (25, 25, 30))
        cols = {'LCD': [(70, 120, 200), (110, 170, 230)], 'IPS': [(60, 160, 150), (120, 220, 200)], 'AMOLED': [(120, 50, 190), (240, 110, 150)]}[kind]
        for y in range(2, 14): rect(im, x0 + 1, y, x1 - 1, y, tuple(int(cols[0][i] + (cols[1][i] - cols[0][i]) * (y - 2) / 11) for i in range(3)))
        px(im, [(8, 1)], (80, 80, 90))
    elif k == 'cam':
        mp = a[1]; r = 3 if mp <= 8 else 4 if mp <= 48 else 5; rect(im, 2, 2, 13, 13, (45, 47, 55)); disc(im, 8, 8, r + 1.5, (20, 20, 24)); disc(im, 8, 8, r, (60, 70, 110)); disc(im, 8, 8, r - 2, (30, 40, 90)); px(im, [(7, 7)], (200, 225, 255))
        if mp >= 48: disc(im, 3, 3, 1, (230, 230, 120))
    elif k == 'board':
        c = TIER[a[1] + 1]; rect(im, 3, 1, 12, 14, (30, 110, 60)); rect(im, 3, 1, 12, 1, (45, 140, 80))
        rect(im, 5, 3, 9, 7, sh(c, .7)); rect(im, 6, 4, 8, 6, c); rect(im, 5, 9, 7, 10, (30, 30, 36)); rect(im, 9, 9, 11, 12, (40, 40, 48))
        px(im, [(4, 13), (6, 13), (8, 13)], (225, 190, 60)); px(im, [(10, 4), (11, 6), (10, 7)], (200, 160, 70))
    elif k == 'case':
        c, sz = a[1], a[2]; x0, x1 = 8 - (2 + sz), 7 + (2 + sz); rect(im, x0, 0, x1, 15, sh(c, .6)); rect(im, x0 + 1, 1, x1 - 1, 14, c); rect(im, x0 + 1, 1, x1 - 1, 1, sh(c, 1.2))
        rect(im, x0 + 2, 2, x0 + 4, 4, (30, 30, 34)); px(im, [(x0 + 3, 3)], (90, 110, 170)); px(im, [(8, 12), (9, 12)], sh(c, .5))
    elif k == 'modem':
        c = a[2]; rect(im, 2, 5, 13, 13, (30, 110, 60)); rect(im, 4, 7, 8, 11, (30, 30, 36)); px(im, [(5, 8), (7, 10)], c)
        for i in range(a[1]): px(im, [(10, 11 - i * 3), (11, 11 - i * 3), (12, 11 - i * 3)], c); px(im, [(11, 10 - i * 3)], c)
        px(im, [(10, 3), (10, 4), (9, 2), (11, 2)], c)
    return im
for p in P:
    im = icon(p[7]); im.save(os.path.join(A, 'textures', 'item', p[0] + '.png'))
    wj(os.path.join(A, 'models', 'item', p[0] + '.json'), {"parent": "item/generated", "textures": {"layer0": "pcmod:item/" + p[0]}})
# lang
for fn, idx in (('ru_ru.json', 1), ('en_us.json', 2)):
    path = os.path.join(A, 'lang', fn); d = json.load(open(path, encoding='utf-8'))
    for p in P: d['item.pcmod.' + p[0]] = p[idx]
    wj(path, d)
# рецепты (shapeless, только предметы мода)
for p in P:
    ing = []
    for k, n in p[6].items(): ing += [{"item": "pcmod:" + k}] * n
    assert len(ing) <= 9, p[0]
    wj(os.path.join(D, 'recipes', p[0] + '.json'), {"type": "minecraft:crafting_shapeless", "ingredients": ing, "result": {"item": "pcmod:" + p[0]}})
if '--java' in sys.argv:
    for p in P: print('        reg("%s", new PartSpec(Cat.%s, "%s").%s);' % (p[0], p[3], p[4].replace('"', '\\"'), p[5]))
print('ok', len(P), file=sys.stderr)
