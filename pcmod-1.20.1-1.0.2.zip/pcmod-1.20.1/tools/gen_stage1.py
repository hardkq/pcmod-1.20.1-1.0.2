#!/usr/bin/env python3
"""Этап 1 (телефоны): генерирует текстуры, модели, lang, рецепты, worldgen, лут материалов. Запуск: python3 tools/gen_stage1.py из корня проекта."""
import json, os, random
from PIL import Image
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'main', 'resources')
A = os.path.join(R, 'assets', 'pcmod'); D = os.path.join(R, 'data', 'pcmod')

def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f: json.dump(obj, f, ensure_ascii=False, indent=2)

# id: (ru, en)
MATS = {
 'silicon': ('Кремний', 'Silicon'), 'lithium': ('Литий', 'Lithium'),
 'copper_wire': ('Медная проволока', 'Copper Wire'), 'gold_wire': ('Золотая проволока', 'Gold Wire'),
 'plastic': ('Пластик', 'Plastic'), 'glass_panel': ('Стеклянная панель', 'Glass Panel'),
 'rare_earth': ('Редкоземельный концентрат', 'Rare Earth Concentrate'),
 'raw_silicon': ('Сырой кремний', 'Raw Silicon'), 'raw_lithium': ('Сырой литий', 'Raw Lithium'),
 'oil_shale': ('Горючий сланец', 'Oil Shale'),
 'silicon_wafer': ('Кремниевая пластина', 'Silicon Wafer'), 'memory_die': ('Кристалл памяти', 'Memory Die'),
 'lithium_cell': ('Литиевая ячейка', 'Lithium Cell'), 'pcb_blank': ('Печатная плата-заготовка', 'PCB Blank'),
 'microchip': ('Микрочип', 'Microchip'), 'microchip_adv': ('Продвинутый микрочип', 'Advanced Microchip'),
 'case_blank': ('Корпусная заготовка', 'Case Blank'), 'case_blank_premium': ('Премиальная корпусная заготовка', 'Premium Case Blank'),
 'sensor': ('Сенсор', 'Sensor'), 'lens': ('Линза', 'Lens'), 'glass_matrix': ('Стеклянная матрица', 'Glass Matrix'),
 'flex_cable': ('Шлейф', 'Flex Cable'), 'antenna_coil': ('Антенная катушка', 'Antenna Coil'),
}
ORES = {  # id: (ru, en, base rgb, speck rgb, hardness, tool tag, drop item, min, max, xp)
 'silicon_ore': ('Кремниевая руда', 'Silicon Ore', (125,125,130), (70,75,100), 3.0, 'stone', 'raw_silicon', 1, 2, 2),
 'lithium_ore': ('Литиевая руда', 'Lithium Ore', (125,125,130), (225,225,235), 3.5, 'iron', 'raw_lithium', 1, 2, 3),
 'rare_earth_ore': ('Руда редкоземельных металлов', 'Rare Earth Ore', (125,125,130), (190,70,200), 4.5, 'iron', 'rare_earth', 1, 1, 4),
 'oil_shale_ore': ('Залежь горючего сланца', 'Oil Shale Deposit', (70,70,72), (30,30,32), 3.0, 'stone', 'oil_shale', 1, 3, 1),
}
# worldgen: id -> (size, count, ymin, ymax)
GEN = {'silicon_ore': (9, 14, -20, 80), 'lithium_ore': (6, 7, -40, 40), 'rare_earth_ore': (4, 2, -60, 0), 'oil_shale_ore': (12, 9, 0, 64)}

# ---------- текстуры ----------
def img(): return Image.new('RGBA', (16, 16), (0, 0, 0, 0))
def px(im, pts, c):
    for x, y in pts:
        if 0 <= x < 16 and 0 <= y < 16: im.putpixel((x, y), c + (255,))
def rect(im, x0, y0, x1, y1, c):
    px(im, [(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)], c)
def shade(c, k): return tuple(max(0, min(255, int(v * k))) for v in c)
def frame(im, x0, y0, x1, y1, c):
    rect(im, x0, y0, x1, y1, shade(c, .6)); rect(im, x0 + 1, y0 + 1, x1 - 1, y1 - 1, c)

def t_silicon(im): 
    for i, (x, y, w, h) in enumerate([(3,7,6,5),(6,4,6,6),(2,10,5,3)]): rect(im, x, y, x+w, y+h, (92+i*12, 98+i*12, 125+i*10))
    px(im, [(7,5),(8,5),(4,8)], (170,180,210))
def t_lithium(im):
    rect(im, 3, 4, 12, 12, (205,208,220)); rect(im, 3, 4, 12, 5, (235,238,245)); rect(im, 3, 12, 12, 12, (150,153,170)); px(im, [(6,8),(9,7),(8,10)], (250,160,170))
def t_wire(im, c):
    for i in range(3):
        for a in range(0, 360, 20):
            import math; x = int(8 + (3+i*1.5) * math.cos(math.radians(a))); y = int(8 + (3+i*1.5) * math.sin(math.radians(a)))
            px(im, [(x, y)], shade(c, 1.15 if (a//20) % 2 else .85))
    px(im, [(8,8)], shade(c, .6))
def t_plastic(im): rect(im, 2, 5, 13, 11, (238,238,232)); rect(im, 2, 5, 13, 6, (255,255,250)); rect(im, 2, 11, 13, 11, (185,185,180)); px(im, [(5,8),(10,8)], (205,205,200))
def t_glass(im):
    frame(im, 2, 2, 13, 13, (150,205,225)); px(im, [(4,4),(5,5),(6,6),(10,4),(11,5)], (235,250,255))
def t_rare(im):
    rect(im, 4, 6, 11, 12, (140,60,160)); rect(im, 5, 4, 10, 6, (175,90,200)); px(im, [(6,8),(9,10),(7,11),(5,7)], (235,170,250)); px(im, [(8,5)], (255,220,255))
def t_rawsi(im): rect(im, 3, 5, 12, 12, (88,92,112)); rect(im, 5, 3, 10, 5, (110,115,138)); px(im, [(5,8),(9,9),(7,11)], (60,62,80)); px(im, [(6,6),(10,7)], (150,158,185))
def t_rawli(im): rect(im, 3, 5, 12, 12, (150,150,160)); rect(im, 5, 3, 10, 5, (175,175,188)); px(im, [(5,8),(9,9),(7,11)], (230,130,150)); px(im, [(6,6),(10,7)], (235,235,245))
def t_shale(im): rect(im, 3, 5, 12, 12, (50,50,54)); rect(im, 5, 3, 10, 5, (68,68,72)); px(im, [(5,8),(9,9),(7,11)], (25,25,28)); px(im, [(6,6),(10,7)], (110,100,60))
def t_wafer(im):
    import math
    for y in range(16):
        for x in range(16):
            if (x-7.5)**2 + (y-7.5)**2 <= 30: im.putpixel((x, y), (120+(x*3)%25, 130+(y*3)%20, 170, 255))
    px(im, [(5,5),(6,5),(5,6)], (210,220,250))
def t_memdie(im):
    rect(im, 3, 3, 12, 12, (40,110,70)); rect(im, 5, 5, 10, 10, (30,30,34))
    for i in range(4, 12, 2): px(im, [(i,2),(i,13),(2,i),(13,i)], (225,190,60))
def t_cell(im):
    rect(im, 4, 3, 11, 13, (60,160,90)); rect(im, 4, 3, 11, 4, (200,200,205)); rect(im, 7, 1, 8, 2, (225,190,60)); rect(im, 5, 6, 10, 6, (230,240,230)); px(im, [(7,9),(8,9),(7,10),(8,10)], (255,245,120))
def t_pcb(im):
    rect(im, 2, 3, 13, 12, (30,120,60)); px(im, [(x,5) for x in range(3,9)]+[(8,y) for y in range(5,10)]+[(x,10) for x in range(8,13)], (200,160,70)); px(im, [(4,8),(11,6)], (225,225,200))
def t_chip(im, c, pin):
    rect(im, 3, 3, 12, 12, c); rect(im, 4, 4, 11, 11, shade(c, 1.25)); rect(im, 6, 6, 9, 9, shade(c, .5))
    for i in range(4, 12, 2): px(im, [(i,2),(i,13),(2,i),(13,i)], pin)
def t_case(im, c, edge): frame(im, 2, 1, 13, 14, c); rect(im, 3, 2, 12, 2, edge); px(im, [(7,12),(8,12)], shade(c, .5))
def t_sensor(im):
    rect(im, 3, 3, 12, 12, (50,52,60)); rect(im, 5, 5, 10, 10, (20,20,26)); rect(im, 6, 6, 9, 9, (40,80,170)); px(im, [(7,7)], (170,210,255)); px(im, [(3,3)], (200,60,60))
def t_lens(im):
    import math
    for y in range(16):
        for x in range(16):
            d = (x-7.5)**2 + (y-7.5)**2
            if d <= 30: im.putpixel((x, y), (60,70,110,255) if d > 20 else (110,150,210,255))
    px(im, [(5,5),(6,5),(5,6)], (240,250,255))
def t_matrix(im):
    frame(im, 1, 2, 14, 13, (30,35,50))
    for y in range(4, 12, 2):
        for x in range(3, 13, 2): px(im, [(x,y)], [(220,60,60),(60,200,90),(70,110,230)][(x//2+y//2) % 3])
def t_flex(im):
    rect(im, 1, 6, 14, 9, (205,130,40)); rect(im, 1, 7, 14, 8, (225,160,60)); rect(im, 1, 5, 3, 10, (60,60,66)); rect(im, 12, 5, 14, 10, (60,60,66)); px(im, [(5,7),(8,8),(10,7)], (150,90,25))
def t_coil(im):
    c = (205,125,60)
    for y in range(3, 13): px(im, [(4,y),(11,y)], c)
    for x in range(4, 12): px(im, [(x,3),(x,12)] if x % 2 else [(x,5),(x,10)], c)
    px(im, [(7,7),(8,8)], (235,200,80))
ICONS = {
 'silicon': t_silicon, 'lithium': t_lithium, 'copper_wire': lambda i: t_wire(i, (205,125,60)), 'gold_wire': lambda i: t_wire(i, (240,200,50)),
 'plastic': t_plastic, 'glass_panel': t_glass, 'rare_earth': t_rare, 'raw_silicon': t_rawsi, 'raw_lithium': t_rawli, 'oil_shale': t_shale,
 'silicon_wafer': t_wafer, 'memory_die': t_memdie, 'lithium_cell': t_cell, 'pcb_blank': t_pcb,
 'microchip': lambda i: t_chip(i, (60,62,72), (190,190,195)), 'microchip_adv': lambda i: t_chip(i, (95,50,125), (240,200,60)),
 'case_blank': lambda i: t_case(i, (120,125,135), (160,165,175)), 'case_blank_premium': lambda i: t_case(i, (190,150,60), (245,215,110)),
 'sensor': t_sensor, 'lens': t_lens, 'glass_matrix': t_matrix, 'flex_cable': t_flex, 'antenna_coil': t_coil,
}
for k, f in ICONS.items():
    im = img(); f(im)
    os.makedirs(os.path.join(A, 'textures', 'item'), exist_ok=True); im.save(os.path.join(A, 'textures', 'item', k + '.png'))
    wj(os.path.join(A, 'models', 'item', k + '.json'), {"parent": "item/generated", "textures": {"layer0": "pcmod:item/" + k}})

for k, o in ORES.items():
    rnd = random.Random(k); im = Image.new('RGBA', (16, 16))
    for y in range(16):
        for x in range(16):
            j = rnd.randint(-10, 10); im.putpixel((x, y), tuple(max(0, min(255, v + j)) for v in o[2]) + (255,))
    for _ in range(5):
        cx, cy = rnd.randint(2, 12), rnd.randint(2, 12)
        for dx, dy in [(0,0),(1,0),(0,1),(1,1)] + ([(2,1)] if rnd.random() < .5 else []):
            im.putpixel((cx+dx, cy+dy), o[3] + (255,))
    im.save(os.path.join(A, 'textures', 'block', k + '.png'))
    wj(os.path.join(A, 'models', 'block', k + '.json'), {"parent": "minecraft:block/cube_all", "textures": {"all": "pcmod:block/" + k}})
    wj(os.path.join(A, 'models', 'item', k + '.json'), {"parent": "pcmod:block/" + k})
    wj(os.path.join(A, 'blockstates', k + '.json'), {"variants": {"": {"model": "pcmod:block/" + k}}})

# ---------- lang ----------
for fn, idx in (('ru_ru.json', 0), ('en_us.json', 1)):
    p = os.path.join(A, 'lang', fn); d = json.load(open(p, encoding='utf-8'))
    for k, v in MATS.items(): d['item.pcmod.' + k] = v[idx]
    for k, v in ORES.items(): d['block.pcmod.' + k] = v[idx]
    wj(p, d)

# ---------- рецепты ----------
def it(i): return {"item": "pcmod:" + i}
def shaped(name, pat, key, res, n=1):
    wj(os.path.join(D, 'recipes', name + '.json'), {"type": "minecraft:crafting_shaped", "pattern": pat, "key": {k: it(v) for k, v in key.items()}, "result": {"item": "pcmod:" + res, "count": n}})
def shapeless(name, ings, res, n=1):
    wj(os.path.join(D, 'recipes', name + '.json'), {"type": "minecraft:crafting_shapeless", "ingredients": [it(i) for i in ings], "result": {"item": "pcmod:" + res, "count": n}})
def smelt(name, src, res, xp, t=200):
    ing = {"item": src if ':' in src else "pcmod:" + src}
    wj(os.path.join(D, 'recipes', name + '.json'), {"type": "minecraft:smelting", "ingredient": ing, "result": "pcmod:" + res, "experience": xp, "cookingtime": t})
    wj(os.path.join(D, 'recipes', name + '_blasting.json'), {"type": "minecraft:blasting", "ingredient": ing, "result": "pcmod:" + res, "experience": xp, "cookingtime": t // 2})

# сырьё: плавка (ванильная печь) и проволока из слитков
smelt('silicon_from_raw', 'raw_silicon', 'silicon', 0.7)
smelt('lithium_from_raw', 'raw_lithium', 'lithium', 0.9)
smelt('plastic_from_shale', 'oil_shale', 'plastic', 0.3, 160)
smelt('glass_panel_from_sand', 'minecraft:sand', 'glass_panel', 0.1, 120)
wj(os.path.join(D, 'recipes', 'copper_wire.json'), {"type": "minecraft:crafting_shapeless", "ingredients": [{"item": "minecraft:copper_ingot"}], "result": {"item": "pcmod:copper_wire", "count": 6}})
wj(os.path.join(D, 'recipes', 'gold_wire.json'), {"type": "minecraft:crafting_shapeless", "ingredients": [{"item": "minecraft:gold_ingot"}], "result": {"item": "pcmod:gold_wire", "count": 6}})
# полуфабрикаты: только предметы мода
shapeless('silicon_wafer', ['silicon', 'silicon', 'plastic'], 'silicon_wafer', 2)
shapeless('memory_die', ['silicon_wafer', 'silicon_wafer', 'gold_wire'], 'memory_die')
shapeless('lithium_cell', ['lithium', 'lithium', 'copper_wire', 'plastic'], 'lithium_cell')
shapeless('pcb_blank', ['plastic', 'plastic', 'copper_wire', 'copper_wire'], 'pcb_blank', 2)
shapeless('microchip', ['silicon_wafer', 'gold_wire', 'gold_wire', 'plastic'], 'microchip')
shapeless('microchip_adv', ['microchip', 'silicon_wafer', 'silicon_wafer', 'rare_earth', 'rare_earth', 'gold_wire'], 'microchip_adv')
shaped('case_blank', ['ppp', 'p p'], {'p': 'plastic'}, 'case_blank')
shapeless('case_blank_premium', ['case_blank', 'glass_panel', 'glass_panel', 'rare_earth', 'copper_wire', 'copper_wire'], 'case_blank_premium')
shapeless('sensor', ['silicon_wafer', 'glass_panel', 'copper_wire', 'plastic'], 'sensor')
shapeless('lens', ['glass_panel', 'glass_panel', 'plastic'], 'lens')
shaped('glass_matrix', ['ggg', 'cpc'], {'g': 'glass_panel', 'c': 'copper_wire', 'p': 'plastic'}, 'glass_matrix')
shapeless('flex_cable', ['copper_wire', 'copper_wire', 'copper_wire', 'plastic'], 'flex_cable', 2)
shapeless('antenna_coil', ['copper_wire', 'copper_wire', 'copper_wire', 'copper_wire', 'gold_wire'], 'antenna_coil')

# ---------- лут, теги, worldgen ----------
for k, o in ORES.items():
    drop = o[6]
    wj(os.path.join(D, 'loot_tables', 'blocks', k + '.json'), {"type": "minecraft:block", "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{
        "type": "minecraft:alternatives", "children": [
            {"type": "minecraft:item", "name": "pcmod:" + k, "conditions": [{"condition": "minecraft:match_tool", "predicate": {"enchantments": [{"enchantment": "minecraft:silk_touch", "levels": {"min": 1}}]}}]},
            {"type": "minecraft:item", "name": "pcmod:" + drop, "functions": [
                {"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": o[7], "max": o[8]}},
                {"function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops"},
                {"function": "minecraft:explosion_decay"}]}]}]}]})
    size, cnt, y0, y1 = GEN[k]
    tg = lambda tag: {"state": {"Name": "pcmod:" + k}, "target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:" + tag}}
    wj(os.path.join(D, 'worldgen', 'configured_feature', 'ore_' + k + '.json'), {"type": "minecraft:ore", "config": {"discard_chance_on_air_exposure": 0.0, "size": size, "targets": [tg('stone_ore_replaceables'), tg('deepslate_ore_replaceables')]}})
    wj(os.path.join(D, 'worldgen', 'placed_feature', 'ore_' + k + '.json'), {"feature": "pcmod:ore_" + k, "placement": [
        {"type": "minecraft:count", "count": cnt}, {"type": "minecraft:in_square"},
        {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": y0}, "max_inclusive": {"absolute": y1}}},
        {"type": "minecraft:biome"}]})
    wj(os.path.join(D, 'forge', 'biome_modifier', 'ore_' + k + '.json'), {"type": "forge:add_features", "biomes": "#minecraft:is_overworld", "features": "pcmod:ore_" + k, "step": "underground_ores"})

mt = os.path.join(R, 'data', 'minecraft', 'tags', 'blocks', 'mineable', 'pickaxe.json'); d = json.load(open(mt))
for k in ORES:
    if 'pcmod:' + k not in d['values']: d['values'].append('pcmod:' + k)
wj(mt, d)
for lvl in ('stone', 'iron'):
    wj(os.path.join(R, 'data', 'minecraft', 'tags', 'blocks', 'needs_%s_tool.json' % lvl), {"replace": False, "values": ["pcmod:" + k for k, o in ORES.items() if o[5] == lvl]})
print('ok', len(MATS), 'items', len(ORES), 'ores')
