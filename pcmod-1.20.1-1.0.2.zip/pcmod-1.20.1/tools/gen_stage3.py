#!/usr/bin/env python3
"""Этап 3 (телефоны): стол сборки - текстуры, 3D-модель, blockstate, лут, рецепт, lang; предмет phone (текстура/модель/lang)."""
import json, os, random
from PIL import Image
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'main', 'resources')
A = os.path.join(R, 'assets', 'pcmod'); D = os.path.join(R, 'data', 'pcmod')
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f: json.dump(obj, f, ensure_ascii=False, indent=2)
def rect(im, x0, y0, x1, y1, c):
    for x in range(x0, x1 + 1):
        for y in range(y0, y1 + 1): im.putpixel((x, y), tuple(c) + (255,))
def noise(im, base, rnd, j=6):
    for y in range(16):
        for x in range(16):
            v = rnd.randint(-j, j); im.putpixel((x, y), tuple(max(0, min(255, b + v)) for b in base) + (255,))
rnd = random.Random(33); T = os.path.join(A, 'textures', 'block')
# верх: зелёный коврик с сеткой и рамкой
im = Image.new('RGBA', (16, 16)); noise(im, (40, 110, 70), rnd, 4)
rect(im, 0, 0, 15, 0, (90, 95, 105)); rect(im, 0, 15, 15, 15, (90, 95, 105)); rect(im, 0, 0, 0, 15, (90, 95, 105)); rect(im, 15, 0, 15, 15, (90, 95, 105))
for i in (4, 8, 12):
    for k in range(1, 15): im.putpixel((i, k), (70, 150, 100, 255)); im.putpixel((k, i), (70, 150, 100, 255))
im.putpixel((8, 8), (240, 240, 240, 255)); im.save(os.path.join(T, 'phone_table_top.png'))
# бок: металл с заклёпками
im = Image.new('RGBA', (16, 16)); noise(im, (110, 115, 125), rnd, 5)
rect(im, 0, 0, 15, 0, (150, 155, 165)); rect(im, 0, 15, 15, 15, (70, 74, 82))
for p in ((2, 2), (13, 2), (2, 13), (13, 13)): im.putpixel(p, (60, 64, 72, 255))
im.save(os.path.join(T, 'phone_table_side.png'))
# ящик: фронт с ручкой и шильдиком
im = Image.new('RGBA', (16, 16)); noise(im, (95, 100, 112), rnd, 4)
rect(im, 0, 0, 15, 0, (150, 155, 165)); rect(im, 0, 15, 15, 15, (60, 64, 72)); rect(im, 5, 6, 10, 8, (220, 190, 70)); rect(im, 6, 7, 9, 7, (150, 120, 30))
rect(im, 2, 2, 5, 3, (60, 150, 210)); im.save(os.path.join(T, 'phone_table_drawer.png'))

def box(f, t, tex, front=None):
    faces = {s: {"texture": "#" + tex} for s in ("north", "east", "west", "up", "down")}
    faces["south"] = {"texture": "#" + (front or tex)}
    if tex == 'top':
        faces = {s: {"texture": "#side"} for s in ("north", "east", "south", "west", "down")}; faces["up"] = {"texture": "#top"}
    return {"from": f, "to": t, "faces": faces}
els = [box([0, 10, 0], [16, 14, 16], 'top'),                         # столешница
       box([1, 0, 1], [3, 10, 3], 'side'), box([13, 0, 1], [15, 10, 3], 'side'),   # ножки
       box([1, 0, 13], [3, 10, 13 + 2], 'side'), box([13, 0, 13], [15, 10, 15], 'side'),
       box([3, 6, 2], [13, 10, 14], 'side', 'drawer'),                  # ящик с лицевой панелью (юг)
       box([2, 14, 2], [6, 15, 6], 'side'),                              # лоток для микросхем
       box([9, 14, 3], [13, 14.8, 11], 'side'),                          # заготовка телефона
       box([2, 14, 11], [4, 17, 13], 'side')]                            # лампа-стойка
els[6]['faces']['up'] = {"texture": "#top"}; els[7]['faces']['up'] = {"texture": "#drawer"}
wj(os.path.join(A, 'models', 'block', 'phone_table.json'), {"parent": "block/block", "textures": {
    "top": "pcmod:block/phone_table_top", "side": "pcmod:block/phone_table_side", "drawer": "pcmod:block/phone_table_drawer", "particle": "pcmod:block/phone_table_side"}, "elements": els})
wj(os.path.join(A, 'models', 'item', 'phone_table.json'), {"parent": "pcmod:block/phone_table"})
wj(os.path.join(A, 'blockstates', 'phone_table.json'), {"variants": {
    "facing=south": {"model": "pcmod:block/phone_table"}, "facing=west": {"model": "pcmod:block/phone_table", "y": 90},
    "facing=north": {"model": "pcmod:block/phone_table", "y": 180}, "facing=east": {"model": "pcmod:block/phone_table", "y": 270}}})
wj(os.path.join(D, 'loot_tables', 'blocks', 'phone_table.json'), {"type": "minecraft:block", "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{"type": "minecraft:item", "name": "pcmod:phone_table"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
mt = os.path.join(R, 'data', 'minecraft', 'tags', 'blocks', 'mineable', 'pickaxe.json'); d = json.load(open(mt))
if 'pcmod:phone_table' not in d['values']: d['values'].append('pcmod:phone_table')
wj(mt, d)
# рецепт: только предметы мода
wj(os.path.join(D, 'recipes', 'phone_table.json'), {"type": "minecraft:crafting_shaped", "pattern": ["gmg", "pbp", "ckc"],
    "key": {"g": {"item": "pcmod:glass_panel"}, "m": {"item": "pcmod:microchip"}, "p": {"item": "pcmod:plastic"}, "b": {"item": "pcmod:pcb_blank"},
            "c": {"item": "pcmod:copper_wire"}, "k": {"item": "pcmod:case_blank"}}, "result": {"item": "pcmod:phone_table"}})
# предмет «Телефон» (иконки по моделям - этап 4)
im = Image.new('RGBA', (16, 16))
for y in range(16):
    for x in range(16): im.putpixel((x, y), (0, 0, 0, 0))
rect(im, 4, 0, 11, 15, (25, 25, 30)); rect(im, 5, 2, 10, 13, (60, 130, 220)); rect(im, 5, 2, 10, 4, (110, 180, 240)); rect(im, 7, 14, 8, 14, (90, 90, 100)); rect(im, 7, 1, 8, 1, (80, 80, 90))
im.save(os.path.join(A, 'textures', 'item', 'phone.png'))
wj(os.path.join(A, 'models', 'item', 'phone.json'), {"parent": "item/generated", "textures": {"layer0": "pcmod:item/phone"}})

L = {
 'block.pcmod.phone_table': ('Стол сборки телефонов', 'Phone Assembly Table'),
 'item.pcmod.phone': ('Телефон', 'Phone'),
 'gui.pcmod.phone.slot.soc': ('SoC', 'SoC'), 'gui.pcmod.phone.slot.ram': ('ОЗУ', 'RAM'), 'gui.pcmod.phone.slot.rom': ('Память', 'Storage'),
 'gui.pcmod.phone.slot.battery': ('Акб', 'Batt'), 'gui.pcmod.phone.slot.screen': ('Экран', 'Screen'), 'gui.pcmod.phone.slot.camera': ('Камера', 'Camera'),
 'gui.pcmod.phone.slot.board': ('Плата', 'Board'), 'gui.pcmod.phone.slot.case': ('Корпус', 'Case'), 'gui.pcmod.phone.slot.modem': ('Модем', 'Modem'),
 'gui.pcmod.phone.slot.out': ('Готово', 'Output'),
 'gui.pcmod.phone.missing': ('Не хватает: %s', 'Missing: %s'),
 'gui.pcmod.phone.err.platform': ('SoC не подходит к плате (платформа)', 'SoC does not fit the board (platform)'),
 'gui.pcmod.phone.err.ram_type': ('Тип ОЗУ не подходит к плате', 'RAM type does not match the board'),
 'gui.pcmod.phone.err.ram_mix': ('Модули ОЗУ разных типов', 'RAM modules differ in type'),
 'gui.pcmod.phone.err.ram_slots': ('На плате только один слот ОЗУ', 'The board has only one RAM slot'),
 'gui.pcmod.phone.err.screen_size': ('Экран не того размера для корпуса', 'Screen size does not match the case'),
 'gui.pcmod.phone.err.board_size': ('Плата не влезает в корпус', 'The board does not fit the case'),
 'gui.pcmod.phone.err.batt_cap': ('Аккумулятор слишком ёмкий для корпуса', 'Battery capacity is too big for the case'),
 'gui.pcmod.phone.err.batt_size': ('Аккумулятор не влезает в корпус', 'The battery does not fit the case'),
 'gui.pcmod.phone.err.modem_net': ('Плата не поддерживает этот модем', 'The board does not support this modem'),
 'gui.pcmod.phone.ok': ('Детали совместимы', 'Parts are compatible'),
 'gui.pcmod.phone.assemble': ('Собрать', 'Assemble'),
 'gui.pcmod.phone.done': ('Телефон собран', 'Phone assembled'),
 'gui.pcmod.phone.busy': ('Заберите готовый телефон', 'Take the finished phone first'),
 'gui.pcmod.phone.inventory': ('Инвентарь', 'Inventory'),
 'tooltip.pcmod.phone.battery': ('Заряд: %s%%', 'Charge: %s%%'),
 'tooltip.pcmod.phone.model': ('Корпус: %s', 'Case: %s'),
}
for fn, i in (('ru_ru.json', 0), ('en_us.json', 1)):
    p = os.path.join(A, 'lang', fn); d = json.load(open(p, encoding='utf-8'))
    for k, v in L.items(): d[k] = v[i]
    wj(p, d)
print('ok')
