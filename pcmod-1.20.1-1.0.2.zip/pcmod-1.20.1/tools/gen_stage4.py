#!/usr/bin/env python3
"""Этап 4 (телефоны): модели телефона в руке (5 корпусов x экран вкл/выкл), зарядная станция (блок, 3D-модель, blockstate, лут, рецепт),
USB-кабель (текстура, модель, рецепт), lang ru/en."""
import json, os, random
from PIL import Image
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'main', 'resources')
A = os.path.join(R, 'assets', 'pcmod'); D = os.path.join(R, 'data', 'pcmod')
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f: json.dump(obj, f, ensure_ascii=False, indent=2)
def rect(im, x0, y0, x1, y1, c):
    for x in range(x0, x1 + 1):
        for y in range(y0, y1 + 1): im.putpixel((x, y), tuple(c) + ((255,) if len(c) == 3 else ()))
def noise(im, base, rnd, j=5):
    for y in range(16):
        for x in range(16):
            v = rnd.randint(-j, j); im.putpixel((x, y), tuple(max(0, min(255, b + v)) for b in base) + (255,))
TI = os.path.join(A, 'textures', 'item'); TB = os.path.join(A, 'textures', 'block')
os.makedirs(TI, exist_ok=True); os.makedirs(TB, exist_ok=True)
rnd = random.Random(44)

# ---------- телефон в руке ----------
CASES = [('mini', (230, 120, 150)), ('classic', (70, 80, 95)), ('slim', (200, 205, 215)), ('flagship', (50, 120, 200)), ('max', (30, 30, 36))]
def front(color, on):
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    rect(im, 5, 1, 10, 14, color)                                            # корпус 6x14 (совпадает с гранью модели)
    scr = [(30, 60, 120), (12, 20, 48)] if on else [(10, 10, 12), (10, 10, 12)]
    for y in range(2, 14):                                                   # экран 4x12
        t = (y - 2) / 11.0; c = tuple(int(scr[0][i] + (scr[1][i] - scr[0][i]) * t) for i in range(3))
        for x in range(6, 10): im.putpixel((x, y), c + (255,))
    im.putpixel((7, 2), (240, 245, 255, 255) if on else (40, 40, 44, 255))
    if on:
        for x in range(6, 10): im.putpixel((x, 13), (200, 210, 230, 255))
        im.putpixel((8, 6), (130, 200, 255, 255)); im.putpixel((7, 6), (130, 200, 255, 255))
    return im
def back(color):
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0)); rect(im, 5, 1, 10, 14, color)
    rect(im, 6, 2, 8, 4, tuple(max(0, c - 60) for c in color)); im.putpixel((7, 3), (20, 20, 24, 255)); return im
def side(color):
    im = Image.new('RGBA', (16, 16), tuple(max(0, c - 25) for c in color) + (255,)); return im
for name, col in CASES:
    front(col, True).save(os.path.join(TI, 'phone_%s_on.png' % name)); front(col, False).save(os.path.join(TI, 'phone_%s_off.png' % name))
    back(col).save(os.path.join(TI, 'phone_%s_back.png' % name)); side(col).save(os.path.join(TI, 'phone_%s_side.png' % name))
DISPLAY = {
    "gui": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
    "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
    "thirdperson_lefthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
    "firstperson_righthand": {"rotation": [0, 180, 0], "translation": [1.5, 1.5, 0], "scale": [0.68, 0.68, 0.68]},
    "firstperson_lefthand": {"rotation": [0, 180, 0], "translation": [1.5, 1.5, 0], "scale": [0.68, 0.68, 0.68]}}
def phone_model(name, on):
    face = lambda t: {"texture": "#" + t}
    return {"textures": {"front": "pcmod:item/phone_%s_%s" % (name, 'on' if on else 'off'), "back": "pcmod:item/phone_%s_back" % name,
                         "side": "pcmod:item/phone_%s_side" % name, "particle": "pcmod:item/phone_%s_side" % name},
            "elements": [{"from": [5, 1, 7.2], "to": [11, 15, 8.8], "faces": {
                "south": face("front"), "north": face("back"), "east": face("side"), "west": face("side"), "up": face("side"), "down": face("side")}}],
            "display": DISPLAY}
for name, col in CASES:
    wj(os.path.join(A, 'models', 'item', 'phone_%s_on.json' % name), phone_model(name, True))
    wj(os.path.join(A, 'models', 'item', 'phone_%s_off.json' % name), phone_model(name, False))
ov = []
for i, (name, col) in enumerate(CASES):
    ov.append({"predicate": {"pcmod:case": i + 1}, "model": "pcmod:item/phone_%s_off" % name})
    ov.append({"predicate": {"pcmod:case": i + 1, "pcmod:screen": 1}, "model": "pcmod:item/phone_%s_on" % name})
m = phone_model('classic', False); m["overrides"] = ov
wj(os.path.join(A, 'models', 'item', 'phone.json'), m)

# ---------- USB-кабель ----------
im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
for i in range(10):                                                         # провод по диагонали
    im.putpixel((3 + i, 12 - i), (30, 30, 36, 255)); im.putpixel((4 + i, 12 - i), (60, 62, 72, 255))
rect(im, 1, 11, 4, 14, (170, 175, 185)); rect(im, 2, 12, 3, 13, (60, 64, 72))     # штекер
rect(im, 11, 1, 14, 4, (60, 150, 210)); rect(im, 12, 2, 13, 3, (20, 60, 100))     # USB-A
im.save(os.path.join(TI, 'usb_cable.png'))
wj(os.path.join(A, 'models', 'item', 'usb_cable.json'), {"parent": "item/generated", "textures": {"layer0": "pcmod:item/usb_cable"}})

# ---------- зарядная станция ----------
im = Image.new('RGBA', (16, 16)); noise(im, (52, 56, 66), rnd, 4)
rect(im, 0, 0, 15, 0, (92, 98, 110)); rect(im, 0, 15, 15, 15, (30, 32, 38)); im.save(os.path.join(TB, 'phone_charger_base.png'))
im = Image.new('RGBA', (16, 16)); noise(im, (86, 92, 104), rnd, 4)
rect(im, 6, 2, 9, 3, (30, 32, 38)); im.putpixel((7, 2), (200, 205, 215, 255)); im.save(os.path.join(TB, 'phone_charger_stand.png'))
im = Image.new('RGBA', (16, 16)); noise(im, (20, 24, 30), rnd, 3)
rect(im, 3, 6, 12, 10, (14, 16, 20)); rect(im, 5, 7, 9, 9, (60, 220, 120)); rect(im, 10, 7, 11, 9, (60, 220, 120)); im.save(os.path.join(TB, 'phone_charger_screen.png'))
im = Image.new('RGBA', (16, 16)); noise(im, (30, 130, 70), rnd, 3); im.save(os.path.join(TB, 'phone_charger_led.png'))
def box(f, t, tex): return {"from": f, "to": t, "faces": {s: {"texture": "#" + tex} for s in ("north", "south", "east", "west", "up", "down")}}
base = [box([2, 0, 2], [14, 2, 14], 'base'),                                # плита
        box([3, 2, 3], [13, 12, 5], 'stand'),                               # спинка
        box([3, 2, 6.5], [13, 4, 9], 'base'),                               # упор для телефона
        box([11, 2, 10], [13, 3, 12], 'led')]                               # светодиод
phone = box([5, 3, 5], [11, 15, 6], 'screen'); phone["faces"]["south"] = {"texture": "#screen", "uv": [0, 0, 16, 16]}
tx = {"base": "pcmod:block/phone_charger_base", "stand": "pcmod:block/phone_charger_stand", "led": "pcmod:block/phone_charger_led",
      "screen": "pcmod:block/phone_charger_screen", "particle": "pcmod:block/phone_charger_base"}
wj(os.path.join(A, 'models', 'block', 'phone_charger.json'), {"parent": "block/block", "textures": tx, "elements": base})
wj(os.path.join(A, 'models', 'block', 'phone_charger_full.json'), {"parent": "block/block", "textures": tx, "elements": base + [phone]})
wj(os.path.join(A, 'models', 'item', 'phone_charger.json'), {"parent": "pcmod:block/phone_charger"})
bs = {}
for has in ("false", "true"):
    mdl = "pcmod:block/phone_charger" + ("_full" if has == "true" else "")
    for f, y in (("south", 0), ("west", 90), ("north", 180), ("east", 270)):
        v = {"model": mdl}
        if y: v["y"] = y
        bs["facing=%s,has_phone=%s" % (f, has)] = v
wj(os.path.join(A, 'blockstates', 'phone_charger.json'), {"variants": bs})
wj(os.path.join(D, 'loot_tables', 'blocks', 'phone_charger.json'), {"type": "minecraft:block", "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{"type": "minecraft:item", "name": "pcmod:phone_charger"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
mt = os.path.join(R, 'data', 'minecraft', 'tags', 'blocks', 'mineable', 'pickaxe.json'); d = json.load(open(mt))
if 'pcmod:phone_charger' not in d['values']: d['values'].append('pcmod:phone_charger')
wj(mt, d)

# ---------- рецепты (только предметы мода) ----------
wj(os.path.join(D, 'recipes', 'phone_charger.json'), {"type": "minecraft:crafting_shaped", "pattern": ["plp", "cbc", "ppp"],
    "key": {"p": {"item": "pcmod:plastic"}, "l": {"item": "pcmod:lithium_cell"}, "c": {"item": "pcmod:copper_wire"}, "b": {"item": "pcmod:pcb_blank"}},
    "result": {"item": "pcmod:phone_charger"}})
wj(os.path.join(D, 'recipes', 'usb_cable.json'), {"type": "minecraft:crafting_shapeless",
    "ingredients": [{"item": "pcmod:copper_wire"}, {"item": "pcmod:copper_wire"}, {"item": "pcmod:flex_cable"}, {"item": "pcmod:plastic"}],
    "result": {"item": "pcmod:usb_cable"}})

# ---------- lang ----------
RU = {"block.pcmod.phone_charger": "Зарядная станция телефонов", "item.pcmod.usb_cable": "USB-кабель",
      "gui.pcmod.phone.unassembled": "Телефон не собран", "gui.pcmod.phone.dead": "Телефон разряжен",
      "gui.pcmod.phone.power": "Питание", "gui.pcmod.phone.unplugged": "Кабель отключён",
      "gui.pcmod.phone.cable.no_phone": "Возьмите телефон в другую руку", "gui.pcmod.phone.cable.pc_off": "ПК выключен",
      "gui.pcmod.phone.cable.plugged": "Телефон подключён к ПК", "tooltip.pcmod.phone.plugged": "Подключён кабелем к ПК"}
EN = {"block.pcmod.phone_charger": "Phone Charging Dock", "item.pcmod.usb_cable": "USB Cable",
      "gui.pcmod.phone.unassembled": "The phone is not assembled", "gui.pcmod.phone.dead": "The phone is out of battery",
      "gui.pcmod.phone.power": "Power", "gui.pcmod.phone.unplugged": "Cable unplugged",
      "gui.pcmod.phone.cable.no_phone": "Hold a phone in your other hand", "gui.pcmod.phone.cable.pc_off": "The PC is off",
      "gui.pcmod.phone.cable.plugged": "Phone connected to the PC", "tooltip.pcmod.phone.plugged": "Plugged into a PC"}
for fn, add in (('ru_ru.json', RU), ('en_us.json', EN)):
    p = os.path.join(A, 'lang', fn); d = json.load(open(p, encoding='utf-8')); d.update(add); wj(p, d)
print('stage4 assets ok')
